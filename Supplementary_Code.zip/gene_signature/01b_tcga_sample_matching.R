## ===========================================================================
## gene_signature/01b_tcga_sample_matching.R
##
## Select the 380 primary colorectal tumours of TCGA-COAD/READ and match them
## to the RSEM expression matrix; writes TCGA_CRC_380_samples.RData.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

############################################################
#
# 1. tcga_RSEM_Hugo_norm_count.gz
# 2. TCGA.COAD.sampleMap_COAD_clinicalMatrix
# 3. TCGA.READ.sampleMap_READ_clinicalMatrix
#
# COAD + READ
#        ↓
# Primary Tumor
#        ↓
# sampleID
#        ↓
#        ↓
############################################################


############################################################
############################################################

setwd(DATA_ROOT)  # reads only
setwd_out <- file.path(QCSC_PROJECT_DIR, "output")

cat("\n========================================\n")
cat("TCGA CRC: sample selection start
")
cat("========================================\n\n")


############################################################
############################################################

cat("Working directory:
")
cat(getwd(), "\n\n")

cat("TCGA files in the current directory:
")

print(
  list.files(
    pattern = "TCGA|tcga",
    ignore.case = TRUE
  )
)


############################################################
############################################################

## Inputs are declared once in 00_config.R; accept a gzip file or a plain TSV.
expr_file <- F_TCGA_RSEM
if (!file.exists(expr_file) && file.exists(paste0(expr_file, ".gz"))) {
  expr_file <- paste0(expr_file, ".gz")
}

coad_file <- F_TCGA_CLIN_COAD

read_file <- F_TCGA_CLIN_READ


############################################################
############################################################

cat("\n========================================\n")
cat("Checking files
")
cat("========================================\n")

cat("Expression matrix: ", file.exists(expr_file), "\n")
cat("COAD clinical matrix: ", file.exists(coad_file), "\n")
cat("READ clinical matrix: ", file.exists(read_file), "\n")


if (!file.exists(expr_file)) {
  stop("tcga_RSEM_Hugo_norm_count.gz not found")
}

if (!file.exists(coad_file)) {
  stop("TCGA.COAD.sampleMap_COAD_clinicalMatrix not found")
}

if (!file.exists(read_file)) {
  stop("TCGA.READ.sampleMap_READ_clinicalMatrix not found")
}


############################################################
############################################################

cat("\n========================================\n")
cat("Reading the COAD clinical matrix
")
cat("========================================\n")

coad <- read.delim(
  coad_file,
  header = TRUE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

cat("COAD dimensions: 
")
print(dim(coad))

cat("
First COAD sample IDs:
")
print(head(coad$sampleID))


############################################################
############################################################

cat("\n========================================\n")
cat("Reading the READ clinical matrix
")
cat("========================================\n")

read <- read.delim(
  read_file,
  header = TRUE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

cat("READ dimensions: 
")
print(dim(read))

cat("
First READ sample IDs:
")
print(head(read$sampleID))


############################################################
############################################################

cat("\n========================================\n")
cat("Checking key fields
")
cat("========================================\n")

required_coad <- c(
  "sampleID",
  "sample_type",
  "sample_type_id"
)

required_read <- c(
  "sampleID",
  "sample_type",
  "sample_type_id"
)

cat("
Fields missing in COAD:
")
print(setdiff(required_coad, colnames(coad)))

cat("
Fields missing in READ:
")
print(setdiff(required_read, colnames(read)))


############################################################
############################################################

cat("\n========================================\n")
cat("COAD sample_type distribution
")
cat("========================================\n")

print(table(coad$sample_type, useNA = "ifany"))


cat("\n========================================\n")
cat("READ sample_type distribution
")
cat("========================================\n")

print(table(read$sample_type, useNA = "ifany"))


############################################################
############################################################

cat("\n========================================\n")
cat("Selecting Primary Tumour
")
cat("========================================\n")


coad_primary <- coad[
  !is.na(coad$sample_type) &
    coad$sample_type == "Primary Tumor",
]

read_primary <- read[
  !is.na(read$sample_type) &
    read$sample_type == "Primary Tumor",
]


cat("COAD Primary Tumour: ",
    nrow(coad_primary), "\n")

cat("READ Primary Tumour: ",
    nrow(read_primary), "\n")


############################################################
############################################################

cat("\n========================================\n")
cat("sample_type_id for Primary Tumour
")
cat("========================================\n")

cat("
COAD:
")
print(table(
  coad_primary$sample_type_id,
  useNA = "ifany"
))

cat("
READ:
")
print(table(
  read_primary$sample_type_id,
  useNA = "ifany"
))


############################################################
############################################################

coad_ids <- unique(
  coad_primary$sampleID[
    !is.na(coad_primary$sampleID)
  ]
)

read_ids <- unique(
  read_primary$sampleID[
    !is.na(read_primary$sampleID)
  ]
)


cat("\n========================================\n")
cat("Number of Primary Tumour sample IDs
")
cat("========================================\n")

cat("COAD: ", length(coad_ids), "\n")
cat("READ: ", length(read_ids), "\n")


############################################################
############################################################

samples_keep <- unique(
  c(coad_ids, read_ids)
)

cat("\n========================================\n")
cat("COAD + READ\n")
cat("========================================\n")

cat("COAD: ", length(coad_ids), "\n")
cat("READ: ", length(read_ids), "\n")
cat("After merging and de-duplication: ", length(samples_keep), "\n")


############################################################
############################################################

cat("\n========================================\n")
cat("Reading the TCGA RSEM expression matrix
")
cat("========================================\n")

## The matrix may be distributed gzip-compressed or as a plain TSV; open it
## accordingly instead of always assuming gzip.
expr_con <- if (grepl("\\.gz$", expr_file, ignore.case = TRUE)) {
  gzfile(expr_file)
} else {
  file(expr_file, "rt")
}

expr_raw <- read.delim(
  expr_con,
  header = TRUE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

cat("Raw matrix dimensions:
")
print(dim(expr_raw))


############################################################
############################################################

cat("\n========================================\n")
cat("Checking the expression matrix
")
cat("========================================\n")

cat("
First five column names:
")
print(colnames(expr_raw)[1:5])

cat("
First column of the first five rows:
")
print(head(expr_raw[[1]]))


############################################################
############################################################

gene_id <- expr_raw[[1]]

expr <- as.data.frame(
  expr_raw[, -1, drop = FALSE],
  check.names = FALSE
)

rownames(expr) <- gene_id


############################################################
############################################################

cat("
Final expression matrix dimensions: 
")
print(dim(expr))


############################################################
############################################################

cat("\n========================================\n")
cat("Matching sample IDs
")
cat("========================================\n")

samples_final <- samples_keep[
  samples_keep %in% colnames(expr)
]

cat("Samples selected from the clinical matrix: ",
    length(samples_keep), "\n")

cat("Matched in the expression matrix: ",
    length(samples_final), "\n")

cat("Unmatched: ",
    length(setdiff(samples_keep, colnames(expr))),
    "\n")


############################################################
############################################################

missing_samples <- setdiff(
  samples_keep,
  colnames(expr)
)

if (length(missing_samples) > 0) {
  
  cat("\n========================================\n")
  cat("Samples without a match in the expression matrix
")
  cat("========================================\n")
  
  print(missing_samples)
  
} else {
  
  cat("
All samples from the clinical matrix were matched.
")
  
}


############################################################
############################################################

expr_crc <- expr[
  ,
  samples_final,
  drop = FALSE
]


############################################################
############################################################

cat("\n========================================\n")
cat("Final CRC expression matrix
")
cat("========================================\n")

print(dim(expr_crc))


############################################################
############################################################

cat("\n========================================\n")
cat("Checking for duplicated IDs
")
cat("========================================\n")

cat("Duplicated COAD IDs: ",
    sum(duplicated(coad_ids)), "\n")

cat("Duplicated READ IDs: ",
    sum(duplicated(read_ids)), "\n")

cat("Duplicated IDs in the final sample set: ",
    sum(duplicated(samples_final)), "\n")


############################################################
############################################################

final_coad <- intersect(
  samples_final,
  coad_ids
)

final_read <- intersect(
  samples_final,
  read_ids
)


cat("\n========================================\n")
cat("Composition of the final CRC sample set
")
cat("========================================\n")

cat("COAD: ",
    length(final_coad), "\n")

cat("READ: ",
    length(final_read), "\n")

cat("COAD + READ: ",
    length(unique(c(final_coad, final_read))),
    "\n")


############################################################
############################################################

cat("\n========================================\n")
cat("Verifying Primary Tumour status of the final samples
")
cat("========================================\n")

coad_final_info <- coad[
  coad$sampleID %in% samples_final,
  ,
  drop = FALSE
]

read_final_info <- read[
  read$sampleID %in% samples_final,
  ,
  drop = FALSE
]

cat("
Final COAD sample types:
")
print(table(
  coad_final_info$sample_type,
  useNA = "ifany"
))

cat("
Final READ sample types:
")
print(table(
  read_final_info$sample_type,
  useNA = "ifany"
))


############################################################
############################################################

## The matched object is written where the later steps read it: next to the other
## TCGA inputs when that location is writable, otherwise inside the package.
rdata_out <- local({
  d <- file.path(dirname(F_TCGA_RDATA))
  target <- file.path(DATA_ROOT, "TCGA_CRC_380_samples.RData")
  if (dir.exists(DATA_ROOT) && file.access(DATA_ROOT, 2L) == 0L) {
    target
  } else {
    d <- file.path(QCSC_PROJECT_DIR, "output")
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
    file.path(d, "TCGA_CRC_380_samples.RData")
  }
})

save(
  expr_crc,
  samples_final,
  samples_keep,
  coad_ids,
  read_ids,
  final_coad,
  final_read,
  file = rdata_out
)


cat("\n========================================\n")
cat("Analysis complete
")
cat("========================================\n")

cat("
Final expression matrix: 
")
print(dim(expr_crc))

cat("
Final number of samples: ",
    ncol(expr_crc), "\n")

cat("
Results saved: 
")
cat("TCGA_CRC_380_samples.RData\n")