## ===========================================================================
## figures/08e_Fig5_annotation.R
## Figure 5: panel-gene annotation, genome-wide correlation and GO enrichment.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
############################################################
#
#
#
#
#
#
############################################################

suppressPackageStartupMessages({ library(ggplot2) })

tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
dir.create(fig_dir, showWarnings = FALSE, recursive = TRUE)

corr <- read.csv(file.path(tab_dir, "panel_genomewide_correlation.csv"), check.names = FALSE)
go   <- read.csv(file.path(tab_dir, "panel_genomewide_GO.csv"),         check.names = FALSE)
goP  <- read.csv(file.path(tab_dir, "panel_gene_GO.csv"),               check.names = FALSE)

th <- theme_classic(base_size = 14) +
  theme(plot.title    = element_blank(),
        plot.subtitle = element_text(size = 12, color = "grey35"),
        axis.text     = element_text(color = "black"),
        strip.background = element_rect(fill = "grey93", color = NA),legend.title  = element_text(size = 11),legend.text   = element_text(size = 10),
        strip.text    = element_text(face = "bold", size = 9))

save_one <- function(p, stem, w, h) {
  ggsave(file.path(fig_dir, paste0(stem, ".pdf")), p, width = w, height = h, bg = "white")
  ggsave(file.path(fig_dir, paste0(stem, ".png")), p, width = w, height = h, dpi = 600, bg = "white")
  cat("saved:", file.path(fig_dir, paste0(stem, ".{pdf,png}")), "\n")
}

## ==========================================================
## ==========================================================
pos_genes <- c("TFF1", "TFF2", "TFF3", "KRT19", "CEACAM5", "AGR2")

neg_ribo   <- c("RPS27A", "RPL21", "RPL13", "RPS20", "EEF1D", "ASCL2")
neg_prolif <- c("UBE2C", "MKI67")
neg_genes  <- c(neg_ribo, neg_prolif)

sel <- corr[corr$gene %in% c(pos_genes, neg_genes), ]
sel$group <- ifelse(sel$gene %in% pos_genes, "Positively correlated", "Negatively correlated")

sel$sub <- ifelse(sel$gene %in% pos_genes,  "Secretory / epithelial",
                  ifelse(sel$gene %in% neg_prolif, "Proliferation",
                         "Ribosome / translation"))

sel <- sel[order(-sel$rho), ]
neg_order <- c(neg_ribo, neg_prolif)
sel$gene <- factor(sel$gene, levels = c(pos_genes, rev(neg_order)))

cat("\n[B] selected genes rho:\n"); print(sel[, c("gene", "rho", "sub")],
                                          row.names = FALSE, digits = 3)

miss <- setdiff(c(pos_genes, neg_genes), corr$gene)
if (length(miss)) {
  cat("WARNING: the following genes are absent from panel_genomewide_correlation.csv: ",
      paste(miss, collapse = ", "), "\n")
}

pB <- ggplot(sel, aes(x = 1, y = gene, fill = rho)) +
  geom_tile(color = "white", linewidth = 0.8) +
  geom_text(aes(label = sprintf("%.3f", rho)), size = 3.4,
            color = ifelse(abs(sel$rho) > 0.42, "white", "black")) +
  scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                       midpoint = 0, limits = c(-0.6, 0.6), name = "Spearman rho") +
  facet_grid(group ~ ., scales = "free_y", space = "free_y") +
  labs(x = NULL, y = NULL,
       title = NULL,
       subtitle = "GSE132465, 17,469 tumour epithelial cells") +
  th + theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(),
             axis.line.x = element_blank(), legend.position = "right")

save_one(pB, "Fig9B_gene_correlation", 4.4, 5.8)

write.csv(sel[order(sel$group, -sel$rho), c("gene", "group", "sub", "rho")],
          file.path(fig_dir, "Fig9B_selected_genes.csv"), row.names = FALSE)
cat("saved: Fig9B_selected_genes.csv\n")

## ==========================================================
## ==========================================================
g <- go
g$neglog10 <- -log10(g$p.adjust)
g$ratio <- sapply(strsplit(g$GeneRatio, "/"), function(x) {
  n1 <- suppressWarnings(as.numeric(x[1])); n2 <- suppressWarnings(as.numeric(x[2]))
  ifelse(is.na(n2) | n2 == 0, NA_real_, n1 / n2)
})

neg_terms <- c("cytoplasmic translation",
               "ribonucleoprotein complex biogenesis",
               "ribosome biogenesis",
               "rRNA processing")

neg <- g[g$direction == "negative" & g$Description %in% neg_terms, ]
neg <- neg[order(match(neg$Description, neg_terms)), ]

pos_terms <- c("response to wounding",
               "digestion",
               "digestive system process",
               "plasma membrane organization",
               "cell-matrix adhesion",
               "maintenance of gastrointestinal epithelium")

pos <- g[g$direction == "positive" & g$Description %in% pos_terms, ]
pos <- pos[order(match(pos$Description, pos_terms)), ]

cat("
[C] Negative direction (terms cited in the manuscript):
")
if (nrow(neg)) print(neg[, c("Description","p.adjust","Count")], row.names = FALSE, digits = 2)
cat("
[C] Positive direction (terms cited in the manuscript):
")
if (nrow(pos)) print(pos[, c("Description","p.adjust","Count")], row.names = FALSE, digits = 2)

na_miss <- setdiff(neg_terms, neg$Description)
if (length(na_miss)) {
  cat("
WARNING: unmatched negative-direction terms: ", paste(na_miss, collapse = " | "), "\n")
  for (kw in na_miss) {
    key <- sub(" .*$", "", kw)
    cat("  approximate candidates matching '", key, ")':
")
    print(head(grep(key, g$Description[g$direction == "negative"],
                    value = TRUE, ignore.case = TRUE), 5))
  }
}
po_miss <- setdiff(pos_terms, pos$Description)
if (length(po_miss)) {
  cat("
WARNING: unmatched positive-direction terms: ", paste(po_miss, collapse = " | "), "\n")
  for (kw in po_miss) {
    key <- sub(" .*$", "", kw)
    cat("  approximate candidates matching '", key, ")':
")
    print(head(grep(key, g$Description[g$direction == "positive"],
                    value = TRUE, ignore.case = TRUE), 5))
  }
}

gc <- rbind(
  data.frame(Description = neg$Description, neglog10 = neg$neglog10,
             Count = neg$Count, direction = "Negatively correlated",
             stringsAsFactors = FALSE),
  data.frame(Description = pos$Description, neglog10 = pos$neglog10,
             Count = pos$Count, direction = "Positively correlated",
             stringsAsFactors = FALSE)
)
gc$direction <- factor(gc$direction,
                       levels = c("Negatively correlated", "Positively correlated"))
gc <- gc[order(gc$direction, gc$neglog10), ]
gc$Description <- factor(gc$Description, levels = unique(gc$Description))

pC <- ggplot(gc, aes(x = neglog10, y = Description, color = direction)) +
  geom_segment(aes(x = 0, xend = neglog10, yend = Description),
               linewidth = 1.1, alpha = 0.55) +
  geom_point(aes(size = Count)) +
  scale_color_manual(values = c("Negatively correlated" = "#2166AC",
                                "Positively correlated" = "#B2182B"), name = NULL) +
  scale_size_continuous(range = c(2, 5.5), name = "Gene count") +
  facet_grid(direction ~ ., scales = "free_y", space = "free_y") +
  labs(x = expression(-log[10](FDR)), y = NULL,
       title = NULL,
       subtitle = "Top 200 most positively / negatively correlated genes; GO-BP over-representation, FDR by BH") +
  th + theme(axis.text.y = element_text(size = 19), axis.title.x = element_text(size = 19), plot.subtitle = element_text(size = 15, color = "grey35", face = "plain"),legend.text = element_text(size = 12),  legend.title = element_text(size = 13, face = "plain"),legend.position = "right")

save_one(pC, "Fig9C_GO_bidirectional", 14, 5.2)

## ==========================================================
## ==========================================================
key_terms <- c("cytoplasmic translation",
               "ribonucleoprotein complex biogenesis",
               "ribosome biogenesis")

kd <- g[g$Description %in% key_terms & g$geneID != "", ]
stopifnot(nrow(kd) >= 3)

gsets <- lapply(seq_len(nrow(kd)), function(i) strsplit(kd$geneID[i], "/")[[1]])
names(gsets) <- kd$Description

cat("\n[D] term sizes:\n")
for (nm in names(gsets)) cat(sprintf("  %-42s %d genes\n", nm, length(gsets[[nm]])))

shared <- Reduce(intersect, gsets)
cat(sprintf("  shared by all three terms: %d genes\n", length(shared)))
cat(sprintf("  ribosomal-protein genes: %d / %d\n",
            sum(grepl("^RP[LS]", shared)), length(shared)))

edge <- do.call(rbind, lapply(names(gsets), function(nm) {
  data.frame(term = nm, gene = intersect(gsets[[nm]], shared),
             stringsAsFactors = FALSE)
}))
edge_n <- table(edge$gene)
cat(sprintf("  edges: %d ; each gene connected to %s term(s)\n",
            nrow(edge), paste(sort(unique(as.integer(edge_n))), collapse = "/")))

term_levels <- key_terms
gene_levels <- sort(shared)
n_gene <- length(gene_levels)

term_y <- c(
  n_gene,
  (n_gene + 1) / 2,
  1
)

node_term <- data.frame(
  name = term_levels,
  x = 0,
  y = term_y,
  stringsAsFactors = FALSE
)

node_gene <- data.frame(
  name = gene_levels,
  x = 1,
  y = rev(seq_along(gene_levels)),
  stringsAsFactors = FALSE
)

edge$term_y <- node_term$y[match(edge$term, node_term$name)]
edge$gene_y <- node_gene$y[match(edge$gene, node_gene$name)]

fig_h  <- max(7.0, 0.5 * n_gene + 1.8)
cat(sprintf("  figure: %.1f x %.1f in\n", 8.0, fig_h))

pD <- ggplot() +
  geom_segment(data = edge,
               aes(x = 0, xend = 1, y = term_y, yend = gene_y),
               color = "grey78", linewidth = 0.22) +
  geom_point(data = node_term, aes(x, y), size = 8, color = "#2C7FB8") +
  geom_text(data = node_term, aes(x = x - 0.06, y = y, label = name),
            hjust = 1, size = 5, color = "black") +
  geom_point(data = node_gene, aes(x, y), size = 8, color = "#B2182B") +
  geom_text(data = node_gene, aes(x = x + 0.06, y = y, label = name),
            hjust = 0, size = 6, color = "black") +
  coord_cartesian(xlim = c(-1.05, 1.30), clip = "off",
                  ylim = c(0.3, n_gene + 0.7)) +
  labs(x = NULL, y = NULL,
       title = NULL,
       subtitle = sprintf("%d genes shared by all three terms; all encode ribosomal proteins",
                          length(shared))) +
  th + theme(axis.text    = element_blank(),
             axis.ticks   = element_blank(),
             axis.line    = element_blank(), plot.subtitle = element_text(size = 16, color = "grey"),
             panel.border = element_blank())

save_one(pD, "Fig9D_term_gene_network", 8.0, fig_h)

write.csv(data.frame(gene = gene_levels,
                     n_terms = as.integer(edge_n[gene_levels]),
                     stringsAsFactors = FALSE),
          file.path(fig_dir, "Fig9D_shared_genes.csv"), row.names = FALSE)
cat("saved: Fig9D_shared_genes.csv\n")

## ==========================================================
## ==========================================================
sigE <- goP[goP$p.adjust < 0.05, ]
cat("\n[E] panel-gene GO terms with FDR<0.05:\n")
cat(sprintf("  total: %d (BP %d, CC %d, MF %d)\n",
            nrow(sigE), sum(sigE$ontology == "BP"),
            sum(sigE$ontology == "CC"), sum(sigE$ontology == "MF")))
if (nrow(sigE)) {
  print(sigE[, c("ontology","Description","GeneRatio","p.adjust")], row.names = FALSE, digits = 2)
}

if (nrow(sigE) > 0) {
  
  sigE$ratio <- sapply(strsplit(sigE$GeneRatio, "/"), function(x) {
    n1 <- suppressWarnings(as.numeric(x[1])); n2 <- suppressWarnings(as.numeric(x[2]))
    ifelse(is.na(n2) | n2 == 0, NA_real_, n1 / n2)
  })
  sigE <- sigE[order(sigE$p.adjust), ]
  sigE$Description <- factor(sigE$Description, levels = rev(sigE$Description))
  
  ont_n <- table(sigE$ontology)
  ont_txt <- paste(sprintf("%s %d", names(ont_n), as.integer(ont_n)), collapse = ", ")
  
  min_by_ont <- tapply(goP$p.adjust, goP$ontology, min, na.rm = TRUE)
  nonsig_ont <- names(min_by_ont)[min_by_ont >= 0.05]
  nonsig_txt <- if (length(nonsig_ont)) {
    paste0(paste(nonsig_ont, collapse = "/"), " not significant (min FDR ",
           formatC(min(min_by_ont[nonsig_ont]), format = "f", digits = 2), ")")
  } else "all ontologies significant"
  
  pE <- ggplot(sigE, aes(x = -log10(p.adjust), y = Description,
                         color = ontology, size = ratio)) +
    geom_segment(aes(x = 0, xend = -log10(p.adjust), yend = Description),
                 color = "grey75", linewidth = 0.8) +
    geom_point() +
    scale_color_manual(values = c(BP = "#B2182B", CC = "#2166AC", MF = "#4DAF4A"),
                       name = "Ontology") +
    scale_size_continuous(range = c(2.2, 5.2), name = "Gene ratio") +
    labs(x = expression(-log[10](FDR)), y = NULL,
         title = NULL,
         subtitle = sprintf("%d terms with FDR < 0.05 (%s); Hallmark not significant; %s",
                            nrow(sigE), ont_txt, nonsig_txt)) +
    th + theme(axis.text.y = element_text(size = 15))
  
  save_one(pE, "Fig9E_panel_GO", 10, 3.9)
  
} else {
  cat("
[E] WARNING: no GO term reaches FDR < 0.05 for the panel genes; panel skipped
")
}

cat("
Complete: Fig9B / Fig9C / Fig9D (network, enlarged) / Fig9E
")
