## ===========================================================================
## figures/08b_Fig2B_umap_lineage.R
##
## Figure 2B: UMAP of all GSE188711 cells coloured by lineage annotation.
## Cluster 5 and 14 are merged into Epithelial; no cluster is highlighted.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
############################################################
#
#
#
############################################################


############################
############################

options(stringsAsFactors = FALSE)

## 01a writes its clustered object into a timestamped rebuild_* directory, so take
## the newest one instead of a fixed name.
.rebuild_dirs <- sort(
  Sys.glob(file.path(DATA_ROOT, "GSE188711_SchemeA_marker_annotation", "rebuild_*")),
  decreasing = TRUE
)
if (!length(.rebuild_dirs)) {
  stop("No rebuild_* directory under ", file.path(DATA_ROOT, "GSE188711_SchemeA_marker_annotation"))
}
input_file <- file.path(.rebuild_dirs[1],
                        "10_GSE188711_clustered_with_score_groups.rds")

output_dir <- FIG_DIR

pdf_file <- file.path(
  output_dir,
  "Fig_UMAP_lineage_overview.pdf"
)

png_file <- file.path(
  output_dir,
  "Fig_UMAP_lineage_overview.png"
)


############################
############################

if (!file.exists(input_file)) {
  stop(
    "ERROR: input file not found: \n",
    input_file
  )
}

if (!dir.exists(output_dir)) {
  dir.create(
    output_dir,
    recursive = TRUE
  )
}


############################
############################

required_packages <- c(
  "Seurat",
  "ggplot2",
  "grid"
)

for (pkg in required_packages) {
  
  if (!requireNamespace(pkg, quietly = TRUE)) {
    
    stop(
      "Missing R package(s): ",
      pkg,
      "\nPlease install it and re-run."
    )
    
  }
  
}

suppressPackageStartupMessages({
  
  library(Seurat)
  library(ggplot2)
  
})


############################
############################

cat("\n========== Reading the Seurat object ==========\n")

obj <- readRDS(input_file)

if (!inherits(obj, "Seurat")) {
  stop("ERRORSeurat")
}

cat("Seurat\n")
cat("cells", ncol(obj), "\n")
cat("", nrow(obj), "\n")


############################
############################

if (!"umap" %in% names(obj@reductions)) {
  stop("ERRORdoes not existumapresult")
}

if (!"seurat_clusters" %in% colnames(obj@meta.data)) {
  stop(
    "ERRORmeta.datadoes not existseurat_clusters"
  )
}

cluster_values <- as.character(
  obj$seurat_clusters
)

cat("\ncluster\n")

print(
  sort(unique(cluster_values))
)


############################
############################

required_clusters <- c(
  "5",
  "9",
  "10",
  "12",
  "13",
  "14"
)

missing_clusters <- setdiff(
  required_clusters,
  unique(cluster_values)
)

if (length(missing_clusters) > 0) {
  
  stop(
    "ERRORcluster",
    paste(
      missing_clusters,
      collapse = ", "
    )
  )
  
}


############################
############################


group <- rep(
  "Immune",
  length(cluster_values)
)

group[
  cluster_values %in% c("5", "14")
] <- "Epithelial"

group[
  cluster_values %in% c("9", "13")
] <- "Stromal"

group[
  cluster_values == "12"
] <- "Endothelial"

group[
  cluster_values == "10"
] <- "Proliferative"


############################
############################

grp_levels <- c(
  "Epithelial",
  "Immune",
  "Stromal",
  "Endothelial",
  "Proliferative"
)

obj$group <- factor(
  group,
  levels = grp_levels
)

cat("\n========== cells ==========\n")

print(
  table(obj$group)
)


############################
############################


cols <- c(
  
  "Epithelial" = "#63A69F",
  
  "Immune" = "#A69BB8",
  
  "Stromal" = "#E5BD78",
  
  "Endothelial" = "#83A8C5",
  
  "Proliferative" = "#D98F91"
  
)


############################
############################

cat("\n========== startUMAP ==========\n")

p <- DimPlot(
  object = obj,
  reduction = "umap",
  group.by = "group",
  cols = cols,
  order = grp_levels,
  pt.size = 0.30,
  label = FALSE,
  shuffle = TRUE
) +
  
  labs(
    title = NULL,
    color = NULL
  ) +
  
  guides(
    color = guide_legend(
      title = NULL,
      override.aes = list(
        size = 3,
        alpha = 1
      )
    )
  ) +
  
  theme_classic(
    base_size = 12
  ) +
  
  theme(
    
    plot.title = element_blank(),
    
    legend.title = element_blank(),
    
    legend.position = "right",
    
    legend.text = element_text(
      size = 13,
      color = "#333333"
    ),
    
    legend.key.size = grid::unit(
      0.48,
      "cm"
    ),
    
    legend.spacing.y = grid::unit(
      0.12,
      "cm"
    ),
    
    axis.title = element_text(
      size = 18,
      color = "#333333"
    ),
    
    axis.text = element_text(
      size = 17,
      color = "#666666"
    ),
    
    axis.line = element_line(
      linewidth = 0.45,
      color = "#444444"
    ),
    
    axis.ticks = element_line(
      linewidth = 0.35,
      color = "#666666"
    ),
    
    panel.grid = element_blank(),
    
    panel.background = element_rect(
      fill = "white",
      color = NA
    ),
    
    plot.background = element_rect(
      fill = "white",
      color = NA
    ),
    
    legend.margin = margin(
      l = 8,
      r = 3
    )
    
  )


############################
############################

ggsave(
  filename = pdf_file,
  plot = p,
  width = 7.0,
  height = 5.5,
  units = "in",
  device = "pdf",
  bg = "white"
)


############################
############################

ggsave(
  filename = png_file,
  plot = p,
  width = 7.0,
  height = 5.5,
  units = "in",
  dpi = 600,
  bg = "white"
)


############################
############################

lineage_statistics <- as.data.frame(
  table(obj$group)
)

colnames(lineage_statistics) <- c(
  "Lineage",
  "Cell_Number"
)

lineage_statistics$Percentage <- round(
  100 * lineage_statistics$Cell_Number /
    sum(lineage_statistics$Cell_Number),
  2
)

write.csv(
  lineage_statistics,
  file.path(
    output_dir,
    "Fig_UMAP_lineage_overview_statistics.csv"
  ),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


############################
############################

if (!file.exists(pdf_file)) {
  stop("ERRORPDFfile")
}

if (!file.exists(png_file)) {
  stop("ERRORPNGfile")
}

cat("\n========== Plottingdone ==========\n")

cat("PDFfile\n", pdf_file, "\n\n")

cat("PNGfile\n", png_file, "\n\n")

cat("cellsSummary\n")

print(lineage_statistics)

cat("\nUMAPPlottingdone\n")
cat("localoutliersexcluded\n")
cat("Cluster 5 and 14Epithelial\n")
cat("title and legendtitle\n")