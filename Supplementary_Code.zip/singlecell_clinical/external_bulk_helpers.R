## ===========================================================================
## singlecell_clinical/external_bulk_helpers.R
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

# ============================================================
# external_bulk_helpers.R
#
# ============================================================

suppressPackageStartupMessages({
  library(survival)
  library(hgu133plus2.db)
  library(AnnotationDbi)
})

get_probe_map <- function(target_genes) {
  annot <- suppressMessages(AnnotationDbi::select(
    hgu133plus2.db,
    keys = keys(hgu133plus2.db),
    columns = "SYMBOL",
    keytype = "PROBEID"
  ))
  annot <- annot[!is.na(annot$SYMBOL), ]
  annot$SYMBOL <- toupper(annot$SYMBOL)
  map <- setNames(annot$SYMBOL, annot$PROBEID)
  list(
    probe2gene = map,
    target_probes = names(map)[map %in% target_genes],
    n_annot = nrow(annot)
  )
}

read_series_matrix <- function(file, target_genes, probe2gene,
                               chunk_size = 4000L, verbose = TRUE) {
  con <- gzfile(file, open = "rt")
  on.exit(try(close(con), silent = TRUE))

  hdr <- character()
  repeat {
    ln <- readLines(con, n = 1L, warn = FALSE)
    if (!length(ln)) break
    hdr <- c(hdr, ln)
    if (startsWith(ln, "!series_matrix_table_begin")) break
    if (length(hdr) > 20000L) stop("Unexpected series matrix header: table_begin not found")
  }
  if (!startsWith(hdr[length(hdr)], "!series_matrix_table_begin")) {
    stop("!series_matrix_table_begin not found")
  }

  split_row <- function(x) gsub('^"|"$', "", strsplit(x, "\t", fixed = TRUE)[[1]])
  srows <- hdr[grepl("^!Sample_", hdr)]
  stags <- sub("\t.*$", "", srows)
  smat  <- lapply(srows, split_row)
  ncol_v <- vapply(smat, length, integer(1))
  keep <- ncol_v == max(ncol_v)
  srows <- srows[keep]; stags <- stags[keep]; smat <- smat[keep]
  ch <- do.call(rbind, smat)[, -1, drop = FALSE]

  clin <- data.frame(
    gsm   = ch[match("!Sample_geo_accession", stags), ],
    title = ch[match("!Sample_title", stags), ],
    stringsAsFactors = FALSE
  )
  ch_rows <- which(stags == "!Sample_characteristics_ch1")
  if (!length(ch_rows)) stop("!Sample_characteristics_ch1 not found in the series matrix")
  vals <- ch[ch_rows, , drop = FALSE]
  pref <- sub(":.*$", "", vals[, 1])
  for (k in seq_len(nrow(vals))) {
    clin[[pref[k]]] <- sub("^[^:]*:\\s*", "", vals[k, ])
  }
  if (verbose) cat(sprintf("  samples: %d ; clinical fields: %d\n",
                           nrow(clin), ncol(clin) - 2))

  mx_hdr <- readLines(con, n = 1L, warn = FALSE)
  mx_ids <- gsub('"', "", strsplit(mx_hdr, "\t", fixed = TRUE)[[1]][-1])
  if (verbose) cat(sprintf("  matrix columns: %d\n", length(mx_ids)))
  if (!identical(mx_ids, clin$gsm)) {
    if (!setequal(mx_ids, clin$gsm)) stop("Matrix column names do not match the clinical GSMs")
    clin <- clin[match(mx_ids, clin$gsm), ]
    if (verbose) cat("  (sample order realigned to matrix columns)\n")
  }

  target_probes <- names(probe2gene)[probe2gene %in% target_genes]
  kept <- list(); n_read <- 0L
  repeat {
    lines <- readLines(con, n = chunk_size, warn = FALSE)
    lines <- lines[nzchar(lines) & lines != "!series_matrix_table_end"]
    if (!length(lines)) break
    ids <- gsub('"', "", sub("\t.*$", "", lines))
    idx <- which(ids %in% target_probes)
    if (length(idx)) {
      sp <- strsplit(lines[idx], "\t", fixed = TRUE)
      for (k in seq_along(sp)) {
        v <- suppressWarnings(as.numeric(gsub('"', "", sp[[k]][-1])))
        if (length(v) == length(mx_ids)) kept[[ids[idx][k]]] <- v
      }
    }
    n_read <- n_read + length(lines)
    if (verbose && n_read %% 20000L < chunk_size) cat("   probes read:", n_read, "\n")
  }
  if (!length(kept)) stop("No target probes captured; check the annotation or the matrix format")
  if (verbose) cat(sprintf("  total probe rows: %d ; captured: %d\n",
                           n_read, length(kept)))

  expr <- do.call(rbind, kept)
  rownames(expr) <- names(kept)
  colnames(expr) <- mx_ids

  rng <- range(expr, na.rm = TRUE)
  if (verbose) cat(sprintf("  expression range: %.2f - %.2f\n", rng[1], rng[2]))
  if (rng[2] > 50) {
    if (verbose) message("  values look linear -> applying log2(x + 1)")
    expr <- log2(expr + 1)
  }

  gene_of <- probe2gene[rownames(expr)]
  ok <- !is.na(gene_of) & gene_of %in% target_genes
  expr <- expr[ok, , drop = FALSE]; gene_of <- gene_of[ok]
  emean <- rowMeans(expr, na.rm = TRUE)
  ord <- order(gene_of, -emean)
  expr <- expr[ord, , drop = FALSE]; gene_of <- gene_of[ord]
  keep1 <- !duplicated(gene_of)
  expr <- expr[keep1, , drop = FALSE]; gene_of <- gene_of[keep1]
  rownames(expr) <- gene_of
  if (verbose) cat(sprintf("  genes after probe collapsing: %d\n", nrow(expr)))

  list(expr = expr, clin = clin, mx_ids = mx_ids)
}

score_panels <- function(expr, up, down, is_tumour,
                         full_up = NULL, full_down = NULL) {
  mu  <- rowMeans(expr[, is_tumour, drop = FALSE], na.rm = TRUE)
  sdv <- apply(expr[, is_tumour, drop = FALSE], 1, sd, na.rm = TRUE)
  sdv[!is.finite(sdv) | sdv == 0] <- 1
  z_all <- (expr - mu) / sdv

  sc <- function(genes) {
    g <- intersect(genes, rownames(z_all))
    if (!length(g)) return(rep(NA_real_, ncol(z_all)))
    colMeans(z_all[g, , drop = FALSE], na.rm = TRUE)
  }
  panel <- sc(up) - sc(down)
  full  <- if (!is.null(full_up) && !is.null(full_down)) {
    sc(full_up) - sc(full_down)
  } else NULL

  tz <- function(x) {
    mx <- mean(x[is_tumour], na.rm = TRUE); sx <- sd(x[is_tumour], na.rm = TRUE)
    if (!is.finite(sx) || sx == 0) return(rep(NA_real_, length(x)))
    (x - mx) / sx
  }
  list(panel = as.numeric(panel), full = if (is.null(full)) NULL else as.numeric(full),
       panel_z = tz(panel), full_z = if (is.null(full)) NULL else tz(full),
       z_all = z_all)
}

fmt_p <- function(p) {
  if (length(p) != 1L || is.na(p)) return("NA")
  if (p < 0.001) return("< 0.001")
  formatC(p, format = "f", digits = 3)
}

ipcw_auc <- function(time, event, marker, t0) {
  ok <- !is.na(time) & !is.na(event) & !is.na(marker)
  time <- time[ok]; event <- event[ok]; marker <- marker[ok]
  if (!length(time)) return(NA_real_)
  km <- survfit(Surv(time, 1 - event) ~ 1)
  gfun <- function(t) {
    s <- summary(km, times = t, extend = TRUE)$surv
    s[!is.finite(s) | s <= 0] <- NA_real_
    s
  }
  case <- time <= t0 & event == 1
  ctrl <- time > t0
  if (sum(case) < 5L || sum(ctrl) < 5L) return(NA_real_)
  wc <- 1 / gfun(time[case])
  wk <- 1 / gfun(rep(t0, sum(ctrl)))
  if (anyNA(wc) || anyNA(wk)) return(NA_real_)
  cmp <- outer(marker[case], marker[ctrl], function(a, b) (a > b) + 0.5 * (a == b))
  as.numeric(wc %*% (cmp %*% wk)) / (sum(wc) * sum(wk))
}

cox_row <- function(fit, endpoint, model, note = "") {
  s <- summary(fit)
  data.frame(
    endpoint = endpoint, model = model,
    n = s$n, events = s$nevent,
    HR = s$conf.int[1, "exp(coef)"],
    CI_low = s$conf.int[1, "lower .95"],
    CI_high = s$conf.int[1, "upper .95"],
    P = s$coefficients[1, "Pr(>|z|)"],
    note = note, stringsAsFactors = FALSE
  )
}

plot_km_one <- function(time, event, group, ylab, main,
                        hr_txt = NULL, cols = c("#2C7FB8", "#D95F0E")) {
  sf <- survfit(Surv(time, event) ~ group)
  sd <- survdiff(Surv(time, event) ~ group)
  p  <- pchisq(sd$chisq, df = length(sd$n) - 1, lower.tail = FALSE)
  plot(sf, col = cols, lwd = 2.2, mark.time = TRUE, xaxs = "i", yaxs = "i",
       bty = "l", xlab = "Time (months)", ylab = ylab,
       main = sprintf("%s\nlog-rank P = %s", main, fmt_p(p)), cex.main = 1.05, las = 1)
  abline(h = 0.5, lty = 3, col = "grey55")
  abline(v = 60, lty = 3, col = "grey55")
  legend("topright", bty = "n", lwd = 2.4, col = cols, cex = 0.9,
         legend = c(sprintf("panel low (n = %d)", sum(group == levels(group)[1])),
                    sprintf("panel high (n = %d)", sum(group == levels(group)[2]))))
  if (!is.null(hr_txt)) {
    legend("bottomleft", bty = "n", cex = 0.8, legend = hr_txt)
  }
  invisible(p)
}
