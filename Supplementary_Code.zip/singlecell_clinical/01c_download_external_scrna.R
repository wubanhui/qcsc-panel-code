## ===========================================================================
## singlecell_clinical/01c_download_external_scrna.R
## Download the independent single-cell cohort GSE144735 (needs network).
## ===========================================================================
# ============================================================
# 05_download_external_scrna.R
#
# ============================================================

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
dest_dir <- file.path(QCSC_PROJECT_DIR, "external", "GSE144735")
dir.create(dest_dir, recursive = TRUE, showWarnings = FALSE)

base <- "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE144nnn/GSE144735/suppl"
files <- c(
  "GSE144735_processed_KUL3_CRC_10X_raw_UMI_count_matrix.txt.gz",
  "GSE144735_processed_KUL3_CRC_10X_annotation.txt.gz"
)
for (f in files) {
  dest <- file.path(dest_dir, f)
  if (!file.exists(dest)) {
    message("Downloading ", f, " ...")
    download.file(file.path(base, f), dest, mode = "wb", timeout = 3600)
  }
  message(f, ": ", round(file.size(dest) / 1e6, 1), " MB")
}
message("Downloaded to: ", dest_dir)
