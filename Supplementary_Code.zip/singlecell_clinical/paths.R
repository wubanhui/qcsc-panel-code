## ===========================================================================
## singlecell_clinical/paths.R
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

# Shared path helpers: find the newest QC / clustered object.

find_qc132 <- function(root) {
  f <- file.path(root, "QC_stage4_20261025_203115", "seurat_objects",
                 "GSE132465_QC_unfiltered.rds")
  if (file.exists(f)) return(f)
  cand <- Sys.glob(file.path(root, "QC_stage4_*", "seurat_objects",
                             "GSE132465_QC_unfiltered.rds"))
  if (!length(cand)) stop("Cannot find the GSE132465 QC object")
  sort(cand, decreasing = TRUE)[1]
}

find_qc188 <- function(root) {
  f <- file.path(root, "QC_stage4_20261025_203115", "seurat_objects",
                 "GSE188711_all_samples_QC_unfiltered.rds")
  if (file.exists(f)) return(f)
  cand <- Sys.glob(file.path(root, "QC_stage4_*", "seurat_objects",
                             "GSE188711_all_samples_QC_unfiltered.rds"))
  if (!length(cand)) stop("Cannot find the GSE188711 QC object")
  sort(cand, decreasing = TRUE)[1]
}

find_gse188_clustered <- function(root) {
  f <- file.path(root, "GSE188711_SchemeA_marker_annotation",
                 "run_20261026_000040",
                 "10_GSE188711_clustered_with_score_groups.rds")
  if (file.exists(f)) return(f)
  cand <- list.files(root, pattern = "10_GSE188711_clustered.*\\.rds$",
                     recursive = TRUE, full.names = TRUE)
  if (!length(cand)) return(NA_character_)
  sort(cand, decreasing = TRUE)[1]
}
