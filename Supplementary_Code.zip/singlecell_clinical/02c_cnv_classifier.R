## ===========================================================================
## singlecell_clinical/02c_cnv_classifier.R
## Arm-level CNV proxy classifier (41 chromosome-arm features, logistic
## regression, 5-fold CV).
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "paths.R"))

## Arm-level CNV proxy: test on GSE132465 tumour vs normal epithelium and GSE188711 clusters.
suppressPackageStartupMessages({
  library(Seurat); library(SeuratObject); library(Matrix); library(data.table)
})
set.seed(1234)
root <- ROOT_SC
dir.create(out_dir, recursive=TRUE, showWarnings=FALSE)

## 1. Gene positions from GENCODE
gtf <- GENCODE_GTF
gtf_dt <- fread(gtf, sep="\t", header=FALSE, skip=5, quote="", showProgress=FALSE,
                select=c(1,3,4,9), col.names=c("chr","type","start","attr"))
gtf_dt <- gtf_dt[type=="gene"]
gtf_dt[, symbol := sub('.*gene_name "([^"]+)".*', "\\1", attr)]
gtf_dt[, symbol := toupper(symbol)]
gtf_dt <- gtf_dt[!is.na(symbol) & nzchar(symbol) & grepl("^chr([0-9]+|X)$", chr)]
gtf_dt[, chr := sub("^chr", "", chr)]
gtf_dt <- gtf_dt[!duplicated(symbol)]
gene_pos <- as.data.frame(gtf_dt[, .(symbol, chr, start)])
cat("gene positions:", nrow(gene_pos), "\n")

centromere <- c(
  "1"=121700000, "2"=91800000, "3"=87800000, "4"=49700000, "5"=45400000,
  "6"=58800000, "7"=58100000, "8"=43200000, "9"=43000000, "10"=39800000,
  "11"=51000000, "12"=33200000, "13"=17000000, "14"=16000000, "15"=15800000,
  "16"=35300000, "17"=22700000, "18"=15400000, "19"=24200000, "20"=25700000,
  "21"=11200000, "22"=13000000, "X"=60600000
)
gene_pos$arm <- ifelse(
  gene_pos$start < centromere[gene_pos$chr],
  paste0("chr", gene_pos$chr, "p"),
  paste0("chr", gene_pos$chr, "q")
)

## 2. Helper: collapse symbols and compute arm scores
collapse_by_symbol <- function(expr, symbols, total_counts=NULL) {
  symbols <- toupper(as.character(symbols))
  ok <- !is.na(symbols) & nzchar(symbols)
  expr <- expr[ok,,drop=FALSE]; symbols <- symbols[ok]
  if (is.null(total_counts)) total_counts <- Matrix::rowSums(expr) else total_counts <- as.numeric(total_counts)[ok]
  ord <- order(symbols, -total_counts)
  expr <- expr[ord,,drop=FALSE]; symbols <- symbols[ord]
  keep <- !duplicated(symbols)
  expr <- expr[keep,,drop=FALSE]; rownames(expr) <- symbols[keep]
  expr
}

arm_score <- function(expr, gene_pos, min_det=0.05) {
  # expr: genes x cells, log-normalised, rownames symbols
  keep <- rownames(expr) %in% gene_pos$symbol
  expr <- expr[keep,,drop=FALSE]
  pos <- gene_pos[match(rownames(expr), gene_pos$symbol),]
  det <- Matrix::rowMeans(expr > 0)
  keep2 <- det >= min_det
  expr <- expr[keep2,,drop=FALSE]; pos <- pos[keep2,]
  arms <- sort(unique(pos$arm))
  W <- Matrix::sparseMatrix(
    i = seq_len(nrow(expr)),
    j = match(pos$arm, arms),
    x = 1,
    dims = c(nrow(expr), length(arms))
  )
  # normalise each arm by number of genes
  n_per_arm <- tabulate(match(pos$arm, arms), nbins=length(arms))
  W <- W %*% Matrix::Diagonal(x = 1 / n_per_arm)
  scores <- as.matrix(Matrix::t(W) %*% expr)  # arms x cells
  rownames(scores) <- arms
  # centre each arm across cells, then remove cell-level global shift
  scores <- scores - rowMeans(scores)
  scores <- scores - apply(scores, 2, median)
  cnv <- colMeans(abs(scores))
  list(cnv=cnv, arm_scores=scores, n_genes=nrow(expr), arms=arms)
}

## 3. GSE132465 tumour vs normal epithelial
obj <- readRDS(find_qc132(root))
meta <- obj[[]]
keep <- !is.na(meta$Cell_type) & meta$Cell_type=="Epithelial cells" &
  !is.na(meta$Class) & meta$Class %in% c("Tumor","Normal")
obj <- subset(obj, cells=rownames(meta)[keep])
obj <- NormalizeData(obj, assay="RNA", normalization.method="LogNormalize", scale.factor=10000, verbose=FALSE)
expr <- SeuratObject::LayerData(obj[["RNA"]], layer="data")
counts <- SeuratObject::LayerData(obj[["RNA"]], layer="counts")
expr <- collapse_by_symbol(expr, rownames(expr), Matrix::rowSums(counts))
meta <- obj[[]][colnames(expr),,drop=FALSE]
cat("GSE132465 epithelial:", dim(expr), "\n")
res132 <- arm_score(expr, gene_pos)
meta$cnv_score <- res132$cnv
cat("CNV tumour vs normal:\n"); print(tapply(meta$cnv_score, meta$Class, summary))
cat("AUC tumour vs normal:", {
  w <- wilcox.test(meta$cnv_score[meta$Class=="Tumor"], meta$cnv_score[meta$Class=="Normal"])
  as.numeric(w$statistic)/(sum(meta$Class=="Tumor")*sum(meta$Class=="Normal"))
}, "\n")
saveRDS(list(scores=meta, arm_scores=res132$arm_scores, genes=res132$n_genes),
        file.path(out_dir,"cnv_gse132465.rds"))
rm(obj, expr, counts); gc()

## 4. GSE188711 epithelial clusters
obj <- readRDS(find_gse188_clustered(root))
meta <- obj[[]]
keep <- as.character(meta$seurat_clusters) %in% c("5","14")
obj <- subset(obj, cells=rownames(meta)[keep])
expr <- SeuratObject::LayerData(obj[["RNA"]], layer="data")
counts <- SeuratObject::LayerData(obj[["RNA"]], layer="counts")
fmeta <- obj[["RNA"]][[]]
expr <- collapse_by_symbol(expr, fmeta$gene_symbol, Matrix::rowSums(counts))
meta <- obj[[]][colnames(expr),,drop=FALSE]
cat("GSE188711 epithelial:", dim(expr), "\n")
res188 <- arm_score(expr, gene_pos)
meta$cnv_score <- res188$cnv
cat("CNV by cluster:\n"); print(tapply(meta$cnv_score, meta$seurat_clusters, summary))
cat("AUC cluster14 vs 5:", {
  w <- wilcox.test(meta$cnv_score[meta$seurat_clusters=="14"], meta$cnv_score[meta$seurat_clusters=="5"])
  as.numeric(w$statistic)/(sum(meta$seurat_clusters=="14")*sum(meta$seurat_clusters=="5"))
}, "\n")
saveRDS(list(scores=meta, arm_scores=res188$arm_scores, genes=res188$n_genes),
        file.path(out_dir,"cnv_gse188711.rds"))
cat("done\n")
