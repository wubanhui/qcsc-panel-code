## ===========================================================================
## singlecell_clinical/02b_gse188711_epithelial.R
## Select epithelial clusters of GSE188711 and assemble the two-cohort
## expression object used for panel selection.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "paths.R"))

## GSE188711: select epithelial clusters and build matched two-cohort panel data.
suppressPackageStartupMessages({library(Seurat); library(SeuratObject); library(Matrix)})
set.seed(1234)

root <- ROOT_SC
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

g132 <- readRDS(file.path(out_dir, "gse132_epithelial_signature.rds"))
sig <- union(g132$up, g132$down)

gse188_clustered <- find_gse188_clustered(root)
if (is.na(gse188_clustered) || !file.exists(gse188_clustered)) {
  gse188_clustered <- file.path(root, "GSE188711_auto_clustered",
                                "10_GSE188711_clustered.rds")
  qc_file <- find_qc188(root)
  suppressPackageStartupMessages({
    library(scDblFinder); library(SingleCellExperiment); library(BiocParallel)
  })
  BiocParallel::register(BiocParallel::SerialParam())
  qc_list <- readRDS(qc_file)
  qc_list <- lapply(qc_list, function(o) {
    subset(o, subset = nFeature_RNA > 200 & nFeature_RNA < 6000 & percent.mt < 25)
  })
  singlets <- list()
  for (nm in names(qc_list)) {
    o <- qc_list[[nm]]
    sce <- SingleCellExperiment(assays = list(counts = LayerData(o[["RNA"]], layer = "counts")))
    set.seed(1234)
    sce <- scDblFinder(sce, clusters = FALSE, verbose = FALSE)
    keep <- SummarizedExperiment::colData(sce)$scDblFinder.class == "singlet"
    o$scDblFinder.class <- SummarizedExperiment::colData(sce)$scDblFinder.class
    o$scDblFinder.score <- SummarizedExperiment::colData(sce)$scDblFinder.score
    singlets[[nm]] <- subset(o, cells = colnames(o)[keep])
  }
  seu <- merge(singlets[[1]], singlets[-1], add.cell.ids = names(singlets),
               project = "GSE188711")
  seu <- SeuratObject::JoinLayers(seu, assay = "RNA")
  seu <- NormalizeData(seu, verbose = FALSE)
  seu <- FindVariableFeatures(seu, nfeatures = 3000, verbose = FALSE)
  seu <- ScaleData(seu, features = VariableFeatures(seu), verbose = FALSE)
  seu <- RunPCA(seu, npcs = 30, verbose = FALSE)
  seu <- FindNeighbors(seu, dims = 1:30, verbose = FALSE)
  seu <- FindClusters(seu, resolution = 0.5, verbose = FALSE)
  seu <- RunUMAP(seu, dims = 1:30, verbose = FALSE)
  dir.create(dirname(gse188_clustered), recursive = TRUE, showWarnings = FALSE)
  saveRDS(seu, gse188_clustered, compress = FALSE)
}
obj <- readRDS(gse188_clustered)
fmeta <- obj[["RNA"]][[]]
sym <- toupper(as.character(fmeta$gene_symbol))

lineage_markers <- c(
  "EPCAM", "KRT8", "KRT18", "KRT19", "CDH1", "KRT20", "MUC1", "TACSTD2", "CEACAM5", "CEACAM6",
  "PTPRC", "CD3D", "CD3E", "CD2", "NKG7", "GNLY", "TRAC",
  "MS4A1", "CD79A", "MZB1", "JCHAIN", "IGHG1",
  "LYZ", "C1QA", "C1QB", "S100A8", "S100A9", "FCGR3B", "CD68",
  "COL1A1", "COL1A2", "DCN", "LUM", "COL3A1", "FAP", "ACTA2",
  "PECAM1", "VWF", "KDR", "EMCN", "TPSAB1", "TPSB2", "KIT",
  "MKI67", "TOP2A", "CDK1", "UBE2C"
)
need <- unique(c(sig, lineage_markers))
keep_feat <- !is.na(sym) & sym %in% need
cat("features retained for scoring/markers:", sum(keep_feat), "\n")

expr <- SeuratObject::LayerData(obj[["RNA"]], layer = "data")[keep_feat, , drop = FALSE]
counts <- SeuratObject::LayerData(obj[["RNA"]], layer = "counts")[keep_feat, , drop = FALSE]
sym <- sym[keep_feat]

## one row per symbol, highest total counts
tc <- Matrix::rowSums(counts)
ord <- order(sym, -tc)
expr <- expr[ord, , drop = FALSE]; sym <- sym[ord]; tc <- tc[ord]
keep_row <- !duplicated(sym)
expr <- expr[keep_row, , drop = FALSE]
sym <- sym[keep_row]
rownames(expr) <- sym

clusters <- sort(unique(as.character(obj$seurat_clusters)))
cl_mean <- sapply(lineage_markers, function(g) {
  if (!g %in% rownames(expr)) return(rep(NA_real_, length(clusters)))
  vapply(clusters, function(cl) {
    cells <- colnames(expr)[as.character(obj$seurat_clusters) == cl]
    mean(expr[g, cells, drop = FALSE])
  }, numeric(1))
})
rownames(cl_mean) <- clusters

lineage_tab <- data.frame(
  cluster = clusters,
  n_cells = as.integer(table(factor(as.character(obj$seurat_clusters), levels = clusters))),
  check.names = FALSE
)
lineage_tab <- cbind(lineage_tab, as.data.frame(round(cl_mean, 3), check.names = FALSE))
print(lineage_tab[, c("cluster", "n_cells", "EPCAM", "KRT8", "KRT18", "KRT19",
                      "PTPRC", "COL1A1", "PECAM1")], row.names = FALSE)
write.csv(lineage_tab, file.path(out_dir, "GSE188711_cluster_lineage_markers.csv"), row.names = FALSE)

epi_clusters <- clusters[cl_mean[, "EPCAM"] > 1 & cl_mean[, "KRT18"] > 2]
if (length(epi_clusters) == 0) stop("No epithelial cluster found by EPCAM/KRT18 threshold.")
cat("selected epithelial clusters:", paste(epi_clusters, collapse = ", "), "\n")

cells188 <- colnames(obj)[as.character(obj$seurat_clusters) %in% epi_clusters]
expr188 <- as.matrix(expr[, cells188, drop = FALSE])
meta188 <- obj[[]][cells188, , drop = FALSE]
cat("GSE188711 epithelial cells:", length(cells188), "\n")
print(table(meta188$sample_code))

common <- intersect(rownames(expr188), rownames(g132$expr))
up_use <- intersect(g132$up, common)
down_use <- intersect(g132$down, common)
genes <- c(up_use, down_use)
cat("common genes:", length(common), " UP:", length(up_use), " DOWN:", length(down_use), "\n")

E1 <- g132$expr[genes, , drop = FALSE]
E2 <- expr188[genes, , drop = FALSE]
meta1 <- g132$meta

score1 <- colMeans(E1[up_use, , drop = FALSE]) - colMeans(E1[down_use, , drop = FALSE])
score2 <- colMeans(E2[up_use, , drop = FALSE]) - colMeans(E2[down_use, , drop = FALSE])
cat("GSE132465 full score summary:\n"); print(summary(score1))
cat("GSE188711 full score summary:\n"); print(summary(score2))

gene_stats <- data.frame(
  gene = genes,
  direction = ifelse(genes %in% up_use, "UP", "DOWN"),
  detection_132 = 100 * rowMeans(E1 > 0),
  detection_188 = 100 * rowMeans(E2 > 0),
  mean_132 = rowMeans(E1),
  mean_188 = rowMeans(E2),
  stringsAsFactors = FALSE
)
gene_stats$r_132 <- as.numeric(cor(t(E1), score1))
gene_stats$r_188 <- as.numeric(cor(t(E2), score2))
gene_stats$expected_sign <- ifelse(gene_stats$direction == "UP", 1, -1)
gene_stats$consistent <- !is.na(gene_stats$r_132) & !is.na(gene_stats$r_188) &
  sign(gene_stats$r_132) == gene_stats$expected_sign &
  sign(gene_stats$r_188) == gene_stats$expected_sign
write.csv(gene_stats, file.path(out_dir, "01_gene_level_full_signature_stats.csv"), row.names = FALSE)

cat("direction-consistent:", sum(gene_stats$consistent, na.rm = TRUE), "/", nrow(gene_stats), "\n")
print(table(gene_stats$direction, gene_stats$consistent, useNA = "ifany"))

## correlation with pre-existing GSE188711 score (sanity check of mapping)
old_score <- obj$qCSC_LINCS_score[match(cells188, colnames(obj))]
cat("cor(new score2, existing qCSC_LINCS_score):",
    round(cor(score2, old_score, use = "complete.obs"), 4), "\n")

saveRDS(list(
  genes = genes, up_use = up_use, down_use = down_use,
  E1 = E1, E2 = E2, score1 = score1, score2 = score2,
  meta1 = meta1, meta2 = meta188,
  gene_stats = gene_stats,
  epi_clusters = epi_clusters,
  lineage_table = lineage_tab,
  old_score188 = old_score
), file.path(out_dir, "panel_data.rds"), compress = FALSE)
cat("saved panel_data.rds\n")
