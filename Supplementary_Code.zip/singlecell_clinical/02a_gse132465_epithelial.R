## ===========================================================================
## singlecell_clinical/02a_gse132465_epithelial.R
## Extract CMS1-4 tumour epithelial cells from GSE132465 and log-normalise.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "paths.R"))

## GSE132465: extract CMS1-4 tumour epithelial cells and log-normalise.
suppressPackageStartupMessages({library(Seurat); library(SeuratObject); library(Matrix)})
set.seed(1234)

root <- ROOT_SC
gene_dir <- ROOT_LINCS
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

read_gene_list <- function(path) {
  x <- readLines(path, warn = FALSE, encoding = "UTF-8")
  x <- trimws(x)
  x <- x[nzchar(x) & !grepl("^#", x)]
  x <- unlist(strsplit(x, "[,\t;]"), use.names = FALSE)
  x <- trimws(gsub('^"|"$', "", x))
  x <- toupper(x)
  unique(x[nzchar(x) & !x %in% c("GENE", "GENES", "SYMBOL", "GENE_SYMBOL", "GENE SYMBOL", "V1")])
}
up <- read_gene_list(file.path(gene_dir, "LINCS_UP_protein_coding.txt"))
down <- read_gene_list(file.path(gene_dir, "LINCS_DOWN_protein_coding.txt"))
conflict <- intersect(up, down)
up <- setdiff(up, conflict); down <- setdiff(down, conflict)
sig <- unique(c(up, down))
cat("signature genes:", length(sig), "\n")

obj <- readRDS(find_qc132(root))
meta <- obj[[]]
keep <- !is.na(meta$Class) & meta$Class == "Tumor" &
  !is.na(meta$Cell_type) & meta$Cell_type == "Epithelial cells" &
  !is.na(meta$Cell_subtype) & grepl("^CMS[1-4]$", meta$Cell_subtype)
cat("tumour epithelial cells:", sum(keep), "\n")
print(table(meta$Cell_subtype[keep]))

obj <- subset(obj, cells = rownames(meta)[keep])
obj <- NormalizeData(obj, assay = "RNA", normalization.method = "LogNormalize",
                     scale.factor = 10000, verbose = FALSE)
expr <- SeuratObject::LayerData(obj[["RNA"]], layer = "data")
counts <- SeuratObject::LayerData(obj[["RNA"]], layer = "counts")

## one row per symbol, highest total counts
sym <- toupper(rownames(expr))
ok <- !is.na(sym) & nzchar(sym)
expr <- expr[ok, , drop = FALSE]; sym <- sym[ok]
tc <- Matrix::rowSums(counts)[ok]
ord <- order(sym, -tc)
expr <- expr[ord, , drop = FALSE]; sym <- sym[ord]
keep_row <- !duplicated(sym)
expr <- expr[keep_row, , drop = FALSE]
rownames(expr) <- sym[keep_row]

sig_present <- intersect(sig, rownames(expr))
cat("signature genes present:", length(sig_present), "/", length(sig), "\n")
expr_sig <- as.matrix(expr[sig_present, , drop = FALSE])
meta <- obj[[]][colnames(expr_sig), , drop = FALSE]
saveRDS(list(expr = expr_sig, meta = meta, up = up, down = down,
             genes_present = sig_present),
        file.path(out_dir, "gse132_epithelial_signature.rds"), compress = FALSE)
cat("saved GSE132465:", dim(expr_sig), "\n")
