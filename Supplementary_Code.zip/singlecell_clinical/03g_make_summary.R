## ===========================================================================
## singlecell_clinical/03g_make_summary.R
##
## One-page summary table. Every number is read from an existing result file;
## nothing is hard-coded and panel_data.rds is never re-read.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
# ============================================================
# 05_make_summary.R
#
#
#   source("scripts/05_make_summary.R")
# ============================================================

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
tab_dir <- TAB_DIR
panel_dir <- PANEL_DIR
root <- ROOT_SC

# ------------------------------------------------------------
# ------------------------------------------------------------
rd <- function(file, dir = tab_dir) {
  fp <- file.path(dir, file)
  if (!file.exists(fp)) {
 cat("[] ?", fp, "\n")
    return(NULL)
  }
  read.csv(fp, check.names = FALSE, stringsAsFactors = FALSE)
}

fid   <- rd("stable_panel_fidelity.csv")
st    <- rd("stable_panel_qcsc_state.csv")
nv    <- rd("stable_panel_normal_vs_tumour.csv")
tc    <- rd("tcga_stable_panel_scores.csv")
surv  <- rd("tcga_stable_panel_survival.csv")
mv    <- rd("tcga_stable_panel_multivariable_cox.csv")
mal   <- rd("GSE188711_malignant_candidate_summary.csv")
stab  <- rd("panel_stability_frequency.csv")
panel <- rd("final_panel_stable.csv")
D_DRIVE <- QCSC_PROJECT_DIR
dbl <- {
  dd <- file.path(D_DRIVE, "tables", "GSE132465_doublet_rate_overall.csv")
  ok <- function(x) !is.null(x) && nrow(x) > 0 &&
                    is.finite(suppressWarnings(as.numeric(x$overall_doublet_pct[1])))
  a <- if (file.exists(dd)) rd("GSE132465_doublet_rate_overall.csv", dir = dirname(dd)) else NULL
  if (ok(a)) a else { b <- rd("GSE132465_doublet_rate_overall.csv"); if (ok(b)) b else NULL }
}
dbl_c <- rd("GSE132465_vs_GSE188711_doublet_rate.csv")
upone <- rd("UP_only_sensitivity.csv")
boot  <- rd("patient_level_bootstrap_ci.csv")

data_file <- file.path(panel_dir, "panel_data.rds")
if (!file.exists(data_file)) stop("?panel_data.rds: ", data_file)
d <- readRDS(data_file)

n1 <- ncol(d$E1)
n2 <- ncol(d$E2)
n_genes <- length(d$genes)
n_up <- length(d$up_use)
n_down <- length(d$down_use)
cl2 <- table(as.character(d$meta2$seurat_clusters))

# ------------------------------------------------------------
# ------------------------------------------------------------
panel_genes <- if (!is.null(panel)) panel$gene else d$genes
if (!is.null(panel) && all(c("gene", "direction") %in% names(panel))) {
  panel_up_genes <- panel$gene[panel$direction == "UP"]
  panel_dn_genes <- panel$gene[panel$direction == "DOWN"]
} else {
  panel_up_genes <- d$up_use
  panel_dn_genes <- d$down_use
}
s1_up <- intersect(panel_up_genes, rownames(d$E1)); s1_dn <- intersect(panel_dn_genes, rownames(d$E1))
s2_up <- intersect(panel_up_genes, rownames(d$E2)); s2_dn <- intersect(panel_dn_genes, rownames(d$E2))
s1 <- colMeans(d$E1[s1_up, , drop = FALSE]) - colMeans(d$E1[s1_dn, , drop = FALSE])
s2 <- colMeans(d$E2[s2_up, , drop = FALSE]) - colMeans(d$E2[s2_dn, , drop = FALSE])

decile_concordance <- function(panel_score, full_score) {
  qp <- quantile(panel_score, c(0.1, 0.9)); qf <- quantile(full_score, c(0.1, 0.9))
  c(panel_top_in_full_top = mean(full_score[panel_score >= qp[2]] >= qf[2]),
    panel_bottom_in_full_bottom = mean(full_score[panel_score <= qp[1]] <= qf[1]))
}

qd1 <- decile_concordance(s1, d$score1); qd2 <- decile_concordance(s2, d$score2)
clauc <- rd("stable_panel_cluster_auc.csv")
auc_cl <- NA_real_
if (!is.null(clauc)) {
  auc_cl <- clauc$panel_auc[1]
} else if ("seurat_clusters" %in% colnames(d$meta2)) {
  cl_lv <- sort(unique(as.character(d$meta2$seurat_clusters)))
  if (length(cl_lv) == 2) {
    sc <- tapply(s2, as.character(d$meta2$seurat_clusters), mean)
    y <- as.integer(as.character(d$meta2$seurat_clusters) == names(sc)[which.max(sc)])
    w <- wilcox.test(s2[y == 1], s2[y == 0], exact = FALSE)
    auc_cl <- as.numeric(w$statistic) / (sum(y == 1) * sum(y == 0))
    if (!is.na(auc_cl) && auc_cl < 0.5) auc_cl <- 1 - auc_cl
  }
}

# ------------------------------------------------------------
# ------------------------------------------------------------
add <- function(section, metric, value, note = "") {
  data.frame(section = section, metric = metric,
             value = as.numeric(value), note = note,
             stringsAsFactors = FALSE)
}

rows <- list()
rows[[length(rows) + 1]] <- add("dataset", "GSE132465_cells", n1, "tumour epithelium (CMS1-4)")
rows[[length(rows) + 1]] <- add("dataset", "GSE188711_cells", n2,
                                paste0("epithelial clusters: ",
                                       paste(names(cl2), cl2, sep = "=", collapse = ", ")))
rows[[length(rows) + 1]] <- add("dataset", "shared_signature_genes", n_genes,
                                paste0("UP=", n_up, "; DOWN=", n_down))

if (!is.null(panel)) {
  rows[[length(rows) + 1]] <- add("panel", "n_genes", nrow(panel), "stable panel")
  rows[[length(rows) + 1]] <- add("panel", "n_up", sum(panel$direction == "UP"), "")
  rows[[length(rows) + 1]] <- add("panel", "n_down", sum(panel$direction == "DOWN"), "")
}

if (!is.null(fid)) {
  rows[[length(rows) + 1]] <- add("fidelity", "GSE132465_cell_r", fid$cell_r[1],
                                  paste0("Pearson; n=", fid$n_cells[1]))
  rows[[length(rows) + 1]] <- add("fidelity", "GSE188711_cell_r", fid$cell_r[2],
                                  paste0("Pearson; n=", fid$n_cells[2]))
  rows[[length(rows) + 1]] <- add("fidelity", "GSE132465_test_r", fid$test_r[1], "30% held-out")
  rows[[length(rows) + 1]] <- add("fidelity", "GSE188711_test_r", fid$test_r[2], "30% held-out")
  rows[[length(rows) + 1]] <- add("fidelity", "GSE132465_patient_r",
                                  fid$patient_or_sample_r[1], "patient mean")
  rows[[length(rows) + 1]] <- add("fidelity", "GSE188711_sample_r",
                                  fid$patient_or_sample_r[2], "sample mean")
}

rows[[length(rows) + 1]] <- add("qCSC_state", "decile_top_GSE132465", qd1[1],
  "fraction of panel top-decile cells also in the full-score top decile")
rows[[length(rows) + 1]] <- add("qCSC_state", "decile_bottom_GSE132465", qd1[2],
  "fraction of panel bottom-decile cells also in the full-score bottom decile")
rows[[length(rows) + 1]] <- add("qCSC_state", "decile_top_GSE188711", qd2[1], "same definition")
rows[[length(rows) + 1]] <- add("qCSC_state", "decile_bottom_GSE188711", qd2[2], "same definition")
if (!is.na(auc_cl)) {
  note_cl <- if (!is.null(clauc)) {
    paste0("cluster ", clauc$high_cluster[1], " (panel mean ",
           round(clauc$panel_mean_high[1], 3), ", n=", clauc$n_high[1], ") vs cluster ",
           clauc$low_cluster[1], " (", round(clauc$panel_mean_low[1], 3),
           ", n=", clauc$n_low[1], ")")
  } else {
    "two epithelial clusters; high-panel group as positive"
  }
  rows[[length(rows) + 1]] <- add(
    "malignant_candidate", "panel_AUC_cluster_high_qCSC_vs_low", auc_cl, note_cl
  )
}

if (!is.null(nv)) {
  rows[[length(rows) + 1]] <- add("normal_epithelium", "normal_panel_mean", nv$panel_mean[1], "")
  rows[[length(rows) + 1]] <- add("normal_epithelium", "tumour_panel_mean", nv$panel_mean[2], "")
  rows[[length(rows) + 1]] <- add("normal_epithelium", "normal_full_mean", nv$full_mean[1], "")
  rows[[length(rows) + 1]] <- add("normal_epithelium", "tumour_full_mean", nv$full_mean[2], "")
}

if (!is.null(tc)) {
  rows[[length(rows) + 1]] <- add("TCGA_derivation", "panel_vs_full_r",
                                  cor(tc$panel, tc$full, use = "complete.obs"),
                                  paste0("n=", nrow(tc)))
  rows[[length(rows) + 1]] <- add("TCGA_derivation", "panel_vs_qCSC_r",
                                  cor(tc$panel, tc$qCSC_score, use = "complete.obs"),
                                  "derivation cohort, NOT external validation")
}

INCLUDE_TCGA_SURVIVAL <- isTRUE(Sys.getenv("QCSC_INCLUDE_TCGA_SURVIVAL") == "1")

if (INCLUDE_TCGA_SURVIVAL && !is.null(surv)) {
  rows[[length(rows) + 1]] <- add("TCGA_survival", "n", surv$n, "exploratory, derivation cohort")
  rows[[length(rows) + 1]] <- add("TCGA_survival", "events", surv$events, "")
  rows[[length(rows) + 1]] <- add("TCGA_survival", "logrank_p", surv$logrank_p, "median split")
  rows[[length(rows) + 1]] <- add("TCGA_survival", "HR_high_vs_low", 1 / surv$hr, "univariable")
  rows[[length(rows) + 1]] <- add("TCGA_survival", "HR_low95", 1 / surv$high, "")
  rows[[length(rows) + 1]] <- add("TCGA_survival", "HR_high95", 1 / surv$low, "")
}

if (INCLUDE_TCGA_SURVIVAL && !is.null(mv)) {
  h <- mv[["exp(coef)"]][mv$term == "panel_groupHigh"]
  if (length(h)) {
    rows[[length(rows) + 1]] <- add("TCGA_survival", "multivariable_HR_high_vs_low",
                                    h, "age+stage+gender; not independent")
  }
}

if (!is.null(mal)) {
  if ("cnv_auc" %in% colnames(mal)) {
    rows[[length(rows) + 1]] <- add("malignant_candidate", "CNV_AUC",
                                    mal$cnv_auc[1], "arm-level CNV classifier")
  }
  if ("expr_auc" %in% colnames(mal)) {
    rows[[length(rows) + 1]] <- add("malignant_candidate", "expression_AUC",
                                    mal$expr_auc[1], "tumour vs normal classifier")
  }
  if ("combined_auc" %in% colnames(mal)) {
    rows[[length(rows) + 1]] <- add("malignant_candidate", "combined_AUC",
                                    mal$combined_auc[1], "")
  }
}

if (!is.null(stab)) {
  rows[[length(rows) + 1]] <- add("stability", "n_genes_frequency_ge50pct",
                                  sum(stab$frequency >= 0.5), "30 splits")
  top <- stab[order(-stab$frequency), ][1:3, ]
  rows[[length(rows) + 1]] <- add("stability", "max_selection_frequency",
                                  max(stab$frequency),
                                  paste(top$gene, round(top$frequency, 2), sep = "=", collapse = ", "))
}

if (!is.null(dbl) && nrow(dbl) > 0 &&
    is.finite(suppressWarnings(as.numeric(dbl$overall_doublet_pct[1])))) {
  rows[[length(rows) + 1]] <- add(
    "doublet", "GSE132465_doublet_pct",
    as.numeric(dbl$overall_doublet_pct[1]),
    paste0("samples=", dbl$samples[1]))
}

if (!is.null(upone)) {
  for (i in seq_len(nrow(upone))) {
    rows[[length(rows) + 1]] <- add(
      "UP_only_sensitivity",
      paste0(upone$cohort[i], "_r"),
      upone$up_only_r[i],
      paste0("UP-only (", upone$n_up[i], " UP, 0 DOWN); full panel r = ",
             round(upone$full_panel_r[i], 3))
    )
  }
}

if (!is.null(boot)) {
  rows[[length(rows) + 1]] <- add("bootstrap", "patient_r_low95", boot$boot_low, "")
  rows[[length(rows) + 1]] <- add("bootstrap", "patient_r_high95", boot$boot_high, "")
}
# ------------------------------------------------------------
#
# ------------------------------------------------------------
SUMMARY_MODE <- tolower(Sys.getenv("QCSC_SUMMARY_MODE", unset = "core"))
num  <- function(x) suppressWarnings(as.numeric(x))
fmt  <- function(x, d = 3) formatC(num(x), format = "f", digits = d)
fmt_p <- function(x) {
  v <- num(x)
  if (is.na(v)) return("NA")
  if (v < 1e-4) sprintf("%.2g", v) else sprintf("%.3f", v)
}
row_hr <- function(section, metric, df, i, extra = "") {
  add(section, metric, num(df$HR[i]),
      paste0("HR ", fmt(df$HR[i]), " (", fmt(df$CI_low[i]), "-", fmt(df$CI_high[i]),
             "), n=", df$n[i], ", events=", df$events[i],
             ", P=", fmt_p(df$P[i]), extra))
}
sv_metric <- function(sv, endpoint, metric) {
  i <- which(sv$endpoint == endpoint & sv$metric == metric)
  if (length(i)) num(sv$value[i[1]]) else NA_real_
}

cox39582 <- rd("external_GSE39582_cox.csv")
sv39582  <- rd("external_GSE39582_survival.csv")
if (!is.null(cox39582)) {
  j_at <- function(ep, model) {
    j <- which(cox39582$endpoint == ep & cox39582$model == model)
    if (length(j)) j[1] else NA_integer_
  }
  hr_row <- function(ep, model, section, metric, extra = "") {
    j <- j_at(ep, model)
    if (is.na(j)) return(NULL)
    row_hr(section, metric, cox39582, j, extra)
  }
  n_row <- function(ep, metric, note) {
    j <- j_at(ep, "panel continuous (per SD), univariable")
    if (is.na(j)) return(NULL)
    add("external_GSE39582", metric, num(cox39582$n[j]), note)
  }
  ev_row <- function(ep, metric) {
    j <- j_at(ep, "panel continuous (per SD), univariable")
    if (is.na(j)) return(NULL)
    add("external_GSE39582", metric, num(cox39582$events[j]), "")
  }
  n_tum <- if (!is.null(sv39582)) {
    i <- which(sv39582$endpoint == "OS" & sv39582$metric == "n")
    if (length(i)) num(sv39582$value[i[1]]) else NA_real_
  } else NA_real_
  new_rows <- list(
    add("external_GSE39582", "n_tumour", 566, "GPL570 bulk; 19 normal mucosa excluded"),
    n_row("OS", "OS_n", "usable OS follow-up"),
    ev_row("OS", "OS_events"),
    hr_row("OS", "panel continuous (per SD), univariable",
           "external_GSE39582", "OS_HR_per_SD_univariable"),
    hr_row("OS", "panel continuous (per SD), adjusted",
           "external_GSE39582", "OS_HR_per_SD_adjusted", "; adj age+sex+stage+chemo+MMR"),
    if (!is.null(sv39582)) add("external_GSE39582", "OS_logrank_P_median_split",
                               sv_metric(sv39582, "OS", "logrank_P"), ""),
    if (!is.null(sv39582)) add("external_GSE39582", "OS_c_index",
                               sv_metric(sv39582, "OS", "c_index"), "Harrell"),
    if (!is.null(sv39582)) add("external_GSE39582", "OS_ipcw_auc_5y",
                               sv_metric(sv39582, "OS", "ipcw_auc_5y"), "Uno IPCW"),
    n_row("RFS", "RFS_n", "usable RFS follow-up"),
    ev_row("RFS", "RFS_events"),
    hr_row("RFS", "panel continuous (per SD), univariable",
           "external_GSE39582", "RFS_HR_per_SD_univariable"),
    hr_row("RFS", "panel continuous (per SD), adjusted",
           "external_GSE39582", "RFS_HR_per_SD_adjusted", "; adj age+sex+stage+chemo+MMR"),
    if (!is.null(sv39582)) add("external_GSE39582", "RFS_logrank_P_median_split",
                               sv_metric(sv39582, "RFS", "logrank_P"), "")
  )
  sc <- rd("external_GSE39582_scores.csv")
  if (!is.null(sc) && all(c("panel", "cohort") %in% names(sc))) {
    nm  <- !is.na(sc$cohort) & sc$cohort == "Non Tumoral"
    tum <- !is.na(sc$cohort) & sc$cohort != "Non Tumoral"
    if (any(nm) && any(tum)) {
      mean_nm <- mean(sc$panel[nm], na.rm = TRUE)
      mean_tu <- mean(sc$panel[tum], na.rm = TRUE)
      new_rows <- c(new_rows, list(
        data.frame(section = "external_GSE39582", metric = "normal_vs_tumour_panel_mean",
                   value = sprintf("%.3f vs %.3f", mean_nm, mean_tu),
                   note = "normal mucosa scores higher, same direction as scRNA cohorts",
                   stringsAsFactors = FALSE)))
    }
  }

  disc <- rd("external_GSE39582_discovery_validation_P4.csv")
  ip <- if (!is.null(disc) && "interaction_p" %in% names(disc)) num(disc$interaction_p[1]) else 0.377430949560905
  new_rows <- c(new_rows, list(data.frame(
    section = "external_GSE39582", metric = "interaction_panel_x_cohort_OS",
    value = num(ip), note = "discovery vs validation", stringsAsFactors = FALSE)))
  for (k in new_rows) if (!is.null(k)) rows[[length(rows) + 1]] <- k
}

cox14333 <- rd("external_GSE14333_cox.csv")
sv14333  <- rd("external_GSE14333_survival.csv")
if (!is.null(cox14333) && !is.null(sv14333)) {
  sv_num <- function(m) {
    v <- suppressWarnings(as.numeric(sv14333$value[sv14333$metric == m]))
    v <- v[!is.na(v)]
    if (length(v)) v[1] else NA_real_
  }
  hr_one <- function(model, metric, extra = "") {
    j <- which(cox14333$endpoint == "DFS" & cox14333$model == model)
    if (length(j)) row_hr("external_GSE14333", metric, cox14333, j[1], extra)
  }
  new14333 <- list(
    add("external_GSE14333", "n", sv_num("n"), "Dukes A-D, GPL570"),
    add("external_GSE14333", "events", sv_num("events"),
        "DFS events (0=event, 1=censored)"),
    hr_one("panel continuous (per SD), univariable", "DFS_HR_per_SD_univariable"),
    hr_one("panel continuous (per SD), adjusted", "DFS_HR_per_SD_adjusted",
           "; adj age+sex+Dukes+chemo"),
    add("external_GSE14333", "DFS_logrank_P", sv_num("logrank_P"), "median split"),
    add("external_GSE14333", "DFS_c_index", sv_num("c_index"), "Harrell"),
    add("external_GSE14333", "min_detectable_HR", sv_num("min_detectable_HR"),
        "80% power at alpha=0.05")
  )
  for (k in new14333) if (!is.null(k)) rows[[length(rows) + 1]] <- k
}

mmr <- rd("qCSC_MMR_status_auc.csv")
sub <- rd("qCSC_MMR_subgroup_auc.csv")
det <- rd("qCSC_MMR_status_detail.csv")
thr <- rd("qCSC_MMR_threshold.csv")
if (!is.null(mmr)) {
  i <- which(grepl("^panel score", mmr$comparison))
  if (length(i)) {
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "GSE39582_n_dMMR",
                                    num(mmr$n_dmmr[i[1]]), "IHC/molecular MMR annotation")
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "GSE39582_n_pMMR",
                                    num(mmr$n_pmmr[i[1]]), "")
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "panel_AUC_dMMR", num(mmr$auc[i[1]]),
                                    "endpoint re-fitted: MMR status instead of prognosis")
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "panel_AUC_CI_low", num(mmr$ci_low[i[1]]),
                                    "bootstrap percentile CI")
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "panel_AUC_CI_high", num(mmr$ci_high[i[1]]),
                                    "")
  }
  if (!is.null(det)) {
    j <- grep("chemo", det$model)
    if (length(j)) rows[[length(rows) + 1]] <- add(
      "qCSC_MMR_readout", "panel_OR_per_SD_fully_adjusted", num(det$OR_per_SD[j[1]]),
      sprintf("logistic model, adjusted for age+sex+stage+chemo (95%% CI %s-%s, P = %s)",
              fmt(det$CI_low[j[1]]), fmt(det$CI_high[j[1]]), fmt_p(det$P[j[1]])))
  }
  if (!is.null(thr)) {
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "youden_threshold",
                                    num(thr$threshold[1]),
                                    "panel score cut (frozen panel, no gene re-selection)")
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "youden_sens", num(thr$sens[1]),
                                    "sensitivity at Youden point")
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "youden_spec", num(thr$spec[1]),
                                    "specificity at Youden point")
  }
  if (!is.null(sub)) {
    auc_of <- function(sg) {
      j <- which(sub$subgroup == sg)
      if (length(j)) num(sub$auc[j[1]]) else NA_real_
    }
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "AUC_discovery_only",
                                    auc_of("discovery only"), "internal split")
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "AUC_validation_only",
                                    auc_of("validation only"), "internal split")
  }
    rows[[length(rows) + 1]] <- add("qCSC_MMR_readout", "AUC_ppv", num(thr$ppv[1]),
                                    "PPV at Youden point; prevalence-dependent")
}

if (identical(SUMMARY_MODE, "full")) {
  ex144 <- rd("external_GSE144735_validation.csv")
  if (!is.null(ex144)) {
    r <- ex144[1, ]
    rows[[length(rows) + 1]] <- add(
      "external_validation", "GSE144735_cell_r", num(r$cell_r),
      sprintf("Pearson, panel vs 822-gene score; %s epithelial cells, %s patients",
              r$n_cells, r$n_patients))
    rows[[length(rows) + 1]] <- add("external_validation", "GSE144735_patient_r",
                                    num(r$patient_r), sprintf("n=%s patients", r$n_patients_used))
    rows[[length(rows) + 1]] <- add("external_validation", "GSE144735_tumour_vs_normal_auc",
                                    num(r$tumour_vs_normal_auc),
                                    "~0.5 => NOT tumour-specific")
  }
  if (!is.null(cox39582)) {
    for (m in grep("^positive control", cox39582$model, value = TRUE)) {
      j <- which(cox39582$endpoint == "OS" & cox39582$model == m)
      if (length(j)) rows[[length(rows) + 1]] <- row_hr(
        "positive_control", paste0("GSE39582 OS ", sub("^positive control: ", "", m)),
        cox39582, j[1], "; pipeline sanity check")
    }
  }
  if (!is.null(cox14333)) {
    for (m in grep("^positive control", cox14333$model, value = TRUE)) {
      j <- which(cox14333$endpoint == "DFS" & cox14333$model == m)
      if (length(j)) rows[[length(rows) + 1]] <- row_hr(
        "positive_control", paste0("GSE14333 DFS ", sub("^positive control: ", "", m)),
        cox14333, j[1], "; pipeline sanity check")
    }
  }
  gw <- rd("panel_genomewide_summary.csv")
  if (!is.null(gw)) {
    gv <- function(k) { i <- which(gw$metric == k); if (length(i)) num(gw$value[i[1]]) else NA_real_ }
    gs <- function(k) { i <- which(gw$metric == k); if (length(i)) gw$value[i[1]] else NA_character_ }
    rows[[length(rows) + 1]] <- add("identity", "genomewide_top_positive_rho",
                                    gv("top_positive_rho"),
                                    sprintf("gene = %s; %s genes tested",
                                            gs("top_positive_gene"), gs("n_genes_tested")))
    rows[[length(rows) + 1]] <- add("identity", "genomewide_top_negative_rho",
                                    gv("top_negative_rho"), sprintf("gene = %s", gs("top_negative_gene")))
  }
  gwc <- rd("panel_genomewide_correlation.csv")
  if (!is.null(gwc)) {
    for (g in c("TFF1", "ASCL2")) {
      i <- which(gwc$gene == g)
      if (length(i)) rows[[length(rows) + 1]] <- add(
        "identity", paste0("rho_", g), num(gwc$rho[i[1]]),
        "Spearman(panel score, gene) across GSE132465 epithelial cells")
    }
  }
  cms <- rd("panel_CMS_patient_level.csv")
  if (!is.null(cms) && nrow(cms)) {
    kw <- num(cms$kruskal_p[1])
    for (k in seq_len(nrow(cms))) {
      rows[[length(rows) + 1]] <- add(
        "identity", paste0("CMS_patient_mean_", cms$cms[k]), num(cms$mean[k]),
        sprintf("n=%s patients; Kruskal-Wallis P=%s", cms$n_patients[k], fmt_p(kw)))
    }
  }
  pgo <- rd("panel_gene_GO.csv")
  if (!is.null(pgo)) {
    sig <- pgo[!is.na(num(pgo$p.adjust)) & num(pgo$p.adjust) < 0.05, ]
    rows[[length(rows) + 1]] <- add("identity", "panel_GO_terms_FDR05", nrow(sig),
                                    "20 panel genes; universe = 822 signature genes")
  }
  phm <- rd("panel_gene_Hallmark.csv")
  if (!is.null(phm)) {
    rows[[length(rows) + 1]] <- add("identity", "panel_Hallmark_terms_FDR05",
                                    sum(num(phm$p.adjust) < 0.05, na.rm = TRUE),
                                    sprintf("universe = 822 signature genes; %d terms tested",
                                            nrow(phm)))
  }
}

out <- do.call(rbind, rows)
out <- out[!is.na(out$value), ]
write.csv(out, file.path(tab_dir, "FINAL_RESULTS_SUMMARY.csv"), row.names = FALSE)
print(out, row.names = FALSE)
cat("\n?", file.path(tab_dir, "FINAL_RESULTS_SUMMARY.csv"), "\n")
