## ===========================================================================
## singlecell_clinical/05c_panel_annotation.R
## Biological annotation of the panel: gene-level ORA, genome-wide gene
## correlation and CMS distribution.
## ===========================================================================
# ============================================================
# 09b_panel_annotation_enrichment.R
#
#
#
#   tables/panel_20_direction_vector.csv
#   intermediate/two_cohort_panel/panel_data.rds
#
#   tables/panel_gene_GO.csv
#   tables/panel_gene_Hallmark.csv
#   tables/panel_score_correlation_GO.csv
#   tables/panel_CMS_association.csv
#   figures/Fig15_panel_CMS_and_annotation.png / .pdf
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(msigdbr)
  library(ggplot2)
})

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
panel_dir <- file.path(QCSC_PROJECT_DIR, "intermediate", "two_cohort_panel")

# ------------------------------------------------------------
# ------------------------------------------------------------
dv <- read.csv(file.path(tab_dir, "panel_20_direction_vector.csv"),
               check.names = FALSE, stringsAsFactors = FALSE)
dv$gene <- toupper(dv$gene)
up_genes   <- dv$gene[dv$direction == "UP"]
down_genes <- dv$gene[dv$direction == "DOWN"]
panel_genes <- c(up_genes, down_genes)
cat(sprintf("Panel: %d UP + %d DOWN = %d\n",
            length(up_genes), length(down_genes), length(panel_genes)))

d <- readRDS(file.path(panel_dir, "panel_data.rds"))
E1 <- d$E1; meta1 <- d$meta1; genes822 <- toupper(rownames(E1))
cat(sprintf("E1: %d genes x %d cells\n", nrow(E1), ncol(E1)))

# ------------------------------------------------------------
# ------------------------------------------------------------
pg <- intersect(panel_genes, genes822)
if (length(pg) < length(panel_genes)) {
  warning("The following panel genes are absent from E1: ",
          paste(setdiff(panel_genes, genes822), collapse = ", "))
}
pg_up <- intersect(up_genes,   genes822)
pg_dn <- intersect(down_genes, genes822)
cat(sprintf("panel score genes: %d UP + %d DOWN\n", length(pg_up), length(pg_dn)))
panel_score <- colMeans(E1[pg_up, , drop = FALSE]) - colMeans(E1[pg_dn, , drop = FALSE])
cat(sprintf("Panel score: mean %.4f, sd %.4f, range %.3f to %.3f\n",
            mean(panel_score), sd(panel_score), min(panel_score), max(panel_score)))

# ------------------------------------------------------------
# ------------------------------------------------------------
gene_df <- bitr(panel_genes, fromType = "SYMBOL", toType = "ENTREZID",
                OrgDb = org.Hs.eg.db)
univ_df <- bitr(genes822, fromType = "SYMBOL", toType = "ENTREZID",
                OrgDb = org.Hs.eg.db)
cat(sprintf("Mapped: %d/%d panel genes, %d/%d universe genes\n",
            nrow(gene_df), length(panel_genes), nrow(univ_df), length(genes822)))

go_res <- NULL
for (ont in c("BP", "CC", "MF")) {
  r <- try(enrichGO(gene = gene_df$ENTREZID, universe = univ_df$ENTREZID,
                    OrgDb = org.Hs.eg.db, ont = ont, keyType = "ENTREZID",
                    pAdjustMethod = "BH", pvalueCutoff = 0.5,
                    qvalueCutoff = 0.5, minGSSize = 5, maxGSSize = 500,
                    readable = TRUE), silent = TRUE)
  if (inherits(r, "try-error") || is.null(r) || nrow(as.data.frame(r)) == 0) next
  df <- as.data.frame(r)
  df$ontology <- ont
  go_res <- rbind(go_res, df)
}
if (!is.null(go_res)) {
  go_res <- go_res[order(go_res$p.adjust), ]
  keep <- c("ontology", "ID", "Description", "GeneRatio", "BgRatio",
            "pvalue", "p.adjust", "qvalue", "geneID", "Count")
  go_res <- go_res[, keep]
  go_res$pvalue <- signif(go_res$pvalue, 3)
  go_res$p.adjust <- signif(go_res$p.adjust, 3)
  write.csv(go_res, file.path(tab_dir, "panel_gene_GO.csv"), row.names = FALSE)
  cat(sprintf("\nGO terms (p.adjust < 0.05): %d\n", sum(go_res$p.adjust < 0.05)))
  print(head(go_res[go_res$p.adjust < 0.05, c("ontology", "Description", "p.adjust", "Count")], 12),
        row.names = FALSE)
} else {
  cat("
GO: no result
")
}

get_h <- function() {
  a <- try(msigdbr(species = "Homo sapiens", collection = "H"), silent = TRUE)
  if (!inherits(a, "try-error") && !is.null(a) && nrow(a)) return(a)
  b <- try(msigdbr(species = "Homo sapiens", category = "H"), silent = TRUE)
  if (!inherits(b, "try-error") && !is.null(b) && nrow(b)) return(b)
  NULL
}
hm <- get_h()
hm_res <- NULL
if (!is.null(hm)) {
  gs_col <- if ("gene_symbol" %in% names(hm)) "gene_symbol" else "human_gene_symbol"
  set_col <- if ("gs_name" %in% names(hm)) "gs_name" else "gs_collection_name"
  term2gene <- unique(data.frame(term = hm[[set_col]], gene = hm[[gs_col]]))
  r <- try(enricher(panel_genes, TERM2GENE = term2gene, universe = genes822,
                    pAdjustMethod = "BH", pvalueCutoff = 0.5, qvalueCutoff = 0.5,
                    minGSSize = 5, maxGSSize = 500), silent = TRUE)
  if (!inherits(r, "try-error") && !is.null(r) && nrow(as.data.frame(r)) > 0) {
    hm_res <- as.data.frame(r)
    hm_res <- hm_res[order(hm_res$p.adjust), ]
    hm_res$pvalue <- signif(hm_res$pvalue, 3)
    hm_res$p.adjust <- signif(hm_res$p.adjust, 3)
    write.csv(hm_res, file.path(tab_dir, "panel_gene_Hallmark.csv"), row.names = FALSE)
    cat(sprintf("\nHallmark sets (p.adjust < 0.05): %d\n", sum(hm_res$p.adjust < 0.05)))
    print(head(hm_res[hm_res$p.adjust < 0.05, c("ID", "p.adjust", "Count")], 10),
          row.names = FALSE)
  } else cat("
Hallmark: no result
")
} else cat("
Hallmark: msigdbr retrieval failed
")

# ------------------------------------------------------------
# ------------------------------------------------------------
cors <- apply(E1, 1, function(v) {
  if (sd(v) == 0) return(NA_real_)
  cor(v, panel_score, method = "spearman")
})
cor_df <- data.frame(gene = genes822, rho = as.numeric(cors),
                     stringsAsFactors = FALSE)
cor_df$is_panel <- cor_df$gene %in% panel_genes
cor_df <- cor_df[order(-cor_df$rho), ]
write.csv(cor_df, file.path(tab_dir, "panel_score_gene_correlation.csv"), row.names = FALSE)
cor_rank <- cor_df[!cor_df$is_panel & !is.na(cor_df$rho), ]
cat(sprintf("Correlation with panel score (panel genes excluded, n = %d): top %s (rho %.2f), bottom %s (rho %.2f)\n",
            nrow(cor_rank), cor_rank$gene[1], cor_rank$rho[1],
            cor_rank$gene[nrow(cor_rank)], cor_rank$rho[nrow(cor_rank)]))

top_up <- head(cor_rank$gene, 100)
top_dn <- tail(cor_rank$gene, 100)
cor_go <- NULL
for (direction in c("positive", "negative")) {
  gl <- if (direction == "positive") top_up else top_dn
  e <- bitr(gl, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  r <- try(enrichGO(gene = e$ENTREZID, universe = univ_df$ENTREZID,
                    OrgDb = org.Hs.eg.db, ont = "BP", keyType = "ENTREZID",
                    pAdjustMethod = "BH", pvalueCutoff = 0.5, qvalueCutoff = 0.5,
                    minGSSize = 10, maxGSSize = 500, readable = TRUE), silent = TRUE)
  if (inherits(r, "try-error") || is.null(r) || nrow(as.data.frame(r)) == 0) next
  df <- as.data.frame(r)
  df$direction <- direction
  cor_go <- rbind(cor_go, df)
}
if (!is.null(cor_go)) {
  cor_go <- cor_go[order(cor_go$direction, cor_go$p.adjust), ]
  keep <- c("direction", "ID", "Description", "GeneRatio", "BgRatio",
            "pvalue", "p.adjust", "geneID", "Count")
  cor_go <- cor_go[, keep]
  cor_go$pvalue <- signif(cor_go$pvalue, 3)
  cor_go$p.adjust <- signif(cor_go$p.adjust, 3)
  write.csv(cor_go, file.path(tab_dir, "panel_score_correlation_GO.csv"), row.names = FALSE)
  cat("\n--- GO for genes correlated with panel score (BP, p.adjust<0.05) ---\n")
  for (dir in c("positive", "negative")) {
    s <- cor_go[cor_go$direction == dir & cor_go$p.adjust < 0.05, ]
    cat(sprintf("\n[%s] %d terms\n", dir, nrow(s)))
    if (nrow(s)) print(head(s[, c("Description", "p.adjust", "Count")], 8), row.names = FALSE)
  }
}

# ------------------------------------------------------------
# ------------------------------------------------------------
cms <- as.character(meta1$Cell_subtype)
ok  <- !is.na(cms) & cms != ""
cat("\n--- CMS cell counts ---\n"); print(table(cms[ok]))

big <- names(which(table(cms[ok]) >= 100))
cat("CMS groups used for testing:", paste(big, collapse = ", "), "\n")
sub <- data.frame(cms = cms[ok], score = panel_score[ok])
sub <- sub[sub$cms %in% big, ]
kw <- kruskal.test(score ~ cms, data = sub)
cat(sprintf("Kruskal-Wallis chi2 = %.2f, df = %d, P = %s\n",
            kw$statistic, kw$parameter, format.pval(kw$p.value, digits = 3)))

agg <- aggregate(score ~ cms, data = sub,
                 FUN = function(x) c(n = length(x), mean = mean(x), sd = sd(x),
                                     median = median(x)))
agg <- data.frame(cms = agg$cms, agg$score)
pw <- pairwise.wilcox.test(sub$score, sub$cms, p.adjust.method = "BH", exact = FALSE)
pw_df <- as.data.frame(as.table(pw$p.value))
pw_df <- pw_df[!is.na(pw_df$Freq), ]
names(pw_df) <- c("group1", "group2", "p_adjusted")

cms_df <- agg
cms_df$kruskal_p <- kw$p.value
write.csv(cms_df, file.path(tab_dir, "panel_CMS_association.csv"), row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
pw_df$note <- "CELL-LEVEL (pseudo-replication); DO NOT CITE; use panel_CMS_patient_pairwise.csv"
write.csv(pw_df,
          file.path(tab_dir, "panel_CMS_cell_pairwise_DO_NOT_CITE.csv"),
          row.names = FALSE)
cat("\n--- panel score by CMS (cell level; NOTE pseudo-replication) ---\n")
print(cms_df, row.names = FALSE)
cat("\n--- pairwise (BH, CELL-LEVEL; not for citation) ---\n"); print(pw_df, row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
pat <- as.character(meta1$Patient)
keep_p <- !is.na(pat) & pat != "" & cms %in% c("CMS1", "CMS2", "CMS3")
pat_df <- data.frame(patient = pat[keep_p], cms = cms[keep_p],
                     score = panel_score[keep_p], stringsAsFactors = FALSE)
pat_agg <- aggregate(score ~ patient + cms, data = pat_df, FUN = mean)
pat_n   <- aggregate(score ~ patient + cms, data = pat_df, FUN = length)
pat_agg$n_cells <- pat_n$score
cat(sprintf("\nPatients with CMS1-3: %d\n", nrow(pat_agg)))
print(table(pat_agg$cms))

if (length(unique(pat_agg$cms)) >= 2 && nrow(pat_agg) >= 6) {
  kw_p <- kruskal.test(score ~ cms, data = pat_agg)
  cat(sprintf("Patient-level Kruskal-Wallis: chi2 = %.2f, df = %d, P = %s\n",
              kw_p$statistic, kw_p$parameter, format.pval(kw_p$value, digits = 3)))
  pat_sum <- aggregate(score ~ cms, data = pat_agg,
                       FUN = function(x) c(n_patients = length(x), mean = mean(x), sd = sd(x)))
  pat_sum <- data.frame(cms = pat_sum$cms, pat_sum$score)
  pat_sum$kruskal_p <- kw_p$p.value
  write.csv(pat_sum, file.path(tab_dir, "panel_CMS_patient_level.csv"), row.names = FALSE)
  cat("\n--- patient-level panel score by CMS ---\n"); print(pat_sum, row.names = FALSE)
  pat_pw <- try(pairwise.wilcox.test(pat_agg$score, pat_agg$cms,
                                     p.adjust.method = "BH", exact = FALSE), silent = TRUE)
  if (!inherits(pat_pw, "try-error")) {
    pw2 <- as.data.frame(as.table(pat_pw$p.value))
    pw2 <- pw2[!is.na(pw2$Freq), ]
    names(pw2) <- c("group1", "group2", "p_adjusted_patient")
    write.csv(pw2, file.path(tab_dir, "panel_CMS_patient_pairwise.csv"), row.names = FALSE)
    cat("\n--- patient-level pairwise (BH) ---\n"); print(pw2, row.names = FALSE)
  }
} else {
  cat("Too few patients; skipping the patient-level test
")
}

# ------------------------------------------------------------
# ------------------------------------------------------------
gw_go_file <- file.path(tab_dir, "panel_genomewide_GO.csv")
gene_go_file <- file.path(tab_dir, "panel_gene_GO.csv")
hall_file <- file.path(tab_dir, "panel_gene_Hallmark.csv")

gw_go <- if (file.exists(gw_go_file)) read.csv(gw_go_file, stringsAsFactors = FALSE) else NULL
gene_go <- if (file.exists(gene_go_file)) read.csv(gene_go_file, stringsAsFactors = FALSE) else NULL
hall <- if (file.exists(hall_file)) read.csv(hall_file, stringsAsFactors = FALSE) else NULL
if (is.null(gw_go)) {
  warning("panel_genomewide_GO.csv is missing (run 06a first); the right-hand side of Fig. 15 falls back to the 822-gene subset, which is weaker evidence")
}

go_panel <- function(df, direction, n = 8) {
  if (is.null(df)) return(NULL)
  s <- df[df$direction == direction & !is.na(df$p.adjust) & df$p.adjust < 0.05, , drop = FALSE]
  if (!nrow(s)) return(NULL)
  s <- s[order(s$p.adjust), ]
  head(s, n)
}

draw <- function() {
  par(mfrow = c(1, 3), mar = c(4.4, 4.8, 3.6, 1.2), mgp = c(2.6, 0.7, 0))
  kw_lab <- if (exists("kw_p")) kw_p$value else kw$p.value
  boxplot(score ~ cms, data = sub, outline = FALSE, las = 1,
          col = c("#FDD0A2", "#A1D99B", "#9ECAE1"),
          xlab = "CMS subtype", ylab = "qCSC panel score (per cell)",
          main = sprintf("Panel score across CMS\npatient-level KW P = %s",
                         format.pval(kw_lab, digits = 2)))
  stripchart(score ~ cms, data = sub, vertical = TRUE, method = "jitter",
             pch = 16, cex = 0.15, col = rgb(0, 0, 0, 0.12), add = TRUE)

  neg <- if (!is.null(gw_go)) go_panel(gw_go, "negative", 8) else go_panel(cor_go, "negative", 8)
  src_lab <- if (!is.null(gw_go)) "genome-wide (25,775 genes)" else "822-gene subset"
  if (!is.null(neg) && nrow(neg)) {
    d2 <- neg[rev(seq_len(nrow(neg))), ]
    lab <- ifelse(nchar(d2$Description) > 42,
                  paste0(substr(d2$Description, 1, 39), "..."), d2$Description)
    par(mar = c(4.4, 14, 3.6, 1.2))
    barplot(-log10(d2$p.adjust), names.arg = lab, horiz = TRUE, las = 1,
            col = "#D95F0E", border = NA, cex.names = 0.7,
            xlab = "-log10(adjusted P)",
            main = sprintf("GO BP negatively associated\nwith panel score (%s)", src_lab))
    abline(v = -log10(0.05), lty = 2, col = "grey40")
  } else {
    plot.new(); title(main = "GO: no term reached P < 0.05")
  }

  cc <- if (!is.null(gene_go)) {
    x <- gene_go[gene_go$ontology == "CC" & !is.na(gene_go$p.adjust) & gene_go$p.adjust < 0.05, ,
                 drop = FALSE]
    x[order(x$p.adjust), , drop = FALSE]
  } else NULL
  n_hall_sig <- if (!is.null(hall)) sum(as.numeric(hall$p.adjust) < 0.05, na.rm = TRUE) else NA
  if (!is.null(cc) && nrow(cc)) {
    d3 <- cc[rev(seq_len(nrow(cc))), ]
    lab3 <- ifelse(nchar(d3$Description) > 38,
                   paste0(substr(d3$Description, 1, 35), "..."), d3$Description)
    par(mar = c(4.4, 14, 3.6, 1.2))
    barplot(-log10(d3$p.adjust), names.arg = lab3, horiz = TRUE, las = 1,
            col = "#3182BD", border = NA, cex.names = 0.7,
            xlab = "-log10(adjusted P)", xlim = c(0, max(3.5, -log10(min(d3$p.adjust)) * 1.25)),
            main = sprintf("20 panel genes: GO-CC only\nBP/MF and Hallmark: 0 significant (FDR 5%%)"))
    abline(v = -log10(0.05), lty = 2, col = "grey40")
    legend("bottomright", bty = "n", cex = 0.6,
           legend = sprintf("Hallmark terms tested: %d, significant: %s",
                            if (is.null(hall)) NA else nrow(hall), n_hall_sig))
  } else {
    plot.new(); title(main = "20 panel genes: no GO-CC term at P < 0.05")
  }
}
png(file.path(fig_dir, "Fig15_panel_CMS_and_annotation.png"),
    width = 4200, height = 1800, res = 300)
draw(); dev.off()
pdf(file.path(fig_dir, "Fig15_panel_CMS_and_annotation.pdf"), width = 14, height = 6)
draw(); dev.off()

cat("\nWritten:\n",
    file.path(tab_dir, "panel_gene_GO.csv"), "\n",
    file.path(tab_dir, "panel_CMS_association.csv"), "\n",
    file.path(tab_dir, "panel_score_correlation_GO.csv"), "\n",
    file.path(fig_dir, "Fig15_panel_CMS_and_annotation.png"), "\n")
