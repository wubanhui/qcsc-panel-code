## ===========================================================================
## figures/08c_Fig3_normal_tumour.R
## Figure 3A and 3B: normal versus tumour epithelium, including the paired
## patient-level line plot.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

############################################################
#
#
#
#
#
#   Fig5_Normal_vs_Tumour_Violin.pdf
#   Fig5_Normal_vs_Tumour_Violin.png
#   Fig5_paired_patient_scores.csv
#   Fig5_paired_statistics.csv
#   Fig5_matched_cell_level_scores.csv
#   Fig5_test_method.txt
############################################################


############################
############################

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})


############################
############################


panel_dir <- file.path(
  QCSC_PROJECT_DIR,
  "intermediate",
  "two_cohort_panel"
)

fig_dir <- FIG_DIR

dir.create(
  fig_dir,
  showWarnings = FALSE,
  recursive = TRUE
)


############################
############################

files <- c(
  
  panel_data = file.path(
    panel_dir,
    "panel_data.rds"
  ),
  
  normal_expr_sig = file.path(
    QCSC_PROJECT_DIR,
    "normal_expr_sig.rds"
  ),
  
  final_stable_panel = file.path(
    QCSC_PROJECT_DIR,
    "final_stable_panel.rds"
  )
)

for (nm in names(files)) {
  
  if (!file.exists(files[[nm]])) {
    stop(
      "File does not exist: ",
      files[[nm]]
    )
  }
  
  cat(
    sprintf(
      "%-22s OK\n",
      nm
    )
  )
}

d  <- readRDS(files[["panel_data"]])
nv <- readRDS(files[["normal_expr_sig"]])
fp <- readRDS(files[["final_stable_panel"]])


############################
############################

required_d <- c(
  "E1",
  "score1",
  "up_use",
  "down_use",
  "meta1"
)

required_nv <- c(
  "expr",
  "meta"
)

if (!all(required_d %in% names(d))) {
  stop(
    "panel_data.rds is missing objects: ",
    paste(
      setdiff(required_d, names(d)),
      collapse = ", "
    )
  )
}

if (!all(required_nv %in% names(nv))) {
  stop(
    "normal_expr_sig.rds is missing objects: ",
    paste(
      setdiff(required_nv, names(nv)),
      collapse = ", "
    )
  )
}

if (is.null(fp$stable)) {
  stop("final_stable_panel.rds is missing fp$stable.")
}

if (is.null(d$meta1$Patient)) {
  stop("The tumour metadata has no Patient column.")
}

if (is.null(nv$meta$Patient)) {
  stop("The normal metadata has no Patient column.")
}


############################
############################

if (is.null(rownames(d$E1)) ||
    is.null(colnames(d$E1))) {
  stop("The tumour expression matrix has no row or column names.")
}

if (is.null(rownames(nv$expr)) ||
    is.null(colnames(nv$expr))) {
  stop("The normal expression matrix has no row or column names.")
}

if (anyDuplicated(rownames(d$E1)) ||
    anyDuplicated(rownames(nv$expr))) {
  stop("Duplicated gene names in the expression matrix; please check.")
}

if (anyDuplicated(colnames(d$E1)) ||
    anyDuplicated(colnames(nv$expr))) {
  stop("Duplicated cell names in the expression matrix; please check.")
}


############################
############################

align_metadata <- function(meta, cell_names, label) {
  
  meta <- as.data.frame(meta)
  
  if (is.null(rownames(meta))) {
    stop(
      label,
      " metadata has no row names; cells cannot be matched safely."
    )
  }
  
  if (anyDuplicated(rownames(meta))) {
    stop(
      label,
      " metadata has duplicated row names."
    )
  }
  
  if (!setequal(rownames(meta), cell_names)) {
    stop(
      label,
      " metadata row names do not match the expression matrix columns; ",
      "falling back to the original order is not allowed."
    )
  }
  
  meta <- meta[
    match(cell_names, rownames(meta)),
    ,
    drop = FALSE
  ]
  
  if (!identical(rownames(meta), cell_names)) {
    stop(label, " metadata and the expression matrix could not be fully aligned.")
  }
  
  meta
}

meta_tumor <- align_metadata(
  d$meta1,
  colnames(d$E1),
  "Tumour"
)

meta_normal <- align_metadata(
  nv$meta,
  colnames(nv$expr),
  "Normal"
)

if (anyNA(meta_tumor$Patient) ||
    anyNA(meta_normal$Patient)) {
  stop("Missing values in the Patient column.")
}

meta_tumor$Patient <- as.character(
  meta_tumor$Patient
)

meta_normal$Patient <- as.character(
  meta_normal$Patient
)


############################
############################

stable_up <- intersect(
  fp$stable,
  d$up_use
)

stable_dn <- intersect(
  fp$stable,
  d$down_use
)

if (length(stable_up) != 17 ||
    length(stable_dn) != 3) {
  
  stop(
    "Unexpected panel composition: UP=",
    length(stable_up),
    "), DOWN=",
    length(stable_dn)
  )
}

cat("\n20-gene panel:\n")
cat("UP:", length(stable_up), "\n")
cat("DOWN:", length(stable_dn), "\n")


############################
############################

full_up <- d$up_use
full_dn <- d$down_use

if (length(full_up) != 738 ||
    length(full_dn) != 84) {
  stop(
    "The full gene axis does not have the expected composition: ",
    "UP=", length(full_up),
    "), DOWN=", length(full_dn)
  )
}

required_full <- c(
  full_up,
  full_dn
)

missing_normal_full <- setdiff(
  required_full,
  rownames(nv$expr)
)

if (length(missing_normal_full) > 0) {
  stop(
    "The normal expression matrix is missing full-axis genes: ",
    paste(
      missing_normal_full,
      collapse = ", "
    )
  )
}

missing_normal_panel <- setdiff(
  c(stable_up, stable_dn),
  rownames(nv$expr)
)

if (length(missing_normal_panel) > 0) {
  stop(
    "The normal expression matrix is missing panel genes: ",
    paste(
      missing_normal_panel,
      collapse = ", "
    )
  )
}

missing_tumor_panel <- setdiff(
  c(stable_up, stable_dn),
  rownames(d$E1)
)

if (length(missing_tumor_panel) > 0) {
  stop(
    "The tumour expression matrix is missing panel genes: ",
    paste(
      missing_tumor_panel,
      collapse = ", "
    )
  )
}


############################
############################

s1_tumor <- colMeans(
  d$E1[stable_up, , drop = FALSE]
) -
  colMeans(
    d$E1[stable_dn, , drop = FALSE]
  )

f1_tumor <- d$score1


############################
############################

s1_normal <- colMeans(
  nv$expr[stable_up, , drop = FALSE]
) -
  colMeans(
    nv$expr[stable_dn, , drop = FALSE]
  )

f1_normal <- colMeans(
  nv$expr[full_up, , drop = FALSE]
) -
  colMeans(
    nv$expr[full_dn, , drop = FALSE]
  )


############################
############################

stopifnot(
  length(s1_tumor) == ncol(d$E1),
  length(f1_tumor) == ncol(d$E1),
  length(s1_normal) == ncol(nv$expr),
  length(f1_normal) == ncol(nv$expr)
)

all_scores <- c(
  s1_tumor,
  f1_tumor,
  s1_normal,
  f1_normal
)

if (any(!is.finite(all_scores))) {
  stop("The scores contain NA, NaN or Inf.")
}

full_recalculated <- colMeans(
  d$E1[full_up, , drop = FALSE]
) -
  colMeans(
    d$E1[full_dn, , drop = FALSE]
  )

full_difference <- max(
  abs(full_recalculated - f1_tumor)
)

cat(
  "\nFull score recalculation difference:",
  full_difference,
  "\n"
)

if (full_difference > 1e-8) {
  stop("Recomputing the full axis in the tumour cells does not reproduce the original score.")
}


############################
############################

patients_normal <- unique(
  meta_normal$Patient
)

patients_tumor <- unique(
  meta_tumor$Patient
)

paired_patients <- sort(
  intersect(
    patients_normal,
    patients_tumor
  )
)

cat("\nMatched patients:\n")
cat(
  paste(
    paired_patients,
    collapse = ", "
  ),
  "\n"
)

if (length(paired_patients) != 10) {
  stop(
    "Expected 10 paired patients, found ",
    length(paired_patients),
    " Please re-check the patient IDs."
  )
}


############################
############################

keep_normal <- meta_normal$Patient %in%
  paired_patients

keep_tumor <- meta_tumor$Patient %in%
  paired_patients

normal_full_matched <- f1_normal[keep_normal]
normal_panel_matched <- s1_normal[keep_normal]

tumor_full_matched <- f1_tumor[keep_tumor]
tumor_panel_matched <- s1_tumor[keep_tumor]

normal_patient_matched <- meta_normal$Patient[
  keep_normal
]

tumor_patient_matched <- meta_tumor$Patient[
  keep_tumor
]

cat("\nMatched cells:\n")
cat("Normal:", length(normal_full_matched), "\n")
cat("Tumour:", length(tumor_full_matched), "\n")

## Cell-level means restricted to the matched (paired) cells, reported next to
## the cohort-wide means so that the two summaries can be compared directly.
cat(sprintf("Matched-cell means full : normal %.4f  tumour %.4f\n",
            mean(normal_full_matched), mean(tumor_full_matched)))
cat(sprintf("Matched-cell means panel: normal %.4f  tumour %.4f\n",
            mean(normal_panel_matched), mean(tumor_panel_matched)))


############################
############################

patient_mean <- function(score, patient) {
  
  result <- tapply(
    score,
    patient,
    mean
  )
  
  result
}

pat_normal_full <- patient_mean(
  normal_full_matched,
  normal_patient_matched
)

pat_tumor_full <- patient_mean(
  tumor_full_matched,
  tumor_patient_matched
)

pat_normal_panel <- patient_mean(
  normal_panel_matched,
  normal_patient_matched
)

pat_tumor_panel <- patient_mean(
  tumor_panel_matched,
  tumor_patient_matched
)


############################
############################

pat_normal_full <- pat_normal_full[
  paired_patients
]

pat_tumor_full <- pat_tumor_full[
  paired_patients
]

pat_normal_panel <- pat_normal_panel[
  paired_patients
]

pat_tumor_panel <- pat_tumor_panel[
  paired_patients
]

patient_scores <- c(
  pat_normal_full,
  pat_tumor_full,
  pat_normal_panel,
  pat_tumor_panel
)

if (any(!is.finite(patient_scores))) {
  stop("Patient-level scores contain missing or non-finite values.")
}


############################
############################

diff_full <- pat_normal_full -
  pat_tumor_full

diff_panel <- pat_normal_panel -
  pat_tumor_panel

if (any(diff_full == 0) ||
    any(diff_panel == 0)) {
  
  warning(
    "Some paired differences are zero; the Wilcoxon test uses the valid non-zero differences."
  )
}


############################
############################

check_exact <- function(x) {
  
  x <- x[is.finite(x)]
  
  x <- x[x != 0]
  
  no_zero <- length(x) > 0
  
  no_ties <- !anyDuplicated(abs(x))
  
  list(
    no_zero = no_zero,
    no_ties = no_ties,
    exact_available = no_zero && no_ties
  )
}

run_paired_wilcox <- function(x, y, label) {
  
  difference <- x - y
  
  chk <- check_exact(difference)
  
  if (chk$exact_available) {
    
    method_used <- "Exact paired Wilcoxon signed-rank test"
    
    test <- wilcox.test(
      x,
      y,
      paired = TRUE,
      alternative = "two.sided",
      exact = TRUE,
      conf.int = FALSE
    )
    
  } else {
    
    method_used <- paste(
      "Paired Wilcoxon signed-rank test",
      "(normal approximation; ties or zero differences)"
    )
    
    test <- wilcox.test(
      x,
      y,
      paired = TRUE,
      alternative = "two.sided",
      exact = FALSE,
      correct = TRUE,
      conf.int = FALSE
    )
  }
  
  list(
    test = test,
    p = test$p.value,
    method = method_used,
    difference = difference
  )
}

res_full <- run_paired_wilcox(
  pat_normal_full,
  pat_tumor_full,
  "Full"
)

res_panel <- run_paired_wilcox(
  pat_normal_panel,
  pat_tumor_panel,
  "Panel"
)

p_full <- res_full$p
p_panel <- res_panel$p

cat("\n============================\n")
cat("Paired Wilcoxon results\n")
cat("============================\n")

cat(
  "Full P = ",
  format.pval(p_full, digits = 5),
  "\n"
)

cat(
  "Panel P = ",
  format.pval(p_panel, digits = 5),
  "\n"
)

cat(
  "Full method:",
  res_full$method,
  "\n"
)

cat(
  "Panel method:",
  res_panel$method,
  "\n"
)


############################
############################

paired_result <- data.frame(
  
  Patient = paired_patients,
  
  Normal_Full = as.numeric(pat_normal_full),
  
  Tumour_Full = as.numeric(pat_tumor_full),
  
  Difference_Full = as.numeric(diff_full),
  
  Normal_Panel = as.numeric(pat_normal_panel),
  
  Tumour_Panel = as.numeric(pat_tumor_panel),
  
  Difference_Panel = as.numeric(diff_panel),
  
  stringsAsFactors = FALSE
)

write.csv(
  paired_result,
  file.path(
    TAB_DIR,
    "Fig5_paired_patient_scores.csv"
  ),
  row.names = FALSE
)


############################
############################

stat_result <- data.frame(
  
  Score = c(
    "Full 822-gene score",
    "20-gene panel score"
  ),
  
  Paired_patients = length(paired_patients),
  
  Normal_cells = length(normal_full_matched),
  
  Tumour_cells = length(tumor_full_matched),
  
  Normal_median = c(
    median(pat_normal_full),
    median(pat_normal_panel)
  ),
  
  Tumour_median = c(
    median(pat_tumor_full),
    median(pat_tumor_panel)
  ),
  
  Median_paired_difference = c(
    median(diff_full),
    median(diff_panel)
  ),
  
  Normal_higher_n = c(
    sum(diff_full > 0),
    sum(diff_panel > 0)
  ),
  
  P_value = c(
    p_full,
    p_panel
  ),
  
  Test_method = c(
    res_full$method,
    res_panel$method
  ),
  
  stringsAsFactors = FALSE
)

write.csv(
  stat_result,
  file.path(
    fig_dir,
    "Fig5_paired_statistics.csv"
  ),
  row.names = FALSE
)


############################
############################

df_normal <- data.frame(
  
  Group = "Normal epithelium",
  
  Patient = normal_patient_matched,
  
  Full_Score = normal_full_matched,
  
  Panel_Score = normal_panel_matched,
  
  stringsAsFactors = FALSE
)

df_tumor <- data.frame(
  
  Group = "Tumour epithelium",
  
  Patient = tumor_patient_matched,
  
  Full_Score = tumor_full_matched,
  
  Panel_Score = tumor_panel_matched,
  
  stringsAsFactors = FALSE
)

df_plot <- rbind(
  df_normal,
  df_tumor
)

df_plot$Group <- factor(
  df_plot$Group,
  levels = c(
    "Normal epithelium",
    "Tumour epithelium"
  )
)


############################
############################

write.csv(
  df_plot,
  file.path(
    fig_dir,
    "Fig5_matched_cell_level_scores.csv"
  ),
  row.names = FALSE
)


############################
############################

my_cols <- c(
  
  "Normal epithelium" = "#35BFA3",
  
  "Tumour epithelium" = "#F07868"
)

fmt_p <- function(p) {
  
  if (is.na(p)) {
    return("P = NA")
  }
  
  if (p < 0.001) {
    return("P < 0.001")
  }
  
  paste0(
    "P = ",
    format.pval(
      p,
      digits = 2,
      eps = 0.001
    )
  )
}


############################
############################

make_violin <- function(
    data,
    y_col,
    y_label,
    p_value
) {
  
  dd <- data[
    is.finite(data[[y_col]]) &
      !is.na(data$Group),
    ,
    drop = FALSE
  ]
  
  yr <- range(
    dd[[y_col]],
    na.rm = TRUE
  )
  
  y_range <- diff(yr)
  
  if (!is.finite(y_range) || y_range == 0) {
    y_range <- max(abs(yr), 1)
  }
  
  y_top <- yr[2] + y_range * 0.13
  
  ggplot(
    dd,
    aes(
      x = Group,
      y = .data[[y_col]],
      fill = Group
    )
  ) +
    
    geom_violin(
      trim = TRUE,
      scale = "width",
      width = 0.78,
      color = "white",
      linewidth = 0.65,
      alpha = 0.90
    ) +
    
    geom_boxplot(
      width = 0.105,
      outlier.shape = NA,
      fill = "white",
      color = "#505050",
      linewidth = 0.40
    ) +
    
    scale_fill_manual(
      values = my_cols
    ) +
    
    annotate(
      "text",
      x = 1.5,
      y = y_top,
      label = fmt_p(p_value),
      size = 3.8,
      color = "#333333"
    ) +
    
    scale_y_continuous(
      expand = expansion(
        mult = c(0.035, 0.19)
      )
    ) +
    
    labs(
      x = NULL,
      y = y_label,
      title = NULL
    ) +
    
    theme_classic(
      base_size = 16
    ) +
    
    theme(
      
      legend.position = "none",
      
      plot.title = element_blank(),
      
      axis.title.x = element_blank(),
      
      axis.title.y = element_text(
        size = 18,
        color = "#333333",
        margin = margin(r = 9)
      ),
      
      axis.text.x = element_text(
        size = 13,
        color = "#333333",
        face = "plain"
      ),
      
      axis.text.y = element_text(
        size = 17,
        color = "#444444"
      ),
      
      axis.line = element_line(
        color = "#555555",
        linewidth = 0.40
      ),
      
      axis.ticks = element_line(
        color = "#555555",
        linewidth = 0.35
      ),
      
      panel.grid = element_blank(),
      
      plot.margin = margin(
        12, 14, 10, 10
      )
    )
}


############################
############################

p_A <- make_violin(
  
  data = df_plot,
  
  y_col = "Full_Score",
  
  y_label = "Full 822-gene score",
  
  p_value = p_full
)

p_B <- make_violin(
  
  data = df_plot,
  
  y_col = "Panel_Score",
  
  y_label = "20-gene panel score",
  
  p_value = p_panel
)


############################
############################


p_final <- p_A | p_B

p_final <- p_final +
  plot_layout(
    widths = c(1, 1)
  )


############################
############################

ggsave(
  
  filename = file.path(
    fig_dir,
    "Fig5_Normal_vs_Tumour_Violin.pdf"
  ),
  
  plot = p_final,
  
  width = 9,
  
  height = 4.6,
  
  bg = "white"
)

ggsave(
  
  filename = file.path(
    fig_dir,
    "Fig5_Normal_vs_Tumour_Violin.png"
  ),
  
  plot = p_final,
  
  width = 9,
  
  height = 4.6,
  
  dpi = 600,
  
  bg = "white"
)


############################
############################

method_text <- c(
  
  "Figure 5 statistical analysis",
  
  paste0(
    "Matched patients: ",
    length(paired_patients)
  ),
  
  paste0(
    "Patient IDs: ",
    paste(paired_patients, collapse = ", ")
  ),
  
  paste0(
    "Normal cells: ",
    length(normal_full_matched)
  ),
  
  paste0(
    "Tumour cells: ",
    length(tumor_full_matched)
  ),
  
  paste0(
    "Full score test: ",
    res_full$method
  ),
  
  paste0(
    "Full score P value: ",
    format.pval(p_full, digits = 6)
  ),
  
  paste0(
    "Panel score test: ",
    res_panel$method
  ),
  
  paste0(
    "Panel score P value: ",
    format.pval(p_panel, digits = 6)
  ),
  
  paste0(
    "Full score normal > tumour: ",
    sum(diff_full > 0),
    "/",
    length(diff_full)
  ),
  
  paste0(
    "Panel score normal > tumour: ",
    sum(diff_panel > 0),
    "/",
    length(diff_panel)
  )
)

writeLines(
  method_text,
  file.path(
    fig_dir,
    "Fig5_test_method.txt"
  )
)


############################
############################

cat("\n")
cat("====================================\n")
cat("Figure 5 complete.
")
cat("====================================\n")

cat(
  "Paired patients: ",
  length(paired_patients),
  "\n"
)

cat(
  "Normal epithelial cells: ",
  length(normal_full_matched),
  "\n"
)

cat(
  "Tumour epithelial cells: ",
  length(tumor_full_matched),
  "\n"
)

cat(
  "Full 822 P = ",
  format.pval(p_full, digits = 5),
  "\n"
)

cat(
  "Panel 20-gene P = ",
  format.pval(p_panel, digits = 5),
  "\n"
)

cat(
  "Full signature: normal above tumour ",
  sum(diff_full > 0),
  "/",
  length(diff_full),
  "\n"
)

cat(
  "Panel: normal above tumour ",
  sum(diff_panel > 0),
  "/",
  length(diff_panel),
  "\n"
)

cat("
Output directory: ", fig_dir, "\n")

cat("
All done.
")
