## ===========================================================================
## singlecell_clinical/06b_ORA_background.R
## Panel-gene ORA repeated with the whole-transcriptome background.
## ===========================================================================
# ============================================================
# 09d_panel_ORA_fulltranscriptome_background.R
#
#
#
#   D:/.../QC_stage4_*/seurat_objects/GSE132465_QC_unfiltered.rds
#   tables/panel_20_direction_vector.csv
#   tables/panel_ORA_fulltranscriptome_GO.csv
#   tables/panel_ORA_fulltranscriptome_Hallmark.csv
#   tables/panel_ORA_background_comparison.csv
# ============================================================

options(stringsAsFactors = FALSE, encoding = "UTF-8")
set.seed(1234)

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(msigdbr)
})

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

cat(sprintf("[%s] 09d start\n", format(Sys.time(), "%H:%M:%S")))

## ---- 1. panel ----
dv <- read.csv(file.path(TAB_DIR, "panel_20_direction_vector.csv"),
               check.names = FALSE, stringsAsFactors = FALSE)
panel_genes <- toupper(dv$gene)
cat(sprintf("panel: %d genes (%d UP + %d DOWN)\n",
            length(panel_genes), sum(dv$sign > 0), sum(dv$sign < 0)))

root <- ROOT_SC
qc_file <- sort(Sys.glob(file.path(root, "QC_stage4_*", "seurat_objects",
                                   "GSE132465_QC_unfiltered.rds")),
                decreasing = TRUE)[1]
if (is.na(qc_file)) stop("Cannot find the GSE132465 QC object")

message("Reading the QC object to build the universe (~1.4 GB)...")
obj <- readRDS(qc_file)
md <- obj[[]]
idx <- md$Class == "Tumor" &
  md$Cell_type == "Epithelial cells" &
  md$Cell_subtype %in% c("CMS1", "CMS2", "CMS3", "CMS4")
idx[is.na(idx)] <- FALSE
cat(sprintf("tumour epithelial cells: %d\n", sum(idx)))

DefaultAssay(obj) <- "RNA"
lay <- Layers(obj[["RNA"]])
E <- if ("data" %in% lay) {
  LayerData(obj, assay = "RNA", layer = "data")[, idx, drop = FALSE]
} else {
  E <- LayerData(obj, assay = "RNA", layer = "counts")[, idx, drop = FALSE]
  NormalizeData(E, normalization.method = "LogNormalize",
                scale.factor = 1e4, verbose = FALSE)
}

genes_all <- toupper(rownames(E))
feat <- obj[["RNA"]][[]]
if ("gene_symbol" %in% names(feat)) {
  sym <- feat$gene_symbol[match(rownames(E), rownames(feat))]
  ok <- !is.na(sym) & nzchar(sym)
  genes_all[ok] <- toupper(sym[ok])
}
rm(obj, E); gc()

genes_all <- genes_all[!is.na(genes_all) & nzchar(genes_all)]
genes_all <- unique(genes_all)
cat(sprintf("genes in object (post symbol): %d\n", length(genes_all)))

map <- suppressMessages(AnnotationDbi::select(
  org.Hs.eg.db, keys = genes_all, columns = "ENTREZID", keytype = "SYMBOL"))
map <- map[!is.na(map$ENTREZID), ]
universe_entrez <- unique(map$ENTREZID)
cat(sprintf("universe mapped to ENTREZ: %d\n", length(universe_entrez)))

q <- suppressMessages(AnnotationDbi::select(
  org.Hs.eg.db, keys = panel_genes, columns = "ENTREZID", keytype = "SYMBOL"))
q <- q[!is.na(q$ENTREZID), ]
query_entrez <- unique(q$ENTREZID)
cat(sprintf("query mapped: %d / %d\n", length(query_entrez), length(panel_genes)))

go_res <- NULL
for (ont in c("BP", "CC", "MF")) {
  r <- try(enrichGO(gene = query_entrez, universe = universe_entrez,
                    OrgDb = org.Hs.eg.db, ont = ont, keyType = "ENTREZID",
                    pAdjustMethod = "BH", pvalueCutoff = 0.5, qvalueCutoff = 0.5,
                    minGSSize = 5, maxGSSize = 1000, readable = TRUE),
           silent = TRUE)
  if (inherits(r, "try-error") || is.null(r) || nrow(as.data.frame(r)) == 0) {
    cat(sprintf("  GO-%s: no result\n", ont)); next
  }
  df <- as.data.frame(r); df$ontology <- ont
  go_res <- rbind(go_res, df)
  cat(sprintf("  GO-%s: %d terms, %d with adj.P<0.05\n",
              ont, nrow(df), sum(df$p.adjust < 0.05)))
}
if (!is.null(go_res)) {
  go_res <- go_res[order(go_res$p.adjust), ]
  keep <- c("ontology", "ID", "Description", "GeneRatio", "BgRatio",
            "pvalue", "p.adjust", "qvalue", "geneID", "Count")
  go_res <- go_res[, keep]
  go_res$pvalue <- signif(go_res$pvalue, 3)
  go_res$p.adjust <- signif(go_res$p.adjust, 3)
  go_res$universe_size <- length(universe_entrez)
  write.csv(go_res, file.path(TAB_DIR, "panel_ORA_fulltranscriptome_GO.csv"),
            row.names = FALSE)
  cat("\n--- top 12 GO (full-transcriptome background) ---\n")
  print(head(go_res[go_res$p.adjust < 0.05,
                    c("ontology", "Description", "p.adjust", "Count")], 12),
        row.names = FALSE)
}

get_h <- function() {
  a <- try(msigdbr(species = "Homo sapiens", collection = "H"), silent = TRUE)
  if (!inherits(a, "try-error") && !is.null(a) && nrow(a)) return(a)
  b <- try(msigdbr(species = "Homo sapiens", category = "H"), silent = TRUE)
  if (!inherits(b, "try-error") && !is.null(b) && nrow(b)) return(b)
  NULL
}
hm <- get_h()
hm_res <- NULL
if (!is.null(hm)) {
  gs_col  <- if ("gene_symbol" %in% names(hm)) "gene_symbol" else "human_gene_symbol"
  set_col <- if ("gs_name" %in% names(hm)) "gs_name" else "gs_collection_name"
  term2gene <- unique(data.frame(term = hm[[set_col]], gene = hm[[gs_col]]))
  r <- try(enricher(panel_genes, TERM2GENE = term2gene, universe = genes_all,
                    pAdjustMethod = "BH", pvalueCutoff = 0.5, qvalueCutoff = 0.5,
                    minGSSize = 5, maxGSSize = 500), silent = TRUE)
  if (!inherits(r, "try-error") && !is.null(r) && nrow(as.data.frame(r)) > 0) {
    hm_res <- as.data.frame(r)
    hm_res <- hm_res[order(hm_res$p.adjust), ]
    hm_res$pvalue <- signif(hm_res$pvalue, 3)
    hm_res$p.adjust <- signif(hm_res$p.adjust, 3)
    hm_res$universe_size <- length(genes_all)
    write.csv(hm_res, file.path(TAB_DIR, "panel_ORA_fulltranscriptome_Hallmark.csv"),
              row.names = FALSE)
    cat(sprintf("\nHallmark tested: %d sets ; significant (adj.P<0.05): %d\n",
                nrow(hm_res), sum(hm_res$p.adjust < 0.05)))
    print(head(hm_res[, c("ID", "p.adjust", "Count")], 10), row.names = FALSE)
  } else cat("\nHallmark: no result\n")
}

cmp <- data.frame(
  comparison = c("panel ORA, 822-gene background",
                 "panel ORA, full-transcriptome background"),
  universe = c(822, length(universe_entrez)),
  go_significant = c(NA_integer_, if (is.null(go_res)) 0L else sum(go_res$p.adjust < 0.05)),
  hallmark_tested = c(NA_integer_, if (is.null(hm_res)) 0L else nrow(hm_res)),
  hallmark_significant = c(NA_integer_, if (is.null(hm_res)) 0L else sum(hm_res$p.adjust < 0.05)),
  stringsAsFactors = FALSE
)
f822_go <- file.path(TAB_DIR, "panel_gene_GO.csv")
f822_hm <- file.path(TAB_DIR, "panel_gene_Hallmark.csv")
if (file.exists(f822_go)) {
  a <- read.csv(f822_go, stringsAsFactors = FALSE)
  cmp$go_significant[1] <- sum(a$p.adjust < 0.05)
}
if (file.exists(f822_hm)) {
  b <- read.csv(f822_hm, stringsAsFactors = FALSE)
  cmp$hallmark_tested[1] <- nrow(b)
  cmp$hallmark_significant[1] <- sum(b$p.adjust < 0.05)
} else {
  cmp$hallmark_tested[1] <- 0L
}
write.csv(cmp, file.path(TAB_DIR, "panel_ORA_background_comparison.csv"),
          row.names = FALSE)
cat("\n=== background comparison ===\n")
print(cmp, row.names = FALSE)

cat("
=== stemness / WNT / Notch term check ===
")
pat <- "\\bWNT\\b|\\bWnt\\b|stem cell|stemness|\\bNotch\\b|\\bNOTCH\\b|beta-catenin|canonical Wnt"
hit <- data.frame(source = character(), term = character(),
                  adjP = numeric(), stringsAsFactors = FALSE)
if (!is.null(go_res)) {
  h <- go_res[grepl(pat, go_res$Description, ignore.case = FALSE),
              c("ontology", "Description", "p.adjust")]
  if (nrow(h)) {
    hit <- rbind(hit, data.frame(source = paste0("GO-", h$ontology),
                                 term = h$Description,
                                 adjP = as.numeric(h$p.adjust),
                                 stringsAsFactors = FALSE))
  }
}
if (!is.null(hm_res)) {
  h <- hm_res[grepl(pat, hm_res$ID, ignore.case = FALSE), c("ID", "p.adjust")]
  if (nrow(h)) {
    hit <- rbind(hit, data.frame(source = "Hallmark", term = h$ID,
                                 adjP = as.numeric(h$p.adjust),
                                 stringsAsFactors = FALSE))
  }
}
if (nrow(hit)) {
  hit <- hit[order(hit$adjP), ]
  cat("  terms actually matched:
")
  print(hit, row.names = FALSE)
  write.csv(hit, file.path(TAB_DIR, "panel_ORA_stemness_WNT_Notch_check.csv"),
            row.names = FALSE)
  if (any(hit$adjP < 0.05)) {
    cat("  >>> WARNING: stemness/WNT/Notch terms with adj.P < 0.05 are present; the manuscript wording must be revised!
")
  } else {
    cat(sprintf("  >>> all adjusted P >= %.3f; none significant
", min(hit$adjP)))
    cat("  >>> The wording 'no evidence for enrichment of stemness/WNT/Notch' is safe
")
  }
} else {
  cat("  no WNT / stemness / Notch term detected (whole-transcriptome background)
")
  cat("  >>> The wording 'no evidence for enrichment of stemness/WNT/Notch' is safe
")
}

cat(sprintf("\n[%s] 09d done\n", format(Sys.time(), "%H:%M:%S")))
