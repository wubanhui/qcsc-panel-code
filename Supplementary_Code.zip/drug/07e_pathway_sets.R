## ===========================================================================
## drug/07e_pathway_sets.R
## Pathway-level analysis of the drug perturbation data using a common set of
## MSigDB collections across all four compounds.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
OUT_DIR <- file.path(QCSC_PROJECT_DIR, "output", "drug_pathways")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)
############################################################
#
#
#
#
#
#   Wortmannin  GSE18005   GPL96  (hgu133a.db)      HCT116/HT29/SW480 x (DMSO,Wortmannin)  N=1
#
#
#   tables/three_drug_focus_sets.csv, three_drug_summary.csv,
#          calcitriol_focus_sets.csv, calcitriol_set_level.csv,
#          calcitriol_per_patient_log2FC.csv, panel_vs_vdr.csv
#   figures/heatmap_three_drug.pdf/.png, heatmap_calcitriol.pdf/.png
############################################################


############################
############################
data_dir <- DATA_ROOT
## Results go next to the inputs when that directory is writable, otherwise into
## the package output folder, so a read-only data mount does not stop the run.
out_root <- local({
  d <- file.path(data_dir, "mechanism_standard_R")
  if (dir.exists(d) && file.access(d, 2L) == 0L) {
    d
  } else {
    d2 <- file.path(QCSC_PROJECT_DIR, "output", "mechanism_standard_R")
    dir.create(d2, recursive = TRUE, showWarnings = FALSE)
    d2
  }
})
tab_dir  <- file.path(out_root, "tables")
fig_dir  <- file.path(out_root, "figures")
gmt_dir  <- file.path(out_root, "gmt")
for (d in c(tab_dir, fig_dir, gmt_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

f_cx        <- file.path(data_dir, "GSE201899_series_matrix.txt.gz")
f_wort      <- file.path(data_dir, "GSE18005_series_matrix.txt.gz")
f_emetine   <- file.path(data_dir,
  "GSE5486_Emetine_RMA_20gene_20261028_000952/results/GSE5486_RMA_gene_level_expression_all_samples.csv")
f_counts785 <- file.path(data_dir, "GSE100785_counts_htseq_GeneInfo.csv")
if (!file.exists(f_counts785)) f_counts785 <- paste0(f_counts785, ".gz")
f_sig       <- file.path(data_dir, "input2.tsv")

need <- c(f_cx, f_wort, f_emetine, f_counts785, f_sig)
missing <- need[!file.exists(need)]
if (length(missing)) stop("Missing file(s):
", paste(missing, collapse = "\n"))


############################
############################
suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(hgu133plus2.db)   # GPL570: CX-5461, Emetine
  library(hgu133a.db)       # GPL96 : Wortmannin
  library(dplyr)
})

read_msigdb <- function() {
  urls <- c(
    h.all    = "https://data.broadinstitute.org/gsea-msigdb/msigdb/release/2024.1.Hs/h.all.v2024.1.Hs.symbols.gmt",
    c5.go.bp = "https://data.broadinstitute.org/gsea-msigdb/msigdb/release/2024.1.Hs/c5.go.bp.v2024.1.Hs.symbols.gmt",
    c2.cp    = "https://data.broadinstitute.org/gsea-msigdb/msigdb/release/2024.1.Hs/c2.cp.v2024.1.Hs.symbols.gmt")
  ## Prefer a gene-set cache that already sits next to the input data, so the
  ## script does not need network access on a machine that ran it before.
  cache_dirs <- c(gmt_dir,
                  file.path(data_dir, "mechanism_standard_R", "gmt"),
                  file.path(QCSC_PROJECT_DIR, "data", "gmt"))
  out <- list()
  for (nm in names(urls)) {
    f <- file.path(gmt_dir, paste0(nm, ".gmt"))
    if (!file.exists(f) || file.info(f)$size < 1e4) {
      for (cd in cache_dirs) {
        g <- file.path(cd, paste0(nm, ".gmt"))
        if (file.exists(g) && file.info(g)$size >= 1e4) {
          file.copy(g, f, overwrite = TRUE)
          message("gene set ", nm, " taken from the local cache: ", g)
          break
        }
      }
    }
    if (!file.exists(f) || file.info(f)$size < 1e4) {
      download.file(urls[[nm]], f, mode = "wb", quiet = TRUE)
    }
    fields <- strsplit(readLines(f, warn = FALSE), "\t")
    ok <- vapply(fields, length, integer(1)) >= 3
    sets <- lapply(fields[ok], function(x) toupper(x[-c(1, 2)]))
    names(sets) <- vapply(fields[ok], `[`, character(1), 1)
    out <- c(out, sets)
  }
  out
}

#
set_evidence <- function(fc, sets, min_size = 10, max_size = 500) {
  if (is.data.frame(fc) || is.matrix(fc)) {
    m  <- as.matrix(fc)
    nm <- rownames(m)
    fc <- as.numeric(m[, 1])
    names(fc) <- nm
  } else {
    nm <- names(fc)
    fc <- as.numeric(fc)
    names(fc) <- nm
  }
  fc <- fc[is.finite(fc)]
  empty <- data.frame(set = character(0), n_genes = integer(0), mean_log2FC = numeric(0),
                      frac_up = numeric(0), mw_p = numeric(0), fdr = numeric(0),
                      stringsAsFactors = FALSE)
  if (length(fc) < 2) return(empty)

  set_names <- names(sets)
  keep <- vapply(set_names, function(s) {
    n <- length(intersect(sets[[s]], names(fc)))
    n >= min_size && n <= max_size
  }, logical(1))
  set_names <- set_names[keep]
  if (length(set_names) == 0) {
    warning("set_evidence(): no set passed the size filter (detected genes: ", length(fc), ")")
    return(empty)
  }

  n_genes    <- integer(length(set_names))
  mean_fc    <- numeric(length(set_names))
  frac_up    <- numeric(length(set_names))
  mw_p       <- numeric(length(set_names))
  for (i in seq_along(set_names)) {
    hit  <- intersect(sets[[set_names[i]]], names(fc))
    x    <- fc[hit]
    rest <- fc[setdiff(names(fc), hit)]
    n_genes[i] <- length(hit)
    mean_fc[i] <- mean(x)
    frac_up[i] <- mean(x > 0)
    mw_p[i]    <- tryCatch(
      suppressWarnings(wilcox.test(x, rest, alternative = "two.sided")$p.value),
      error = function(e) NA_real_)
  }
  res <- data.frame(set = set_names, n_genes = n_genes, mean_log2FC = mean_fc,
                    frac_up = frac_up, mw_p = mw_p, stringsAsFactors = FALSE)
  res$fdr <- p.adjust(res$mw_p, method = "BH")
  res[order(res$mw_p), , drop = FALSE]
}

probe_to_symbol_first <- function(probes, platform = c("hgu133plus2", "hgu133a")) {
  platform <- match.arg(platform)
  db <- if (platform == "hgu133a") hgu133a.db else hgu133plus2.db
  ann <- AnnotationDbi::select(db, keys = probes, columns = "SYMBOL", keytype = "PROBEID")
  ann <- ann %>% dplyr::filter(!is.na(SYMBOL), SYMBOL != "") %>%
    dplyr::distinct(PROBEID, SYMBOL) %>%
    dplyr::group_by(PROBEID) %>% dplyr::slice(1) %>% dplyr::ungroup()
  setNames(toupper(ann$SYMBOL), ann$PROBEID)
}

to_gene_level <- function(mat, platform = "hgu133plus2") {
  p2s  <- probe_to_symbol_first(rownames(mat), platform)
  keep <- rownames(mat) %in% names(p2s)
  mat  <- mat[keep, , drop = FALSE]
  g    <- p2s[rownames(mat)]
  gm   <- rowsum(mat, group = g, reorder = FALSE)
  sweep(gm, 1, table(g)[rownames(gm)], "/")
}

read_geo_block <- function(path) {
  con <- gzfile(path, "rt"); lines <- readLines(con, warn = FALSE); close(con)
  h <- which(grepl("ID_REF", lines, fixed = TRUE) & grepl("GSM", lines, fixed = TRUE))[1]
  endc <- which(seq_along(lines) > h & grepl("^!", lines))
  de <- if (length(endc)) endc[1] - 1 else length(lines)
  tf <- tempfile(fileext = ".txt"); writeLines(lines[h:de], tf)
  d <- read.delim(tf, header = TRUE, sep = "\t", quote = "\"", comment.char = "",
                  check.names = FALSE, stringsAsFactors = FALSE)
  unlink(tf)
  colnames(d) <- gsub('^"|"$', "", colnames(d))
  m <- as.matrix(d[, setdiff(colnames(d), "ID_REF"), drop = FALSE]); mode(m) <- "numeric"
  rownames(m) <- as.character(d[["ID_REF"]])
  m <- m[!is.na(rownames(m)) & rownames(m) != "", , drop = FALSE]
  m[!duplicated(rownames(m)), , drop = FALSE]
}

draw_heat <- function(mat, file_pdf, file_png, title, cex_axis = 0.7) {
  mat[is.na(mat)] <- 0
  lim <- max(abs(mat)); if (!is.finite(lim) || lim == 0) lim <- 1
  pal <- colorRampPalette(c("#2166ac", "white", "#b2182b"))(101)
  draw <- function() {
    op <- par(mar = c(9, 19, 3, 6))
    image(1:ncol(mat), 1:nrow(mat), t(mat[rev(seq_len(nrow(mat))), ]),
          col = pal, zlim = c(-lim, lim), axes = FALSE, xlab = "", ylab = "", main = title)
    axis(1, at = 1:ncol(mat), labels = colnames(mat), las = 2, cex.axis = cex_axis)
    axis(2, at = 1:nrow(mat), labels = rev(rownames(mat)), las = 1, cex.axis = cex_axis)
    box(); par(op)
  }
  pdf(file_pdf, width = 9, height = max(4.5, 0.35 * nrow(mat) + 1)); draw(); dev.off()
  png(file_png, width = 1800, height = max(900, 60 * nrow(mat)), res = 150); draw(); dev.off()
}

to_matrix <- function(df, row_col, col_cols, value_col) {
  key <- do.call(paste, c(lapply(df[col_cols], as.character), sep = " | "))
  rows <- unique(as.character(df[[row_col]]))
  cols <- sort(unique(key))
  m <- matrix(NA_real_, nrow = length(rows), ncol = length(cols),
              dimnames = list(rows, cols))
  idx_r <- match(as.character(df[[row_col]]), rows)
  idx_c <- match(key, cols)
  m[cbind(idx_r, idx_c)] <- as.numeric(df[[value_col]])
  m
}

msig <- read_msigdb()
cat("MSigDB sets:", length(msig), "\n")


############################################################
############################################################
cx_genes <- to_gene_level(read_geo_block(f_cx), "hgu133plus2")
cx_design <- list(
  "DLD-1" = c(ctl = "GSM6077746", d1 = "GSM6077747", d10 = "GSM6077748"),
  "HT-29" = c(ctl = "GSM6077749", d1 = "GSM6077750", d10 = "GSM6077751"),
  "SW480" = c(ctl = "GSM6077752", d1 = "GSM6077753", d10 = "GSM6077754"))
cx_fc <- list()
for (cl in names(cx_design)) {
  g <- cx_design[[cl]]
  cx_fc[[paste("CX-5461", cl, "1uM",  sep = "|")]] <- cx_genes[, g["d1"]]  - cx_genes[, g["ctl"]]
  cx_fc[[paste("CX-5461", cl, "10uM", sep = "|")]] <- cx_genes[, g["d10"]] - cx_genes[, g["ctl"]]
}

wt_genes <- to_gene_level(log2(pmax(read_geo_block(f_wort), 1)), "hgu133a")
wt_design <- list(
  HCT116 = list(drug = "GSM450450", ctl = "GSM450448"),
  HT29   = list(drug = "GSM450455", ctl = "GSM450453"),
  SW480  = list(drug = "GSM450460", ctl = "GSM450458"))
wt_fc <- lapply(names(wt_design), function(cl) {
  d <- wt_design[[cl]]
  wt_genes[, d$drug] - wt_genes[, d$ctl]
})
names(wt_fc) <- paste("Wortmannin", names(wt_design), "Wortmannin", sep = "|")

em <- read.csv(f_emetine, check.names = FALSE, stringsAsFactors = FALSE,
               fileEncoding = "UTF-8-BOM")
gene_col <- names(em)[1]
em_gene  <- toupper(as.character(em[[gene_col]]))
em       <- em[, -1, drop = FALSE]
em       <- em[!is.na(em_gene) & nzchar(em_gene), , drop = FALSE]
em_gene  <- em_gene[!is.na(em_gene) & nzchar(em_gene)]
rownames(em) <- em_gene
em <- em[!duplicated(rownames(em)), , drop = FALSE]

need_cols <- c("GSM126419", "GSM126420", "GSM126423", "GSM126424")
missing_cols <- setdiff(need_cols, names(em))
if (length(missing_cols)) {
  stop("The Emetine matrix is missing columns: ", paste(missing_cols, collapse = ", "),
       "
Current columns: ", paste(names(em), collapse = ", "))
}
em_fc <- list(
  "Emetine|LS180|Emetine" = as.numeric(em[["GSM126420"]]) - as.numeric(em[["GSM126419"]]),
  "Emetine|SW480|Emetine" = as.numeric(em[["GSM126424"]]) - as.numeric(em[["GSM126423"]]))
for (k in names(em_fc)) names(em_fc[[k]]) <- rownames(em)
cat("Emetine matrix:", nrow(em), "genes x", ncol(em), "samples\n")

three_fc <- c(cx_fc, wt_fc, em_fc)
for (k in names(three_fc)) {
  v <- three_fc[[k]]
  if (!is.numeric(v) || is.null(names(v))) {
    stop("Compare ", k, " log2FC is not a named numeric vector (class = ",
         paste(class(v), collapse = "/"), ")")
  }
}
res_list <- list()
for (key in names(three_fc)) {
  parts <- strsplit(key, "|", fixed = TRUE)[[1]]
  r <- set_evidence(three_fc[[key]], msig)
  r$drug <- parts[1]; r$cell_line <- parts[2]; r$dose <- parts[3]
  res_list[[key]] <- r[, c("drug", "cell_line", "dose", "set", "n_genes",
                           "mean_log2FC", "frac_up", "mw_p", "fdr")]
  cat(sprintf("  [three-drug] %-30s genes=%-6d sets=%d\n",
              key, length(three_fc[[key]]), nrow(r)))
}
all_three <- do.call(rbind, res_list)

focus_three <- c("HALLMARK_MYC_TARGETS_V1", "HALLMARK_MYC_TARGETS_V2",
                 "HALLMARK_E2F_TARGETS", "HALLMARK_G2M_CHECKPOINT",
                 "HALLMARK_P53_PATHWAY", "HALLMARK_DNA_REPAIR", "HALLMARK_APOPTOSIS",
                 "GOBP_RIBOSOME_BIOGENESIS", "GOBP_RIBOSOME_ASSEMBLY",
                 "GOBP_RRNA_METABOLIC_PROCESS", "REACTOME_RRNA_PROCESSING",
                 "GOBP_CYTOPLASMIC_TRANSLATION", "KEGG_RIBOSOME",
                 "KEGG_RNA_POLYMERASE", "KEGG_P53_SIGNALING_PATHWAY")

focus_tab <- all_three[all_three$set %in% focus_three, ]
write.csv(focus_tab, file.path(tab_dir, "three_drug_focus_sets.csv"), row.names = FALSE)

summ_three <- focus_tab %>%
  group_by(drug, set) %>%
  summarise(n_contrasts = n(), n_down = sum(mean_log2FC < 0),
            n_fdr05 = sum(fdr < 0.05), median_log2FC = median(mean_log2FC),
            .groups = "drop")
write.csv(summ_three, file.path(tab_dir, "three_drug_summary.csv"), row.names = FALSE)

mat3 <- to_matrix(focus_tab, "set", c("drug", "cell_line", "dose"), "mean_log2FC")
draw_heat(mat3, file.path(fig_dir, "heatmap_three_drug.pdf"),
          file.path(fig_dir, "heatmap_three_drug.png"), "Three drugs: mean log2FC (blue = down)")


############################################################
############################################################
read_counts_gse100785 <- function(path) {
  con <- if (grepl("\\.gz$", path)) gzfile(path, "rt") else file(path, "rt")
  lines <- readLines(con, warn = FALSE); close(con)
  header <- strsplit(gsub('^"|"$', "", lines[1]), "[[:space:]]+")[[1]]
  sym_col <- match("hgnc_symbol", header)
  sample_start <- 7L
  samples <- header[sample_start:length(header)]
  body <- strsplit(lines[-1], "\t", fixed = TRUE)
  body <- body[vapply(body, length, integer(1)) >= length(header)]
  sym <- toupper(gsub('^"|"$', "", vapply(body, `[`, character(1), sym_col)))
  ok <- !is.na(sym) & nzchar(sym) & sym != "NA" & !grepl("^ENSG", sym)
  body <- body[ok]; sym <- sym[ok]
  cnt <- t(vapply(body, function(f)
    as.numeric(gsub('"', "", f[sample_start:length(header)])), numeric(length(samples))))
  colnames(cnt) <- samples
  rownames(cnt) <- sym
  rowsum(cnt, group = sym, reorder = FALSE) / as.numeric(table(sym)[unique(sym)])
}

cnt <- read_counts_gse100785(f_counts785)
cat("GSE100785 counts:", nrow(cnt), "genes x", ncol(cnt), "samples\n")
lg <- log2(sweep(cnt, 2, colSums(cnt), "/") * 1e6 + 1)

ids <- colnames(lg)
pairs785 <- list()
for (s in ids) {
  if (!grepl("C$", s)) next
  pid <- sub("C$", "", s); dcol <- paste0(pid, "D")
  if (dcol %in% ids) {
    pairs785[[length(pairs785) + 1]] <- list(
      patient = sub("[HT]$", "", pid),
      tissue  = ifelse(grepl("T$", pid), "Tumour", "Healthy"),
      fc = lg[, dcol] - lg[, s])
  }
}
P785 <- do.call(cbind, lapply(pairs785, function(p) p$fc))
colnames(P785) <- paste0(vapply(pairs785, `[[`, "", "tissue"), "-",
                         vapply(pairs785, `[[`, "", "patient"))
write.csv(P785, file.path(tab_dir, "calcitriol_per_patient_log2FC.csv"))

focus_cal <- c("GOBP_RESPONSE_TO_VITAMIN_D", "GOBP_VITAMIN_D_METABOLIC_PROCESS",
               "GOBP_VITAMIN_D_RECEPTOR_SIGNALING_PATHWAY", "GOBP_CELLULAR_RESPONSE_TO_VITAMIN_D",
               "GOBP_INTESTINAL_ABSORPTION", "GOBP_CALCIUM_ION_TRANSPORT", "GOBP_BONE_MINERALIZATION",
               "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION", "HALLMARK_E2F_TARGETS",
               "HALLMARK_G2M_CHECKPOINT", "HALLMARK_MYC_TARGETS_V1", "HALLMARK_P53_PATHWAY",
               "HALLMARK_NOTCH_SIGNALING", "HALLMARK_WNT_BETA_CATENIN_SIGNALING",
               "GOBP_INTESTINAL_EPITHELIAL_CELL_DIFFERENTIATION", "GOBP_EPITHELIAL_CELL_DIFFERENTIATION",
               "GOBP_MUCIN_BIOSYNTHETIC_PROCESS", "GOBP_REGULATION_OF_WNT_SIGNALING_PATHWAY",
               "HALLMARK_APOPTOSIS", "HALLMARK_TNFA_SIGNALING_VIA_NFKB")

cal_list <- list()
for (tissue in c("Tumour", "Healthy")) {
  cols <- grep(paste0("^", tissue, "-"), colnames(P785), value = TRUE)
  r <- set_evidence(rowMeans(P785[, cols, drop = FALSE]), msig)
  r$group <- tissue; r$n_pairs <- length(cols)
  r$sign_pos <- vapply(r$set, function(s) {
    hit <- intersect(msig[[s]], rownames(P785))
    if (length(hit) < 10) return(NA_integer_)
    sum(colMeans(P785[hit, cols, drop = FALSE]) > 0)
  }, integer(1))
  r$sign_p <- vapply(r$sign_pos, function(k)
    if (is.na(k)) NA_real_ else binom.test(k, length(cols))$p.value, numeric(1))
  cal_list[[tissue]] <- r[, c("group", "n_pairs", "set", "n_genes", "mean_log2FC",
                              "frac_up", "mw_p", "fdr", "sign_pos", "sign_p")]
  cat(sprintf("  [calcitriol] %-8s pairs=%d sets=%d\n", tissue, length(cols), nrow(r)))
}
all_cal <- do.call(rbind, cal_list)
write.csv(all_cal, file.path(tab_dir, "calcitriol_set_level.csv"), row.names = FALSE)
focus_cal_tab <- all_cal[all_cal$set %in% focus_cal, ]
write.csv(focus_cal_tab, file.path(tab_dir, "calcitriol_focus_sets.csv"), row.names = FALSE)

mat_cal <- to_matrix(focus_cal_tab, "set", c("group"), "mean_log2FC")
draw_heat(mat_cal, file.path(fig_dir, "heatmap_calcitriol.pdf"),
          file.path(fig_dir, "heatmap_calcitriol.png"), "Calcitriol (GSE100785): mean log2FC")

vdr_name <- "GOBP_VITAMIN_D_RECEPTOR_SIGNALING_PATHWAY"
if (!vdr_name %in% names(msig)) {
  cand <- grep("VITAMIN_D_RECEPTOR_SIGNALING", names(msig), value = TRUE)
  cand <- cand[!grepl("REGULATION_OF|POSITIVE_REGULATION_OF", cand)]
  if (length(cand)) {
    vdr_name <- cand[1]
    warning("Exact set name absent; using: ", vdr_name)
  } else {
    vdr_name <- "GOBP_VITAMIN_D_METABOLIC_PROCESS"
    warning("No VDR-related set found; using: ", vdr_name)
  }
}
cat("[B.4] VDR set used:", vdr_name, "\n")

sig <- read.delim(f_sig, stringsAsFactors = FALSE, check.names = FALSE,
                  fileEncoding = "UTF-8-BOM")
sig$Name <- toupper(trimws(as.character(sig$Name)))
sig_up   <- unique(sig$Name[sig[["Input Type"]] == "up_entities"   & sig[["Type"]] == "valid"])
sig_down <- unique(sig$Name[sig[["Input Type"]] == "down_entities" & sig[["Type"]] == "valid"])
up_g <- intersect(sig_up, rownames(P785))
dn_g <- intersect(sig_down, rownames(P785))
vdr_g <- intersect(msig[[vdr_name]], rownames(P785))
if (!length(up_g) || !length(dn_g) || !length(vdr_g)) {
  stop("B.4: panel/VDR genes not found in P785 (up=", length(up_g),
       ", down=", length(dn_g), ", vdr=", length(vdr_g), ", set=", vdr_name,
       "). Check that the gene names of input2.tsv and the GSE100785 counts agree (upper-case symbols)")
}
cat(sprintf("[B.4] panel UP=%d DOWN=%d | VDR program genes=%d | CYP24A1 present=%s\n",
            length(up_g), length(dn_g), length(vdr_g), "CYP24A1" %in% rownames(P785)))

.colmean_named <- function(m) {
  v <- colMeans(m, na.rm = TRUE)
  if (is.null(names(v))) names(v) <- colnames(m)
  v
}
d_up <- .colmean_named(P785[up_g, , drop = FALSE])
d_dn <- .colmean_named(P785[dn_g, , drop = FALSE])
d_vdr <- .colmean_named(P785[vdr_g, , drop = FALSE])
samples <- colnames(P785)
if (!identical(names(d_up), samples) || !identical(names(d_vdr), samples)) {
  stop("B.4: gene-set means do not align with sample columns")
}
panel_vdr <- data.frame(
  sample      = samples,
  Delta       = as.numeric(d_up - d_dn),
  VDR_program = as.numeric(d_vdr),
  CYP24A1     = if ("CYP24A1" %in% rownames(P785)) as.numeric(P785["CYP24A1", samples]) else NA_real_,
  stringsAsFactors = FALSE)
write.csv(panel_vdr, file.path(tab_dir, "panel_vs_vdr.csv"), row.names = FALSE)

.sp <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok) < 4 || sd(x[ok]) == 0 || sd(y[ok]) == 0) return(NULL)
  suppressWarnings(cor.test(x[ok], y[ok], method = "spearman"))
}
ct_vdr <- .sp(panel_vdr$VDR_program, panel_vdr$Delta)
ct_cyp <- .sp(panel_vdr$CYP24A1,     panel_vdr$Delta)


############################################################
############################################################
cat("\n########## Cross-compound concordance ##########\n")
print(as.data.frame(summ_three), digits = 3)

cat("\n########## Calcitriol: key sets ##########\n")
print(focus_cal_tab[, c("group", "set", "n_genes", "mean_log2FC", "fdr", "sign_pos", "sign_p")],
      row.names = FALSE, digits = 3)

cat("\n########## Panel delta vs VDR programme ##########\n")
print(panel_vdr, digits = 3, row.names = FALSE)
if (is.null(ct_vdr)) {
  cat("Spearman(VDR_program, Delta): not computed (fewer than 4 valid samples or zero variance)\n")
} else {
  cat(sprintf("Spearman(VDR_program, Delta): rho = %.3f, P = %.3f, n = %d\n",
              unname(ct_vdr$estimate), ct_vdr$p.value, nrow(panel_vdr)))
}
if (is.null(ct_cyp)) {
  cat("Spearman(CYP24A1, Delta): not computed (fewer than 4 valid samples or zero variance)\n")
} else {
  cat(sprintf("Spearman(CYP24A1,     Delta): rho = %.3f, P = %.3f, n = %d\n",
              unname(ct_cyp$estimate), ct_cyp$p.value, nrow(panel_vdr)))
}

cat("\nAll results saved to: ", out_root, "\n")




############################################################
#
#
#
############################################################

## tab_dir is defined earlier in this script; do not re-point it at a relative
## path, otherwise the file written a few blocks above cannot be found again.
panel_vdr <- read.csv(file.path(tab_dir, "panel_vs_vdr.csv"),
                      stringsAsFactors = FALSE)

required <- c("sample", "Delta")
miss <- setdiff(required, colnames(panel_vdr))
if (length(miss)) stop("panel_vs_vdr.csv is missing columns: ", paste(miss, collapse = ", "))
if (any(!is.finite(panel_vdr$Delta))) {
  stop("NA / NaN / Inf in the Delta column; check the input.")
}

.cal_group <- factor(sub("-.*$", "", panel_vdr$sample),
                     levels = c("Healthy", "Tumour"))
cat("Counts by tissue:\n"); print(table(.cal_group))

if (length(unique(.cal_group)) < 2) {
  stop("The samples do not cover both the Healthy and the Tumour group; no group test is possible.")
}

del_t <- panel_vdr$Delta[.cal_group == "Tumour"]
del_h <- panel_vdr$Delta[.cal_group == "Healthy"]
n_t <- length(del_t); n_h <- length(del_h)
k_t <- sum(del_t > 0, na.rm = TRUE)
k_h <- sum(del_h > 0, na.rm = TRUE)

wt_cal <- wilcox.test(del_t, del_h, alternative = "two.sided", exact = FALSE)

cat("\n===== Descriptive statistics =====\n")
cat(sprintf("Tumour delta: n = %d, delta > 0 in %d, median %+.4f, range %+.4f ~ %+.4f\n",
            n_t, k_t, median(del_t), min(del_t), max(del_t)))
cat(sprintf("Normal delta: n = %d, delta > 0 in %d, median %+.4f, range %+.4f ~ %+.4f\n",
            n_h, k_h, median(del_h), min(del_h), max(del_h)))

cat("\n===== Between-group test =====\n")
cat(sprintf("Two-sided Wilcoxon rank-sum test: W = %.1f, P = %.4f\n",
            unname(wt_cal$statistic), wt_cal$p.value))

cal_test <- data.frame(
  comparison          = "Tumour vs Healthy Delta, Wilcoxon rank-sum",
  W_statistic         = unname(wt_cal$statistic),
  p_value             = signif(wt_cal$p.value, 4),
  n_tumour            = n_t,
  n_delta_pos_tumour  = k_t,
  median_tumour       = round(median(del_t), 4),
  n_healthy           = n_h,
  n_delta_pos_healthy = k_h,
  median_healthy      = round(median(del_h), 4),
  method              = "wilcox.test, two.sided, exact = FALSE (continuity correction)",
  stringsAsFactors    = FALSE
)

cat("\n"); print(cal_test, row.names = FALSE)

write.csv(cal_test,
          file.path(tab_dir, "calcitriol_tumour_vs_normal_test.csv"),
          row.names = FALSE)
cat("\nSaved: ", file.path(tab_dir, "calcitriol_tumour_vs_normal_test.csv"), "\n")

cat("\n===== Check against the values reported in the manuscript =====\n")
chk2 <- function(lbl, cond) cat(sprintf("  %-46s %s\n", lbl,
                                        if (isTRUE(cond)) "OK" else "MISMATCH"))

chk2("Tumour delta > 0: 4/6",           k_t == 4 && n_t == 6)
chk2("Normal delta > 0: 0/6",           k_h == 0 && n_h == 6)
chk2("Tumour median = +0.1139",          abs(median(del_t) - 0.1139) < 0.001)
chk2("Normal median = -0.6205",          abs(median(del_h) + 0.6205) < 0.001)
chk2("Wilcoxon W = 32",               unname(wt_cal$statistic) == 32)
chk2("Wilcoxon P ≈ 0.031 (0.0306)",   abs(wt_cal$p.value - 0.0306) < 0.001)