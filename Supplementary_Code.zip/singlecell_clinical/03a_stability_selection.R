## ===========================================================================
## singlecell_clinical/03a_stability_selection.R
## Stability selection: 30 stratified 70/30 splits with greedy forward
## selection; genes selected in at least 50% of the splits form the panel.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

## Stability selection of the compact qCSC panel across repeated patient/sample splits.
suppressPackageStartupMessages({library(Matrix); library(ggplot2)})
set.seed(1234)
tab_dir <- TAB_DIR; fig_dir <- FIG_DIR
dir.create(tab_dir, recursive=TRUE, showWarnings=FALSE); dir.create(fig_dir, recursive=TRUE, showWarnings=FALSE)
d <- readRDS(file.path(panel_dir,"panel_data.rds"))
E1 <- d$E1; E2 <- d$E2; f1 <- d$score1; f2 <- d$score2
up <- d$up_use; down <- d$down_use; meta1 <- d$meta1; meta2 <- d$meta2
expected <- ifelse(rownames(E1) %in% up,1,-1)

stratified_split <- function(strata, prop=0.7) {
  train <- rep(FALSE,length(strata))
  for (s in unique(strata)) { idx <- which(strata==s); train[sample(idx,max(1,floor(prop*length(idx))))] <- TRUE }
  train
}
make_prep <- function(E,f,cells,genes) {
  X <- E[genes,cells,drop=FALSE]; Xc <- X-rowMeans(X); fc <- f[cells]-mean(f[cells]); n <- length(fc)
  list(Xc=Xc,fc=fc,n=n,cov_xf=as.numeric(Xc%*%fc)/(n-1),var_x=rowSums(Xc^2)/(n-1),var_f=sum(fc^2)/(n-1))
}
ps <- function(E,cells,genes) colMeans(E[genes,cells,drop=FALSE])

select_once <- function(seed) {
  set.seed(seed)
  tr1 <- stratified_split(meta1$Patient); tr2 <- stratified_split(meta2$sample_code)
  sd1 <- apply(E1[,tr1,drop=FALSE],1,sd); sd2 <- apply(E2[,tr2,drop=FALSE],1,sd)
  ok1 <- sd1>0; ok2 <- sd2>0
  r1 <- rep(NA_real_,nrow(E1)); r2 <- rep(NA_real_,nrow(E2))
  r1[ok1] <- as.numeric(cor(t(E1[ok1,tr1,drop=FALSE]),f1[tr1]))
  r2[ok2] <- as.numeric(cor(t(E2[ok2,tr2,drop=FALSE]),f2[tr2]))
  det1 <- 100*rowMeans(E1[,tr1,drop=FALSE]>0); det2 <- 100*rowMeans(E2[,tr2,drop=FALSE]>0)
  cand <- which(!is.na(r1)&!is.na(r2)&sd1>0&sd2>0&det1>=5&det2>=5&
                sign(r1)==expected&sign(r2)==expected&
                (expected==1 | (r1<=-0.05 & r2<=-0.05)))
  if (length(cand)<20 || sum(expected[cand]==-1)<3) return(NULL)
  p1 <- make_prep(E1,f1,tr1,cand); p2 <- make_prep(E2,f2,tr2,cand)
  dirs <- expected[cand]; sel <- integer(0); s1 <- rep(0,sum(tr1)); s2 <- rep(0,sum(tr2))
  for (step in 1:20) {
    k <- length(sel)
    if(k==0){r1a<-p1$cov_xf/sqrt(p1$var_x*p1$var_f);r2a<-p2$cov_xf/sqrt(p2$var_x*p2$var_f)} else {
      r1a<-r2a<-rep(-Inf,length(cand))
      for(w in 1:2){p<-if(w==1)p1 else p2;s<-if(w==1)s1 else s2;sc<-s-mean(s)
        cov_sf<-sum(sc*p$fc)/(p$n-1);var_s<-sum(sc^2)/(p$n-1);cov_sx<-as.numeric(p$Xc%*%sc)/(p$n-1)
        cov_new<-(k*cov_sf+p$cov_xf)/(k+1);var_new<-(k^2*var_s+2*k*cov_sx+p$var_x)/(k+1)^2
        rr<-cov_new/sqrt(var_new*p$var_f);if(w==1)r1a<-rr else r2a<-rr}
    }
    r1a[sel]<--Inf;r2a[sel]<--Inf;obj<-pmin(r1a,r2a)-0.01*abs(r1a-r2a)
    n_up<-sum(dirs[sel]==1);n_down<-sum(dirs[sel]==-1)
    if(k>=8){if(n_down<3)allowed<-dirs==-1 else if(n_up<3)allowed<-dirs==1 else
      allowed<-(n_up+(dirs==1))/(n_down+(dirs==-1))<=6 & (n_down+(dirs==-1))/(n_up+(dirs==1))<=3
      allowed[sel]<-FALSE;if(any(allowed))obj[!allowed]<--Inf}
    sel<-c(sel,which.max(obj));s1<-ps(E1,tr1,cand[sel]);s2<-ps(E2,tr2,cand[sel])
  }
  rownames(E1)[cand[sel]]
}

n_iter <- 30
res <- lapply(1:n_iter, function(i) { cat("iter",i,"\n"); select_once(1000+i) })
freq <- sort(table(unlist(res)), decreasing=TRUE)
freq_tab <- data.frame(gene=names(freq), n_selected=as.integer(freq),
                       frequency=as.integer(freq)/n_iter,
                       direction=ifelse(names(freq) %in% up,"UP","DOWN"))
write.csv(freq_tab, file.path(tab_dir,"panel_stability_frequency.csv"), row.names=FALSE)
cat("\nTop stable genes:\n"); print(head(freq_tab,30), row.names=FALSE)

stable <- freq_tab$gene[freq_tab$frequency >= 0.5]
cat("genes >=50%:", length(stable), "\n")
if (length(stable) >= 10) {
  s1 <- ps(E1,1:ncol(E1),intersect(stable,rownames(E1)))
  s2 <- ps(E2,1:ncol(E2),intersect(stable,rownames(E2)))
  cat("stable panel cell r:",cor(s1,f1),cor(s2,f2)," n=",length(stable),"\n")
  writeLines(stable, file.path(out_dir,"stable_panel_genes.txt"))
}

p <- ggplot(head(freq_tab,30), aes(reorder(gene, frequency), frequency, fill=direction)) +
  geom_col() + coord_flip() +
  scale_fill_manual(values=c(UP="#C0392B",DOWN="#2471A3")) +
  labs(x=NULL,y="Selection frequency across 30 splits",fill="Direction",
       title="Stability of the compact qCSC panel") +
  theme_classic(base_size=11)
ggsave(file.path(fig_dir,"Fig7_panel_stability.png"),p,width=7,height=7,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig7_panel_stability.pdf"),p,width=7,height=7,bg="white")
saveRDS(list(freq=freq_tab, runs=res), file.path(out_dir,"stability.rds"))
cat("saved\n")
