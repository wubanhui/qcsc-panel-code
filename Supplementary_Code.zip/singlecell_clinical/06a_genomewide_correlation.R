## ===========================================================================
## singlecell_clinical/06a_genomewide_correlation.R
## Transcriptome-wide Spearman correlation of the panel score across the
## 17,469 tumour epithelial cells, with GO enrichment of both extremes.
## ===========================================================================
# ============================================================
# 09c_panel_genomewide_correlation.R
#
#
#   tables/panel_20_direction_vector.csv
#   tables/panel_genomewide_correlation.csv
#   tables/panel_genomewide_GO.csv
#   tables/panel_genomewide_summary.csv
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(clusterProfiler)
  library(org.Hs.eg.db)
})

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
tab_dir <- TAB_DIR

root <- ROOT_SC
qc_file <- Sys.glob(file.path(root, "QC_stage4_*", "seurat_objects",
                              "GSE132465_QC_unfiltered.rds"))
qc_file <- sort(qc_file, decreasing = TRUE)[1]
if (is.na(qc_file) || !file.exists(qc_file)) stop("Cannot find the GSE132465 QC object")
cat("QC object:", qc_file, "\n")

dv <- read.csv(file.path(tab_dir, "panel_20_direction_vector.csv"),
               check.names = FALSE, stringsAsFactors = FALSE)
dv$gene <- toupper(dv$gene)
panel_genes <- dv$gene

# ------------------------------------------------------------
# ------------------------------------------------------------
message("Reading the QC object (~1.4 GB, this takes a few minutes)...")
obj <- readRDS(qc_file)
md <- obj[[]]
need <- c("Class", "Cell_type", "Cell_subtype")
miss <- setdiff(need, names(md))
if (length(miss)) stop("missing columns in meta.data: ", paste(miss, collapse = ", "))

idx <- md$Class == "Tumor" &
  md$Cell_type == "Epithelial cells" &
  md$Cell_subtype %in% c("CMS1", "CMS2", "CMS3", "CMS4")
idx[is.na(idx)] <- FALSE
cat(sprintf("Tumour epithelial cells: %d\n", sum(idx)))
if (sum(idx) < 1000) stop("Too few tumour epithelial cells")

DefaultAssay(obj) <- "RNA"
cat("Available layers:", paste(Layers(obj[["RNA"]]), collapse = ", "), "\n")

lay <- Layers(obj[["RNA"]])
if ("data" %in% lay) {
  E <- LayerData(obj, assay = "RNA", layer = "data")
  cat("Using existing 'data' layer\n")
} else {
  cat("Only 'counts' available -> applying LogNormalize (scale.factor = 1e4)\n")
  E <- LayerData(obj, assay = "RNA", layer = "counts")
  E <- E[, idx, drop = FALSE]
  E <- NormalizeData(E, normalization.method = "LogNormalize",
                     scale.factor = 1e4, verbose = FALSE)
  idx <- rep(TRUE, ncol(E))
}
E <- E[, idx, drop = FALSE]
genes_all <- toupper(rownames(E))
cat(sprintf("Full transcriptome: %d genes x %d cells\n", nrow(E), ncol(E)))

feat <- obj[["RNA"]][[]]
if ("gene_symbol" %in% names(feat) && !is.null(rownames(feat))) {
  sym <- feat$gene_symbol[match(rownames(E), rownames(feat))]
  ok <- !is.na(sym) & nzchar(sym)
  genes_all[ok] <- toupper(sym[ok])
}

rm(obj); gc()

emean <- Matrix::rowMeans(E)
ord <- order(genes_all, -emean)
E <- E[ord, , drop = FALSE]; genes_all <- genes_all[ord]
keep <- !duplicated(genes_all) & !is.na(genes_all) & nzchar(genes_all)
E <- E[keep, , drop = FALSE]; genes_all <- genes_all[keep]
rownames(E) <- genes_all
cat(sprintf("After symbol collapse: %d genes\n", nrow(E)))

# ------------------------------------------------------------
# ------------------------------------------------------------
pg <- intersect(panel_genes, genes_all)
cat(sprintf("Panel genes found: %d / %d\n", length(pg), length(panel_genes)))
if (length(pg) < 18) stop("Too many panel genes are missing to compute the score")
pg_up <- intersect(dv$gene[dv$direction == "UP"],   genes_all)
pg_dn <- intersect(dv$gene[dv$direction == "DOWN"], genes_all)
cat(sprintf("panel score genes: %d UP + %d DOWN\n", length(pg_up), length(pg_dn)))
panel_score <- colMeans(E[pg_up, , drop = FALSE]) - colMeans(E[pg_dn, , drop = FALSE])
cat(sprintf("Panel score: mean %.4f, sd %.4f\n", mean(panel_score), sd(panel_score)))

# ------------------------------------------------------------
# ------------------------------------------------------------
Ek <- as.matrix(E)
keep_g <- !(genes_all %in% panel_genes)
Ek <- Ek[keep_g, , drop = FALSE]
gk <- genes_all[keep_g]
cat(sprintf("Genes tested (panel excluded): %d\n", length(gk)))

rk_panel <- rank(panel_score)
rk_panel <- (rk_panel - mean(rk_panel)) / sd(rk_panel)
message("Computing genome-wide correlations ...")
rho <- numeric(length(gk))
for (i in seq_along(gk)) {
  v <- Ek[i, ]
  if (sd(v) == 0) { rho[i] <- NA_real_; next }
  rv <- rank(v)
  rho[i] <- mean(rk_panel * ((rv - mean(rv)) / sd(rv)))
}
cor_df <- data.frame(gene = gk, rho = rho, stringsAsFactors = FALSE)
cor_df <- cor_df[!is.na(cor_df$rho), ]
cor_df <- cor_df[order(-cor_df$rho), ]
write.csv(cor_df, file.path(tab_dir, "panel_genomewide_correlation.csv"),
          row.names = FALSE)

n <- nrow(cor_df)
cat(sprintf("\nGenome-wide rho: range %.2f to %.2f ; |rho|>0.3: %d ; |>0.2|: %d\n",
            min(cor_df$rho), max(cor_df$rho),
            sum(abs(cor_df$rho) > 0.3), sum(abs(cor_df$rho) > 0.2)))
cat("\nTop 20 positive correlates:\n")
print(head(cor_df, 20), row.names = FALSE)
cat("\nTop 20 negative correlates:\n")
print(head(cor_df[order(cor_df$rho), ], 20), row.names = FALSE)

summ <- data.frame(
  metric = c("n_cells", "n_genes_in_cluster", "n_genes_tested",
             "top_positive_gene", "top_positive_rho",
             "top_negative_gene", "top_negative_rho",
             "n_abs_rho_gt_0.3", "n_abs_rho_gt_0.2"),
  value = c(ncol(E), length(genes_all), n,
            cor_df$gene[1], round(cor_df$rho[1], 4),
            cor_df$gene[n], round(cor_df$rho[n], 4),
            sum(abs(cor_df$rho) > 0.3), sum(abs(cor_df$rho) > 0.2)),
  stringsAsFactors = FALSE
)
write.csv(summ, file.path(tab_dir, "panel_genomewide_summary.csv"), row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
univ <- bitr(genes_all, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
go_rows <- NULL
for (sd_name in c("positive", "negative")) {
  gl <- if (sd_name == "positive") head(cor_df$gene, 200) else tail(cor_df$gene, 200)
  e <- bitr(gl, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  r <- try(enrichGO(gene = e$ENTREZID, universe = univ$ENTREZID,
                    OrgDb = org.Hs.eg.db, ont = "BP", keyType = "ENTREZID",
                    pAdjustMethod = "BH", pvalueCutoff = 0.5, qvalueCutoff = 0.5,
                    minGSSize = 10, maxGSSize = 500, readable = TRUE), silent = TRUE)
  if (inherits(r, "try-error") || is.null(r) || nrow(as.data.frame(r)) == 0) next
  df <- as.data.frame(r)
  df$direction <- sd_name
  go_rows <- rbind(go_rows, df)
}
if (!is.null(go_rows)) {
  go_rows <- go_rows[order(go_rows$direction, go_rows$p.adjust), ]
  keep <- c("direction", "ID", "Description", "GeneRatio", "BgRatio",
            "pvalue", "p.adjust", "geneID", "Count")
  go_rows <- go_rows[, keep]
  go_rows$pvalue <- signif(go_rows$pvalue, 3)
  go_rows$p.adjust <- signif(go_rows$p.adjust, 3)
  write.csv(go_rows, file.path(tab_dir, "panel_genomewide_GO.csv"), row.names = FALSE)
  cat("\n--- genome-wide GO (BP, p.adjust<0.05, top 10 per direction) ---\n")
  for (dir in c("positive", "negative")) {
    s <- go_rows[go_rows$direction == dir & go_rows$p.adjust < 0.05, ]
    cat(sprintf("\n[%s] %d terms\n", dir, nrow(s)))
    if (nrow(s)) print(head(s[, c("Description", "p.adjust", "Count")], 10), row.names = FALSE)
  }
} else cat("\nGO: no result\n")

cat("\nWritten:\n  ",
    file.path(tab_dir, "panel_genomewide_correlation.csv"), "\n  ",
    file.path(tab_dir, "panel_genomewide_summary.csv"), "\n  ",
    file.path(tab_dir, "panel_genomewide_GO.csv"), "\n")
