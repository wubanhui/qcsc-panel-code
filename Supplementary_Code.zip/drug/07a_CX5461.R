## ===========================================================================
## drug/07a_CX5461.R
## CX-5461 (GSE201899): score the 20-gene panel in three CRC cell lines at two
## doses and compute the change relative to the matched control.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
OUT_DIR <- file.path(QCSC_PROJECT_DIR, "output", "drug_CX5461")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)
############################################################
# GSE201899 — CX-5461
# 20-gene Differentiation Signature independent validation
#
# Fixed signature:
#   20 genes (17 UP for Differentiation, 3 DOWN for Stemness)
#   Read from: input2.tsv
#
# GSE201899:
#   Affymetrix HG-U133 Plus 2.0 (GPL570)
#   3 CRC cell lines: DLD-1, HT-29, SW480
#   Treatment: Control, CX-5461 1 uM, CX-5461 10 uM
#
# IMPORTANT:
#   This is microarray data. DO NOT use CPM.
#
# qCSC score = mean(UP genes) - mean(DOWN genes)
# Delta qCSC = Drug - Control
# Delta qCSC > 0: supports DIFFERENTIATION induction
#
# Gene-level reversal:
#   UP gene:   Drug log2FC > 0 (differentiation goes up)
#   DOWN gene: Drug log2FC < 0 (stemness goes down)
#
# Full concordant reversal:
#   UP_change > 0 AND DOWN_change < 0
############################################################


############################
############################
data_dir <- DATA_ROOT
out_root <- file.path(QCSC_PROJECT_DIR, "output", "GSE201899_CX5461_20gene_validation")
output_dir <- file.path(out_root, "results")

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cat("Data directory  :", data_dir, "\n")
cat("Output directory:", output_dir, "\n\n")


############################
############################
search_dirs <- c(DATA_ROOT)

find_file <- function(name, dirs) {
  for (d in dirs) {
    p <- file.path(d, name)
    if (file.exists(p)) return(p)
  }
  return(NA_character_)
}

geo_file <- find_file("GSE201899_series_matrix.txt.gz", search_dirs)
annotation_file <- find_file("hgu133plus2.db_3.13.0.tar.gz", search_dirs)

signature_file <- file.path(data_dir, "input2.tsv")

if (is.na(geo_file) || !file.exists(geo_file)) {
  stop("GSE201899_series_matrix.txt.gz not found; please put it in the data directory.")
}
if (!file.exists(signature_file)) {
  stop("Signature file not found: ", signature_file)
}

cat("GEO series matrix:", geo_file, "\n")
cat("Signature        :", signature_file, "\n\n")


############################
############################
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("AnnotationDbi", quietly = TRUE)) BiocManager::install("AnnotationDbi", ask = FALSE, update = FALSE)

if (!requireNamespace("hgu133plus2.db", quietly = TRUE)) {
  if (is.na(annotation_file) || !file.exists(annotation_file)) {
    stop("hgu133plus2.db is not installed and no offline package was found.")
  }
  install.packages(annotation_file, repos = NULL, type = "source")
}

library(AnnotationDbi)
library(hgu133plus2.db)
library(dplyr)


############################
############################
sample_info <- data.frame(
  GSM = c(
    "GSM6077746", "GSM6077747", "GSM6077748",
    "GSM6077749", "GSM6077750", "GSM6077751",
    "GSM6077752", "GSM6077753", "GSM6077754"
  ),
  CellLine = c(
    "DLD-1", "DLD-1", "DLD-1",
    "HT-29", "HT-29", "HT-29",
    "SW480", "SW480", "SW480"
  ),
  Treatment = c(
    "Control", "CX5461_1uM", "CX5461_10uM",
    "Control", "CX5461_1uM", "CX5461_10uM",
    "Control", "CX5461_1uM", "CX5461_10uM"
  ),
  stringsAsFactors = FALSE
)


############################
############################
cat("
Reading GEO data and processing the annotation...
")
con <- gzfile(geo_file, open = "rt")
geo_lines <- readLines(con, warn = FALSE)
close(con)

header_candidates <- which(grepl("ID_REF", geo_lines, fixed = TRUE) & grepl("GSM6077746", geo_lines, fixed = TRUE))
if (length(header_candidates) == 0) stop("No expression matrix header found.")
header_line <- header_candidates[1]

end_candidates <- which(seq_along(geo_lines) > header_line & grepl("^!", geo_lines))
data_end <- if(length(end_candidates) > 0) end_candidates[1] - 1 else length(geo_lines)

expr_lines <- geo_lines[header_line:data_end]
tmp_file <- tempfile(fileext = ".txt")
writeLines(expr_lines, tmp_file)
expr_raw <- read.delim(tmp_file, header = TRUE, sep = "\t", quote = "\"", comment.char = "", check.names = FALSE, stringsAsFactors = FALSE)
unlink(tmp_file)

colnames(expr_raw) <- gsub('^"|"$', "", colnames(expr_raw))
probe_column <- which(colnames(expr_raw) == "ID_REF")
probe_ids <- as.character(expr_raw[[probe_column]])
expr_matrix <- as.matrix(expr_raw[, sample_info$GSM, drop = FALSE])
mode(expr_matrix) <- "numeric"
rownames(expr_matrix) <- probe_ids

keep_probe <- !is.na(rownames(expr_matrix)) & rownames(expr_matrix) != ""
expr_matrix <- expr_matrix[keep_probe, , drop = FALSE]
expr_matrix <- expr_matrix[!duplicated(rownames(expr_matrix)), , drop = FALSE]

probe_annotation <- AnnotationDbi::select(hgu133plus2.db, keys = rownames(expr_matrix), columns = c("SYMBOL"), keytype = "PROBEID")
probe_annotation <- probe_annotation %>% dplyr::filter(!is.na(SYMBOL), SYMBOL != "") %>% dplyr::distinct(PROBEID, SYMBOL) %>% dplyr::group_by(PROBEID) %>% dplyr::slice(1) %>% dplyr::ungroup()

common_probes <- intersect(rownames(expr_matrix), probe_annotation$PROBEID)
expr_matrix2 <- expr_matrix[common_probes, , drop = FALSE]
probe_annotation2 <- probe_annotation[match(common_probes, probe_annotation$PROBEID), , drop = FALSE]

gene_symbols <- toupper(probe_annotation2$SYMBOL)
expr_gene_matrix <- rowsum(expr_matrix2, group = gene_symbols, reorder = FALSE)
probe_count <- table(gene_symbols)
expr_gene_matrix <- sweep(expr_gene_matrix, 1, probe_count[rownames(expr_gene_matrix)], "/")
expr_gene_matrix <- expr_gene_matrix[!is.na(rownames(expr_gene_matrix)) & rownames(expr_gene_matrix) != "", , drop = FALSE]


############################################################
############################################################
sig <- read.delim(signature_file, stringsAsFactors = FALSE, check.names = FALSE)

if ("Input Type" %in% colnames(sig) && "Type" %in% colnames(sig)) {
  sig$Name <- toupper(trimws(as.character(sig$Name)))
  qCSC_UP <- sig$Name[sig[["Input Type"]] == "up_entities" & sig[["Type"]] == "valid"]
  qCSC_DOWN <- sig$Name[sig[["Input Type"]] == "down_entities" & sig[["Type"]] == "valid"]
} else if ("Gene" %in% colnames(sig) && "Direction" %in% colnames(sig)) {
  sig$Gene <- toupper(trimws(as.character(sig$Gene)))
  qCSC_UP <- sig$Gene[sig$Direction == "UP" | sig$Direction == "up"]
  qCSC_DOWN <- sig$Gene[sig$Direction == "DOWN" | sig$Direction == "down"]
} else {
  stop("Unrecognised input2.tsv format; it must contain (Name, Input Type, Type) or (Gene, Direction) columns.")
}

qCSC_UP <- unique(qCSC_UP[qCSC_UP != ""])
qCSC_DOWN <- unique(qCSC_DOWN[qCSC_DOWN != ""])

cat("\n20-Gene Signature Loaded:\n")
cat("UP genes (Differentiation):", length(qCSC_UP), "\n")
cat("DOWN genes (Stemness):", length(qCSC_DOWN), "\n")


############################################################
############################################################
matched_up <- intersect(qCSC_UP, rownames(expr_gene_matrix))
matched_down <- intersect(qCSC_DOWN, rownames(expr_gene_matrix))
matched_total <- unique(c(matched_up, matched_down))

cat("\nSignature matching:\n")
cat("UP matched:", length(matched_up), "/", length(qCSC_UP), "\n")
cat("DOWN matched:", length(matched_down), "/", length(qCSC_DOWN), "\n")

if (length(matched_up) == 0 || length(matched_down) == 0) {
  stop("No gene was matched; check the gene naming (human, upper case) or the array annotation.")
}

UP_score <- colMeans(expr_gene_matrix[matched_up, , drop = FALSE], na.rm = TRUE)
DOWN_score <- colMeans(expr_gene_matrix[matched_down, , drop = FALSE], na.rm = TRUE)
qCSC_score <- UP_score - DOWN_score

sample_score_result <- data.frame(
  GSM = names(qCSC_score),
  CellLine = sample_info$CellLine[match(names(qCSC_score), sample_info$GSM)],
  Treatment = sample_info$Treatment[match(names(qCSC_score), sample_info$GSM)],
  UP_score = as.numeric(UP_score),
  DOWN_score = as.numeric(DOWN_score),
  qCSC_score = as.numeric(qCSC_score),
  stringsAsFactors = FALSE
)


############################################################
############################################################
delta_result <- data.frame(stringsAsFactors = FALSE)

for (cell_line in unique(sample_info$CellLine)) {
  control_gsm <- sample_info$GSM[sample_info$CellLine == cell_line & sample_info$Treatment == "Control"]
  drug_gsm <- sample_info$GSM[sample_info$CellLine == cell_line & sample_info$Treatment != "Control"]
  control_score <- qCSC_score[control_gsm]
  
  for (drug in drug_gsm) {
    delta_value <- qCSC_score[drug] - control_score
    
    delta_result <- rbind(
      delta_result,
      data.frame(
        CellLine = cell_line,
        Control_GSM = control_gsm,
        Drug_GSM = drug,
        Treatment = sample_info$Treatment[match(drug, sample_info$GSM)],
        Control_qCSC = as.numeric(control_score),
        Drug_qCSC = as.numeric(qCSC_score[drug]),
        Delta_qCSC = as.numeric(delta_value),
        Supports_Differentiation = ifelse(delta_value > 0, "YES", "NO"), 
        stringsAsFactors = FALSE
      )
    )
  }
}


############################################################
############################################################
gene_level_result <- data.frame(stringsAsFactors = FALSE)

for (i in seq_len(nrow(delta_result))) {
  cell_line <- delta_result$CellLine[i]
  control_gsm <- delta_result$Control_GSM[i]
  drug_gsm <- delta_result$Drug_GSM[i]
  
  log2FC <- expr_gene_matrix[, drug_gsm] - expr_gene_matrix[, control_gsm]
  
  tmp_up <- data.frame(Gene = matched_up, Direction = "UP", CellLine = cell_line, Control_GSM = control_gsm, Drug_GSM = drug_gsm, log2FC = as.numeric(log2FC[matched_up]), stringsAsFactors = FALSE)
  tmp_down <- data.frame(Gene = matched_down, Direction = "DOWN", CellLine = cell_line, Control_GSM = control_gsm, Drug_GSM = drug_gsm, log2FC = as.numeric(log2FC[matched_down]), stringsAsFactors = FALSE)
  tmp <- rbind(tmp_up, tmp_down)
  
  tmp$Reversed <- ifelse(
    tmp$Direction == "UP", 
    tmp$log2FC > 0,
    tmp$log2FC < 0
  )
  
  tmp$Signed_log2FC <- ifelse(tmp$Direction == "UP", tmp$log2FC, -tmp$log2FC)
  
  gene_level_result <- rbind(gene_level_result, tmp)
}


############################################################
############################################################
reversal_summary <- gene_level_result %>%
  dplyr::group_by(CellLine, Drug_GSM) %>%
  dplyr::summarise(
    matched_genes = sum(!is.na(log2FC)),
    reversed_genes = sum(Reversed, na.rm = TRUE),
    reversal_percentage = reversed_genes / matched_genes * 100,
    mean_signed_log2FC = mean(Signed_log2FC, na.rm = TRUE),
    median_signed_log2FC = median(Signed_log2FC, na.rm = TRUE),
    UP_reversed = sum(Direction == "UP" & Reversed, na.rm = TRUE),
    DOWN_reversed = sum(Direction == "DOWN" & Reversed, na.rm = TRUE),
    .groups = "drop"
  )

reversal_summary$Treatment <- sample_info$Treatment[match(reversal_summary$Drug_GSM, sample_info$GSM)]
reversal_summary <- reversal_summary[, c("CellLine", "Treatment", "Drug_GSM", "matched_genes", "reversed_genes", "reversal_percentage", "mean_signed_log2FC", "median_signed_log2FC", "UP_reversed", "DOWN_reversed")]


############################################################
############################################################
module_result <- data.frame(stringsAsFactors = FALSE)

for (i in seq_len(nrow(delta_result))) {
  cell_line <- delta_result$CellLine[i]
  control_gsm <- delta_result$Control_GSM[i]
  drug_gsm <- delta_result$Drug_GSM[i]
  
  UP_change <- mean(expr_gene_matrix[matched_up, drug_gsm], na.rm = TRUE) - mean(expr_gene_matrix[matched_up, control_gsm], na.rm = TRUE)
  DOWN_change <- mean(expr_gene_matrix[matched_down, drug_gsm], na.rm = TRUE) - mean(expr_gene_matrix[matched_down, control_gsm], na.rm = TRUE)
  delta_qCSC <- UP_change - DOWN_change
  
  full_concordant <- UP_change > 0 & DOWN_change < 0
  
  module_result <- rbind(
    module_result,
    data.frame(
      CellLine = cell_line, Control_GSM = control_gsm, Drug_GSM = drug_gsm,
      Treatment = sample_info$Treatment[match(drug_gsm, sample_info$GSM)],
      UP_change = as.numeric(UP_change), DOWN_change = as.numeric(DOWN_change),
      Delta_qCSC = as.numeric(delta_qCSC),
      Full_concordant_reversal = full_concordant, 
      stringsAsFactors = FALSE
    )
  )
}


############################################################
############################################################
final_result <- delta_result %>%
  dplyr::left_join(reversal_summary %>% dplyr::select(CellLine, Drug_GSM, reversal_percentage, reversed_genes, matched_genes, mean_signed_log2FC, median_signed_log2FC), by = c("CellLine", "Drug_GSM")) %>%
  dplyr::left_join(module_result %>% dplyr::select(CellLine, Drug_GSM, UP_change, DOWN_change, Full_concordant_reversal), by = c("CellLine", "Drug_GSM")) %>%
  dplyr::arrange(CellLine, Treatment)

cat("\n\n############################################\n")
cat("#        GSE201899 20-Gene FINAL RESULT\n")
cat("############################################\n\n")
print(final_result)


write.csv(sample_score_result, file.path(output_dir, "GSE201899_sample_scores_20gene.csv"), row.names = FALSE)
write.csv(delta_result, file.path(output_dir, "GSE201899_delta_20gene.csv"), row.names = FALSE)
write.csv(reversal_summary, file.path(output_dir, "GSE201899_reversal_summary_20gene.csv"), row.names = FALSE)
write.csv(gene_level_result, file.path(output_dir, "GSE201899_gene_level_20gene.csv"), row.names = FALSE)
write.csv(module_result, file.path(output_dir, "GSE201899_module_change_20gene.csv"), row.names = FALSE)
write.csv(final_result, file.path(output_dir, "GSE201899_FINAL_result_20gene.csv"), row.names = FALSE)

cat("\n============================================\n")
cat("GSE201899 CX-5461: 20-gene panel validation complete
")
cat("============================================\n")
cat("Results saved to: ", output_dir, "\n\n")
cat("[Note: revised criteria]
")
cat("Delta qCSC > 0  = supports differentiation induction
")
cat("Delta qCSC < 0  = does not support it
")
cat("The higher the reversal percentage, the more completely the drug flips the genes toward the differentiation state.
")
cat("Full concordant reversal = UP_change > 0 AND DOWN_change < 0\n")