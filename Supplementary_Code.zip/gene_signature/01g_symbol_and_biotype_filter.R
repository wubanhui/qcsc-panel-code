## ===========================================================================
## gene_signature/01g_symbol_and_biotype_filter.R
##
## Standardise gene symbols and keep protein-coding genes only; yields the
## 885-gene consensus set (768 up / 117 down).
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

############################################################
# TCGA CRC qCSC
# Common DEG -> LINCS signature cleaning (optimized)
#
#
############################################################

options(stringsAsFactors = FALSE)

# ============================================================
# ============================================================
required_packages <- c("AnnotationDbi", "org.Hs.eg.db")

for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop("Missing R package(s): ", pkg, "
Please install it first.")
  }
}

suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(org.Hs.eg.db)
})

# ============================================================
# ============================================================
base_dir <- DATA_ROOT

output_root_override <- Sys.getenv("QCSC_LINCS_OUTPUT_ROOT", unset = "")
output_root <- if (nzchar(output_root_override)) {
  output_root_override
} else if (dir.exists(base_dir) && file.access(base_dir, 2L) == 0L) {
  ## Write next to the inputs when the data directory is writable.
  base_dir
} else {
  ## Otherwise keep the results inside the package.
  d <- file.path(QCSC_PROJECT_DIR, "output")
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
  d
}

input_override <- Sys.getenv("QCSC_LINCS_INPUT_OVERRIDE", unset = "")
if (!nzchar(input_override)) {
  input_override <- NA_character_
}

find_latest_common_deg_input <- function(root = base_dir) {
  estimate_dir <- NA_character_
  pointer <- file.path(root, "TCGA_CRC_ESTIMATE_GSVA_LATEST.txt")

  if (file.exists(pointer)) {
    p <- sub(
      "^\ufeff",
      "",
      trimws(readLines(pointer, warn = FALSE)[1])
    )
    if (!is.na(p) && dir.exists(p) &&
        file.exists(file.path(p, "DEG_ESTIMATE_adjusted_FINAL.csv"))) {
      estimate_dir <- p
    }
  }

  if (is.na(estimate_dir)) {
    cand <- list.dirs(root, recursive = FALSE, full.names = TRUE)
    cand <- cand[grepl("^TCGA_CRC_ESTIMATE_GSVA_", basename(cand))]
    cand <- cand[
      file.exists(file.path(cand, "DEG_ESTIMATE_adjusted_FINAL.csv"))
    ]

    if (length(cand) == 0) {
      stop(
        "No directory containing DEG_ESTIMATE_adjusted_FINAL.csv was found: ",
        "TCGA_CRC_ESTIMATE_GSVA_* directory.
",
        "Please run part 1 of 01f_estimate_adjust.R first."
      )
    }

    estimate_dir <- cand[which.max(
      file.info(file.path(
        cand,
        "DEG_ESTIMATE_adjusted_FINAL.csv"
      ))$mtime
    )]
  }

  common_dirs <- list.dirs(
    estimate_dir,
    recursive = FALSE,
    full.names = TRUE
  )
  common_dirs <- common_dirs[
    grepl("^Common_DEG_direction_check_", basename(common_dirs))
  ]
  common_dirs <- common_dirs[
    file.exists(file.path(
      common_dirs,
      "Common_DEG_all_with_logFC_directions.csv"
    ))
  ]

  if (length(common_dirs) == 0) {
    stop(
      "No Common_DEG_direction_check_* directory in the latest ESTIMATE folder:
",
      estimate_dir,
      "
Please run part 3 of 01f_estimate_adjust.R first."
    )
  }

  common_dirs[
    which.max(
      file.info(file.path(
        common_dirs,
        "Common_DEG_all_with_logFC_directions.csv"
      ))$mtime
    )
  ]
}

input_file <- if (!is.na(input_override)) {
  input_override
} else {
  file.path(
    find_latest_common_deg_input(base_dir),
    "Common_DEG_all_with_logFC_directions.csv"
  )
}

if (!file.exists(input_file) || dir.exists(input_file)) {
  stop(
    "Cannot find the common-DEG input file:
", input_file,
    "
Please check the path, or edit input_file in the script."
  )
}

# ============================================================
# ============================================================
time_tag <- format(Sys.time(), "%Y%m%d_%H%M%S")
output_dir <- file.path(
  output_root,
  paste0("TCGA_CRC_qCSC_Common_DEG_LINCS_cleaning_optimized_", time_tag)
)

if (dir.exists(output_dir)) {
  stop("The output directory already exists; stopping to avoid overwriting results:
", output_dir)
}

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cat("============================================================\n")
cat("TCGA CRC qCSC common DEG -> LINCS gene cleaning (optimised)
")
cat("============================================================\n")
cat("Input file:
", input_file, "\n")
cat("Output directory: 
", output_dir, "\n\n")

# ============================================================
# ============================================================
common_raw <- read.csv(
  input_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

required_cols <- c(
  "Gene",
  "logFC_original",
  "logFC_adjusted"
)

missing_cols <- setdiff(required_cols, colnames(common_raw))
if (length(missing_cols) > 0) {
  stop("The input file is missing required columns: ", paste(missing_cols, collapse = ", "))
}

fix_symbol <- function(x) {
  x <- trimws(as.character(x))
  x <- sub("^\ufeff", "", x)
  x <- gsub('^"|"$', "", x)
  x <- trimws(x)
  x <- ifelse(
    grepl("^[A-Za-z0-9]+,[0-9]+$", x),
    sub(",", ".", x, fixed = TRUE),
    x
  )
  x
}

common <- common_raw
common$Gene_input <- fix_symbol(common$Gene)
common$Gene_key <- toupper(common$Gene_input)

common$Symbol_fixed <- ifelse(
  common$Gene_input != trimws(as.character(common$Gene)),
  common$Gene_input,
  ""
)

empty_gene <- is.na(common$Gene_key) | !nzchar(common$Gene_key)
n_empty_gene <- sum(empty_gene)
common <- common[!empty_gene, , drop = FALSE]

if (nrow(common) == 0) {
  stop("The input file contains no usable gene symbols.")
}

dup_input <- common$Gene_key[
  duplicated(common$Gene_key) | duplicated(common$Gene_key, fromLast = TRUE)
]

if (length(unique(dup_input)) > 0) {
  dup_rows <- common[common$Gene_key %in% unique(dup_input), , drop = FALSE]
  write.csv(
    dup_rows,
    file.path(output_dir, "Input_duplicate_gene_symbols.csv"),
    row.names = FALSE,
    na = ""
  )
  stop(
    "Duplicated gene symbols are present in the input (after case standardisation).
",
    "Written: ", file.path(output_dir, "Input_duplicate_gene_symbols.csv"),
    "
Please remove duplicates before running this script."
  )
}

direction_from_logfc <- function(x) {
  ifelse(
    is.na(x), NA_character_,
    ifelse(x > 0, "UP", ifelse(x < 0, "DOWN", "ZERO"))
  )
}

common$logFC_original <- suppressWarnings(as.numeric(common$logFC_original))
common$logFC_adjusted <- suppressWarnings(as.numeric(common$logFC_adjusted))

common$Dir_orig <- direction_from_logfc(common$logFC_original)
common$Dir_adj <- direction_from_logfc(common$logFC_adjusted)

common$Dir_consistent <- (
  !is.na(common$Dir_orig) &
    !is.na(common$Dir_adj) &
    common$Dir_orig %in% c("UP", "DOWN") &
    common$Dir_adj %in% c("UP", "DOWN") &
    common$Dir_orig == common$Dir_adj
)

common$Direction <- ifelse(
  common$Dir_consistent,
  ifelse(common$Dir_orig == "UP", "UP", "DOWN"),
  NA_character_
)

direction_problem <- common[!common$Dir_consistent, , drop = FALSE]

write.csv(
  direction_problem,
  file.path(output_dir, "Direction_recheck_problems.csv"),
  row.names = FALSE,
  na = ""
)

if (nrow(direction_problem) > 0) {
  stop(
    "Direction check found problems; written to:
",
    file.path(output_dir, "Direction_recheck_problems.csv"),
    "
Please check this file; LINCS input should not be generated yet."
  )
}

common <- common[common$Dir_consistent, , drop = FALSE]
common$Input_key <- common$Gene_key

write.csv(
  common,
  file.path(output_dir, "Common_DEG_input_checked.csv"),
  row.names = FALSE,
  na = ""
)

cat("Input rows (raw): ", nrow(common_raw), "\n")
cat("Rows with an empty gene symbol: ", n_empty_gene, "\n")
cat("Rows with direction problems: ", nrow(direction_problem), "\n")
cat("Genes entering the cleaning step: ", nrow(common), "\n")
cat("UP: ", sum(common$Direction == "UP"),
    " DOWN: ", sum(common$Direction == "DOWN"), "\n\n")

# ============================================================
# ============================================================
expr_rdata <- file.path(base_dir, "TCGA_CRC_380_samples.RData")
expression_genes <- character(0)

if (file.exists(expr_rdata)) {
  expr_env <- new.env(parent = emptyenv())
  load(expr_rdata, envir = expr_env)

  if (exists("expr_crc", envir = expr_env, inherits = FALSE)) {
    expr_obj <- get("expr_crc", envir = expr_env, inherits = FALSE)
    expression_genes <- toupper(trimws(rownames(expr_obj)))
    expression_genes <- unique(
      expression_genes[!is.na(expression_genes) & nzchar(expression_genes)]
    )
  }
}

if (length(expression_genes) == 0) {
  warning(
    "expr_crc could not be read from TCGA_CRC_380_samples.RData; ",
    "Homonym disambiguation will be skipped; MPP6/DEC1/AGPAT9 and similar may be mis-mapped."
  )
}

# ============================================================
# ============================================================
orgdb <- org.Hs.eg.db::org.Hs.eg.db
available_columns <- AnnotationDbi::columns(orgdb)
annotation_cols <- intersect(
  c("SYMBOL", "ENTREZID", "ENSEMBL", "GENETYPE"),
  available_columns
)

if (!all(c("SYMBOL", "ENTREZID", "GENETYPE") %in% annotation_cols)) {
  stop("The installed org.Hs.eg.db does not provide SYMBOL/ENTREZID/GENETYPE columns.")
}

symbol_keys <- AnnotationDbi::keys(orgdb, keytype = "SYMBOL")
symbol_upper <- toupper(symbol_keys)

safe_select <- function(keys, keytype, columns) {
  keys <- unique(as.character(keys))
  keys <- keys[!is.na(keys) & nzchar(keys)]
  if (length(keys) == 0) {
    return(NULL)
  }

  out <- tryCatch(
    AnnotationDbi::select(
      orgdb,
      keys = keys,
      keytype = keytype,
      columns = columns
    ),
    error = function(e) NULL
  )

  if (is.null(out) || nrow(out) == 0) {
    return(NULL)
  }

  out <- out[!is.na(out[[keytype]]), , drop = FALSE]
  if (nrow(out) == 0) NULL else out
}

# ============================================================
# ============================================================
manual_map_file <- file.path(base_dir, "retired_symbol_map.csv")

if (file.exists(manual_map_file)) {
  manual_map <- read.csv(
    manual_map_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  cat("External retired-symbol table used: ", manual_map_file, "\n")
} else {
  manual_map <- data.frame(
    old_symbol = c(
      "C11ORF86", "C16ORF62", "C4ORF19", "C2ORF88", "MPP6", "C1ORF186",
      "C1ORF177", "C15ORF48", "AGPAT9", "C6ORF163", "DEC1", "HIST1H2BI",
      "C11ORF53"
    ),
    new_symbol = c(
      "C11orf86", "VPS35L", "PGCKA1", "AKAP19", "PALS2", "RHEX",
      "CIMAP2", "COXFA4L3", "GPAT3", "C6orf163", "DELEC1", "H2BC10",
      "POU2AF2"
    ),
    entrez_id = c(
      254439, 57020, 55286, 84281, 51678, 440712,
      163747, 84419, 84803, 206412, 50514, 8346, 341032
    ),
    ensembl_id = c(
      "ENSG00000173237", "ENSG00000103544", "ENSG00000154274",
      "ENSG00000187699", "ENSG00000105926", "ENSG00000263961",
      "ENSG00000162398", "ENSG00000166920", "ENSG00000138678",
      "ENSG00000203872", "ENSG00000173077", "ENSG00000278588",
      "ENSG00000150750"
    ),
    genetype_override = c(
      "protein-coding", "protein-coding", "protein-coding",
      "protein-coding", "protein-coding", "protein-coding",
      "protein-coding", "protein-coding", "protein-coding",
      "protein-coding", "non-coding RNA", "protein-coding",
      "protein-coding"
    ),
    source = c(
      "current_case", "prev_symbol", "prev_symbol", "prev_symbol",
      "prev_symbol", "prev_symbol", "prev_symbol", "prev_symbol",
      "prev_symbol", "current_case", "prev_symbol", "prev_symbol",
      "prev_symbol"
    ),
    note = c(
      "case-only change; matrix has C11orf86",
      "C16orf62 renamed to VPS35L",
      "C4orf19 renamed to PGCKA1",
      "C2orf88 renamed to AKAP19; same ENTREZID as matrix C2orf88",
      "TCGA MPP6 = PALS2; MPHOSPH6 is a separate matrix row and also has alias MPP6",
      "C1orf186 renamed to RHEX",
      "C1orf177 renamed to CIMAP2",
      "C15orf48 renamed to COXFA4L3; same ENTREZID as matrix C15orf48",
      "AGPAT9 prev=GPAT3; LPCAT1 is a separate matrix row and alias conflict",
      "case-only change; matrix has C6orf163",
      "TCGA DEC1 = DELEC1 lncRNA; BHLHE40 is a separate matrix row",
      "HIST1H2BI renamed to H2BC10",
      "C11orf53 renamed to POU2AF2"
    ),
    stringsAsFactors = FALSE
  )
}

required_map_cols <- c(
  "old_symbol", "new_symbol", "entrez_id",
  "genetype_override", "source", "note"
)

missing_map_cols <- setdiff(required_map_cols, colnames(manual_map))
if (length(missing_map_cols) > 0) {
  stop(
    "The retired-symbol table is missing columns: ", paste(missing_map_cols, collapse = ", "),
    "
Required: ", paste(required_map_cols, collapse = ", ")
  )
}

if (!"ensembl_id" %in% colnames(manual_map)) {
  manual_map$ensembl_id <- NA_character_
}

manual_map$old_symbol <- toupper(trimws(as.character(manual_map$old_symbol)))
manual_map$new_symbol <- trimws(as.character(manual_map$new_symbol))
manual_map$entrez_id <- as.character(manual_map$entrez_id)
manual_map$ensembl_id <- as.character(manual_map$ensembl_id)
manual_map$genetype_override <- trimws(as.character(manual_map$genetype_override))
manual_map$source <- ifelse(
  is.na(manual_map$source) | !nzchar(manual_map$source),
  "manual",
  manual_map$source
)
manual_map$note <- ifelse(
  is.na(manual_map$note),
  "",
  manual_map$note
)

manual_map <- manual_map[
  !is.na(manual_map$old_symbol) & nzchar(manual_map$old_symbol) &
    !is.na(manual_map$new_symbol) & nzchar(manual_map$new_symbol),
  ,
  drop = FALSE
]

manual_rows <- lapply(seq_len(nrow(manual_map)), function(i) {
  m <- manual_map[i, , drop = FALSE]

  ann <- safe_select(m$new_symbol, "SYMBOL", annotation_cols)
  if (is.null(ann) || nrow(ann) == 0) {
    ann <- safe_select(m$entrez_id, "ENTREZID", annotation_cols)
  }

  ent <- m$entrez_id
  ens <- m$ensembl_id
  gt <- m$genetype_override

  if (!is.null(ann) && nrow(ann) > 0) {
    if (is.na(ent) || !nzchar(ent)) {
      ent <- as.character(ann$ENTREZID[1])
    }
    if (is.na(ens) || !nzchar(ens)) {
      ens <- as.character(ann$ENSEMBL[1])
    }
    if (is.na(gt) || !nzchar(gt)) {
      gt <- as.character(ann$GENETYPE[1])
    }
  }

  data.frame(
    Input_key = m$old_symbol,
    Candidate_symbol = m$new_symbol,
    ENTREZID = as.character(ent),
    ENSEMBL = as.character(ens),
    GENETYPE = as.character(gt),
    Mapping_Type = paste0("Retired_", m$source),
    Priority = 1L,
    Note = m$note,
    stringsAsFactors = FALSE
  )
})

manual_df <- do.call(rbind, manual_rows)

# ============================================================
# ============================================================
empty_cand <- data.frame(
  Input_key = character(),
  Candidate_symbol = character(),
  ENTREZID = character(),
  ENSEMBL = character(),
  GENETYPE = character(),
  Mapping_Type = character(),
  Priority = integer(),
  Note = character(),
  stringsAsFactors = FALSE
)

direct_raw <- safe_select(
  unique(common$Gene_input),
  "SYMBOL",
  annotation_cols
)

if (!is.null(direct_raw)) {
  direct_raw <- direct_raw[!is.na(direct_raw$ENTREZID), , drop = FALSE]
  direct_df <- data.frame(
    Input_key = toupper(direct_raw$SYMBOL),
    Candidate_symbol = as.character(direct_raw$SYMBOL),
    ENTREZID = as.character(direct_raw$ENTREZID),
    ENSEMBL = as.character(direct_raw$ENSEMBL),
    GENETYPE = as.character(direct_raw$GENETYPE),
    Mapping_Type = "SYMBOL_direct",
    Priority = 2L,
    Note = "",
    stringsAsFactors = FALSE
  )
  direct_df <- unique(direct_df)
} else {
  direct_df <- empty_cand
}

unique_keys <- unique(common$Input_key)
case_idx <- match(unique_keys, symbol_upper)

case_map <- data.frame(
  Input_key = unique_keys,
  Candidate_symbol = symbol_keys[case_idx],
  stringsAsFactors = FALSE
)
case_map <- case_map[!is.na(case_map$Candidate_symbol), , drop = FALSE]

if (nrow(case_map) > 0) {
  case_ann <- safe_select(
    unique(case_map$Candidate_symbol),
    "SYMBOL",
    annotation_cols
  )

  if (!is.null(case_ann)) {
    case_df <- merge(
      case_map,
      case_ann,
      by.x = "Candidate_symbol",
      by.y = "SYMBOL",
      all.x = TRUE,
      sort = FALSE
    )
    case_df <- case_df[!is.na(case_df$ENTREZID), , drop = FALSE]
    case_df$Mapping_Type <- "SYMBOL_case_insensitive"
    case_df$Priority <- 3L
    case_df$Note <- ""
    case_df <- case_df[
      ,
      c(
        "Input_key", "Candidate_symbol", "ENTREZID", "ENSEMBL",
        "GENETYPE", "Mapping_Type", "Priority", "Note"
      ),
      drop = FALSE
    ]
    case_df <- unique(case_df)
  } else {
    case_df <- empty_cand
  }
} else {
  case_df <- empty_cand
}

alias_raw <- safe_select(
  unique(c(common$Gene_input, common$Gene_key)),
  "ALIAS",
  c("ALIAS", "SYMBOL", "ENTREZID", "ENSEMBL", "GENETYPE")
)

if (!is.null(alias_raw)) {
  alias_raw <- alias_raw[
    !is.na(alias_raw$SYMBOL) &
      !is.na(alias_raw$ENTREZID),
    ,
    drop = FALSE
  ]

  alias_df <- data.frame(
    Input_key = toupper(alias_raw$ALIAS),
    Candidate_symbol = as.character(alias_raw$SYMBOL),
    ENTREZID = as.character(alias_raw$ENTREZID),
    ENSEMBL = as.character(alias_raw$ENSEMBL),
    GENETYPE = as.character(alias_raw$GENETYPE),
    Mapping_Type = "ALIAS",
    Priority = 4L,
    Note = "",
    stringsAsFactors = FALSE
  )
  alias_df <- unique(alias_df)
} else {
  alias_df <- empty_cand
}

cand_all <- rbind(manual_df, direct_df, case_df, alias_df)
cand_all <- cand_all[
  !is.na(cand_all$Input_key) & nzchar(cand_all$Input_key) &
    !is.na(cand_all$Candidate_symbol) & nzchar(cand_all$Candidate_symbol),
  ,
  drop = FALSE
]
cand_all$Candidate_symbol <- as.character(cand_all$Candidate_symbol)
cand_all$ENTREZID <- as.character(cand_all$ENTREZID)
cand_all$GENETYPE <- as.character(cand_all$GENETYPE)
cand_all <- unique(cand_all)

cand_all <- cand_all[
  order(
    cand_all$Input_key,
    cand_all$Priority,
    cand_all$Candidate_symbol,
    cand_all$ENTREZID,
    na.last = TRUE
  ),
  ,
  drop = FALSE
]
cand_all <- cand_all[
  !duplicated(paste(
    cand_all$Input_key,
    cand_all$Candidate_symbol,
    cand_all$ENTREZID,
    sep = "|"
  )),
  ,
  drop = FALSE
]

# ============================================================
# ============================================================
cand_all$Candidate_upper <- toupper(cand_all$Candidate_symbol)
cand_all$Separate_matrix_gene <- (
  length(expression_genes) > 0 &
    cand_all$Candidate_upper %in% expression_genes &
    cand_all$Candidate_upper != cand_all$Input_key
)

cand_f <- if (nrow(cand_all) == 0) {
  cand_all
} else {
  do.call(
    rbind,
    lapply(split(cand_all, cand_all$Input_key), function(d) {
      if (length(expression_genes) > 0 && any(!d$Separate_matrix_gene)) {
        d <- d[!d$Separate_matrix_gene, , drop = FALSE]
      }
      d
    })
  )
}
rownames(cand_f) <- NULL

# ============================================================
# ============================================================
resolve_candidate <- function(d) {
  if (nrow(d) == 0) {
    return(NULL)
  }

  if (all(d$Separate_matrix_gene)) {
    return(NULL)
  }

  manual_ok <- d[d$Priority == 1L & !d$Separate_matrix_gene, , drop = FALSE]
  if (nrow(manual_ok) > 0 &&
      length(unique(manual_ok$Candidate_symbol)) == 1 &&
      length(unique(manual_ok$ENTREZID[!is.na(manual_ok$ENTREZID)])) <= 1) {
    return(manual_ok[1, , drop = FALSE])
  }

  best_priority <- min(d$Priority, na.rm = TRUE)
  best <- d[d$Priority == best_priority, , drop = FALSE]
  best_syms <- unique(best$Candidate_symbol)
  best_ent <- unique(
    best$ENTREZID[!is.na(best$ENTREZID) & nzchar(best$ENTREZID)]
  )
  if (length(best_syms) == 1 && length(best_ent) <= 1) {
    return(best[1, , drop = FALSE])
  }

  d <- d[
    order(
      d$Priority,
      ifelse(is.na(d$GENETYPE) | d$GENETYPE != "protein-coding", 1L, 0L),
      is.na(d$ENSEMBL),
      na.last = TRUE
    ),
    ,
    drop = FALSE
  ]

  ent <- unique(d$ENTREZID[!is.na(d$ENTREZID) & nzchar(d$ENTREZID)])

  if (length(ent) == 1) {
    return(d[1, , drop = FALSE])
  }

  syms <- unique(d$Candidate_symbol)
  if (length(syms) == 1) {
    return(d[1, , drop = FALSE])
  }

  pc_syms <- unique(d$Candidate_symbol[d$GENETYPE == "protein-coding"])
  if (length(pc_syms) == 1) {
    z <- d[d$Candidate_symbol == pc_syms, , drop = FALSE]
    z_ent <- unique(z$ENTREZID[!is.na(z$ENTREZID) & nzchar(z$ENTREZID)])
    if (length(z_ent) <= 1) {
      return(z[1, , drop = FALSE])
    }
  }

  NULL
}

input_keys <- unique(common$Input_key)

resolved_list <- lapply(input_keys, function(k) {
  resolve_candidate(cand_f[cand_f$Input_key == k, , drop = FALSE])
})
names(resolved_list) <- input_keys

resolved_ok <- resolved_list[
  !vapply(resolved_list, is.null, logical(1))
]

if (length(resolved_ok) > 0) {
  resolved <- do.call(rbind, resolved_ok)
} else {
  resolved <- data.frame(
    Input_key = character(),
    Candidate_symbol = character(),
    ENTREZID = character(),
    ENSEMBL = character(),
    GENETYPE = character(),
    Mapping_Type = character(),
    Priority = integer(),
    Note = character(),
    Candidate_upper = character(),
    Separate_matrix_gene = logical(),
    stringsAsFactors = FALSE
  )
}
rownames(resolved) <- NULL

mapping_status <- vapply(input_keys, function(k) {
  d_all <- cand_all[cand_all$Input_key == k, , drop = FALSE]
  r <- resolved_list[[k]]

  if (!is.null(r)) {
    "Mapped"
  } else if (nrow(d_all) == 0) {
    "Unmapped"
  } else {
    "Ambiguous"
  }
}, character(1))

status_df <- data.frame(
  Input_key = input_keys,
  Mapping_status = mapping_status,
  stringsAsFactors = FALSE
)

candidate_summary <- if (nrow(cand_all) > 0) {
  z <- aggregate(
    Candidate_symbol ~ Input_key,
    data = cand_all,
    FUN = function(v) paste(sort(unique(v)), collapse = "; ")
  )
  colnames(z)[2] <- "Candidate_symbols"
  z
} else {
  data.frame(
    Input_key = character(),
    Candidate_symbols = character(),
    stringsAsFactors = FALSE
  )
}

# ============================================================
# ============================================================
mapped <- merge(
  common,
  resolved,
  by = "Input_key",
  all.x = TRUE,
  sort = FALSE
)

mapped <- merge(
  mapped,
  status_df,
  by = "Input_key",
  all.x = TRUE,
  sort = FALSE
)

mapped <- merge(
  mapped,
  candidate_summary,
  by = "Input_key",
  all.x = TRUE,
  sort = FALSE
)

mapped$HGNC_symbol <- mapped$Candidate_symbol
mapped$Protein_coding <- (
  !is.na(mapped$GENETYPE) &
    mapped$GENETYPE == "protein-coding"
)

mapped$Final_status <- "Kept"
mapped$Final_status[mapped$Mapping_status == "Unmapped"] <-
  "Dropped_unmapped"
mapped$Final_status[mapped$Mapping_status == "Ambiguous"] <-
  "Dropped_ambiguous"

is_clone_or_lncRNA <- function(x) {
  x <- toupper(trimws(as.character(x)))
  clone_pattern <- paste0(
    "^(RP[0-9]|CT[A-Z]|LL[0-9]|LA[0-9]|KB-|BP-|CH[0-9]|",
    "AC[0-9]{6}|AP[0-9]{6}|AL[0-9]{6}|AF[0-9]{6}|Z[0-9]{5}|",
    "DJ[0-9]|DKFZP|FLJ|KIAA|PP[0-9])"
  )
  (grepl(clone_pattern, x) & grepl("\\.[0-9]+$", x)) |
    grepl("^(DKFZP|PP[0-9]|FLJ|KIAA)", x) |
    grepl("^LINC[0-9]", x)
}

clone_unmapped <- (
  mapped$Final_status %in% c("Dropped_unmapped", "Dropped_ambiguous") &
    is_clone_or_lncRNA(mapped$Gene_input)
)
mapped$Final_status[clone_unmapped] <-
  "Dropped_clone_name_or_lncRNA"

mapped$Final_status[
  mapped$Final_status == "Kept" & !mapped$Protein_coding
] <- "Dropped_non_protein_coding"
mapped$Final_status[
  is.na(mapped$Direction)
] <- "Dropped_direction"

mapped$effect_strength <- (
  abs(mapped$logFC_original) + abs(mapped$logFC_adjusted)
) / 2

mapped$row_id <- seq_len(nrow(mapped))

# ============================================================
# ============================================================
kept <- mapped[mapped$Final_status == "Kept", , drop = FALSE]

if (nrow(kept) > 0) {
  ord <- order(
    kept$Priority,
    -kept$effect_strength,
    kept$Gene_input
  )
  keep_ids <- kept$row_id[ord][
    !duplicated(toupper(kept$HGNC_symbol[ord]))
  ]
  drop_ids <- setdiff(kept$row_id, keep_ids)

  mapped$Final_status[
    mapped$row_id %in% drop_ids
  ] <- "Dropped_duplicate_symbol"

  duplicate_rows <- mapped[
    mapped$row_id %in% drop_ids,
    ,
    drop = FALSE
  ]
} else {
  duplicate_rows <- mapped[0, , drop = FALSE]
}

# ============================================================
# ============================================================
final <- mapped[mapped$Final_status == "Kept", , drop = FALSE]

up_genes <- sort(unique(final$HGNC_symbol[final$Direction == "UP"]))
down_genes <- sort(unique(final$HGNC_symbol[final$Direction == "DOWN"]))

if (length(up_genes) + length(down_genes) == 0) {
  stop(
    "No gene passed the cleaning step (all are unmapped / ambiguous / non-coding).
",
    "Please check the input file, the annotation package version and retired_symbol_map.csv."
  )
}

check_clean <- function(x, label) {
  if (anyNA(x) || any(!nzchar(x))) {
    stop(label, " contains NA or empty symbols.")
  }
  if (anyDuplicated(toupper(x))) {
    stop(label, " contains symbols that are duplicated case-insensitively.")
  }
}

check_clean(up_genes, "UP")
check_clean(down_genes, "DOWN")

overlap <- intersect(up_genes, down_genes)
if (length(overlap) > 0) {
  writeLines(
    overlap,
    file.path(output_dir, "UP_DOWN_overlap_error.txt")
  )
  stop("The final UP and DOWN sets still overlap; the overlap list was written and the script stopped.")
}

writeLines(
  up_genes,
  file.path(output_dir, "LINCS_UP_protein_coding.txt")
)
writeLines(
  down_genes,
  file.path(output_dir, "LINCS_DOWN_protein_coding.txt")
)

final_out <- final[
  ,
  c(
    "HGNC_symbol", "Direction",
    "logFC_original", "logFC_adjusted", "Mapping_Type"
  ),
  drop = FALSE
]
colnames(final_out)[1] <- "Gene"
final_out <- final_out[order(final_out$Direction, final_out$Gene), , drop = FALSE]

write.csv(
  final_out,
  file.path(output_dir, "LINCS_all_protein_coding.csv"),
  row.names = FALSE,
  na = ""
)

# ============================================================
# ============================================================
qc_cols <- c(
  "Gene_input", "Gene_key", "Symbol_fixed",
  "logFC_original", "logFC_adjusted",
  "Dir_orig", "Dir_adj", "Direction",
  "Mapping_status", "Mapping_Type",
  "HGNC_symbol", "ENTREZID", "ENSEMBL", "GENETYPE",
  "Protein_coding", "Final_status",
  "Candidate_symbols", "Note"
)

qc_table <- mapped[, qc_cols, drop = FALSE]
qc_table <- qc_table[
  order(qc_table$Final_status, qc_table$Gene_input),
  ,
  drop = FALSE
]

write.csv(
  qc_table,
  file.path(output_dir, "Final_gene_cleaning_table.csv"),
  row.names = FALSE,
  na = ""
)

unmapped_ambiguous <- mapped[
  mapped$Final_status %in% c("Dropped_unmapped", "Dropped_ambiguous"),
  ,
  drop = FALSE
]
write.csv(
  unmapped_ambiguous[, qc_cols, drop = FALSE],
  file.path(output_dir, "Unmapped_or_ambiguous_genes.csv"),
  row.names = FALSE,
  na = ""
)

noncoding <- mapped[
  mapped$Final_status == "Dropped_non_protein_coding",
  ,
  drop = FALSE
]
write.csv(
  noncoding[, qc_cols, drop = FALSE],
  file.path(output_dir, "Dropped_non_protein_coding.csv"),
  row.names = FALSE,
  na = ""
)

clone_dropped <- mapped[
  mapped$Final_status == "Dropped_clone_name_or_lncRNA",
  ,
  drop = FALSE
]
write.csv(
  clone_dropped[, qc_cols, drop = FALSE],
  file.path(output_dir, "Dropped_clone_name_or_lncRNA.csv"),
  row.names = FALSE,
  na = ""
)

write.csv(
  duplicate_rows[, qc_cols, drop = FALSE],
  file.path(output_dir, "Duplicate_official_SYMBOL_collisions.csv"),
  row.names = FALSE,
  na = ""
)

manual_used <- manual_map[
  manual_map$old_symbol %in% unique(common$Input_key),
  ,
  drop = FALSE
]
write.csv(
  manual_used,
  file.path(output_dir, "Retired_symbol_map_used.csv"),
  row.names = FALSE,
  na = ""
)

# ============================================================
# ============================================================
count_kept_type <- function(type) {
  sum(final$Mapping_Type == type, na.rm = TRUE)
}

summary_df <- data.frame(
  Metric = c(
    "Input_rows",
    "Empty_gene_rows_removed",
    "Symbols_fixed",
    "Direction_problem_rows",
    "Unique_input_genes",
    "Mapped_direct_SYMBOL",
    "Mapped_case_insensitive",
    "Mapped_retired_symbol",
    "Mapped_ALIAS",
    "Unmapped",
    "Ambiguous",
    "Dropped_non_protein_coding",
    "Dropped_clone_name_or_lncRNA",
    "Dropped_duplicate_symbol",
    "Final_UP",
    "Final_DOWN",
    "Final_total",
    "Retired_symbol_map_rows_used"
  ),
  Count = c(
    nrow(common_raw),
    n_empty_gene,
    sum(nzchar(common$Symbol_fixed)),
    nrow(direction_problem),
    nrow(common),
    count_kept_type("SYMBOL_direct"),
    count_kept_type("SYMBOL_case_insensitive"),
    sum(grepl("^Retired_", final$Mapping_Type), na.rm = TRUE),
    count_kept_type("ALIAS"),
    sum(mapped$Final_status == "Dropped_unmapped", na.rm = TRUE),
    sum(mapped$Final_status == "Dropped_ambiguous", na.rm = TRUE),
    sum(mapped$Final_status == "Dropped_non_protein_coding", na.rm = TRUE),
    sum(mapped$Final_status == "Dropped_clone_name_or_lncRNA", na.rm = TRUE),
    sum(mapped$Final_status == "Dropped_duplicate_symbol", na.rm = TRUE),
    length(up_genes),
    length(down_genes),
    length(up_genes) + length(down_genes),
    nrow(manual_used)
  ),
  stringsAsFactors = FALSE
)

write.csv(
  summary_df,
  file.path(output_dir, "Cleaning_QC_summary.csv"),
  row.names = FALSE
)

# ============================================================
# 15. README + sessionInfo
# ============================================================
log_lines <- c(
  "TCGA CRC qCSC common DEG -> LINCS cleaning (optimized)",
  paste0("Run time: ", as.character(Sys.time())),
  paste0("Input file: ", input_file),
  paste0("Output directory: ", output_dir),
  "",
  "Mapping policy:",
  "1. Manual retired/previous/alias table (highest priority).",
  "2. Exact official SYMBOL.",
  "3. Case-insensitive official SYMBOL.",
  "4. org.Hs.eg.db ALIAS.",
  "5. If a candidate current symbol already exists as a separate row in the expression matrix, it is down-weighted/dropped to avoid merging two genes.",
  "6. Highest-priority candidate wins (manual > exact > case > alias); an alias cannot override an exact SYMBOL.",
  "7. Only GENETYPE == protein-coding is kept.",
  "8. Clone-name lncRNAs (RP11-/CTD-/AC.../LINC...) are reported separately as Dropped_clone_name_or_lncRNA, not as unmapped protein-coding genes.",
  "",
  "Manual map source:",
  if (file.exists(manual_map_file)) manual_map_file else "built-in table (13 symbols, HGNC 2026-10)",
  "",
  "Summary:",
  capture.output(print(summary_df, row.names = FALSE)),
  "",
  "Session info:",
  capture.output(sessionInfo())
)

writeLines(
  log_lines,
  file.path(output_dir, "README_summary.txt"),
  useBytes = TRUE
)

# ============================================================
# ============================================================
cat("\n============================================================\n")
cat("Cleaning complete
")
cat("============================================================\n")
print(summary_df, row.names = FALSE)
cat("
LINCS UP:
", length(up_genes), "\n", sep = "")
cat("LINCS DOWN: ", length(down_genes), "\n", sep = "")
cat("Output directory: 
", output_dir, "\n")
cat("
Note: GENETYPE is taken from org.Hs.eg.db; if GENCODE v50 is required, the annotation source must be unified.
")

## Record where the cleaned lists were written so that 01i can find them without
## relying on a fixed timestamp.
if (exists("out_root")) {
  try(writeLines(normalizePath(out_root, mustWork = FALSE),
                 file.path(DATA_ROOT,
                           "TCGA_CRC_qCSC_Common_DEG_LINCS_cleaning_LATEST.txt")),
      silent = TRUE)
}
