## ===========================================================================
## singlecell_clinical/02d_expression_classifier.R
## Tumour-versus-normal expression classifier for the malignant-cell call.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "paths.R"))

## Tumour-vs-normal epithelial expression classifier:
## train on GSE132465, apply to GSE188711 epithelial clusters.
suppressPackageStartupMessages({library(Seurat); library(SeuratObject); library(Matrix)})
root <- ROOT_SC
dir.create(out_dir, recursive=TRUE, showWarnings=FALSE)

collapse_by_symbol <- function(expr, symbols, total_counts=NULL) {
  symbols <- toupper(as.character(symbols)); ok <- !is.na(symbols) & nzchar(symbols)
  expr <- expr[ok,,drop=FALSE]; symbols <- symbols[ok]
  if (is.null(total_counts)) total_counts <- Matrix::rowSums(expr) else total_counts <- as.numeric(total_counts)[ok]
  ord <- order(symbols, -total_counts); expr <- expr[ord,,drop=FALSE]; symbols <- symbols[ord]
  keep <- !duplicated(symbols); expr <- expr[keep,,drop=FALSE]; rownames(expr) <- symbols[keep]; expr
}

## ---- GSE132465 ----
obj <- readRDS(find_qc132(root))
meta <- obj[[]]
keep <- !is.na(meta$Cell_type) & meta$Cell_type=="Epithelial cells" &
  !is.na(meta$Class) & meta$Class %in% c("Tumor","Normal")
obj <- subset(obj, cells=rownames(meta)[keep])
obj <- NormalizeData(obj, assay="RNA", normalization.method="LogNormalize", scale.factor=10000, verbose=FALSE)
expr <- SeuratObject::LayerData(obj[["RNA"]], layer="data")
counts <- SeuratObject::LayerData(obj[["RNA"]], layer="counts")
expr <- collapse_by_symbol(expr, rownames(expr), Matrix::rowSums(counts))
meta <- obj[[]][colnames(expr),,drop=FALSE]
is_t <- meta$Class=="Tumor"
mean_t <- Matrix::rowMeans(expr[,is_t,drop=FALSE])
mean_n <- Matrix::rowMeans(expr[,!is_t,drop=FALSE])
det_t <- Matrix::rowMeans(expr[,is_t,drop=FALSE] > 0)
det_n <- Matrix::rowMeans(expr[,!is_t,drop=FALSE] > 0)
lfc <- mean_t - mean_n
ok <- det_t >= 0.10 & det_n >= 0.10 & is.finite(lfc)
up <- names(sort(lfc[ok & lfc > 1], decreasing=TRUE))[1:min(200, sum(ok & lfc > 1))]
dn <- names(sort(lfc[ok & lfc < -1], decreasing=FALSE))[1:min(200, sum(ok & lfc < -1))]
cat("tumour-up:", length(up), " normal-up:", length(dn), "\n")
writeLines(up, file.path(out_dir,"malignant_up_genes.txt"))
writeLines(dn, file.path(out_dir,"normal_up_genes.txt"))

## z-score across cells (gene-wise) and module score
z <- function(E, g) {
  g <- intersect(g, rownames(E)); if (!length(g)) return(rep(NA_real_, ncol(E)))
  X <- as.matrix(E[g,,drop=FALSE])
  X <- (X - rowMeans(X)) / pmax(apply(X,1,sd), 1e-6)
  colMeans(X)
}
score_t <- z(expr, up); score_n <- z(expr, dn)
mal_score <- score_t - score_n
cat("GSE132465 AUC malignant score:", {
  w <- wilcox.test(mal_score[is_t], mal_score[!is_t]); as.numeric(w$statistic)/(sum(is_t)*sum(!is_t))
}, "\n")
saveRDS(list(up=up, dn=dn, score=mal_score, meta=meta), file.path(out_dir,"malignancy_gse132465.rds"))
rm(obj, expr, counts); gc()

## ---- GSE188711 ----
obj <- readRDS(find_gse188_clustered(root))
meta2 <- obj[[]]
keep2 <- as.character(meta2$seurat_clusters) %in% c("5","14")
obj <- subset(obj, cells=rownames(meta2)[keep2])
expr2 <- SeuratObject::LayerData(obj[["RNA"]], layer="data")
counts2 <- SeuratObject::LayerData(obj[["RNA"]], layer="counts")
fmeta <- obj[["RNA"]][[]]
expr2 <- collapse_by_symbol(expr2, fmeta$gene_symbol, Matrix::rowSums(counts2))
meta2 <- obj[[]][colnames(expr2),,drop=FALSE]
score2_t <- z(expr2, up); score2_n <- z(expr2, dn)
mal2 <- score2_t - score2_n
cat("GSE188711 cluster means:\n"); print(tapply(mal2, meta2$seurat_clusters, summary))
w <- wilcox.test(mal2[meta2$seurat_clusters=="14"], mal2[meta2$seurat_clusters=="5"])
cat("AUC cluster14 vs 5:", as.numeric(w$statistic)/(sum(meta2$seurat_clusters=="14")*sum(meta2$seurat_clusters=="5")), "\n")
saveRDS(list(score=mal2, meta=meta2), file.path(out_dir,"malignancy_gse188711.rds"))
cat("done\n")
