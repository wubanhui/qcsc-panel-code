## ===========================================================================
## figures/08d_Fig4_prognosis_MMR.R
## Figure 4A-D: Kaplan-Meier curves, Cox forest plot and the MMR ROC/density.
## The log-rank P values printed on the curves are also written to a table.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
############################################################
#
#
############################################################


if (!requireNamespace("pROC", quietly = TRUE)) {
  stop("Install pROC first: install.packages('pROC')")
}

if (!requireNamespace("survival", quietly = TRUE)) {
  stop("Install the survival package first")
}

library(pROC)
library(survival)


input_dir  <- TAB_DIR
output_dir <- FIG_DIR

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}


cat("Reading data...
")

need <- c(
  "external_GSE39582_scores.csv",
  "external_GSE14333_scores.csv",
  "external_GSE39582_cox.csv",
  "external_GSE14333_cox.csv"
)

for (f in need) {
  p <- file.path(input_dir, f)
  
  cat(sprintf("  %-38s %s\n", f, ifelse(file.exists(p), "OK", "MISSING")))
  
  if (!file.exists(p)) {
    stop("File does not exist: ", p)
  }
}

dat_39582 <- read.csv(
  file.path(input_dir, "external_GSE39582_scores.csv"),
  stringsAsFactors = FALSE
)

dat_14333 <- read.csv(
  file.path(input_dir, "external_GSE14333_scores.csv"),
  stringsAsFactors = FALSE
)

cox_39582 <- read.csv(
  file.path(input_dir, "external_GSE39582_cox.csv"),
  stringsAsFactors = FALSE
)

cox_14333 <- read.csv(
  file.path(input_dir, "external_GSE14333_cox.csv"),
  stringsAsFactors = FALSE
)



tt_39582 <- dat_39582[dat_39582$cohort != "Non Tumoral", ]

cat("GSE39582 tumour samples: ", nrow(tt_39582), "\n")



panel_median_39582 <- median(tt_39582$panel, na.rm = TRUE)

tt_39582$group <- factor(
  ifelse(tt_39582$panel >= panel_median_39582, "high", "low"),
  levels = c("low", "high")
)



dd_mmr <- tt_39582[!is.na(tt_39582$mmr), ]

dd_mmr$y <- as.integer(dd_mmr$mmr == "dMMR")

cat(sprintf(
  "  MMR available: %d (dMMR=%d, pMMR=%d)
",
  nrow(dd_mmr),
  sum(dd_mmr$y),
  sum(!dd_mmr$y)
))



dd_14333 <- dat_14333[
  !is.na(dat_14333$dfs_time) &
    !is.na(dat_14333$dfs_event) &
    dat_14333$dfs_time > 0,
]

cat(sprintf(
  "GSE14333 DFS available: %d (events=%d)
",
  nrow(dd_14333),
  sum(dd_14333$dfs_event)
))



dd_14333$group <- factor(
  ifelse(
    dd_14333$panel >= median(dd_14333$panel),
    "high",
    "low"
  ),
  levels = c("low", "high")
)

print(table(dd_14333$group))



fmt_cox <- function(tbl, endpoint, model_name, label) {
  
  r <- tbl[
    tbl$endpoint == endpoint &
      tbl$model == model_name,
    ,
    drop = FALSE
  ]
  
  if (nrow(r) == 0) {
    warning(sprintf(
      "Cox row not found: endpoint=%s, model=%s",
      endpoint,
      model_name
    ))
    return(paste0(label, ": NA"))
  }
  
  if (nrow(r) > 1) {
    stop(sprintf(
      "Cox row not unique: endpoint=%s, model=%s",
      endpoint,
      model_name
    ))
  }
  
  sprintf(
    "%s = %.2f (%.2f-%.2f), P = %.3f",
    label,
    r$HR[1] + 1e-9,
    r$CI_low[1] + 1e-9,
    r$CI_high[1] + 1e-9,
    r$P[1]
  )
}


hr_39582_os <- fmt_cox(
  cox_39582,
  "OS",
  "panel continuous (per SD), adjusted",
  "adj. HR/SD"
)

hr_39582_rfs <- fmt_cox(
  cox_39582,
  "RFS",
  "panel continuous (per SD), adjusted",
  "adj. HR/SD"
)

hr_14333 <- fmt_cox(
  cox_14333,
  "DFS",
  "panel continuous (per SD), adjusted",
  "adj. HR/SD"
)


cat(
  "
HR labels drawn on the figure:
",
  "  GSE39582 OS :", hr_39582_os,
  "\n  GSE39582 RFS:", hr_39582_rfs,
  "\n  GSE14333 DFS:", hr_14333,
  "\n"
)



if (hr_39582_os == hr_39582_rfs) {
  warning("The OS and RFS labels for GSE39582 are still identical; check the structure of the Cox table.")
}


# ==========================================================
# ==========================================================

## ROC
roc_obj <- roc(
  dd_mmr$y,
  dd_mmr$panel,
  levels = c(0, 1),
  direction = "<",
  quiet = TRUE
)

ci_auc <- ci.auc(roc_obj, method = "delong")

cat(sprintf(
  "\nROC: AUC = %.3f (95%%CI %.3f-%.3f)\n",
  ci_auc[2], ci_auc[1], ci_auc[3]
))


thr <- 0.5732

col_pmmr <- rgb(0.17, 0.50, 0.72, 0.60)
col_dmmr <- rgb(0.85, 0.37, 0.05, 0.60)

brk <- seq(
  min(dd_mmr$panel, na.rm = TRUE),
  max(dd_mmr$panel, na.rm = TRUE),
  length.out = 31
)

h1 <- hist(dd_mmr$panel[dd_mmr$y == 1], breaks = brk, plot = FALSE)
h0 <- hist(dd_mmr$panel[dd_mmr$y == 0], breaks = brk, plot = FALSE)

h1$density <- h1$counts / (sum(h1$counts) * diff(h1$breaks)[1])
h0$density <- h0$counts / (sum(h0$counts) * diff(h0$breaks)[1])

d0 <- density(dd_mmr$panel[dd_mmr$y == 0], bw = "SJ")
d1 <- density(dd_mmr$panel[dd_mmr$y == 1], bw = "SJ")

ymax <- max(c(h0$density, h1$density, d0$y, d1$y)) * 1.20


## GSE14333 DFS
sf_14333 <- survfit(Surv(dfs_time, dfs_event) ~ group, data = dd_14333)
lr_14333 <- survdiff(Surv(dfs_time, dfs_event) ~ group, data = dd_14333)
p_lr_14333 <- 1 - pchisq(lr_14333$chisq, df = 1)

cat(sprintf(
  "GSE14333 DFS: log-rank P = %.3f (high %d / low %d)\n",
  p_lr_14333,
  sum(dd_14333$group == "high"),
  sum(dd_14333$group == "low")
))


## GSE39582 OS
dd_os <- tt_39582[!is.na(tt_39582$os_time) & !is.na(tt_39582$os_event), ]

sf_os <- survfit(Surv(os_time, os_event) ~ group, data = dd_os)
lr_os <- survdiff(Surv(os_time, os_event) ~ group, data = dd_os)
p_lr_os <- 1 - pchisq(lr_os$chisq, df = 1)

cat(sprintf(
  "GSE39582 OS:  n = %d / %d, events = %d, log-rank P = %.3f\n",
  sum(dd_os$group == "high"),
  sum(dd_os$group == "low"),
  sum(dd_os$os_event),
  p_lr_os
))


## GSE39582 RFS
dd_rfs <- tt_39582[!is.na(tt_39582$rfs_time) & !is.na(tt_39582$rfs_event), ]

sf_rfs <- survfit(Surv(rfs_time, rfs_event) ~ group, data = dd_rfs)
lr_rfs <- survdiff(Surv(rfs_time, rfs_event) ~ group, data = dd_rfs)
p_lr_rfs <- 1 - pchisq(lr_rfs$chisq, df = 1)

cat(sprintf(
  "GSE39582 RFS: n = %d / %d, events = %d, log-rank P = %.3f\n",
  sum(dd_rfs$group == "high"),
  sum(dd_rfs$group == "low"),
  sum(dd_rfs$rfs_event),
  p_lr_rfs
))


# ==========================================================
# ==========================================================

draw_roc <- function() {
  
  par(
    mar = c(4.5, 4.5, 1.5, 1.5),
    mgp = c(2.5, 0.7, 0),
    font.lab = 1,
    las = 1
  )
  
  plot(
    roc_obj,
    col = "#D95F0E",
    lwd = 2.5,
    legacy.axes = TRUE,
    xlab = "1 - Specificity",
    ylab = "Sensitivity (dMMR)",
    cex.lab = 1.6,
    cex.axis = 1.5
  )
  
  abline(0, 1, lty = 2, col = "grey60")
  
  legend(
    "bottomright",
    bty = "n",
    cex = 1.1,
    legend = sprintf(
      "panel, AUC = %.3f (%.3f-%.3f)",
      ci_auc[2], ci_auc[1], ci_auc[3]
    ),
    lwd = 2.5,
    col = "#D95F0E"
  )
}


draw_dist <- function() {
  
  par(
    mar = c(4.5, 4.5, 1.5, 1.5),
    mgp = c(2.5, 0.7, 0),
    font.lab = 1,
    las = 1
  )
  
  plot(
    NA,
    xlim = range(brk),
    ylim = c(0, ymax),
    bty = "l",
    xlab = "qCSC panel score",
    ylab = "Density",
    cex.lab = 1.4,
    cex.axis = 1.3
  )
  
  with(
    h0,
    rect(
      breaks[-length(breaks)], 0, breaks[-1], density,
      col = col_pmmr, border = NA
    )
  )
  
  with(
    h1,
    rect(
      breaks[-length(breaks)], 0, breaks[-1], density,
      col = col_dmmr, border = NA
    )
  )
  
  lines(d0, col = "#1F6D9E", lwd = 2.2)
  lines(d1, col = "#B24A06", lwd = 2.2)
  
  abline(v = thr, lty = 2, lwd = 1.5)
  
  text(
    thr, ymax * 0.55,
    sprintf("Youden = %.3f", thr),
    pos = 2, cex = 0.85, srt = 90, offset = 0.35
  )
  
  legend(
    "topright",
    bty = "n",
    cex = 1.0,
    fill = c(col_pmmr, col_dmmr),
    border = NA,
    legend = c(
      sprintf("pMMR (n = %d)", sum(!dd_mmr$y)),
      sprintf("dMMR (n = %d)", sum(dd_mmr$y))
    )
  )
  
  mtext(
    "Each group normalised to unit area",
    side = 3, line = 0.2, adj = 0, cex = 1, col = "grey35"
  )
}


draw_dfs <- function() {
  
  par(
    mar = c(4.5, 4.5, 1.5, 1.5),
    mgp = c(2.5, 0.7, 0),
    font.lab = 1,
    las = 1
  )
  
  plot(
    sf_14333,
    col = c("#2C7FB8", "#D95F0E"),
    lwd = 2.2,
    mark.time = TRUE,
    xaxs = "i",
    yaxs = "i",
    bty = "l",
    xlab = "Time (months)",
    ylab = "Disease-free survival",
    cex.lab = 1.6,
    cex.axis = 1.5
  )
  
  abline(h = 0.5, lty = 3, col = "grey55")
  abline(v = 60,  lty = 3, col = "grey55")
  
  legend(
    "topright",
    bty = "n",
    lwd = 2.4,
    col = c("#2C7FB8", "#D95F0E"),
    cex = 1.05,
    legend = c(
      sprintf("panel low (n = %d)",  sum(dd_14333$group == "low")),
      sprintf("panel high (n = %d)", sum(dd_14333$group == "high"))
    )
  )
  
  legend(
    "bottomleft",
    bty = "n",
    cex = 0.95,
    inset = c(0.06, 0.02),
    legend = c(
      hr_14333,
      sprintf("log-rank P = %.2f", p_lr_14333)
    )
  )
}


draw_os_rfs <- function() {
  
  par(
    mfrow = c(1, 2),
    mar = c(4.5, 4.5, 1.5, 1.5),
    mgp = c(2.5, 0.7, 0),
    font.lab = 1,
    las = 1
  )
  
  ## OS
  plot(
    sf_os,
    col = c("#2C7FB8", "#D95F0E"),
    lwd = 2.2,
    mark.time = TRUE,
    xaxs = "i",
    yaxs = "i",
    bty = "l",
    xlab = "Time (months)",
    ylab = "Overall survival",
    cex.lab = 1.6,
    cex.axis = 1.5
  )
  
  abline(h = 0.5, lty = 3, col = "grey55")
  abline(v = 60,  lty = 3, col = "grey55")
  
  legend(
    "topright",
    bty = "n",
    lwd = 2.4,
    col = c("#2C7FB8", "#D95F0E"),
    cex = 1.05,
    legend = c(
      sprintf("low (n = %d)",  sum(dd_os$group == "low")),
      sprintf("high (n = %d)", sum(dd_os$group == "high"))
    )
  )
  
  legend(
    "bottomleft",
    bty = "n",
    cex = 0.95,
    inset = c(0.06, 0.02),
    legend = c(
      hr_39582_os,
      sprintf("log-rank P = %.2f", p_lr_os)
    )
  )
  
  ## RFS
  plot(
    sf_rfs,
    col = c("#2C7FB8", "#D95F0E"),
    lwd = 2.2,
    mark.time = TRUE,
    xaxs = "i",
    yaxs = "i",
    bty = "l",
    xlab = "Time (months)",
    ylab = "Relapse-free survival",
    cex.lab = 1.5,
    cex.axis = 1.4
  )
  
  abline(h = 0.5, lty = 3, col = "grey55")
  abline(v = 60,  lty = 3, col = "grey55")
  
  legend(
    "topright",
    bty = "n",
    lwd = 2.4,
    col = c("#2C7FB8", "#D95F0E"),
    cex = 1.05,
    legend = c(
      sprintf("low (n = %d)",  sum(dd_rfs$group == "low")),
      sprintf("high (n = %d)", sum(dd_rfs$group == "high"))
    )
  )
  
  legend(
    "bottomleft",
    bty = "n",
    cex = 0.95,
    inset = c(0.06, 0.02),
    legend = c(
      hr_39582_rfs,
      sprintf("log-rank P = %.2f", p_lr_rfs)
    )
  )
}


# ==========================================================
# ==========================================================

save_plot <- function(draw_fun, name, width, height) {
  
  pdf_file <- file.path(output_dir, paste0(name, ".pdf"))
  png_file <- file.path(output_dir, paste0(name, ".png"))
  
  pdf(pdf_file, width = width, height = height, useDingbats = FALSE)
  draw_fun()
  dev.off()
  
  png(
    png_file,
    width = width, height = height,
    units = "in", res = 600, type = "cairo", bg = "white"
  )
  draw_fun()
  dev.off()
  
  cat(sprintf(
    "  %-28s PDF: %-4s  PNG: %-4s\n",
    name,
    ifelse(file.exists(pdf_file) && file.size(pdf_file) > 1000, "OK", "FAIL"),
    ifelse(file.exists(png_file) && file.size(png_file) > 1000, "OK", "FAIL")
  ))
}


# ==========================================================
# ==========================================================

cat("
========== Exporting figures ==========
")

save_plot(draw_roc,    "Fig1_ROC",             5,   5)
save_plot(draw_dist,   "Fig2_Distribution",    5,   4.5)
save_plot(draw_dfs,    "Fig3_GSE14333_DFS",    5,   4.8)
save_plot(draw_os_rfs, "Fig4_GSE39582_OS_RFS", 10,  4.5)


# ==========================================================
# ==========================================================

cat("\n=========================================\n")
cat("All 4 figures have been drawn.
")
cat("Output path: ", output_dir, "\n")
cat("=========================================\n\n")

output_files <- c(
  "Fig1_ROC.pdf",             "Fig1_ROC.png",
  "Fig2_Distribution.pdf",    "Fig2_Distribution.png",
  "Fig3_GSE14333_DFS.pdf",    "Fig3_GSE14333_DFS.png",
  "Fig4_GSE39582_OS_RFS.pdf", "Fig4_GSE39582_OS_RFS.png"
)

cat("Checking output files:
")

all_ok <- TRUE

for (f in output_files) {
  
  fp <- file.path(output_dir, f)
  ok <- file.exists(fp) && file.size(fp) > 1000
  
  if (!ok) all_ok <- FALSE
  
  cat(sprintf(
    "  %-35s %-8s %s\n",
    f,
    ifelse(ok, "OK", "MISSING"),
    ifelse(file.exists(fp), paste0(round(file.size(fp) / 1024), " KB"), "-")
  ))
}

if (!all_ok) {
  warning("Some output files were not created or have an abnormal size; please check.")
}

cat("
All tasks finished.
")
