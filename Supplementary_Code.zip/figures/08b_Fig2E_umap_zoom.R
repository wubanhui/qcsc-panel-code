## ===========================================================================
## figures/08b_Fig2E_umap_zoom.R
##
## Figure 2E: zoom of the GSE188711 epithelial UMAP showing cluster 5 and
## cluster 14, with outlying cells removed by the 3.5 MAD rule.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
############################################################
#
#
############################################################


############################
############################

suppressPackageStartupMessages({
  
  library(Seurat)
  library(ggplot2)
  
})


############################
############################

## 01a writes its clustered object into a timestamped rebuild_* directory, so take
## the newest one instead of a fixed name.
.rebuild_dirs <- sort(
  Sys.glob(file.path(DATA_ROOT, "GSE188711_SchemeA_marker_annotation", "rebuild_*")),
  decreasing = TRUE
)
if (!length(.rebuild_dirs)) {
  stop("No rebuild_* directory under ", file.path(DATA_ROOT, "GSE188711_SchemeA_marker_annotation"))
}
obj_file <- file.path(.rebuild_dirs[1],
                      "10_GSE188711_clustered_with_score_groups.rds")

out_file <- file.path(FIG_DIR, "Fig_UMAP_epithelial_zoom")

pdf_file <- paste0(out_file, ".pdf")
png_file <- paste0(out_file, ".png")
csv_file <- paste0(out_file, "_statistics.csv")


############################
############################

if (!file.exists(obj_file)) {
  stop(
    "ERROR: Seurat object not found: \n",
    obj_file
  )
}


############################
############################

cat("\n========== Reading the Seurat object ==========\n")

obj <- readRDS(obj_file)

if (!inherits(obj, "Seurat")) {
  stop("ERROR: the input file is not a Seurat object.")
}

if (!"umap" %in% Reductions(obj)) {
  stop("ERRORdoes not existUMAPresult")
}

if (!"seurat_clusters" %in% colnames(obj@meta.data)) {
  stop("ERRORdoes not existseurat_clusters")
}

cat("Seurat\n")
cat("", ncol(obj), "\n")


############################
############################

emb <- Embeddings(
  obj,
  reduction = "umap"
)[, 1:2, drop = FALSE]

colnames(emb) <- c(
  "UMAP_1",
  "UMAP_2"
)

cl <- as.character(
  obj$seurat_clusters
)

df_all <- data.frame(
  emb,
  cluster = cl
)


############################
############################

df <- df_all[
  df_all$cluster %in% c("14", "5"),
  ,
  drop = FALSE
]

rownames(df) <- NULL

if (nrow(df) == 0) {
  stop("ERRORextractingCluster 5Cluster 14")
}

cat("\n========== epithelial cells ==========\n")

cat(
  "epithelial cells",
  nrow(df),
  "\n"
)

cat(
  "Cluster 14",
  sum(df$cluster == "14"),
  "\n"
)

cat(
  "Cluster 5",
  sum(df$cluster == "5"),
  "\n"
)


############################
############################


zoom_factor <- 3.5

median_x <- median(df$UMAP_1)
median_y <- median(df$UMAP_2)

mad_x <- mad(
  df$UMAP_1,
  constant = 1.4826
)

mad_y <- mad(
  df$UMAP_2,
  constant = 1.4826
)

if (
  !is.finite(mad_x) ||
  !is.finite(mad_y) ||
  mad_x <= 0 ||
  mad_y <= 0
) {
  stop("ERRORUMAPMADoutliers")
}

x_lower <- median_x - zoom_factor * mad_x
x_upper <- median_x + zoom_factor * mad_x

y_lower <- median_y - zoom_factor * mad_y
y_upper <- median_y + zoom_factor * mad_y

keep_cells <- (
  df$UMAP_1 >= x_lower &
    df$UMAP_1 <= x_upper &
    df$UMAP_2 >= y_lower &
    df$UMAP_2 <= y_upper
)

df_keep <- df[
  keep_cells,
  ,
  drop = FALSE
]

df_removed <- df[
  !keep_cells,
  ,
  drop = FALSE
]

rownames(df_keep) <- NULL
rownames(df_removed) <- NULL

if (nrow(df_keep) == 0) {
  stop("ERRORMADzoom_factor")
}

if (!all(c("5", "14") %in% unique(df_keep$cluster))) {
  stop(
    "ERRORcluster",
    "zoom_factor"
  )
}

cat("\n========== MADoutliersresult ==========\n")

cat("cells", nrow(df), "\n")
cat("cells", nrow(df_keep), "\n")
cat("excludedcells", nrow(df_removed), "\n")

cat(
  "",
  round(100 * nrow(df_keep) / nrow(df), 2),
  "%\n"
)

cat("\ncluster\n")
print(table(df_keep$cluster))

cat("\nclusterexcluded\n")
print(table(df_removed$cluster))


############################
############################

xr <- range(df_keep$UMAP_1)
yr <- range(df_keep$UMAP_2)

padding <- 0.08

x_padding <- diff(xr) * padding
y_padding <- diff(yr) * padding

xr <- xr + c(
  -x_padding,
  x_padding
)

yr <- yr + c(
  -y_padding,
  y_padding
)


############################
############################

lab <- aggregate(
  cbind(UMAP_1, UMAP_2) ~ cluster,
  data = df_keep,
  FUN = median
)

lab$label <- paste0(
  "Cluster ",
  lab$cluster
)


############################
############################

cols <- c(
  "14" = "#4DBBD5",
  "5" = "#E64B35"
)


############################
############################

cat("\n========== startPlotting ==========\n")

p <- ggplot(
  df_keep,
  aes(
    x = UMAP_1,
    y = UMAP_2,
    color = cluster
  )
) +
  
  geom_point(
    size = 1.1,
    alpha = 0.9
  ) +
  
  scale_color_manual(
    values = cols,
    breaks = c("14", "5"),
    labels = c("14", "5")
  ) +
  
  coord_cartesian(
    xlim = xr,
    ylim = yr,
    expand = FALSE
  ) +
  
  geom_label(
    data = lab,
    aes(
      x = UMAP_1,
      y = UMAP_2,
      label = label
    ),
    inherit.aes = FALSE,
    size = 5.5,
    fontface = "bold",
    label.size = 0.25,
    alpha = 0.9,
    fill = "white"
  ) +
  
  labs(
    title = NULL,
    color = NULL
  ) +
  
  theme_classic(
    base_size = 11
  ) +
  
  theme(
    
    plot.title = element_blank(),
    
    legend.title = element_blank(),
    
    legend.position = "right",
    
    legend.text = element_text(
      size = 15
    ),
    
    axis.text = element_blank(),
    
    axis.ticks = element_blank(),
    
    axis.title = element_blank(),
    
    panel.grid = element_blank()
    
  )


############################
############################

ggsave(
  filename = pdf_file,
  plot = p,
  width = 5.5,
  height = 5,
  units = "in",
  bg = "white"
)


############################
############################

ggsave(
  filename = png_file,
  plot = p,
  width = 5.5,
  height = 5,
  units = "in",
  dpi = 600,
  bg = "white"
)


############################
############################

statistics <- data.frame(
  
  cluster = c("5", "14"),
  
  original_cells = c(
    sum(df$cluster == "5"),
    sum(df$cluster == "14")
  ),
  
  retained_cells = c(
    sum(df_keep$cluster == "5"),
    sum(df_keep$cluster == "14")
  ),
  
  excluded_cells = c(
    sum(df_removed$cluster == "5"),
    sum(df_removed$cluster == "14")
  )
  
)

write.csv(
  statistics,
  file = csv_file,
  row.names = FALSE,
  fileEncoding = "UTF-8"
)


############################
############################

cat("\n========== done ==========\n")

cat("PDFfile\n", pdf_file, "\n\n")

cat("PNGfile\n", png_file, "\n\n")

cat("Summary\n", csv_file, "\n\n")

cat("MAD", zoom_factor, "\n")

cat("title\n")

cat("legendtitle\n")

cat("Cluster 5 and Cluster 14\n")

cat("Seurat\n")