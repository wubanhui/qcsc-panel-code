## ===========================================================================
## gene_signature/01h_gene_funnel_summary.R
##
## Assemble the complete gene-selection funnel (301 -> 290 -> 285 -> 2,795 ->
## 1,595 -> 1,295 -> 885) into a single table.
## 
## ===========================================================================
## ===========================================================================
## gene_signature/01i_gene_funnel_summary.R
##
## Assemble the complete gene-selection funnel reported in the manuscript and
## write it as a single table:
##
##   301  genes reported by the three qCSC models (merged, de-duplicated)
##   290  protein-coding signature genes
##   285  detectable in the TCGA expression matrix (used for ssGSEA)
##  2795  DEG between high and low qCSC-score TCGA tumours (unadjusted limma)
##  1595  DEG after adjusting for ESTIMATE stromal and immune scores
##  1295  concordant in both models (967 up / 328 down)
##   885  after symbol standardisation and protein-coding filtering
##
## The script only reads existing intermediate files; it re-runs no analysis.
## ===========================================================================

## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

suppressPackageStartupMessages({ library(data.table) })

cat("\n================ Gene-selection funnel ================\n")

## ---------------------------------------------------------------------------
## Helper: read a one-column gene list
## ---------------------------------------------------------------------------
read_gene_list <- function(path) {
  if (!file.exists(path)) return(NULL)
  x <- readLines(path, warn = FALSE, encoding = "UTF-8")
  x <- trimws(x)
  x <- x[nzchar(x)]
  unique(toupper(x))
}

## ---------------------------------------------------------------------------
## Stage 1: seed genes reported by the three qCSC models
## ---------------------------------------------------------------------------
seed_raw <- read_gene_list(file.path(ROOT_DEG_GSVA, "signature.txt"))
if (is.null(seed_raw)) {
  seed_raw <- read_gene_list(file.path(DATA_ROOT, "signature.txt"))
}
n_seed_raw <- if (is.null(seed_raw)) NA_integer_ else length(seed_raw)
cat(sprintf("1. Seed genes from the three models (merged, de-duplicated): %s\n",
            ifelse(is.na(n_seed_raw), "not available", n_seed_raw)))

## ---------------------------------------------------------------------------
## Stage 2: protein-coding signature genes
## ---------------------------------------------------------------------------
## Locate the signature-construction output (01h writes a timestamped folder).
sig_ptr <- file.path(DATA_ROOT, "CRC_qCSC_signature_publication_LATEST.txt")
sig_dir <- if (file.exists(sig_ptr)) {
  d <- trimws(readLines(sig_ptr, n = 1, warn = FALSE))
  if (nzchar(d) && dir.exists(d)) d else NA_character_
} else NA_character_
if (is.na(sig_dir)) {
  d <- sort(Sys.glob(file.path(DATA_ROOT, "CRC_qCSC_signature_publication_*")),
            decreasing = TRUE)
  sig_dir <- if (length(d)) d[1] else NA_character_
}
pc290 <- NULL
cand_290 <- c(
  if (!is.na(sig_dir)) file.path(sig_dir, "CRC_qCSC_final_protein_coding_gene_signature.txt"),
  if (!is.na(sig_dir)) file.path(sig_dir, "10_CRC_qCSC_protein_coding_signature_290genes.txt"),
  file.path(ROOT_DEG_GSVA, "CRC_qCSC_final_protein_coding_gene_signature.txt")
)
for (f in cand_290) {
  if (file.exists(f)) { pc290 <- read_gene_list(f); break }
}
n_pc <- if (is.null(pc290)) NA_integer_ else length(pc290)
cat(sprintf("2. Protein-coding signature genes: %s\n",
            ifelse(is.na(n_pc), "not available", n_pc)))

## ---------------------------------------------------------------------------
## Stage 3: genes detectable in the TCGA matrix
## ---------------------------------------------------------------------------
eff285 <- NULL
for (f in c(Sys.glob(file.path(DATA_ROOT, "TCGA_qCSC_score_GSVA", "run_*",
                               "CRC_qCSC_signature_effective_for_scoring.txt")),
            file.path(ROOT_DEG_GSVA, "CRC_qCSC_signature_effective_for_scoring.txt"))) {
  if (length(f) && file.exists(f[1])) { eff285 <- read_gene_list(f[1]); break }
}
n_eff <- if (is.null(eff285)) NA_integer_ else length(eff285)
cat(sprintf("3. Detectable in the TCGA expression matrix: %s\n",
            ifelse(is.na(n_eff), "not available", n_eff)))

## ---------------------------------------------------------------------------
## Stage 4-6: differential expression in TCGA
## ---------------------------------------------------------------------------
deg_unadj <- NULL
f <- find_deg_file("DEG_FINAL.csv")
if (!is.na(f) && file.exists(f)) deg_unadj <- fread(f)

deg_adj <- NULL
f2 <- Sys.glob(file.path(DATA_ROOT, "TCGA_CRC_ESTIMATE_GSVA_*",
                         "DEG_ESTIMATE_adjusted_FINAL.csv"))
f2 <- sort(f2, decreasing = TRUE)
if (length(f2) && file.exists(f2[1])) deg_adj <- fread(f2[1])

n_unadj <- if (is.null(deg_unadj)) NA_integer_ else nrow(deg_unadj)
n_adj   <- if (is.null(deg_adj))   NA_integer_ else nrow(deg_adj)

n_up_unadj <- n_down_unadj <- NA_integer_
if (!is.null(deg_unadj) && "logFC" %in% names(deg_unadj)) {
  n_up_unadj   <- sum(deg_unadj$logFC > 0, na.rm = TRUE)
  n_down_unadj <- sum(deg_unadj$logFC < 0, na.rm = TRUE)
}
cat(sprintf("4. DEG, unadjusted limma model: %s%s\n",
            ifelse(is.na(n_unadj), "not available", n_unadj),
            ifelse(is.na(n_up_unadj), "",
                   sprintf(" (%d up / %d down)", n_up_unadj, n_down_unadj))))
cat(sprintf("5. DEG, ESTIMATE-adjusted model: %s\n",
            ifelse(is.na(n_adj), "not available", n_adj)))

## ---------------------------------------------------------------------------
## Stage 7: concordant genes (intersection of the two models)
## ---------------------------------------------------------------------------
conc <- NULL
f3 <- Sys.glob(file.path(DATA_ROOT, "TCGA_CRC_ESTIMATE_GSVA_*",
                         "Common_DEG_direction_check_*",
                         "Common_DEG_all_with_logFC_directions.csv"))
f3 <- sort(f3, decreasing = TRUE)
if (length(f3) && file.exists(f3[1])) conc <- fread(f3[1])
n_conc <- if (is.null(conc)) NA_integer_ else nrow(conc)
n_up_conc <- n_down_conc <- NA_integer_
if (!is.null(conc)) {
  dcol <- intersect(c("Direction_adjusted", "Direction_original", "Direction"),
                    names(conc))[1]
  if (!is.na(dcol)) {
    n_up_conc   <- sum(conc[[dcol]] == "UP", na.rm = TRUE)
    n_down_conc <- sum(conc[[dcol]] == "DOWN", na.rm = TRUE)
  }
}
cat(sprintf("6. Concordant in both models: %s%s\n",
            ifelse(is.na(n_conc), "not available", n_conc),
            ifelse(is.na(n_up_conc), "",
                   sprintf(" (%d up / %d down)", n_up_conc, n_down_conc))))

## ---------------------------------------------------------------------------
## Stage 8: after symbol standardisation and protein-coding filtering
## ---------------------------------------------------------------------------
## 885 = 768 up + 117 down after symbol standardisation and the protein-coding filter
## The cleaning step writes into a timestamped folder. Prefer the pointer written
## by 01h; otherwise take the newest folder.
.latest_cleaning_dir <- function() {
  ptr <- file.path(DATA_ROOT, "TCGA_CRC_qCSC_Common_DEG_LINCS_cleaning_LATEST.txt")
  if (file.exists(ptr)) {
    d <- trimws(readLines(ptr, n = 1, warn = FALSE))
    if (nzchar(d) && dir.exists(d)) return(d)
  }
  d <- sort(Sys.glob(file.path(DATA_ROOT,
                               "TCGA_CRC_qCSC_Common_DEG_LINCS_cleaning_optimized_*")),
            decreasing = TRUE)
  if (length(d)) d[1] else NA_character_
}
clean_dir <- .latest_cleaning_dir()
up885 <- if (!is.na(clean_dir)) read_gene_list(file.path(clean_dir, "LINCS_UP_protein_coding.txt")) else NULL
dn885 <- if (!is.na(clean_dir)) read_gene_list(file.path(clean_dir, "LINCS_DOWN_protein_coding.txt")) else NULL
final885 <- if (is.null(up885) && is.null(dn885)) NULL else unique(c(up885, dn885))
n_up_885   <- if (is.null(up885)) NA_integer_ else length(up885)
n_down_885 <- if (is.null(dn885)) NA_integer_ else length(dn885)
n_885 <- if (is.null(final885)) NA_integer_ else length(final885)
cat(sprintf("7. After symbol standardisation and protein-coding filtering: %s\n",
            ifelse(is.na(n_885), "not available", n_885)))

## ---------------------------------------------------------------------------
## Write the funnel table
## ---------------------------------------------------------------------------
funnel <- data.frame(
  step = c(
    "Seed genes from the three qCSC models (merged, de-duplicated)",
    "Protein-coding signature genes",
    "Detectable in the TCGA expression matrix (used for ssGSEA)",
    "DEG, unadjusted limma model (FDR < 0.05, |log2FC| > 0.5)",
    "  of which up-regulated",
    "  of which down-regulated",
    "DEG, ESTIMATE-adjusted model",
    "Concordant in both models",
    "  of which up-regulated",
    "  of which down-regulated",
    "After symbol standardisation and protein-coding filtering",
    "  of which up-regulated",
    "  of which down-regulated"
  ),
  genes = c(n_seed_raw, n_pc, n_eff,
            n_unadj, n_up_unadj, n_down_unadj,
            n_adj,
            n_conc, n_up_conc, n_down_conc,
            n_885, n_up_885, n_down_885),
  stringsAsFactors = FALSE
)

out <- file.path(TAB_DIR, "gene_funnel_summary.csv")
fwrite(funnel, out)

cat("\n")
print(funnel, row.names = FALSE)
cat("\nSaved:", out, "\n")
