## ===========================================================================
## singlecell_clinical/03c_sensitivity.R
## Sensitivity analyses: up-arm-only panel and patient-level bootstrap CI.
## ===========================================================================
# ============================================================
# 02c_sensitivity.R
# ============================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
tab_dir <- TAB_DIR
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

d <- readRDS(file.path(panel_dir, "panel_data.rds"))
f <- readRDS(file.path(out_dir, "final_stable_panel.rds"))
g <- f$stable
up <- g[g %in% d$up_use]
dn <- g[g %in% d$down_use]
cat(sprintf("panel: %d UP + %d DOWN\n", length(up), length(dn)))

rows <- list()
for (co in c("GSE132465", "GSE188711")) {
  E <- if (co == "GSE132465") d$E1 else d$E2
  full <- if (co == "GSE132465") d$score1 else d$score2
  su <- colMeans(E[up, , drop = FALSE])
  sb <- colMeans(E[up, , drop = FALSE]) - colMeans(E[dn, , drop = FALSE])
  rows[[co]] <- data.frame(
    cohort = co, n_up = length(up), n_down = length(dn),
    up_only_r = cor(su, full), full_panel_r = cor(sb, full)
  )
}

tcga_file <- F_TCGA_RDATA
if (file.exists(tcga_file)) {
  load(tcga_file)
  E <- as.matrix(expr_crc)
  sym <- toupper(rownames(E))
  ord <- order(sym, -rowMeans(E))
  E <- E[ord, , drop = FALSE]; sym <- sym[ord]
  keep <- !duplicated(sym)
  E <- E[keep, , drop = FALSE]; rownames(E) <- sym[keep]
  up_use <- intersect(d$up_use, rownames(E))
  dn_use <- intersect(d$down_use, rownames(E))
  full <- colMeans(E[up_use, , drop = FALSE]) - colMeans(E[dn_use, , drop = FALSE])
  pu <- intersect(up, rownames(E)); pd <- intersect(dn, rownames(E))
  rows[["TCGA"]] <- data.frame(
    cohort = "TCGA_CRC_bulk", n_up = length(pu), n_down = length(pd),
    up_only_r = cor(colMeans(E[pu, , drop = FALSE]), full),
    full_panel_r = cor(colMeans(E[pu, , drop = FALSE]) -
                         colMeans(E[pd, , drop = FALSE]), full)
  )
} else {
  message("TCGA bulk data missing; skipping this row: ", tcga_file,
          "(the UP-only sensitivity analysis of the two cohorts is unaffected)")
}
out <- do.call(rbind, rows); rownames(out) <- NULL
write.csv(out, file.path(tab_dir, "UP_only_sensitivity.csv"), row.names = FALSE)

s1 <- colMeans(d$E1[up, , drop = FALSE]) - colMeans(d$E1[dn, , drop = FALSE])
pat <- tapply(s1, d$meta1$Patient, mean)
full_pat <- tapply(d$score1, d$meta1$Patient, mean)
set.seed(20261026)
b <- replicate(2000, {
  i <- sample(seq_along(pat), length(pat), TRUE)
  cor(pat[i], full_pat[i])
})
boot <- data.frame(
  metric = "patient_level_r_GSE132465", n_patients = length(pat),
  r = cor(pat, full_pat),
  boot_low = quantile(b, 0.025), boot_high = quantile(b, 0.975)
)
write.csv(boot, file.path(tab_dir, "patient_level_bootstrap_ci.csv"), row.names = FALSE)
print(out, row.names = FALSE)
print(boot, row.names = FALSE)
