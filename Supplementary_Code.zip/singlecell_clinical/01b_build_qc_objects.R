## ===========================================================================
## singlecell_clinical/01b_build_qc_objects.R
## Per-cohort QC tables (nCount, nFeature, percent.mt) before filtering.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
# ============================================================
# 00_build_qc_objects.R
#
# GSE132465: GEO processed raw UMI count matrix + cell annotation
#
#   <root>/QC_stage4_<timestamp>/seurat_objects/
#     GSE132465_QC_unfiltered.rds
#     GSE188711_all_samples_QC_unfiltered.rds
#
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

suppressPackageStartupMessages({
  library(Seurat)
  library(SeuratObject)
  library(Matrix)
})

root <- ROOT_SC
data_dir <- file.path(root, "data")
out_dir <- file.path(root, paste0("QC_stage4_", format(Sys.time(), "%Y%m%d_%H%M%S")))
obj_dir <- file.path(out_dir, "seurat_objects")
dir.create(obj_dir, recursive = TRUE, showWarnings = FALSE)

f132_mat <- file.path(data_dir, "GSE132465_GEO_processed_CRC_10X_raw_UMI_count_matrix.txt.gz")
f132_ann <- file.path(data_dir, "GSE132465_GEO_processed_CRC_10X_cell_annotation.txt.gz")
f188_tar <- file.path(data_dir, "GSE188711_RAW.tar")
stopifnot(file.exists(f132_mat), file.exists(f132_ann), file.exists(f188_tar))

add_qc <- function(obj, sample_name, gene_symbols = NULL) {
  obj$sample_id <- sample_name
  fids <- rownames(obj)
  sym <- if (is.null(gene_symbols)) fids else as.character(gene_symbols)
  if (length(sym) != length(fids)) stop(sample_name, ": gene symbol length mismatch")
  mt <- grepl("^MT-", sym, ignore.case = TRUE)
  if (any(mt)) {
    obj[["percent.mt"]] <- PercentageFeatureSet(obj, features = fids[mt], assay = "RNA")
  } else {
    obj[["percent.mt"]] <- NA_real_
  }
  obj
}

## ------------------------------------------------------------
## GSE132465
## ------------------------------------------------------------
cat("\n=== GSE132465 ===\n")
ann <- read.delim(gzfile(f132_ann), check.names = FALSE, stringsAsFactors = FALSE)
ann$Index <- as.character(ann$Index)
stopifnot(!anyDuplicated(ann$Index))

con <- gzfile(f132_mat, "rt")
header <- readLines(con, n = 1, warn = FALSE)
cells <- strsplit(header, "\t", fixed = TRUE)[[1]][-1]
chunk_size <- 200L
gene_names <- character(0)
chunks <- list()
k <- 0L
repeat {
  lines <- readLines(con, n = chunk_size, warn = FALSE)
  if (!length(lines)) break
  parsed <- strsplit(lines, "\t", fixed = TRUE)
  if (any(lengths(parsed) != length(cells) + 1L)) stop("GSE132465 field count mismatch")
  genes <- vapply(parsed, `[`, character(1), 1)
  vals <- lapply(parsed, function(x) suppressWarnings(as.numeric(x[-1])))
  if (any(vapply(vals, function(x) any(!is.finite(x)) || any(x < 0), logical(1)))) {
    stop("GSE132465 non-finite or negative counts")
  }
  nz <- lapply(vals, function(x) which(x != 0))
  ii <- rep.int(seq_along(vals), lengths(nz))
  jj <- unlist(nz, use.names = FALSE)
  xx <- unlist(Map(function(x, i) x[i], vals, nz), use.names = FALSE)
  chunks[[length(chunks) + 1L]] <- sparseMatrix(
    i = as.integer(ii), j = as.integer(jj), x = xx,
    dims = c(length(vals), length(cells)), giveCsparse = TRUE
  )
  gene_names <- c(gene_names, genes)
  k <- k + length(lines)
  if (k %% 5000L < chunk_size) cat("  genes read:", k, "\n")
}
close(con)
if (anyDuplicated(gene_names)) stop("GSE132465 duplicated gene names")
counts <- do.call(rbind, chunks)
rownames(counts) <- gene_names
colnames(counts) <- cells
rm(chunks); gc()

obj <- CreateSeuratObject(counts = counts, project = "GSE132465", min.cells = 0, min.features = 0)
rm(counts); gc()
idx <- match(colnames(obj), ann$Index)
if (anyNA(idx)) stop("GSE132465 annotation match failed")
md <- ann[idx, , drop = FALSE]
stopifnot(identical(colnames(obj), md$Index))
for (col in c("Patient", "Class", "Sample", "Cell_type", "Cell_subtype")) {
  obj[[col]] <- md[[col]]
}
obj <- add_qc(obj, "GSE132465")
saveRDS(obj, file.path(obj_dir, "GSE132465_QC_unfiltered.rds"), compress = FALSE)
cat("GSE132465 cells:", ncol(obj), " genes:", nrow(obj), "\n")
rm(obj); gc()

## ------------------------------------------------------------
## GSE188711
## ------------------------------------------------------------
cat("\n=== GSE188711 ===\n")
extract_dir <- file.path(out_dir, "GSE188711_extracted")
dir.create(extract_dir, recursive = TRUE, showWarnings = FALSE)
members <- utils::untar(f188_tar, list = TRUE)
utils::untar(f188_tar, exdir = extract_dir)
bases <- basename(members)
mat_files <- members[grepl("_matrix.*\\.mtx\\.gz$", bases, ignore.case = TRUE)]
if (length(mat_files) != 6L) stop("GSE188711 matrix count != 6")

sample_info <- data.frame(
  GSM = paste0("GSM", 5688706:5688711),
  sample_code = c("WGC", "JCA", "LS-CRC3", "RS-CRC1", "R_CRC3", "R_CRC4"),
  side = c("Left", "Left", "Left", "Right", "Right", "Right"),
  tissue = "CRC_tumor",
  stringsAsFactors = FALSE
)
sample_info$patient_id <- sample_info$GSM

objs <- list()
for (mf in mat_files) {
  prefix <- sub("_matrix.*$", "", basename(mf))
  bf <- members[grepl(paste0("^", prefix, "_barcodes.*\\.tsv\\.gz$"), bases, ignore.case = TRUE)]
  ff <- members[grepl(paste0("^", prefix, "_features.*\\.tsv\\.gz$"), bases, ignore.case = TRUE)]
  if (length(bf) != 1L || length(ff) != 1L) stop(prefix, ": barcode/feature file match failed")

  mat <- as(Matrix::readMM(gzfile(file.path(extract_dir, mf))), "CsparseMatrix")
  barcodes <- as.character(read.delim(gzfile(file.path(extract_dir, bf)), header = FALSE)[[1]])
  features <- read.delim(gzfile(file.path(extract_dir, ff)), header = FALSE, sep = "\t",
                         quote = "", comment.char = "", check.names = FALSE)
  if (nrow(mat) != nrow(features) || ncol(mat) != length(barcodes)) stop(prefix, ": dimension mismatch")
  if (ncol(features) < 2L) stop(prefix, ": feature file < 2 columns")
  fid <- as.character(features[[1]])
  sym <- as.character(features[[2]])
  ftype <- if (ncol(features) >= 3L) as.character(features[[3]]) else rep(NA_character_, nrow(features))
  if (anyNA(fid) || any(fid == "") || anyDuplicated(fid)) stop(prefix, ": invalid feature ID")
  if (anyNA(sym) || any(sym == "")) stop(prefix, ": invalid gene symbol")

  rownames(mat) <- fid
  colnames(mat) <- paste(prefix, barcodes, sep = "_")
  obj <- CreateSeuratObject(counts = mat, project = prefix, min.cells = 0, min.features = 0)
  stopifnot(identical(rownames(obj[["RNA"]]), fid))

  fmeta <- data.frame(gene_symbol = sym, feature_type = ftype,
                      row.names = fid, stringsAsFactors = FALSE)
  obj[["RNA"]] <- SeuratObject::AddMetaData(obj[["RNA"]], metadata = fmeta)
  obj <- add_qc(obj, prefix, gene_symbols = sym)

  gsm <- regmatches(prefix, regexpr("GSM[0-9]+", prefix))
  if (!length(gsm) || !gsm %in% sample_info$GSM) stop(prefix, ": cannot map GSM")
  si <- sample_info[match(gsm, sample_info$GSM), ]
  obj$GSM <- si$GSM
  obj$sample_code <- si$sample_code
  obj$patient_id <- si$patient_id
  obj$side <- si$side
  obj$tissue <- si$tissue

  objs[[gsm]] <- obj
  cat(" ", prefix, "cells:", ncol(obj), "genes:", nrow(obj), "\n")
}
if (length(objs) != 6L) stop("GSE188711 sample count != 6")
saveRDS(objs, file.path(obj_dir, "GSE188711_all_samples_QC_unfiltered.rds"), compress = FALSE)

writeLines(capture.output(sessionInfo()), file.path(out_dir, "sessionInfo.txt"))
cat("\nDONE:", out_dir, "\n")
