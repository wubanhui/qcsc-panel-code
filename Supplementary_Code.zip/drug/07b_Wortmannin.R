## ===========================================================================
## drug/07b_Wortmannin.R
## Wortmannin (GSE18005): score the panel in three CRC cell lines and compute
## the change relative to the matched DMSO control.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
OUT_DIR <- file.path(QCSC_PROJECT_DIR, "output", "drug_Wortmannin")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)
############################################################
# GSE18005 — Wortmannin
# 20-gene differentiation-associated signature validation
# Logic adapted from the user's GSE201899 CX-5461 script
#
# Dataset:
#   GPL96 / Affymetrix HG-U133A
#   HCT116, HT29, SW480
#   Each cell line: DMSO control vs Wortmannin treatment
#   Treatment duration: 48 h
#
# Signature:
#   input2.tsv; 20-gene signature expected
#   UP   = differentiation-associated genes
#   DOWN = stemness-associated genes
#
# Score = mean(UP genes) - mean(DOWN genes)
# Delta = Wortmannin - matched DMSO control
# Delta > 0: supports movement toward the signature-defined
#            differentiation-associated transcriptional state
#
# IMPORTANT:
#   The uploaded series matrix contains large intensity-scale
#   values rather than log2-scale values. This script applies
#   log2(intensity + 1) before gene-level probe averaging.
#   This is a pragmatic series-matrix analysis, NOT equivalent
#   to RMA normalization of raw CEL files. For publication-grade
#   analysis, preferably obtain CEL files and run RMA.
#   There is one sample per cell-line/treatment condition, so
#   results are descriptive; no inferential P values are computed.
############################################################

############################
# 1. Paths and timestamped output
############################
data_dir <- DATA_ROOT
search_dirs <- c(data_dir, getwd())

find_file <- function(candidates, dirs) {
  for (d in dirs) {
    for (nm in candidates) {
      p <- file.path(d, nm)
      if (file.exists(p)) return(normalizePath(p, winslash = "/", mustWork = TRUE))
    }
  }
  return(NA_character_)
}

geo_file <- find_file(
  c("GSE18005_series_matrix.txt", "GSE18005_series_matrix.txt.gz"),
  c(data_dir, getwd())
)
# Optional fallback for the exact uploaded filename when running in this environment.
if (is.na(geo_file) && file.exists("/mnt/data/GSE18005_series_matrix.txt")) {
  geo_file <- "/mnt/data/GSE18005_series_matrix.txt"
}

signature_file <- find_file(c("input2.tsv"), c(data_dir, getwd()))

if (is.na(geo_file)) {
  stop("GSE18005_series_matrix.txt(.gz) not found; please put it in the data directory.")
}
if (is.na(signature_file)) {
  stop("input2.tsv not found; please put the 20-gene signature file in the data directory.")
}

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
out_root <- file.path(QCSC_PROJECT_DIR, "output", paste0("GSE18005_Wortmannin_20gene_validation_", timestamp))
output_dir <- file.path(out_root, "results")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cat("GEO file: ", geo_file, "\n")
cat("Signature file: ", signature_file, "\n")
cat("Output directory: ", output_dir, "\n\n")

############################
# 2. Packages
############################
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager", repos = "https://cloud.r-project.org")
}
if (!requireNamespace("AnnotationDbi", quietly = TRUE)) {
  BiocManager::install("AnnotationDbi", ask = FALSE, update = FALSE)
}
if (!requireNamespace("hgu133a.db", quietly = TRUE)) {
  BiocManager::install("hgu133a.db", ask = FALSE, update = FALSE)
}
if (!requireNamespace("dplyr", quietly = TRUE)) {
  install.packages("dplyr", repos = "https://cloud.r-project.org")
}
suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(hgu133a.db)
  library(dplyr)
})

############################
# 3. Sample metadata
############################
sample_info <- data.frame(
  GSM = c(
    "GSM450448", "GSM450450",
    "GSM450453", "GSM450455",
    "GSM450458", "GSM450460"
  ),
  CellLine = c("HCT116", "HCT116", "HT29", "HT29", "SW480", "SW480"),
  Treatment = c("Control", "Wortmannin", "Control", "Wortmannin",
                "Control", "Wortmannin"),
  stringsAsFactors = FALSE
)
# GSM mapping from the series matrix:
# HCT116: GSM450448 DMSO; GSM450450 Wortmannin
# HT29:   GSM450453 DMSO; GSM450455 Wortmannin
# SW480:  GSM450458 DMSO; GSM450460 Wortmannin

############################
# 4. Read the series matrix expression table
############################
cat("Reading the series matrix...
")
con <- if (grepl("\\.gz$", geo_file, ignore.case = TRUE)) gzfile(geo_file, open = "rt") else file(geo_file, open = "rt")
geo_lines <- readLines(con, warn = FALSE)
close(con)

header_candidates <- which(grepl("ID_REF", geo_lines, fixed = TRUE) &
                             grepl("GSM450448", geo_lines, fixed = TRUE))
if (length(header_candidates) == 0) stop("Expression matrix header not found.")
header_line <- header_candidates[1]

# GEO matrix table ends at !series_matrix_table_end; do not read metadata after it.
end_candidates <- which(seq_along(geo_lines) > header_line &
                          grepl("^!series_matrix_table_end", geo_lines))
data_end <- if (length(end_candidates) > 0) end_candidates[1] - 1 else length(geo_lines)

tmp_file <- tempfile(fileext = ".txt")
writeLines(geo_lines[header_line:data_end], tmp_file)
expr_raw <- read.delim(
  tmp_file, header = TRUE, sep = "\t", quote = "\"",
  comment.char = "", check.names = FALSE,
  stringsAsFactors = FALSE
)
unlink(tmp_file)

colnames(expr_raw) <- gsub('^"|"$', "", colnames(expr_raw))
if (!"ID_REF" %in% colnames(expr_raw)) stop("The expression matrix has no ID_REF column.")
missing_gsm <- setdiff(sample_info$GSM, colnames(expr_raw))
if (length(missing_gsm) > 0) {
  stop("The following samples are missing from the series matrix: ", paste(missing_gsm, collapse = ", "))
}

probe_ids <- as.character(expr_raw$ID_REF)
expr_matrix <- as.matrix(expr_raw[, sample_info$GSM, drop = FALSE])
mode(expr_matrix) <- "numeric"
rownames(expr_matrix) <- probe_ids

valid <- !is.na(rownames(expr_matrix)) & rownames(expr_matrix) != ""
expr_matrix <- expr_matrix[valid, , drop = FALSE]
expr_matrix <- expr_matrix[!duplicated(rownames(expr_matrix)), , drop = FALSE]
if (any(!is.finite(expr_matrix))) stop("NA/Inf present in the expression matrix; check the source file.")
if (any(expr_matrix < 0)) stop("Negative values in the expression matrix; log2(intensity+1) cannot be applied.")

# Check the scale; GSE18005 series-matrix values are intensity-scale values.
if (max(expr_matrix, na.rm = TRUE) > 100) {
  cat("Intensity-scale values detected; applying log2(intensity + 1).
")
  expr_matrix <- log2(expr_matrix + 1)
} else {
  cat("Values already appear to be on a log scale; log2 is not applied again.
")
}

############################
# 5. Probe ID -> Gene Symbol (GPL96 / HG-U133A)
############################
cat("Annotating GPL96 probes...
")
annotation <- AnnotationDbi::select(
  hgu133a.db,
  keys = rownames(expr_matrix),
  columns = c("SYMBOL"),
  keytype = "PROBEID"
)
annotation <- annotation %>%
  filter(!is.na(SYMBOL), SYMBOL != "") %>%
  distinct(PROBEID, SYMBOL) %>%
  group_by(PROBEID) %>%
  slice(1) %>%
  ungroup()

common_probes <- intersect(rownames(expr_matrix), annotation$PROBEID)
if (length(common_probes) == 0) stop("No probe matched the hgu133a.db annotation.")

expr_probe <- expr_matrix[common_probes, , drop = FALSE]
ann <- annotation[match(common_probes, annotation$PROBEID), , drop = FALSE]
symbols <- toupper(trimws(as.character(ann$SYMBOL)))
valid_symbol <- !is.na(symbols) & symbols != ""
expr_probe <- expr_probe[valid_symbol, , drop = FALSE]
symbols <- symbols[valid_symbol]

# Multiple probes mapped to the same symbol are averaged on the log2 scale,
# following the gene-level aggregation style of the CX-5461 script.
expr_gene_matrix <- rowsum(expr_probe, group = symbols, reorder = FALSE)
probe_n <- table(symbols)
expr_gene_matrix <- sweep(expr_gene_matrix, 1, as.numeric(probe_n[rownames(expr_gene_matrix)]), "/")
expr_gene_matrix <- expr_gene_matrix[!is.na(rownames(expr_gene_matrix)) & rownames(expr_gene_matrix) != "", , drop = FALSE]

cat("Raw probes: ", nrow(expr_matrix), "\n")
cat("Annotated probes: ", nrow(expr_probe), "\n")
cat("Gene symbols after collapsing: ", nrow(expr_gene_matrix), "\n\n")

############################
# 6. Read the fixed 20-gene signature
############################
sig <- read.delim(signature_file, stringsAsFactors = FALSE, check.names = FALSE)

if (all(c("Input Type", "Type", "Name") %in% colnames(sig))) {
  sig$Name <- toupper(trimws(as.character(sig$Name)))
  sig_type <- tolower(trimws(as.character(sig[["Input Type"]])))
  valid_type <- tolower(trimws(as.character(sig[["Type"]])))
  signature_up <- sig$Name[sig_type == "up_entities" & valid_type == "valid"]
  signature_down <- sig$Name[sig_type == "down_entities" & valid_type == "valid"]
} else if (all(c("Gene", "Direction") %in% colnames(sig))) {
  sig$Gene <- toupper(trimws(as.character(sig$Gene)))
  direction <- toupper(trimws(as.character(sig$Direction)))
  signature_up <- sig$Gene[direction == "UP"]
  signature_down <- sig$Gene[direction == "DOWN"]
} else {
  stop("Unrecognised input2.tsv format; Name/Input Type/Type or Gene/Direction columns are required.")
}

signature_up <- unique(signature_up[!is.na(signature_up) & signature_up != ""])
signature_down <- unique(signature_down[!is.na(signature_down) & signature_down != ""])
overlap_sig <- intersect(signature_up, signature_down)
if (length(overlap_sig) > 0) {
  stop("The following genes appear in both UP and DOWN: ", paste(overlap_sig, collapse = ", "))
}
if (length(signature_up) == 0 || length(signature_down) == 0) {
  stop("The UP or the DOWN gene set is empty; check input2.tsv.")
}

matched_up <- intersect(signature_up, rownames(expr_gene_matrix))
matched_down <- intersect(signature_down, rownames(expr_gene_matrix))
unmatched_up <- setdiff(signature_up, matched_up)
unmatched_down <- setdiff(signature_down, matched_down)

cat("Signature genes: UP = ", length(signature_up), "; DOWN =", length(signature_down), "\n")
cat("Matched genes: UP = ", length(matched_up), "; DOWN =", length(matched_down), "\n")
if (length(unmatched_up) > 0) cat("Unmatched UP: ", paste(unmatched_up, collapse = ", "), "\n")
if (length(unmatched_down) > 0) cat("Unmatched DOWN: ", paste(unmatched_down, collapse = ", "), "\n")
if (length(matched_up) == 0 || length(matched_down) == 0) {
  stop("No expressed gene was matched for UP or DOWN; scoring stopped.")
}

############################
# 7. Calculate sample-level signature score
############################
UP_score <- colMeans(expr_gene_matrix[matched_up, , drop = FALSE], na.rm = TRUE)
DOWN_score <- colMeans(expr_gene_matrix[matched_down, , drop = FALSE], na.rm = TRUE)
signature_score <- UP_score - DOWN_score

sample_score_result <- data.frame(
  GSM = names(signature_score),
  CellLine = sample_info$CellLine[match(names(signature_score), sample_info$GSM)],
  Treatment = sample_info$Treatment[match(names(signature_score), sample_info$GSM)],
  UP_score = as.numeric(UP_score),
  DOWN_score = as.numeric(DOWN_score),
  Signature_score = as.numeric(signature_score),
  stringsAsFactors = FALSE
)

############################
# 8. Matched delta: Wortmannin - DMSO
############################
delta_result <- data.frame()
for (cell_line in unique(sample_info$CellLine)) {
  control_gsm <- sample_info$GSM[sample_info$CellLine == cell_line & sample_info$Treatment == "Control"]
  drug_gsm <- sample_info$GSM[sample_info$CellLine == cell_line & sample_info$Treatment == "Wortmannin"]
  if (length(control_gsm) != 1 || length(drug_gsm) != 1) {
    stop("Each cell line must have exactly one Control and one Wortmannin sample: ", cell_line)
  }
  delta_value <- signature_score[drug_gsm] - signature_score[control_gsm]
  delta_result <- rbind(delta_result, data.frame(
    CellLine = cell_line,
    Control_GSM = control_gsm,
    Drug_GSM = drug_gsm,
    Control_score = as.numeric(signature_score[control_gsm]),
    Wortmannin_score = as.numeric(signature_score[drug_gsm]),
    Delta_score = as.numeric(delta_value),
    Supports_Differentiation_state_shift = ifelse(delta_value > 0, "YES",
                                                  ifelse(delta_value < 0, "NO", "NO_CHANGE")),
    stringsAsFactors = FALSE
  ))
}

############################
# 9. Gene-level changes and directional concordance
############################
gene_level_result <- data.frame()
module_result <- data.frame()

for (i in seq_len(nrow(delta_result))) {
  cell_line <- delta_result$CellLine[i]
  control_gsm <- delta_result$Control_GSM[i]
  drug_gsm <- delta_result$Drug_GSM[i]
  gene_change <- expr_gene_matrix[, drug_gsm] - expr_gene_matrix[, control_gsm]
  
  tmp_up <- data.frame(
    Gene = matched_up, Direction = "UP_differentiation",
    CellLine = cell_line, Control_GSM = control_gsm, Drug_GSM = drug_gsm,
    log2_change = as.numeric(gene_change[matched_up]),
    stringsAsFactors = FALSE
  )
  tmp_down <- data.frame(
    Gene = matched_down, Direction = "DOWN_stemness",
    CellLine = cell_line, Control_GSM = control_gsm, Drug_GSM = drug_gsm,
    log2_change = as.numeric(gene_change[matched_down]),
    stringsAsFactors = FALSE
  )
  tmp <- rbind(tmp_up, tmp_down)
  tmp$Directionally_concordant <- ifelse(
    tmp$Direction == "UP_differentiation",
    tmp$log2_change > 0,
    tmp$log2_change < 0
  )
  tmp$Signed_change <- ifelse(tmp$Direction == "UP_differentiation",
                              tmp$log2_change, -tmp$log2_change)
  gene_level_result <- rbind(gene_level_result, tmp)
  
  up_change <- mean(gene_change[matched_up], na.rm = TRUE)
  down_change <- mean(gene_change[matched_down], na.rm = TRUE)
  module_result <- rbind(module_result, data.frame(
    CellLine = cell_line,
    Control_GSM = control_gsm,
    Drug_GSM = drug_gsm,
    Treatment = "Wortmannin",
    UP_change = up_change,
    DOWN_change = down_change,
    Delta_score = up_change - down_change,
    Full_concordant_reversal = (up_change > 0 && down_change < 0),
    stringsAsFactors = FALSE
  ))
}

reversal_summary <- gene_level_result %>%
  group_by(CellLine, Drug_GSM) %>%
  summarise(
    matched_genes = sum(!is.na(log2_change)),
    directionally_concordant_genes = sum(Directionally_concordant, na.rm = TRUE),
    concordance_percentage = directionally_concordant_genes / matched_genes * 100,
    mean_signed_change = mean(Signed_change, na.rm = TRUE),
    median_signed_change = median(Signed_change, na.rm = TRUE),
    UP_genes_in_expected_direction = sum(Direction == "UP_differentiation" & Directionally_concordant, na.rm = TRUE),
    DOWN_genes_in_expected_direction = sum(Direction == "DOWN_stemness" & Directionally_concordant, na.rm = TRUE),
    .groups = "drop"
  )
reversal_summary$Treatment <- "Wortmannin"
reversal_summary <- reversal_summary[, c(
  "CellLine", "Treatment", "Drug_GSM", "matched_genes",
  "directionally_concordant_genes", "concordance_percentage",
  "mean_signed_change", "median_signed_change",
  "UP_genes_in_expected_direction", "DOWN_genes_in_expected_direction"
)]

final_result <- delta_result %>%
  left_join(
    reversal_summary %>% select(CellLine, Drug_GSM, concordance_percentage,
                                directionally_concordant_genes, matched_genes,
                                mean_signed_change, median_signed_change),
    by = c("CellLine", "Drug_GSM")
  ) %>%
  left_join(
    module_result %>% select(CellLine, Drug_GSM, UP_change, DOWN_change,
                             Full_concordant_reversal),
    by = c("CellLine", "Drug_GSM")
  ) %>%
  arrange(CellLine)

############################
# 10. Save outputs
############################
write.csv(sample_score_result, file.path(output_dir, "GSE18005_sample_scores_20gene.csv"), row.names = FALSE)
write.csv(delta_result, file.path(output_dir, "GSE18005_delta_20gene.csv"), row.names = FALSE)
write.csv(gene_level_result, file.path(output_dir, "GSE18005_gene_level_20gene.csv"), row.names = FALSE)
write.csv(reversal_summary, file.path(output_dir, "GSE18005_reversal_summary_20gene.csv"), row.names = FALSE)
write.csv(module_result, file.path(output_dir, "GSE18005_module_change_20gene.csv"), row.names = FALSE)
write.csv(final_result, file.path(output_dir, "GSE18005_FINAL_result_20gene.csv"), row.names = FALSE)
write.csv(data.frame(Unmatched_UP = c(unmatched_up, rep(NA_character_, max(0, length(unmatched_down) - length(unmatched_up)))),
                     Unmatched_DOWN = c(unmatched_down, rep(NA_character_, max(0, length(unmatched_up) - length(unmatched_down))))),
          file.path(output_dir, "GSE18005_unmatched_signature_genes.csv"), row.names = FALSE)

capture.output(sessionInfo(), file = file.path(output_dir, "sessionInfo.txt"))

cat("\n================ GSE18005 FINAL RESULT ================\n")
print(final_result)
cat("
Notes:
")
cat("1) Delta_score > 0: movement toward the differentiation-associated state defined by the 20-gene panel.
")
cat("2) Full_concordant_reversal = TRUE: mean UP change > 0 and mean DOWN change < 0.
")
cat("3) One sample per group per cell line, so the comparison is descriptive only; no significance test is computed.
")
cat("4) This script applies log2(intensity+1) to the series-matrix values; the results are not CEL-based RMA values.
")
cat("Results saved to: ", output_dir, "\n")
