## ===========================================================================
## singlecell_clinical/02g_doublet_rate.R
##
## scDblFinder doublet rate per sample for GSE132465 (QC descriptor only).
## Cells are not removed and the author CMS annotation is left untouched.
##
## Requires a Bioconductor release whose S4Vectors satisfies the S4Arrays
## requirement (>= 0.47.6), i.e. R 4.6 / Bioconductor 3.23 or newer.
## ===========================================================================

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
# ============================================================
# 01g_gse132465_doublet_rate.R
#
#
# ============================================================

out_dir <- QCSC_PROJECT_DIR
tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

suppressPackageStartupMessages({
  library(Seurat)
  library(SeuratObject)
  library(Matrix)
  library(scDblFinder)
  library(SingleCellExperiment)
  library(SummarizedExperiment)
  library(BiocParallel)
  library(ggplot2)
})
BiocParallel::register(BiocParallel::SerialParam())
set.seed(1234)

root <- ROOT_SC
## find_qc132() lives in paths.R
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "paths.R"))

qc_file <- find_qc132(root)
if (!file.exists(qc_file)) {
  stop(
    "Cannot find the GSE132465 QC object: ", qc_file,
    "
Please put the QC_stage4_* directory back into ", root, "/,",
    "or edit root to point to the actual location."
  )
}
message("QC object used: ", qc_file)
obj <- readRDS(qc_file)
md <- obj[[]]
if (!"Sample" %in% colnames(md)) stop("The QC object has no Sample column; scDblFinder cannot be run per sample.")
counts <- SeuratObject::LayerData(obj[["RNA"]], layer = "counts")
samples <- as.character(md$Sample)
names(samples) <- rownames(md)

res <- list()
for (s in sort(unique(samples))) {
  cells <- names(samples)[samples == s]
  n <- length(cells)
  if (n < 50) {
    res[[s]] <- data.frame(
      Sample = s, n_cells = n, n_doublet = NA_integer_,
      doublet_pct = NA_real_, median_score = NA_real_,
      status = "skipped_lt50"
    )
    next
  }
  message("scDblFinder: ", s, " (", n, " cells)")
  sce <- SingleCellExperiment(
    assays = list(counts = counts[, cells, drop = FALSE])
  )
  out <- tryCatch(
    scDblFinder(sce, clusters = FALSE, verbose = FALSE),
    error = function(e) e
  )
  if (inherits(out, "error")) {
    res[[s]] <- data.frame(
      Sample = s, n_cells = n, n_doublet = NA_integer_,
      doublet_pct = NA_real_, median_score = NA_real_,
      status = paste0("error: ", conditionMessage(out))
    )
    next
  }
  cd <- SummarizedExperiment::colData(out)
  cls <- as.character(cd$scDblFinder.class)
  score <- as.numeric(cd$scDblFinder.score)
  res[[s]] <- data.frame(
    Sample = s, n_cells = n,
    n_doublet = sum(cls == "doublet", na.rm = TRUE),
    doublet_pct = 100 * mean(cls == "doublet", na.rm = TRUE),
    median_score = median(score, na.rm = TRUE),
    status = "ok"
  )
}
by_sample <- do.call(rbind, res)
rownames(by_sample) <- NULL
write.csv(
  by_sample,
  file.path(tab_dir, "GSE132465_doublet_rate_by_sample.csv"),
  row.names = FALSE
)

ok <- by_sample[by_sample$status == "ok", ]
overall <- data.frame(
  cohort = "GSE132465",
  samples = nrow(ok),
  cells = sum(ok$n_cells),
  doublets = sum(ok$n_doublet),
  overall_doublet_pct = 100 * sum(ok$n_doublet) / sum(ok$n_cells),
  median_sample_pct = median(ok$doublet_pct),
  min_sample_pct = min(ok$doublet_pct),
  max_sample_pct = max(ok$doublet_pct)
)
write.csv(
  overall,
  file.path(tab_dir, "GSE132465_doublet_rate_overall.csv"),
  row.names = FALSE
)
print(overall, row.names = FALSE)

gse188_file <- find_gse188_clustered(root)
if (!is.na(gse188_file) && file.exists(gse188_file)) {
  obj188 <- readRDS(gse188_file)
  md188 <- obj188[[]]
  if ("scDblFinder.class" %in% colnames(md188)) {
    comp <- data.frame(
      cohort = c("GSE132465", "GSE188711"),
      cells = c(sum(ok$n_cells), nrow(md188)),
      doublet_pct = c(
        100 * sum(ok$n_doublet) / sum(ok$n_cells),
        100 * mean(md188$scDblFinder.class == "doublet", na.rm = TRUE)
      )
    )
    write.csv(
      comp,
      file.path(tab_dir, "GSE132465_vs_GSE188711_doublet_rate.csv"),
      row.names = FALSE
    )
    print(comp, row.names = FALSE)
  }
}

p <- ggplot(
  by_sample[by_sample$status == "ok", ],
  aes(reorder(Sample, doublet_pct), doublet_pct)
) +
  geom_col(fill = "#2E86C1") +
  coord_flip() +
  labs(
    x = NULL, y = "Predicted doublet (%)",
    title = "GSE132465: scDblFinder doublet rate by sample"
  ) +
  theme_classic(base_size = 10)
ggsave(
  file.path(fig_dir, "Fig10_GSE132465_doublet_rate.png"),
  p, width = 7, height = 9, dpi = 300, bg = "white"
)
ggsave(
  file.path(fig_dir, "Fig10_GSE132465_doublet_rate.pdf"),
  p, width = 7, height = 9, bg = "white"
)
cat("saved GSE132465 doublet rate tables\n")
