## ===========================================================================
## singlecell_clinical/03e_tcga_survival.R
## Legacy exploration of TCGA survival for the full axis; skipped unless the
## score table contains clinical fields.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

suppressPackageStartupMessages({library(survival); library(ggplot2)})
tab_dir <- TAB_DIR; fig_dir <- FIG_DIR
d <- readRDS(file.path(out_dir,"final_stable_panel.rds"))
meta <- d$tcga
num <- function(x) suppressWarnings(as.numeric(gsub("[^0-9.].*$","",as.character(x))))
meta$vital <- trimws(meta$vital_status)
meta$os_event <- ifelse(meta$vital=="DECEASED",1,ifelse(meta$vital=="LIVING",0,NA))
meta$os_time <- ifelse(meta$os_event==1,num(meta$days_to_death),num(meta$days_to_last_followup)); meta$os_time[meta$os_time<=0] <- NA
meta$age <- num(meta$age_at_initial_pathologic_diagnosis)
st <- trimws(meta$pathologic_stage)
meta$stage <- ifelse(grepl("^Stage IV",st),"IV",ifelse(grepl("^Stage III",st),"III",ifelse(grepl("^Stage II",st),"II",ifelse(grepl("^Stage I",st),"I",NA))))
meta$gender <- ifelse(grepl("^FEMALE",toupper(meta$gender)),"Female",ifelse(grepl("^MALE",toupper(meta$gender)),"Male",NA))
sv <- meta[!is.na(meta$os_time)&!is.na(meta$os_event)&meta$os_time>0,]
sv$panel_group <- factor(ifelse(sv$panel>=median(sv$panel),"High","Low"),levels=c("Low","High"))
sv$full_group <- factor(ifelse(sv$full>=median(sv$full),"High","Low"),levels=c("Low","High"))
sd <- Surv(sv$os_time,sv$os_event)
cx <- coxph(sd~panel_group,data=sv)
lr <- survdiff(sd~panel_group,data=sv)
cat("univariable:\n"); print(summary(cx)$conf.int); cat("logrank p:",1-pchisq(lr$chisq,1),"\n")
mv <- sv[!is.na(sv$age)&!is.na(sv$stage)&!is.na(sv$gender),]
mv$stage <- factor(mv$stage,levels=c("I","II","III","IV"))
cxm <- coxph(Surv(os_time,os_event)~panel_group+age+stage+gender,data=mv)
cat("\nmultivariable:\n"); print(summary(cxm)$conf.int)
cat("n mv:",nrow(mv)," events:",sum(mv$os_event),"\n")
write.csv(data.frame(term=rownames(summary(cxm)$conf.int),summary(cxm)$conf.int,check.names=FALSE),
          file.path(tab_dir,"tcga_stable_panel_multivariable_cox.csv"),row.names=FALSE)

## KM
km <- survfit(sd~panel_group,data=sv)
df <- data.frame(time=km$time,surv=km$surv,group=rep(sub("panel_group=","",names(km$strata)),km$strata))
p <- ggplot(df,aes(time,surv,color=group))+geom_step(linewidth=1)+
  scale_color_manual(values=c(High="#C0392B",Low="#2E86C1"))+
  labs(x="Overall survival (days)",y="Survival probability",color="Panel score",
       title="TCGA CRC: stable 20-gene qCSC panel")+
  annotate("text",x=0,y=0.08,hjust=0,size=4,label=sprintf("Log-rank P = %.3f",1-pchisq(lr$chisq,1)))+
  theme_classic(base_size=12)
ggsave(file.path(fig_dir,"Fig5_TCGA_survival_stable.png"),p,width=7,height=5.5,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig5_TCGA_survival_stable.pdf"),p,width=7,height=5.5,bg="white")
cat("saved\n")
