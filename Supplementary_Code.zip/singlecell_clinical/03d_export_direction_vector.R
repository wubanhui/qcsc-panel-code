## ===========================================================================
## singlecell_clinical/03d_export_direction_vector.R
## Export the signed direction vector of the panel, the input file for the
## LINCS query and the drug analyses.
## ===========================================================================
# ============================================================
# 09a_export_panel_direction_vector.R
#
#
#   tables/panel_20_direction_vector.csv
#      direction      UP / DOWN
#      sign           +1 / -1
#   tables/panel_20_formula.txt
#
#   tables/final_panel_stable.csv
# ============================================================

options(stringsAsFactors = FALSE)

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
tab_dir <- TAB_DIR

panel_file <- file.path(tab_dir, "final_panel_stable.csv")
if (!file.exists(panel_file)) stop("Cannot find final_panel_stable.csv; please run 03b first")
panel <- read.csv(panel_file, check.names = FALSE, stringsAsFactors = FALSE)

need <- c("gene", "direction", "detection_132", "detection_188",
          "mean_132", "mean_188", "r_132", "r_188")
miss <- setdiff(need, names(panel))
if (length(miss)) stop("final_panel_stable.csv is missing columns: ", paste(miss, collapse = ", "))

panel$gene      <- toupper(trimws(panel$gene))
panel$direction <- toupper(trimws(panel$direction))
if (!all(panel$direction %in% c("UP", "DOWN"))) stop("direction must be either UP or DOWN")

n_up   <- sum(panel$direction == "UP")
n_down <- sum(panel$direction == "DOWN")
cat(sprintf("Panel: %d UP + %d DOWN = %d genes\n", n_up, n_down, nrow(panel)))

# ------------------------------------------------------------
# ------------------------------------------------------------
stab_file <- file.path(tab_dir, "panel_stability_frequency.csv")
if (file.exists(stab_file)) {
  stab <- read.csv(stab_file, check.names = FALSE, stringsAsFactors = FALSE)
  stab$gene <- toupper(trimws(stab$gene))
  panel$selection_frequency <- stab$frequency[match(panel$gene, stab$gene)]
} else {
  warning("no panel_stability_frequency.csv: selection_frequency set to NA")
  panel$selection_frequency <- NA_real_
}

# ------------------------------------------------------------
# ------------------------------------------------------------
out <- data.frame(
  gene      = panel$gene,
  direction = panel$direction,
  sign      = ifelse(panel$direction == "UP", 1L, -1L),
  weight    = ifelse(panel$direction == "UP", 1 / n_up, -1 / n_down),
  rank      = NA_integer_,
  selection_frequency = panel$selection_frequency,
  mean_expr_132 = panel$mean_132,
  mean_expr_188 = panel$mean_188,
  detection_132 = panel$detection_132,
  detection_188 = panel$detection_188,
  r_132     = panel$r_132,
  r_188     = panel$r_188,
  detected_both = panel$detection_132 >= 5 & panel$detection_188 >= 5,
  stringsAsFactors = FALSE
)
out$rank <- NA_integer_
for (dir in c("UP", "DOWN")) {
  i <- which(out$direction == dir)
  if (!length(i)) next
  ord <- order(-(out$detection_132[i] + out$detection_188[i]) / 2)
  out$rank[i[ord]] <- seq_along(i)
}
out <- out[order(match(out$direction, c("UP", "DOWN")), out$rank), ]
rownames(out) <- NULL

num_cols <- c("selection_frequency", "mean_expr_132", "mean_expr_188",
              "detection_132", "detection_188", "r_132", "r_188")
out[num_cols] <- lapply(out[num_cols], function(x) round(x, 4))
out$weight <- round(out$weight, 6)

write.csv(out, file.path(tab_dir, "panel_20_direction_vector.csv"), row.names = FALSE)
cat("\n--- direction vector ---\n")
print(out[, c("gene", "direction", "sign", "weight", "rank", "selection_frequency")],
      row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
up_genes   <- out$gene[out$direction == "UP"]
down_genes <- out$gene[out$direction == "DOWN"]
formula_txt <- c(
  "qCSC-like 20-gene panel score",
  "=============================",
  "",
  sprintf("score = mean(z[%s]) - mean(z[%s])", n_up, n_down),
  sprintf("  where z = per-sample gene-wise z-score across tumour samples"),
  "",
  sprintf("UP  (%d genes, weight +1/%d each):", n_up, n_up),
  sprintf("  %s", paste(up_genes, collapse = ", ")),
  "",
  sprintf("DOWN (%d genes, weight -1/%d each):", n_down, n_down),
  sprintf("  %s", paste(down_genes, collapse = ", ")),
  "",
  "Equivalent weighted form:",
  sprintf("  score = sum_over_genes(weight_g * z_g),  sum of positive weights = 1, negative = -1"),
  "",
  "Notes for Methods:",
  "  - The panel was frozen after stability selection; no gene is re-selected in any external cohort.",
  "  - z-scores are computed within the tumour sample set of each cohort, and the same",
  "    transform is applied to non-tumour samples when they exist.",
  "  - For external bulk arrays, probes were collapsed to genes by keeping the probe with",
  "    the highest mean expression; values are log2 scale.",
  sprintf("  - %d/%d genes were detected (>=5%%) in both single-cell cohorts.", sum(out$detected_both), nrow(out)),
  ""
)
writeLines(formula_txt, file.path(tab_dir, "panel_20_formula.txt"))
cat("\n", paste(formula_txt, collapse = "\n"), "\n", sep = "")

# ------------------------------------------------------------
# ------------------------------------------------------------
cat("\n--- sanity checks ---\n")
cat(sprintf("positive weight sum = %.4f (expect 1)\n", sum(out$weight[out$sign > 0])))
cat(sprintf("negative weight sum = %.4f (expect -1)\n", sum(out$weight[out$sign < 0])))
cat(sprintf("genes with sign/direction mismatch: %d\n",
            sum((out$direction == "UP") != (out$sign == 1L))))
if (!all(is.na(out$selection_frequency))) {
  cat(sprintf("lowest selection frequency = %.3f (%s)\n",
              min(out$selection_frequency, na.rm = TRUE),
              out$gene[which.min(out$selection_frequency)]))
}
cat("\nWritten:\n  ", file.path(tab_dir, "panel_20_direction_vector.csv"),
    "\n  ", file.path(tab_dir, "panel_20_formula.txt"), "\n")
