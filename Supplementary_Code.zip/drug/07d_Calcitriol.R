## ===========================================================================
## drug/07d_Calcitriol.R
## Calcitriol (GSE100785): score the panel in patient-derived tumour and normal
## organoids, paired by patient.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
OUT_DIR <- file.path(QCSC_PROJECT_DIR, "output", "drug_Calcitriol")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)
############################################################
# GSE100785 — Calcitriol (1,25(OH)2D3) 20-gene Differentiation Signature
# COLON organoids (tumour vs matched normal), RNA-seq
#
# This is the COLON counterpart to the GSE143782 RECTAL tumour analysis.
# Running both gives a colon-vs-rectum comparison of the same signature.
#
# Dataset facts (verified from the downloaded files):
#   GSE100785 "RNA-Seq on the effect of VitaminD on colonic and tumor organoids"
#   PMID 31306552 (Fernandez-Barral et al., FEBS J 2020)
#
#   6 patients, 4 organoid cultures each = 24 RNA-seq samples
#     <patient><H|T><C|D>
#       H = Healthy (normal) left colon organoid
#       T = Tumour left colon organoid
#       C = Control / Vehicle      (DMSO/vehicle)
#       D = 1,25(OH)2D3 (calcitriol)
#   96 h treatment. Platform GPL11154 (Illumina HiSeq 2000).
#
#   Primary analysis  : Tumour organoids   (TC vs TD), paired by patient
#   Secondary analysis: Healthy organoids  (HC vs HD), paired by patient
#
# DATA SOURCE — important:
#   The series matrix has metadata only (empty expression table).
#   Expression comes from the supplementary files:
#     GSE100785_counts_htseq_GeneInfo.csv.gz   <- USED (raw htseq counts, 24 cols)
#     GSE100785_htcounts_TumoralTissue_paired_cpm_X.xls.gz   (CPM, 6 patients)
#     GSE100785_htcounts_NormalTissue_paired_cpm.xls.gz      (CPM, 6 patients)
#   Raw counts are preferred because this script applies its own
#   CPM + log2(CPM+1). The precomputed .xls CPM tables are LEFT ALONE.
#
# Standard logic (identical to all earlier scripts):
#   qCSC_score  = mean(UP differentiation genes) - mean(DOWN stemness genes)
#   Delta_qCSC  = Calcitriol - Control
#   Delta_qCSC > 0  => favours differentiation induction
#   Delta_qCSC < 0  => does not favour differentiation induction
#
#   UP gene   reversed if log2FC > 0
#   DOWN gene reversed if log2FC < 0
#   Signed_log2FC = UP ? +log2FC : -log2FC
#   Full concordant reversal: UP_change > 0 AND DOWN_change < 0
#
# Treatment-control check (run BEFORE interpreting the signature):
#   CYP24A1, TRPV6  -> UP after calcitriol (VDR primary targets)
#   LGR5            -> UP is the documented normal-organoid response
#   If CYP24A1 does not rise, the calcitriol arm failed and the
#   signature must not be interpreted.
############################################################


############################
# 1. Paths and parameters
############################
data_dir <- Sys.getenv("GSE100785_DATA_DIR", unset = DATA_ROOT)
out_root <- Sys.getenv(
  "GSE100785_OUT_ROOT",
  unset = file.path(QCSC_PROJECT_DIR, "output", "GSE100785_Colon_Calcitriol_20gene_validation")
)
output_dir <- file.path(out_root, "results")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# Accept the counts file either gzipped or pre-extracted.
# The data may sit next to input2.tsv (data_dir) OR be downloaded into a
# separate folder; GSE100785_DATA_DIR overrides data_dir for that case.
counts_candidates <- c(
  file.path(data_dir, "GSE100785_counts_htseq_GeneInfo.csv.gz"),
  file.path(data_dir, "GSE100785_counts_htseq_GeneInfo.csv")
)
counts_file <- counts_candidates[file.exists(counts_candidates)][1]

# The signature file may live outside data_dir (e.g. data downloaded into a
# working folder while input2.tsv stays in the original project folder).
signature_file <- Sys.getenv("GSE100785_SIGNATURE", unset = "")
if (identical(signature_file, "")) {
  sig_candidates <- c(
    file.path(Sys.getenv("GSE100785_SIG_DIR", unset = DATA_ROOT), "input2.tsv"),
    file.path(data_dir, "input2.tsv")
  )
  hit <- sig_candidates[file.exists(sig_candidates)]
  signature_file <- if (length(hit) > 0) hit[1] else sig_candidates[1]
}

if (is.na(counts_file) || is.null(counts_file)) {
  stop(
    "GSE100785_counts_htseq_GeneInfo.csv(.gz) not found.
",
    "Download from GEO: " ,
    "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE100nnn/GSE100785/suppl/\n",
    "and place it in: ", data_dir
  )
}
if (!file.exists(signature_file)) stop("Signature file not found: ", signature_file)

cat("Counts file  :", counts_file, "\n")
cat("Signature    :", signature_file, "\n")
cat("Output dir   :", output_dir, "\n\n")


############################
# 2. Packages
############################
required_packages <- c("dplyr", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0) install.packages(missing_packages)
suppressWarnings(suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
}))


############################
# 3. Read the htseq counts table
############################
# Format quirks of this specific file (must be handled explicitly):
#   - header line is wrapped in quotes and its fields are SPACE separated
#   - data lines are TAB separated
#   - gene symbol column is quoted, "Gene" column is SYMBOL_ENSGID
cat("Reading counts...\n")

con <- if (grepl("\\.gz$", counts_file)) gzfile(counts_file, "rt") else file(counts_file, "rt")
raw_lines <- readLines(con, warn = FALSE)
close(con)

header_fields <- strsplit(gsub('^"|"$', "", raw_lines[1]), "[[:space:]]+")[[1]]
if (length(header_fields) < 8L) stop("Failed to parse the counts header.")

symbol_col   <- match("hgnc_symbol", header_fields)
gene_col     <- match("Gene", header_fields)
sample_start <- 7L                        # first sample column in this file
sample_ids   <- header_fields[sample_start:length(header_fields)]

cat("Samples in counts file:", length(sample_ids), "\n")
cat("Sample ids:", paste(sample_ids, collapse = ", "), "\n")

body <- raw_lines[-1]
body <- body[nzchar(body)]
field_list <- strsplit(body, "\t", fixed = TRUE)

keep_idx <- vapply(field_list, length, integer(1)) >= length(header_fields)
if (any(!keep_idx)) {
  warning(sum(!keep_idx), " rows had too few fields and were skipped.")
}
field_list <- field_list[keep_idx]

gene_symbols <- vapply(field_list, function(f) {
  toupper(gsub('^"|"$', "", f[symbol_col]))
}, character(1))

count_mat <- matrix(
  NA_real_,
  nrow = length(field_list),
  ncol = length(sample_ids),
  dimnames = list(NULL, sample_ids)
)
for (j in seq_along(sample_ids)) {
  col_j <- sample_start - 1L + j
  count_mat[, j] <- vapply(field_list, function(f) {
    v <- f[col_j]
    if (is.na(v) || v %in% c("NA", "", "null")) NA_real_ else as.numeric(v)
  }, numeric(1))
}
rm(field_list, body, raw_lines)

cat("Genes parsed:", length(gene_symbols), "\n")
na_frac <- mean(is.na(count_mat))
if (na_frac > 0) warning(sprintf("%.2f%% of the counts are NA", 100 * na_frac))
if (all(is.na(count_mat))) stop("All counts are NA; the selected columns are wrong.")


############################
# 4. Sample metadata parsed from the sample id
############################
# id format: <patient><tissue H|T><treatment C|D>
parse_id <- function(id) {
  m <- regmatches(id, regexec("^([0-9]+)([HT])([CD])$", id))[[1]]
  if (length(m) != 4L) return(NULL)
  data.frame(
    Sample = id,
    Patient = m[2],
    Tissue = ifelse(m[3] == "T", "Tumour", "Healthy"),
    Treatment = ifelse(m[4] == "D", "Calcitriol", "Control"),
    stringsAsFactors = FALSE
  )
}

meta_list <- lapply(sample_ids, parse_id)
if (any(vapply(meta_list, is.null, logical(1)))) {
  bad <- sample_ids[vapply(meta_list, is.null, logical(1))]
  stop("Sample names that could not be parsed: ", paste(bad, collapse = ", "))
}
sample_info <- do.call(rbind, meta_list)
sample_info <- sample_info[order(sample_info$Tissue, sample_info$Patient,
                                 sample_info$Treatment), ]
rownames(sample_info) <- NULL

cat("\nDesign:\n")
print(
  as.data.frame(with(sample_info, table(Tissue, Treatment))),
  row.names = FALSE
)

# Every patient must have all 4 conditions.
for (p in unique(sample_info$Patient)) {
  need <- c(paste0(p, "HC"), paste0(p, "HD"), paste0(p, "TC"), paste0(p, "TD"))
  if (!all(need %in% sample_info$Sample)) {
    stop("Patient ", p, " missing samples: ", paste(setdiff(need, sample_info$Sample), collapse = ", "))
  }
}


############################
# 5. Filter and average duplicate symbols
############################
keep <- !is.na(gene_symbols) &
  nzchar(gene_symbols) &
  gene_symbols != "NA" &
  !grepl("^ENSG", gene_symbols) &
  rowSums(is.na(count_mat)) == 0L

cat("\nGenes before filtering:", length(gene_symbols),
    " dropped:", sum(!keep), "\n")
count_mat <- count_mat[keep, , drop = FALSE]
gene_symbols <- gene_symbols[keep]

expr_df <- data.frame(Gene = gene_symbols, count_mat, check.names = FALSE)
expr_agg <- expr_df %>%
  group_by(Gene) %>%
  summarise(across(all_of(sample_ids), ~mean(.x, na.rm = TRUE)), .groups = "drop") %>%
  as.data.frame()
rownames(expr_agg) <- expr_agg$Gene
count_mat <- as.matrix(expr_agg[, sample_ids, drop = FALSE])
storage.mode(count_mat) <- "double"

cat("Genes after collapsing duplicates:", nrow(count_mat), "\n")


############################
# 6. CPM + log2(CPM + 1)
############################
library_size <- colSums(count_mat)
cat("Library sizes (millions):",
    paste(round(library_size / 1e6, 1), collapse = ", "), "\n")

low_lib <- library_size < median(library_size) * 0.4
if (any(low_lib)) {
  warning("Samples with low sequencing depth: ", paste(names(library_size)[low_lib], collapse = ", "))
}

cpm_mat <- sweep(count_mat, 2, library_size, "/") * 1e6
expr_log2 <- log2(cpm_mat + 1)
rm(cpm_mat)


############################
# 7. Read the fixed 20-gene signature
############################
sig <- read.delim(signature_file, stringsAsFactors = FALSE, check.names = FALSE)

if (all(c("Name", "Input Type", "Type") %in% names(sig))) {
  sig$Name <- toupper(trimws(as.character(sig$Name)))
  input_type <- tolower(trimws(as.character(sig[["Input Type"]])))
  sig_type   <- tolower(trimws(as.character(sig[["Type"]])))
  qCSC_UP   <- unique(sig$Name[input_type == "up_entities"   & sig_type == "valid"])
  qCSC_DOWN <- unique(sig$Name[input_type == "down_entities" & sig_type == "valid"])
} else if (all(c("Gene", "Direction") %in% names(sig))) {
  sig$Gene <- toupper(trimws(as.character(sig$Gene)))
  direction <- toupper(trimws(as.character(sig[["Direction"]])))
  qCSC_UP   <- unique(sig$Gene[direction == "UP"])
  qCSC_DOWN <- unique(sig$Gene[direction == "DOWN"])
} else {
  stop("Unrecognised input2.tsv format.")
}
qCSC_UP   <- qCSC_UP[!is.na(qCSC_UP) & qCSC_UP != ""]
qCSC_DOWN <- qCSC_DOWN[!is.na(qCSC_DOWN) & qCSC_DOWN != ""]

cat("\n20-gene signature loaded: UP =", length(qCSC_UP),
    " DOWN =", length(qCSC_DOWN), "\n")


############################
# 8. Match signature genes
############################
matched_up   <- intersect(qCSC_UP, rownames(expr_log2))
matched_down <- intersect(qCSC_DOWN, rownames(expr_log2))

cat("\nSignature matching:\n")
cat("  UP matched  :", length(matched_up), "/", length(qCSC_UP), "\n")
cat("  DOWN matched:", length(matched_down), "/", length(qCSC_DOWN), "\n")
missing_up   <- setdiff(qCSC_UP, matched_up)
missing_down <- setdiff(qCSC_DOWN, matched_down)
if (length(missing_up) > 0)   cat("  Missing UP  :", paste(missing_up, collapse = ", "), "\n")
if (length(missing_down) > 0) cat("  Missing DOWN:", paste(missing_down, collapse = ", "), "\n")

if (length(matched_up) == 0L || length(matched_down) == 0L) {
  stop("No UP or DOWN gene was matched.")
}


############################
# 9. Treatment-control check
############################
# Run on BOTH tumour and healthy organoids: the published biology is that
# calcitriol induces CYP24A1 in both, while LGR5 rises mainly in normal
# organoids. Being explicit about which arm shows what is the point.
control_genes <- data.frame(
  Gene = c("CYP24A1", "TRPV6", "LGR5"),
  Expected = c("up", "up", "up"),
  Module = c("VDR_primary", "VDR_secondary", "stemness_marker"),
  stringsAsFactors = FALSE
)

log2fc_between <- function(gene, tissue) {
  sub <- sample_info[sample_info$Tissue == tissue, ]
  c_cols <- sub$Sample[sub$Treatment == "Control"]
  d_cols <- sub$Sample[sub$Treatment == "Calcitriol"]
  mean(expr_log2[gene, d_cols]) - mean(expr_log2[gene, c_cols])
}

per_patient_fc <- function(gene, tissue) {
  sub <- sample_info[sample_info$Tissue == tissue, ]
  vapply(sort(unique(sub$Patient)), function(p) {
    c_s <- paste0(p, "TC"); d_s <- paste0(p, "TD")
    if (tissue == "Healthy") { c_s <- paste0(p, "HC"); d_s <- paste0(p, "HD") }
    expr_log2[gene, d_s] - expr_log2[gene, c_s]
  }, numeric(1))
}

for (tis in c("Tumour", "Healthy")) {
  cat("\n--- Treatment-control check:", tis, "organoids ---\n")
  tab <- control_genes
  tab$log2FC_mean <- NA_real_
  tab$n_patients_up <- NA_integer_
  tab$Observed <- NA_character_
  tab$Pass <- NA
  for (i in seq_len(nrow(tab))) {
    g <- tab$Gene[i]
    if (!g %in% rownames(expr_log2)) {
      tab$Observed[i] <- "not_found"; tab$Pass[i] <- FALSE; next
    }
    pp <- per_patient_fc(g, tis)
    tab$log2FC_mean[i] <- log2fc_between(g, tis)
    tab$n_patients_up[i] <- sum(pp > 0)
    tab$Observed[i] <- ifelse(tab$log2FC_mean[i] > 0, "up", "down")
    tab$Pass[i] <- tab$Observed[i] == tab$Expected[i]
    cat("  ", g, ": mean log2FC =", sprintf("%+.2f", tab$log2FC_mean[i]),
        "| patients with induction:", tab$n_patients_up[i], "/", length(pp), "\n")
  }
  print(tab[, c("Gene", "Module", "Expected", "log2FC_mean", "n_patients_up", "Pass")],
        row.names = FALSE)
  write.csv(tab, file.path(output_dir,
                           paste0("GSE100785_treatment_check_", tis, ".csv")),
            row.names = FALSE, fileEncoding = "UTF-8")
}


############################
# 10. Core analysis function
############################
run_tissue_analysis <- function(tissue) {
  sub <- sample_info[sample_info$Tissue == tissue, ]
  patients <- sort(unique(sub$Patient))
  
  score_rows <- lapply(seq_len(nrow(sub)), function(i) {
    s <- sub$Sample[i]
    data.frame(
      Sample = s,
      Patient = sub$Patient[i],
      Tissue = tissue,
      Treatment = sub$Treatment[i],
      UP_score = mean(expr_log2[matched_up, s]),
      DOWN_score = mean(expr_log2[matched_down, s]),
      stringsAsFactors = FALSE
    )
  })
  score_df <- do.call(rbind, score_rows)
  score_df$qCSC_score <- score_df$UP_score - score_df$DOWN_score
  
  delta_rows <- lapply(patients, function(p) {
    c_s <- if (tissue == "Tumour") paste0(p, "TC") else paste0(p, "HC")
    d_s <- if (tissue == "Tumour") paste0(p, "TD") else paste0(p, "HD")
    
    cs <- score_df$qCSC_score[score_df$Sample == c_s]
    ds <- score_df$qCSC_score[score_df$Sample == d_s]
    
    up_change <- mean(expr_log2[matched_up, d_s]) - mean(expr_log2[matched_up, c_s])
    dn_change <- mean(expr_log2[matched_down, d_s]) - mean(expr_log2[matched_down, c_s])
    
    data.frame(
      Tissue = tissue,
      Patient = p,
      Control_Sample = c_s,
      Drug_Sample = d_s,
      Treatment = "Calcitriol",
      Control_qCSC = cs,
      Drug_qCSC = ds,
      Delta_qCSC = ds - cs,
      UP_change = up_change,
      DOWN_change = dn_change,
      Full_concordant_reversal = (up_change > 0 & dn_change < 0),
      Supports_Differentiation = ifelse(ds - cs > 0, "YES", "NO"),
      stringsAsFactors = FALSE
    )
  })
  delta_df <- do.call(rbind, delta_rows)
  
  # Internal consistency check.
  gap <- max(abs(delta_df$Delta_qCSC - (delta_df$UP_change - delta_df$DOWN_change)))
  if (gap > 1e-8) stop("Internal consistency error: dqCSC and the module delta disagree (", gap, ")")
  
  gene_rows <- lapply(patients, function(p) {
    c_s <- if (tissue == "Tumour") paste0(p, "TC") else paste0(p, "HC")
    d_s <- if (tissue == "Tumour") paste0(p, "TD") else paste0(p, "HD")
    fc <- expr_log2[, d_s] - expr_log2[, c_s]
    tmp <- data.frame(
      Gene = c(matched_up, matched_down),
      Direction = c(rep("UP", length(matched_up)), rep("DOWN", length(matched_down))),
      Tissue = tissue, Patient = p, Treatment = "Calcitriol",
      log2FC = as.numeric(fc[c(matched_up, matched_down)]),
      stringsAsFactors = FALSE
    )
    tmp$Reversed <- ifelse(tmp$Direction == "UP", tmp$log2FC > 0, tmp$log2FC < 0)
    tmp$Signed_log2FC <- ifelse(tmp$Direction == "UP", tmp$log2FC, -tmp$log2FC)
    tmp
  })
  gene_df <- do.call(rbind, gene_rows)
  
  reversal_df <- gene_df %>%
    group_by(Tissue, Patient) %>%
    summarise(
      matched_genes = sum(!is.na(log2FC)),
      reversed_genes = sum(Reversed),
      reversal_percentage = 100 * reversed_genes / matched_genes,
      mean_signed_log2FC = mean(Signed_log2FC),
      median_signed_log2FC = median(Signed_log2FC),
      UP_reversed = sum(Direction == "UP" & Reversed),
      DOWN_reversed = sum(Direction == "DOWN" & Reversed),
      .groups = "drop"
    ) %>%
    as.data.frame()
  
  final_df <- merge(delta_df, reversal_df,
                    by.x = c("Tissue", "Patient"), by.y = c("Tissue", "Patient"),
                    sort = FALSE)
  final_df <- final_df[order(final_df$Patient), ]
  
  list(scores = score_df, delta = delta_df, gene = gene_df,
       final = final_df, patients = patients)
}

tumour_res  <- run_tissue_analysis("Tumour")
healthy_res <- run_tissue_analysis("Healthy")


############################
# 11. Report
############################
cat("\n\n############################################\n")
cat("#   TUMOUR organoids (primary analysis)\n")
cat("############################################\n\n")
print(tumour_res$final[, c(
  "Patient", "Control_qCSC", "Drug_qCSC", "Delta_qCSC",
  "UP_change", "DOWN_change", "Full_concordant_reversal",
  "reversal_percentage"
)], row.names = FALSE)

cat("\n\n############################################\n")
cat("#   HEALTHY organoids (secondary analysis)\n")
cat("############################################\n\n")
print(healthy_res$final[, c(
  "Patient", "Control_qCSC", "Drug_qCSC", "Delta_qCSC",
  "UP_change", "DOWN_change", "Full_concordant_reversal",
  "reversal_percentage"
)], row.names = FALSE)


############################
# 12. Statistics
############################
run_stats <- function(res, label) {
  d <- res$delta
  n <- nrow(d)
  n_pos <- sum(d$Delta_qCSC > 0)
  
  cat("\n=============", label, "=============\n")
  cat("Patients with Delta qCSC > 0:", n_pos, "/", n, "\n")
  cat("Median Delta qCSC:", sprintf("%+.4f", median(d$Delta_qCSC)), "\n")
  
  w_greater <- suppressWarnings(wilcox.test(
    d$Drug_qCSC, d$Control_qCSC, paired = TRUE, alternative = "greater"
  ))
  w_two <- suppressWarnings(wilcox.test(
    d$Drug_qCSC, d$Control_qCSC, paired = TRUE, alternative = "two.sided"
  ))
  t_greater <- t.test(d$Drug_qCSC, d$Control_qCSC,
                      paired = TRUE, alternative = "greater")
  t_two <- t.test(d$Drug_qCSC, d$Control_qCSC,
                  paired = TRUE, alternative = "two.sided")
  
  cat("Paired Wilcoxon (greater)  : P =", signif(w_greater$p.value, 4), "\n")
  cat("Paired Wilcoxon (two-sided): P =", signif(w_two$p.value, 4), "\n")
  cat("Paired t-test  (greater)   : P =", signif(t_greater$p.value, 4), "\n")
  cat("Paired t-test  (two-sided) : P =", signif(t_two$p.value, 4), "\n")
  cat("Note: with n =", n,
      "the minimum attainable two-sided Wilcoxon P is",
      format(2 / 2^n, digits = 3), "\n")
  
  data.frame(
    Analysis = label,
    n_patients = n,
    n_delta_positive = n_pos,
    median_delta_qCSC = median(d$Delta_qCSC),
    mean_delta_qCSC = mean(d$Delta_qCSC),
    wilcox_p_greater = w_greater$p.value,
    wilcox_p_two_sided = w_two$p.value,
    ttest_p_greater = t_greater$p.value,
    ttest_p_two_sided = t_two$p.value,
    stringsAsFactors = FALSE
  )
}

stats_tumour  <- run_stats(tumour_res,  "Tumour organoids (TC vs TD)")
stats_healthy <- run_stats(healthy_res, "Healthy organoids (HC vs HD)")
stats_all <- rbind(stats_tumour, stats_healthy)

cat("\nSummary of both analyses:\n")
print(stats_all, row.names = FALSE)


############################
# 13. Cross-tissue comparison by patient
############################
cross <- data.frame(
  Patient = tumour_res$delta$Patient,
  Tumour_Delta = tumour_res$delta$Delta_qCSC,
  Healthy_Delta = healthy_res$delta$Delta_qCSC[match(
    tumour_res$delta$Patient, healthy_res$delta$Patient
  )],
  stringsAsFactors = FALSE
)
cat("\nDelta qCSC by tissue, per patient (tumour vs healthy):\n")
print(cross, row.names = FALSE)


############################
# 14. Plots
############################
plot_tissue <- function(res, title_suffix) {
  d <- res$scores
  d$Treatment <- factor(d$Treatment, levels = c("Control", "Calcitriol"))
  ggplot(d, aes(x = Treatment, y = qCSC_score)) +
    geom_boxplot(aes(group = Treatment), width = 0.35, alpha = 0.22,
                 fill = "grey70", outlier.shape = NA, color = "grey40") +
    geom_line(aes(color = Patient, group = Patient), linewidth = 0.8, alpha = 0.75) +
    geom_point(aes(color = Patient), size = 3) +
    theme_classic(base_size = 11) +
    labs(
      title = paste("Calcitriol effect on differentiation score —", title_suffix),
      subtitle = paste0(
        "GSE100785, n = ", length(res$patients), " paired patients; ",
        "median Delta = ", sprintf("%+.3f", median(res$delta$Delta_qCSC)),
        "; ", length(matched_up) + length(matched_down), "/20 genes"
      ),
      x = NULL,
      y = "Differentiation score (mean UP - mean DOWN)"
    ) +
    theme(
      legend.position = "bottom",
      plot.title = element_text(hjust = 0.5, face = "bold", size = 10),
      plot.subtitle = element_text(hjust = 0.5, size = 8)
    )
}

p_tum <- plot_tissue(tumour_res, "tumour colon organoids")
ggsave(file.path(output_dir, "GSE100785_TUMOUR_signature_by_treatment.png"),
       p_tum, width = 5.2, height = 5.2, dpi = 300)
ggsave(file.path(output_dir, "GSE100785_TUMOUR_signature_by_treatment.pdf"),
       p_tum, width = 5.2, height = 5.2)

p_hea <- plot_tissue(healthy_res, "healthy colon organoids")
ggsave(file.path(output_dir, "GSE100785_HEALTHY_signature_by_treatment.png"),
       p_hea, width = 5.2, height = 5.2, dpi = 300)
ggsave(file.path(output_dir, "GSE100785_HEALTHY_signature_by_treatment.pdf"),
       p_hea, width = 5.2, height = 5.2)

# Combined two-panel plot: tumour and healthy side by side.
combined_df <- rbind(tumour_res$scores, healthy_res$scores)
combined_df$Treatment <- factor(combined_df$Treatment, levels = c("Control", "Calcitriol"))
combined_df$Tissue <- factor(combined_df$Tissue, levels = c("Tumour", "Healthy"))

p_both <- ggplot(combined_df, aes(x = Treatment, y = qCSC_score)) +
  geom_boxplot(aes(group = Treatment), width = 0.35, alpha = 0.22,
               fill = "grey70", outlier.shape = NA, color = "grey40") +
  geom_line(aes(color = Patient, group = Patient), linewidth = 0.7, alpha = 0.7) +
  geom_point(aes(color = Patient), size = 2.6) +
  facet_wrap(~ Tissue) +
  theme_classic(base_size = 11) +
  labs(
    title = "GSE100785: calcitriol effect in colon organoids",
    subtitle = "Left = tumour organoids (TC vs TD); right = healthy organoids (HC vs HD)",
    x = NULL,
    y = "Differentiation score (mean UP - mean DOWN)"
  ) +
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, face = "bold", size = 10),
    plot.subtitle = element_text(hjust = 0.5, size = 8)
  )

ggsave(file.path(output_dir, "GSE100785_both_tissues_by_treatment.png"),
       p_both, width = 7.0, height = 4.4, dpi = 300)
ggsave(file.path(output_dir, "GSE100785_both_tissues_by_treatment.pdf"),
       p_both, width = 7.0, height = 4.4)

# Gene-level consistency across patients, per tissue.
gene_consistency_all <- rbind(tumour_res$gene, healthy_res$gene) %>%
  group_by(Tissue, Gene, Direction) %>%
  summarise(
    mean_log2FC = mean(log2FC),
    min_log2FC = min(log2FC),
    max_log2FC = max(log2FC),
    n_consistent = sum(Reversed),
    n_patients = n(),
    .groups = "drop"
  ) %>%
  as.data.frame()

p_gene <- ggplot(gene_consistency_all,
                 aes(x = mean_log2FC,
                     y = reorder(paste0(Gene, " (", Tissue, ")"), mean_log2FC),
                     fill = Direction)) +
  geom_col(width = 0.7, alpha = 0.85) +
  geom_errorbar(aes(xmin = min_log2FC, xmax = max_log2FC), orientation = "y",
                width = 0.2, linewidth = 0.3) +
  geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.4) +
  scale_fill_manual(values = c(UP = "#B2182B", DOWN = "#2166AC")) +
  theme_classic(base_size = 8.5) +
  labs(
    title = "20-gene signature response to calcitriol in colon organoids",
    subtitle = "Bar = mean log2FC across patients; whiskers = range",
    x = "log2FC (Calcitriol - Control)", y = NULL, fill = NULL
  ) +
  theme(
    legend.position = "bottom",
    plot.title = element_text(hjust = 0.5, face = "bold", size = 10),
    plot.subtitle = element_text(hjust = 0.5, size = 8)
  )

ggsave(file.path(output_dir, "GSE100785_signature_genes_log2FC.png"),
       p_gene, width = 6.2, height = 8.2, dpi = 300)
ggsave(file.path(output_dir, "GSE100785_signature_genes_log2FC.pdf"),
       p_gene, width = 6.2, height = 8.2)


############################
# 15. Save tables
############################
write.csv(tumour_res$scores,
          file.path(output_dir, "GSE100785_TUMOUR_sample_scores.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(tumour_res$final,
          file.path(output_dir, "GSE100785_TUMOUR_FINAL_result_20gene.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(healthy_res$final,
          file.path(output_dir, "GSE100785_HEALTHY_FINAL_result_20gene.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(rbind(tumour_res$gene, healthy_res$gene),
          file.path(output_dir, "GSE100785_gene_level_20gene.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(gene_consistency_all,
          file.path(output_dir, "GSE100785_gene_consistency.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(stats_all,
          file.path(output_dir, "GSE100785_statistics.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(cross,
          file.path(output_dir, "GSE100785_tumour_vs_healthy_delta.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

limitation_text <- c(
  "Dataset: GSE100785 (colon organoids, 6 patients, 96 h calcitriol)",
  "Samples: <patient><H|T><C|D>; 24 RNA-seq libraries; platform GPL11154.",
  "Expression source: GSE100785_counts_htseq_GeneInfo.csv.gz (raw htseq counts).",
  "  CPM + log2(CPM+1) applied here; precomputed .xls CPM tables were not used.",
  "The series matrix carries metadata only (empty expression table).",
  paste("Signature genes matched:", length(matched_up) + length(matched_down), "/20"),
  if (length(missing_up) > 0) paste("  Missing UP:", paste(missing_up, collapse=", ")),
  "Primary analysis: TUMOUR organoids (TC vs TD), n = 6 paired patients.",
  "Secondary: HEALTHY organoids (HC vs HD), same 6 patients.",
  "With n = 6 the minimum attainable two-sided Wilcoxon P is 0.031.",
  "",
  "Tumour organoids : Delta qCSC > 0 in",
  paste0("  ", stats_tumour$n_delta_positive, "/", stats_tumour$n_patients,
         "; median Delta = ", sprintf("%+.4f", stats_tumour$median_delta_qCSC),
         "; Wilcoxon greater P = ", signif(stats_tumour$wilcox_p_greater, 4)),
  "Healthy organoids: Delta qCSC > 0 in",
  paste0("  ", stats_healthy$n_delta_positive, "/", stats_healthy$n_patients,
         "; median Delta = ", sprintf("%+.4f", stats_healthy$median_delta_qCSC),
         "; Wilcoxon greater P = ", signif(stats_healthy$wilcox_p_greater, 4))
)
writeLines(limitation_text, file.path(output_dir, "GSE100785_LIMITATIONS.txt"))
writeLines(capture.output(sessionInfo()), file.path(output_dir, "sessionInfo.txt"))

cat("\n============================================\n")
cat("GSE100785 calcitriol colon-organoid analysis finished\n")
cat("============================================\n")
cat("Results saved to:", output_dir, "\n\n")
cat("Key numbers:\n")
cat("  Matched genes        :", length(matched_up) + length(matched_down), "/20\n")
cat("  TUMOUR  Delta > 0    :", stats_tumour$n_delta_positive, "/",
    stats_tumour$n_patients,
    "| median", sprintf("%+.4f", stats_tumour$median_delta_qCSC),
    "| Wilcoxon P =", signif(stats_tumour$wilcox_p_greater, 4), "\n")
cat("  HEALTHY Delta > 0    :", stats_healthy$n_delta_positive, "/",
    stats_healthy$n_patients,
    "| median", sprintf("%+.4f", stats_healthy$median_delta_qCSC),
    "| Wilcoxon P =", signif(stats_healthy$wilcox_p_greater, 4), "\n")