## ===========================================================================
## singlecell_clinical/03f_final_figures.R
##
## Final figures for the 20-gene panel: score distributions, concordance with
## the full axis and the normal-versus-tumour comparison.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

## Final figures for the stable 20-gene qCSC panel.
suppressPackageStartupMessages({library(ggplot2); library(patchwork); library(Matrix)})
fig_dir <- FIG_DIR; dir.create(fig_dir, recursive=TRUE, showWarnings=FALSE)
d <- readRDS(file.path(panel_dir,"panel_data.rds"))
fp <- readRDS(file.path(out_dir,"final_stable_panel.rds"))
stable <- fp$stable
E1 <- d$E1; E2 <- d$E2; f1 <- d$score1; f2 <- d$score2
stable_up <- intersect(stable, d$up_use)
stable_dn <- intersect(stable, d$down_use)
s1 <- colMeans(E1[stable_up, , drop = FALSE]) - colMeans(E1[stable_dn, , drop = FALSE])
s2 <- colMeans(E2[stable_up, , drop = FALSE]) - colMeans(E2[stable_dn, , drop = FALSE])
theme_set(theme_classic(base_size=11))

sc1 <- data.frame(full=f1,panel=s1); sc2 <- data.frame(full=f2,panel=s2)
p1 <- ggplot(sc1,aes(full,panel))+geom_point(alpha=.12,size=.25,color="#2C3E50")+
  geom_smooth(method="lm",se=FALSE,color="#E67E22",linewidth=.8)+
  annotate("text",x=-Inf,y=Inf,hjust=-.05,vjust=1.2,size=3.8,
           label=sprintf("GSE132465\nr = %.3f\nn = %d",cor(f1,s1),length(f1)))+
  labs(x="Full 822-gene score",y="20-gene panel score",title="A  GSE132465 tumour epithelium")+
  theme(plot.title=element_text(face="bold",size=11))
p2 <- ggplot(sc2,aes(full,panel))+geom_point(alpha=.35,size=.6,color="#2C3E50")+
  geom_smooth(method="lm",se=FALSE,color="#E67E22",linewidth=.8)+
  annotate("text",x=-Inf,y=Inf,hjust=-.05,vjust=1.2,size=3.8,
           label=sprintf("GSE188711\nr = %.3f\nn = %d",cor(f2,s2),length(f2)))+
  labs(x="Full 822-gene score",y="20-gene panel score",title="B  GSE188711 epithelium")+
  theme(plot.title=element_text(face="bold",size=11))
g1 <- data.frame(score=s1,group=factor(d$meta1$Cell_subtype,levels=c("CMS1","CMS2","CMS3","CMS4")))
p3 <- ggplot(g1,aes(group,score,fill=group))+geom_boxplot(outlier.shape=NA,width=.6)+
  geom_jitter(width=.15,size=.15,alpha=.15)+
  scale_fill_manual(values=c("#E74C3C","#F39C12","#27AE60","#8E44AD"))+
  labs(x=NULL,y="Panel score",title="C  GSE132465 CMS subtypes")+
  theme(legend.position="none",plot.title=element_text(face="bold",size=11))
g2 <- data.frame(score=s2,group=paste0("Cluster ",d$meta2$seurat_clusters))
p4 <- ggplot(g2,aes(group,score,fill=group))+geom_boxplot(outlier.shape=NA,width=.55)+
  geom_jitter(width=.12,size=.2,alpha=.2)+
  scale_fill_manual(values=c("#5DADE2","#C0392B"))+
  labs(x=NULL,y="Panel score",title="D  GSE188711 epithelial clusters")+
  theme(legend.position="none",plot.title=element_text(face="bold",size=11))
p_fid <- (p1|p2)/(p3|p4)
ggsave(file.path(fig_dir,"Fig1_panel_fidelity_stable.png"),p_fid,width=10,height=8,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig1_panel_fidelity_stable.pdf"),p_fid,width=10,height=8,bg="white")

det <- rbind(data.frame(gene=stable,cohort="GSE132465",pct=100*rowMeans(E1[stable,,drop=FALSE]>0)),
             data.frame(gene=stable,cohort="GSE188711",pct=100*rowMeans(E2[stable,,drop=FALSE]>0)))
det$gene <- factor(det$gene,levels=rev(stable))
p_det <- ggplot(det,aes(pct,gene,fill=cohort))+geom_col(position=position_dodge(width=.75),width=.7)+
  scale_fill_manual(values=c("#34495E","#95A5A6"))+
  labs(x="Cells expressing (%)",y=NULL,fill="Cohort",title="Detection of the stable 20-gene panel")+
  theme(legend.position="top",plot.title=element_text(face="bold"))
ggsave(file.path(fig_dir,"Fig2_panel_gene_detection_stable.png"),p_det,width=7,height=6.5,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig2_panel_gene_detection_stable.pdf"),p_det,width=7,height=6.5,bg="white")

ne <- readRDS(file.path(out_dir,"normal_expr_sig.rds"))
ne_up <- intersect(stable_up, rownames(ne$expr))
ne_dn <- intersect(stable_dn, rownames(ne$expr))
npanel <- colMeans(ne$expr[ne_up, , drop = FALSE]) - colMeans(ne$expr[ne_dn, , drop = FALSE])
nfull <- colMeans(ne$expr[d$up_use,,drop=FALSE])-colMeans(ne$expr[d$down_use,,drop=FALSE])
allg <- data.frame(group=factor(c(rep("Normal epithelium",length(npanel)),rep("Tumour CMS1-4",length(s1))),
                                levels=c("Normal epithelium","Tumour CMS1-4")),
                   panel=c(npanel,s1),full=c(nfull,f1))
p5 <- ggplot(allg,aes(group,panel,fill=group))+geom_boxplot(outlier.shape=NA,width=.55)+
  geom_jitter(width=.12,size=.2,alpha=.15)+scale_fill_manual(values=c("#27AE60","#C0392B"))+
  labs(x=NULL,y="Panel score",title="E  Tumour vs normal epithelium")+
  theme(legend.position="none",plot.title=element_text(face="bold",size=11))
p6 <- ggplot(allg,aes(group,full,fill=group))+geom_boxplot(outlier.shape=NA,width=.55)+
  geom_jitter(width=.12,size=.2,alpha=.15)+scale_fill_manual(values=c("#27AE60","#C0392B"))+
  labs(x=NULL,y="Full score",title="F  Full score, same cells")+
  theme(legend.position="none",plot.title=element_text(face="bold",size=11))
ggsave(file.path(fig_dir,"Fig3_tumour_vs_normal_stable.png"),p5|p6,width=9,height=4.8,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig3_tumour_vs_normal_stable.pdf"),p5|p6,width=9,height=4.8,bg="white")

## TCGA scatter
tc <- fp$tcga
p7 <- ggplot(tc,aes(full,panel))+geom_point(alpha=.5,size=1.2,color="#2C3E50")+
  geom_smooth(method="lm",se=FALSE,color="#E67E22")+
  labs(x="Full 822-gene score",y="20-gene panel score",
       title=sprintf("TCGA CRC bulk: r = %.3f",cor(tc$panel,tc$full)))+
  theme_classic(base_size=12)
ggsave(file.path(fig_dir,"Fig6_TCGA_score_scatter_stable.png"),p7,width=6,height=5,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig6_TCGA_score_scatter_stable.pdf"),p7,width=6,height=5,bg="white")
cat("figures done\n")
