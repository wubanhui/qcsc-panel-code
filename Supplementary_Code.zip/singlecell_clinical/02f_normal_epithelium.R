## ===========================================================================
## singlecell_clinical/02f_normal_epithelium.R
## Paired normal epithelium of GSE132465, used for the normal-versus-tumour
## comparison.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "paths.R"))

suppressPackageStartupMessages({library(Seurat); library(SeuratObject); library(Matrix)})
d <- readRDS(file.path(panel_dir, "panel_data.rds"))
root <- ROOT_SC
obj <- readRDS(find_qc132(root))
meta <- obj[[]]
keep <- !is.na(meta$Class) & meta$Class=="Normal" &
  !is.na(meta$Cell_type) & meta$Cell_type=="Epithelial cells"
obj <- subset(obj, cells=rownames(meta)[keep])
obj <- NormalizeData(obj,assay="RNA",normalization.method="LogNormalize",scale.factor=10000,verbose=FALSE)
expr <- SeuratObject::LayerData(obj[["RNA"]],layer="data")
counts <- SeuratObject::LayerData(obj[["RNA"]],layer="counts")
sym <- toupper(rownames(expr)); ok <- !is.na(sym)&nzchar(sym)
expr <- expr[ok,,drop=FALSE]; sym <- sym[ok]; tc <- Matrix::rowSums(counts)[ok]
ord <- order(sym,-tc); expr <- expr[ord,,drop=FALSE]; sym <- sym[ord]
keep_row <- !duplicated(sym); expr <- expr[keep_row,,drop=FALSE]; rownames(expr) <- sym[keep_row]
genes <- intersect(d$genes, rownames(expr))
expr <- as.matrix(expr[genes,,drop=FALSE])
meta <- obj[[]][colnames(expr),,drop=FALSE]
saveRDS(list(expr=expr, meta=meta, genes=genes), file.path(out_dir,"normal_expr_sig.rds"))
cat("saved normal:",dim(expr),"\n")
