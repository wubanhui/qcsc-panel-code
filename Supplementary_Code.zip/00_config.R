# =============================================================================
# 00_config.R
#
# Single place where every path used by the analysis is declared. All scripts
# source this file; none of them contains an absolute path.
#
# Usage
#   Every script starts by locating this file and sourcing it:
#     QCSC_PROJECT_DIR <- .find_pkg_root(); source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
#
# Overriding the input locations
#   All inputs are read from DATA_ROOT (default: <package>/data). Any of the
#   variables below can be overridden with an environment variable before the
#   run, so the package can be executed on another machine without editing a
#   single file:
#
#     QCSC_PROJECT_DIR    package root                     (auto-detected)
#     QCSC_DATA_ROOT      root of the input data           (default <root>/data)
#     QCSC_ROOT_SC        single-cell data                 (default <data>/scRNA)
#     QCSC_ROOT_BULK      bulk / external cohorts          (default <data>/bulk)
#     QCSC_ROOT_LINCS     cleaned LINCS gene lists         (default <data>/lincs)
#     QCSC_ROOT_DEG_GSVA  TCGA DEG tables                  (default <data>/deg_gsva)
#     QCSC_PANEL_DIR      two_cohort_panel folder          (default <root>/intermediate/two_cohort_panel)
#     QCSC_OBJ_ROOT       intermediate .rds objects        (default <root>/objects)
#     QCSC_TCGA_RDATA     TCGA_CRC_380_samples.RData
#     QCSC_TCGA_GSVA      ssGSEA scores of the 380 TCGA tumours
#     QCSC_TCGA_RSEM      tcga_RSEM_Hugo_norm_count.gz
#     QCSC_TCGA_CLIN_COAD COAD clinical matrix
#     QCSC_TCGA_CLIN_READ READ clinical matrix
#     QCSC_GENCODE_GTF    GENCODE v50 GTF
# =============================================================================

if (!exists("QCSC_PROJECT_DIR") || is.na(QCSC_PROJECT_DIR)) {
  stop("QCSC_PROJECT_DIR is not set. Source this file through a script that ",
       "locates the package root first.")
}
QCSC_PROJECT_DIR <- normalizePath(QCSC_PROJECT_DIR, mustWork = TRUE)
Sys.setenv(QCSC_PROJECT_DIR = QCSC_PROJECT_DIR)

# -----------------------------------------------------------------------------
# 1. Output directories
# -----------------------------------------------------------------------------
TAB_DIR   <- file.path(QCSC_PROJECT_DIR, "tables")
FIG_DIR   <- file.path(QCSC_PROJECT_DIR, "figures")
OBJ_DIR   <- file.path(QCSC_PROJECT_DIR, "objects")
LOG_DIR   <- file.path(QCSC_PROJECT_DIR, "logs")
MW_DIR    <- file.path(QCSC_PROJECT_DIR, "objects", "malignancy")
for (d in c(TAB_DIR, FIG_DIR, OBJ_DIR, LOG_DIR, MW_DIR)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

# Root for the intermediate .rds objects shared between steps
# (epithelial signatures, CNV scores, malignancy scores, stability results).
OBJ_ROOT <- Sys.getenv("QCSC_OBJ_ROOT", unset = OBJ_DIR)
dir.create(OBJ_ROOT, recursive = TRUE, showWarnings = FALSE)

# -----------------------------------------------------------------------------
# 2. Input data roots
# -----------------------------------------------------------------------------
DATA_ROOT <- Sys.getenv("QCSC_DATA_ROOT", unset = file.path(QCSC_PROJECT_DIR, "data"))

ROOT_SC        <- Sys.getenv("QCSC_ROOT_SC",        unset = file.path(DATA_ROOT, "scRNA"))
ROOT_BULK      <- Sys.getenv("QCSC_ROOT_BULK",      unset = file.path(DATA_ROOT, "bulk"))
ROOT_LINCS     <- Sys.getenv("QCSC_ROOT_LINCS",     unset = file.path(DATA_ROOT, "lincs"))
ROOT_DEG_GSVA  <- Sys.getenv("QCSC_ROOT_DEG_GSVA",  unset = file.path(DATA_ROOT, "deg_gsva"))

GENCODE_GTF <- Sys.getenv("QCSC_GENCODE_GTF",
                          unset = file.path(DATA_ROOT, "gencode.v50.basic.annotation.gtf.gz"))

# Intermediate object shared by the panel scripts (about 127 MB). It is produced
# by the scripts in singlecell_clinical/ and distributed separately because of
# its size.
PANEL_DIR  <- Sys.getenv("QCSC_PANEL_DIR",
                         unset = file.path(QCSC_PROJECT_DIR, "intermediate",
                                           "two_cohort_panel"))
PANEL_DATA <- file.path(PANEL_DIR, "panel_data.rds")
if (!dir.exists(PANEL_DIR)) dir.create(PANEL_DIR, recursive = TRUE, showWarnings = FALSE)

#' Directory that holds (or will hold) the DEG tables produced by 01e and 01g.
#'
#' ROOT_DEG_GSVA is used when it exists and is writable; otherwise the tables go
#' to <root>/output/TCGA_CRC_qCSC_DEG_GSVA, so that the package still runs when
#' the data directory is mounted read-only.
DEG_DIR <- local({
  d <- ROOT_DEG_GSVA
  writable <- dir.exists(d) && file.access(d, 2L) == 0L
  if (!writable) {
    d <- file.path(QCSC_PROJECT_DIR, "output", "TCGA_CRC_qCSC_DEG_GSVA")
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
  }
  d
})

#' Directory that holds the ESTIMATE scores and the model-comparison output.
#'
#' Falls back to <root>/output/TCGA_CRC_ESTIMATE_GSVA when ROOT_DEG_GSVA (the
#' natural neighbour of the ESTIMATE folder) is read-only.
ESTIMATE_DIR <- local({
  d <- DATA_ROOT
  writable <- dir.exists(d) && file.access(d, 2L) == 0L
  if (!writable) {
    d <- file.path(QCSC_PROJECT_DIR, "output", "TCGA_CRC_ESTIMATE_GSVA")
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
  }
  d
})

#' Directory that holds the ssGSEA scores produced by 01f.
GSVA_DIR <- local({
  d <- file.path(DATA_ROOT, "TCGA_qCSC_score_GSVA")
  writable <- dir.exists(d) && file.access(d, 2L) == 0L
  if (!writable) {
    d <- file.path(QCSC_PROJECT_DIR, "output", "TCGA_qCSC_score_GSVA")
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
  }
  d
})

#' Resolve a DEG file name against every place the tables can live.
find_deg_file <- function(name) {
  cand <- c(file.path(DEG_DIR, name),
            file.path(ROOT_DEG_GSVA, name),
            file.path(QCSC_PROJECT_DIR, "output", "TCGA_CRC_qCSC_DEG_GSVA", name))
  cand <- cand[file.exists(cand)]
  if (length(cand)) cand[1] else NA_character_
}

# TCGA inputs
F_TCGA_RSEM      <- Sys.getenv("QCSC_TCGA_RSEM",
                               unset = file.path(DATA_ROOT, "tcga_RSEM_Hugo_norm_count.gz"))
F_TCGA_RDATA     <- Sys.getenv("QCSC_TCGA_RDATA",
                               unset = file.path(DATA_ROOT, "TCGA_CRC_380_samples.RData"))
F_TCGA_GSVA      <- Sys.getenv("QCSC_TCGA_GSVA",
                               unset = file.path(DATA_ROOT,
                                                 "TCGA_CRC_qCSC_GSVA_ssGSEA_scores.csv"))
F_TCGA_CLIN_COAD <- Sys.getenv("QCSC_TCGA_CLIN_COAD",
                               unset = file.path(DATA_ROOT,
                                                 "TCGA.COAD.sampleMap_COAD_clinicalMatrix"))
F_TCGA_CLIN_READ <- Sys.getenv("QCSC_TCGA_CLIN_READ",
                               unset = file.path(DATA_ROOT,
                                                 "TCGA.READ.sampleMap_READ_clinicalMatrix"))

# -----------------------------------------------------------------------------
# 3. Key input files
# -----------------------------------------------------------------------------
# Single-cell raw data
SC_DATA_DIR <- file.path(ROOT_SC, "data")

# Signatures used to build the consensus axis (bulk side)
F_DEG_UP   <- file.path(ROOT_DEG_GSVA, "DEG_UP.csv")
F_DEG_DOWN <- file.path(ROOT_DEG_GSVA, "DEG_DOWN.csv")
F_LINCS_UP <- file.path(ROOT_LINCS, "LINCS_UP_protein_coding.txt")
F_LINCS_DN <- file.path(ROOT_LINCS, "LINCS_DOWN_protein_coding.txt")

# External cohorts
F_GSE144735_MAT <- file.path(ROOT_BULK, "GSE144735",
                             "GSE144735_processed_KUL3_CRC_10X_raw_UMI_count_matrix.txt.gz")
F_GSE144735_ANN <- file.path(ROOT_BULK, "GSE144735",
                             "GSE144735_processed_KUL3_CRC_10X_annotation.txt.gz")
F_GSE39582      <- file.path(ROOT_BULK, "GSE39582", "GSE39582_series_matrix.txt.gz")
F_GSE14333      <- file.path(ROOT_BULK, "GSE14333", "GSE14333_series_matrix.txt.gz")

# External MMR cohorts
MMR_DIR <- Sys.getenv("QCSC_MMR_DIR",
                      unset = file.path(DATA_ROOT, "MMR_external_validation"))

# Drug perturbation data
DRUG_DIR <- Sys.getenv("QCSC_DRUG_DIR", unset = file.path(DATA_ROOT, "drug"))

# -----------------------------------------------------------------------------
# 4. Download addresses (used in error messages)
# -----------------------------------------------------------------------------
URLS <- list(
  GSE132465 = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE132465",
  GSE188711 = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE188711",
  GSE144735 = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE144nnn/GSE144735/suppl/",
  GSE39582  = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE39nnn/GSE39582/matrix/",
  GSE14333  = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE143nnn/GSE14333/matrix/",
  TCGA      = "https://portal.gdc.cancer.gov/"
)

# -----------------------------------------------------------------------------
# 5. Helper functions
# -----------------------------------------------------------------------------
#' Check that a set of files exists; list every missing one and stop.
#' @param files named vector or named list: name = purpose, value = path
check_files <- function(files, hint = NULL, stop_on_missing = TRUE) {
  if (is.list(files)) files <- unlist(files)
  miss <- files[!file.exists(files)]
  if (!length(miss)) return(invisible(TRUE))
  msg <- paste0("Missing required file(s) (", length(miss), "):\n",
                paste0("  - ", names(miss), " : ", miss, collapse = "\n"))
  if (!is.null(hint)) msg <- paste0(msg, "\n\n", hint)
  if (stop_on_missing) stop(msg, call. = FALSE)
  message(msg)
  invisible(FALSE)
}

#' Optional files: warn only, do not stop.
warn_optional <- function(files, hint = NULL) {
  if (is.list(files)) files <- unlist(files)
  miss <- files[!file.exists(files)]
  if (!length(miss)) return(invisible(TRUE))
  message("Optional file(s) missing, dependent steps will be skipped:\n",
          paste0("  - ", names(miss), " : ", miss, collapse = "\n"))
  if (!is.null(hint)) message(hint)
  invisible(FALSE)
}

#' Standard start of every analysis script.
init_script <- function(name) {
  options(stringsAsFactors = FALSE)
  setwd(QCSC_PROJECT_DIR)
  cat(sprintf("[%s] start %s  project=%s\n",
              format(Sys.time(), "%Y-%m-%d %H:%M:%S"), name, QCSC_PROJECT_DIR))
  invisible(TRUE)
}

#' Standard end of every analysis script.
finish_script <- function(name, outputs = character()) {
  cat(sprintf("[%s] done  %s\n", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), name))
  if (length(outputs)) {
    ok <- file.exists(outputs)
    cat(sprintf("  outputs: %d written, %d missing\n", sum(ok), sum(!ok)))
    if (any(!ok)) cat("  missing:", paste(outputs[!ok], collapse = ", "), "\n")
  }
  invisible(TRUE)
}

#' Write a snapshot of the resolved paths for provenance.
config_snapshot <- function(file = file.path(LOG_DIR, "config_snapshot.txt")) {
  lines <- c(
    paste("generated:", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
    paste("QCSC_PROJECT_DIR:", QCSC_PROJECT_DIR),
    paste("DATA_ROOT:", DATA_ROOT),
    paste("ROOT_SC:", ROOT_SC),
    paste("ROOT_BULK:", ROOT_BULK),
    paste("ROOT_LINCS:", ROOT_LINCS),
    paste("ROOT_DEG_GSVA:", ROOT_DEG_GSVA),
    paste("PANEL_DIR:", PANEL_DIR),
    paste("OBJ_ROOT:", OBJ_ROOT),
    paste("R version:", R.version.string),
    "",
    "input files:",
    paste0("  ", c(F_DEG_UP, F_DEG_DOWN, F_LINCS_UP, F_LINCS_DN,
                   F_GSE144735_MAT, F_GSE144735_ANN, F_GSE39582, F_GSE14333),
           "  exists=", file.exists(c(F_DEG_UP, F_DEG_DOWN, F_LINCS_UP, F_LINCS_DN,
                                      F_GSE144735_MAT, F_GSE144735_ANN,
                                      F_GSE39582, F_GSE14333)))
  )
  writeLines(lines, file)
  invisible(file)
}

invisible(TRUE)
