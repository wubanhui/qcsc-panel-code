## ===========================================================================
## singlecell_clinical/01a_singlecell_qc_objects.R
## Build the unfiltered Seurat objects for GSE132465 and GSE188711 from the
## raw GEO files.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

# ============================================================
# 00_build_all_upstream.R
#
#   4. Normalize / HVG / PCA / cluster / UMAP
#
#   <root>/QC_stage4_<timestamp>/seurat_objects/
#     GSE132465_QC_unfiltered.rds
#     GSE188711_all_samples_QC_unfiltered.rds
#     GSE188711_SchemeA_predicted_singlets_by_sample.rds
#   <root>/GSE188711_SchemeA_marker_annotation/rebuild_<timestamp>/
#     10_GSE188711_clustered_with_score_groups.rds
#
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

## Locate the package root (the folder that contains 00_config.R) and load it.
## The guard keeps this script usable from 08b, which already sourced the config.
if (!exists("QCSC_PROJECT_DIR") || !file.exists(file.path(QCSC_PROJECT_DIR, "00_config.R"))) {
  .find_pkg_root <- function() {
    r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
    if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
      return(normalizePath(r))
    }
    d <- normalizePath(getwd())
    for (i in seq_len(8)) {
      if (file.exists(file.path(d, "00_config.R"))) return(d)
      nd <- dirname(d)
      if (identical(nd, d)) break
      d <- nd
    }
    stop("Cannot locate the package root (the folder containing 00_config.R).")
  }
  QCSC_PROJECT_DIR <- .find_pkg_root()
}
if (!exists("DATA_ROOT")) source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

suppressPackageStartupMessages({
  library(Seurat)
  library(SeuratObject)
  library(Matrix)
  library(data.table)
  library(scDblFinder)
  library(SingleCellExperiment)
  library(SummarizedExperiment)
  library(BiocParallel)
})

root <- ROOT_SC
data_dir <- file.path(root, "data")
gene_dir <- ROOT_LINCS

f132_mat <- file.path(data_dir, "GSE132465_GEO_processed_CRC_10X_raw_UMI_count_matrix.txt.gz")
f132_ann <- file.path(data_dir, "GSE132465_GEO_processed_CRC_10X_cell_annotation.txt.gz")
f188_tar <- file.path(data_dir, "GSE188711_RAW.tar")
up_file <- file.path(gene_dir, "LINCS_UP_protein_coding.txt")
down_file <- file.path(gene_dir, "LINCS_DOWN_protein_coding.txt")

missing <- c(f132_mat, f132_ann, f188_tar, up_file, down_file)
missing <- missing[!file.exists(missing)]
if (length(missing)) {
  stop(
    "The following input files do not exist:
",
    paste(missing, collapse = "\n"),
    "
Please put data/ and the LINCS gene lists back into the corresponding directories."
  )
}

stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
out_root <- file.path(root, paste0("QC_stage4_", stamp))
obj_dir <- file.path(out_root, "seurat_objects")
dir.create(obj_dir, recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(out_root, "build_upstream_log.txt")
log_con <- file(log_file, open = "wt", encoding = "UTF-8")
sink(log_con, split = TRUE)
on.exit({
  while (sink.number() > 0L) sink()
  close(log_con)
}, add = TRUE)

cat("CRC qCSC upstream build\n")
cat("Run time:", format(Sys.time()), "\n")
cat("Output:", out_root, "\n\n")

# ------------------------------------------------------------
# ------------------------------------------------------------
add_qc_metrics <- function(obj, sample_name, gene_symbols = NULL) {
  obj$sample_id <- rep(sample_name, ncol(obj))
  feature_ids <- rownames(obj)
  sym <- if (is.null(gene_symbols)) feature_ids else as.character(gene_symbols)
  if (length(sym) != length(feature_ids)) stop(sample_name, ": symbol length mismatch")
  mt <- grepl("^MT-", sym, ignore.case = TRUE)
  cat(sample_name, ": mitochondrial features =", sum(mt), "\n")
  if (any(mt)) {
    obj[["percent.mt"]] <- PercentageFeatureSet(
      obj, features = feature_ids[mt], assay = "RNA"
    )
  } else {
    obj[["percent.mt"]] <- NA_real_
  }
  obj
}

read_gene_list <- function(path) {
  x <- readLines(path, warn = FALSE, encoding = "UTF-8")
  x <- trimws(x)
  x <- x[nzchar(x) & !grepl("^#", x)]
  x <- unlist(strsplit(x, "[,\t;]"), use.names = FALSE)
  x <- trimws(gsub('^"|"$', "", x))
  x <- toupper(x)
  unique(x[nzchar(x) & !x %in% c(
    "GENE", "GENES", "SYMBOL", "GENE_SYMBOL", "GENE SYMBOL", "V1"
  )])
}

collapse_by_symbol <- function(expr, symbols, total_counts = NULL) {
  symbols <- toupper(as.character(symbols))
  ok <- !is.na(symbols) & nzchar(symbols)
  expr <- expr[ok, , drop = FALSE]
  symbols <- symbols[ok]
  if (is.null(total_counts)) {
    total_counts <- Matrix::rowSums(expr)
  } else {
    total_counts <- as.numeric(total_counts)[ok]
  }
  ord <- order(symbols, -total_counts)
  expr <- expr[ord, , drop = FALSE]
  symbols <- symbols[ord]
  keep <- !duplicated(symbols)
  expr <- expr[keep, , drop = FALSE]
  rownames(expr) <- symbols[keep]
  expr
}

# ------------------------------------------------------------
# ------------------------------------------------------------
cat("\n========== 1. GSE132465 ==========\n")

anno <- read.delim(gzfile(f132_ann), header = TRUE,
                   check.names = FALSE, stringsAsFactors = FALSE)
required_cols <- c("Index", "Patient", "Class", "Sample", "Cell_type", "Cell_subtype")
missing_cols <- setdiff(required_cols, colnames(anno))
if (length(missing_cols)) stop("GSE132465 annotation missing: ",
                               paste(missing_cols, collapse = ", "))
anno$Index <- as.character(anno$Index)
if (anyNA(anno$Index) || any(anno$Index == "") || anyDuplicated(anno$Index)) {
  stop("GSE132465 annotation has empty/duplicated Index")
}

con <- gzfile(f132_mat, open = "rt")
header <- readLines(con, n = 1L, warn = FALSE)
if (length(header) != 1L) {
  close(con)
  stop("GSE132465 matrix header read failed")
}
header_fields <- strsplit(header, "\t", fixed = TRUE)[[1]]
cell_ids <- as.character(header_fields[-1])
if (anyNA(cell_ids) || any(cell_ids == "") || anyDuplicated(cell_ids)) {
  close(con)
  stop("GSE132465 matrix has empty/duplicated cell IDs")
}
cat("Matrix cells:", length(cell_ids), "\n")

chunk_size <- 200L
gene_names <- character()
chunks <- list()
n_read <- 0L
repeat {
  lines <- readLines(con, n = chunk_size, warn = FALSE)
  if (!length(lines)) break
  parsed <- strsplit(lines, "\t", fixed = TRUE)
  if (any(lengths(parsed) != length(cell_ids) + 1L)) {
    close(con)
    stop("GSE132465 matrix field count mismatch near row ", n_read + 1L)
  }
  genes <- vapply(parsed, `[`, character(1), 1)
  if (anyNA(genes) || any(genes == "")) {
    close(con)
    stop("GSE132465 matrix has empty gene names")
  }
  vals <- lapply(parsed, function(x) suppressWarnings(as.numeric(x[-1])))
  valid <- vapply(vals, function(x) {
    length(x) == length(cell_ids) && all(is.finite(x)) &&
      all(x >= 0) && all(abs(x - round(x)) < 1e-8)
  }, logical(1))
  if (any(!valid)) {
    close(con)
    stop("GSE132465 matrix has non-finite/negative/non-integer counts")
  }
  nz <- lapply(vals, function(x) which(x != 0))
  ii <- rep.int(seq_along(vals), lengths(nz))
  jj <- unlist(nz, use.names = FALSE)
  xx <- unlist(Map(function(x, i) x[i], vals, nz), use.names = FALSE)
  chunks[[length(chunks) + 1L]] <- sparseMatrix(
    i = as.integer(ii), j = as.integer(jj), x = xx,
    dims = c(length(vals), length(cell_ids)), giveCsparse = TRUE
  )
  gene_names <- c(gene_names, genes)
  n_read <- n_read + length(lines)
  if (n_read %% 5000L < chunk_size) cat("  genes read:", n_read, "\n")
}
close(con)

if (anyDuplicated(gene_names)) stop("GSE132465 duplicated gene names")
counts <- do.call(rbind, chunks)
rownames(counts) <- gene_names
colnames(counts) <- cell_ids
rm(chunks); gc()
cat("Matrix:", nrow(counts), "genes x", ncol(counts), "cells\n")

obj132 <- CreateSeuratObject(
  counts = counts, project = "GSE132465",
  min.cells = 0, min.features = 0
)
rm(counts); gc()

idx <- match(colnames(obj132), anno$Index)
if (anyNA(idx)) stop("GSE132465 annotation match failed")
anno_matched <- anno[idx, , drop = FALSE]
if (!identical(colnames(obj132), anno_matched$Index)) {
  stop("GSE132465 cell order mismatch")
}
obj132$Patient <- anno_matched$Patient
obj132$Class <- anno_matched$Class
obj132$Sample <- anno_matched$Sample
obj132$Cell_type <- anno_matched$Cell_type
obj132$Cell_subtype <- anno_matched$Cell_subtype
obj132 <- add_qc_metrics(obj132, "GSE132465")

saveRDS(obj132, file.path(obj_dir, "GSE132465_QC_unfiltered.rds"),
        compress = FALSE)
write.csv(obj132[[]],
          file.path(out_root, "GSE132465_cell_metadata_QC.csv"),
          row.names = TRUE, fileEncoding = "UTF-8")
cat("GSE132465:", ncol(obj132), "cells;", nrow(obj132), "genes\n")
rm(obj132); gc()

# ------------------------------------------------------------
# ------------------------------------------------------------
cat("\n========== 2. GSE188711 ==========\n")

extract_dir <- file.path(out_root, "GSE188711_extracted")
dir.create(extract_dir, recursive = TRUE, showWarnings = FALSE)
members <- utils::untar(f188_tar, list = TRUE)
utils::untar(f188_tar, exdir = extract_dir)
bases <- basename(members)
mat_files <- members[grepl("_matrix.*\\.mtx\\.gz$", bases, ignore.case = TRUE)]
if (length(mat_files) != 6L) {
  stop("GSE188711 matrix file count != 6, got ", length(mat_files))
}

sample_info <- data.frame(
  GSM = paste0("GSM", 5688706:5688711),
  sample_code = c("WGC", "JCA", "LS-CRC3", "RS-CRC1", "R_CRC3", "R_CRC4"),
  side = c("Left", "Left", "Left", "Right", "Right", "Right"),
  tissue = rep("CRC_tumor", 6),
  stringsAsFactors = FALSE
)
sample_info$patient_id <- sample_info$GSM

objects188 <- list()
summary188 <- list()

for (mf in mat_files) {
  prefix <- sub("_matrix.*$", "", basename(mf))
  bf <- members[grepl(paste0("^", prefix, "_barcodes.*\\.tsv\\.gz$"),
                      bases, ignore.case = TRUE)]
  ff <- members[grepl(paste0("^", prefix, "_features.*\\.tsv\\.gz$"),
                      bases, ignore.case = TRUE)]
  if (length(bf) != 1L || length(ff) != 1L) {
    stop(prefix, ": barcode/feature match failed")
  }
  mat_path <- file.path(extract_dir, mf)
  barcode_path <- file.path(extract_dir, bf)
  feature_path <- file.path(extract_dir, ff)
  if (!all(file.exists(mat_path, barcode_path, feature_path))) {
    stop(prefix, ": extracted files not found")
  }

  mat <- as(Matrix::readMM(gzfile(mat_path)), "CsparseMatrix")
  barcodes <- as.character(read.delim(
    gzfile(barcode_path), header = FALSE, stringsAsFactors = FALSE
  )[[1]])
  features <- read.delim(
    gzfile(feature_path), header = FALSE, sep = "\t",
    quote = "", comment.char = "", check.names = FALSE
  )
  if (nrow(mat) != nrow(features) || ncol(mat) != length(barcodes)) {
    stop(prefix, ": matrix vs feature/barcode dimension mismatch")
  }
  if (anyNA(barcodes) || any(barcodes == "") || anyDuplicated(barcodes)) {
    stop(prefix, ": invalid barcodes")
  }
  if (ncol(features) < 2L) stop(prefix, ": feature file < 2 columns")
  feature_id <- as.character(features[[1]])
  gene_symbol <- as.character(features[[2]])
  feature_type <- if (ncol(features) >= 3L) as.character(features[[3]]) else NA_character_
  if (anyNA(feature_id) || any(feature_id == "") || anyDuplicated(feature_id)) {
    stop(prefix, ": invalid feature IDs")
  }
  if (anyNA(gene_symbol) || any(gene_symbol == "")) {
    stop(prefix, ": empty gene symbols")
  }

  rownames(mat) <- feature_id
  colnames(mat) <- paste(prefix, barcodes, sep = "_")
  obj <- CreateSeuratObject(
    counts = mat, project = prefix,
    min.cells = 0, min.features = 0
  )
  if (!identical(rownames(obj[["RNA"]]), feature_id)) {
    stop(prefix, ": feature order mismatch")
  }
  feature_meta <- data.frame(
    gene_symbol = gene_symbol,
    feature_type = feature_type,
    row.names = feature_id,
    stringsAsFactors = FALSE
  )
  obj[["RNA"]] <- SeuratObject::AddMetaData(
    object = obj[["RNA"]], metadata = feature_meta
  )
  obj <- add_qc_metrics(obj, prefix, gene_symbols = gene_symbol)

  gsm <- regmatches(prefix, regexpr("GSM[0-9]+", prefix))
  if (!length(gsm) || !gsm %in% sample_info$GSM) {
    hit <- which(sample_info$sample_code == prefix)
    if (length(hit) != 1L) stop(prefix, ": cannot map to sample_info")
    si <- sample_info[hit, ]
  } else {
    si <- sample_info[match(gsm, sample_info$GSM), ]
  }
  obj$GSM <- si$GSM
  obj$sample_code <- si$sample_code
  obj$patient_id <- si$patient_id
  obj$side <- si$side
  obj$tissue <- si$tissue

  objects188[[si$GSM]] <- obj
  summary188[[si$GSM]] <- data.frame(
    GSM = si$GSM, sample_code = si$sample_code,
    n_genes = nrow(obj), n_cells = ncol(obj),
    median_nFeature = median(obj$nFeature_RNA),
    median_nCount = median(obj$nCount_RNA),
    median_percent_mt = median(obj$percent.mt, na.rm = TRUE),
    stringsAsFactors = FALSE
  )
  cat(prefix, ": ", ncol(obj), " cells\n", sep = "")
  rm(mat, obj, barcodes, features); gc()
}

if (length(objects188) != 6L) stop("GSE188711 object count != 6")
saveRDS(objects188,
        file.path(obj_dir, "GSE188711_all_samples_QC_unfiltered.rds"),
        compress = FALSE)
write.csv(do.call(rbind, summary188),
          file.path(out_root, "GSE188711_sample_QC_summary.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
rm(objects188); gc()

# ------------------------------------------------------------
# ------------------------------------------------------------
cat("\n========== 3. GSE188711 QC + doublet ==========\n")

qc_list <- readRDS(file.path(obj_dir, "GSE188711_all_samples_QC_unfiltered.rds"))
BiocParallel::register(BiocParallel::SerialParam())

qc_pass <- lapply(qc_list, function(o) {
  subset(o, subset = nFeature_RNA > 200 & nFeature_RNA < 6000 & percent.mt < 25)
})
cat("After QC:",
    paste(vapply(qc_pass, function(o) as.integer(ncol(o)), integer(1)),
          collapse = ", "),
    "\n")

singlets <- list()
doublet_summary <- list()
for (nm in names(qc_pass)) {
  o <- qc_pass[[nm]]
  counts <- SeuratObject::LayerData(o[["RNA"]], layer = "counts")
  sce <- SingleCellExperiment(assays = list(counts = counts))
  set.seed(1234)
  sce <- scDblFinder(sce, clusters = FALSE, verbose = FALSE)
  cd <- SummarizedExperiment::colData(sce)
  o$scDblFinder.class <- as.character(cd$scDblFinder.class)
  o$scDblFinder.score <- as.numeric(cd$scDblFinder.score)
  keep <- o$scDblFinder.class == "singlet"
  singlets[[nm]] <- subset(o, cells = colnames(o)[keep])
  doublet_summary[[nm]] <- data.frame(
    GSM = nm,
    cells_input = ncol(o),
    predicted_singlets = sum(keep),
    predicted_doublets = sum(!keep),
    doublet_pct = 100 * mean(!keep),
    stringsAsFactors = FALSE
  )
  cat(nm, ": ", ncol(o), " -> ", sum(keep), " singlets\n", sep = "")
  rm(o, counts, sce); gc()
}
if (length(singlets) != 6L) stop("GSE188711 singlet list != 6")
saveRDS(singlets,
        file.path(obj_dir, "GSE188711_SchemeA_predicted_singlets_by_sample.rds"),
        compress = FALSE)
write.csv(do.call(rbind, doublet_summary),
          file.path(out_root, "GSE188711_scDblFinder_summary.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

seu <- merge(
  x = singlets[[1]],
  y = singlets[-1],
  add.cell.ids = names(singlets),
  project = "GSE188711_SchemeA",
  merge.data = FALSE
)
seu <- SeuratObject::JoinLayers(seu, assay = "RNA")
if (!"sample_id" %in% colnames(seu[[]])) {
  seu$sample_id <- as.character(seu$orig.ident)
}
cat("Merged:", ncol(seu), "cells\n")
rm(singlets, qc_list, qc_pass); gc()

# ------------------------------------------------------------
# 4. Normalize / HVG / PCA / cluster / UMAP
# ------------------------------------------------------------
cat("\n========== 4. GSE188711 clustering ==========\n")

seu <- NormalizeData(seu, assay = "RNA",
                     normalization.method = "LogNormalize",
                     scale.factor = 10000, verbose = FALSE)
n_hvg <- min(3000, nrow(seu) - 1)
seu <- FindVariableFeatures(seu, selection.method = "vst",
                            nfeatures = n_hvg, verbose = FALSE)
seu <- ScaleData(seu, features = VariableFeatures(seu), verbose = FALSE)
n_pcs <- min(30, length(VariableFeatures(seu)) - 1, ncol(seu) - 1)
seu <- RunPCA(seu, features = VariableFeatures(seu),
              npcs = n_pcs, seed.use = 1234, verbose = FALSE)
dims_use <- seq_len(min(30, ncol(Embeddings(seu, "pca"))))
seu <- FindNeighbors(seu, reduction = "pca", dims = dims_use, verbose = FALSE)
seu <- FindClusters(seu, resolution = 0.5, algorithm = 1,
                    random.seed = 1234, verbose = FALSE)
seu <- RunUMAP(seu, reduction = "pca", dims = dims_use,
               seed.use = 1234, verbose = FALSE)
cat("Clusters:", length(unique(seu$seurat_clusters)), "\n")

# ------------------------------------------------------------
# 5. qCSC_LINCS_score + score_group
# ------------------------------------------------------------
cat("\n========== 5. qCSC score ==========\n")

up_genes <- read_gene_list(up_file)
down_genes <- read_gene_list(down_file)
conflict <- intersect(up_genes, down_genes)
up_genes <- setdiff(up_genes, conflict)
down_genes <- setdiff(down_genes, conflict)

expr <- SeuratObject::LayerData(seu[["RNA"]], layer = "data")
counts <- SeuratObject::LayerData(seu[["RNA"]], layer = "counts")
fmeta <- seu[["RNA"]][[]]
sym <- as.character(fmeta$gene_symbol)
if (length(sym) != nrow(expr)) stop("feature metadata length mismatch")

need <- unique(c(up_genes, down_genes))
keep_feat <- !is.na(sym) & sym %in% need
expr <- expr[keep_feat, , drop = FALSE]
counts <- counts[keep_feat, , drop = FALSE]
sym <- sym[keep_feat]
expr <- collapse_by_symbol(expr, sym, Matrix::rowSums(counts))

up_use <- intersect(up_genes, rownames(expr))
down_use <- intersect(down_genes, rownames(expr))
cat("Matched UP:", length(up_use), "/", length(up_genes),
    "; DOWN:", length(down_use), "/", length(down_genes), "\n")
if (length(up_use) < 5 || length(down_use) < 5) {
  stop("Matched qCSC genes < 5 in one direction; check feature metadata")
}
score <- colMeans(expr[up_use, , drop = FALSE]) -
  colMeans(expr[down_use, , drop = FALSE])
seu$qCSC_LINCS_score <- as.numeric(score)
q10 <- unname(quantile(score, 0.10))
q90 <- unname(quantile(score, 0.90))
seu$score_group <- ifelse(
  score >= q90, "Top10%",
  ifelse(score <= q10, "Bottom10%", "Middle80%")
)
seu$score_group <- factor(
  seu$score_group, levels = c("Bottom10%", "Middle80%", "Top10%")
)
cat("qCSC score summary:\n"); print(summary(seu$qCSC_LINCS_score))
print(table(seu$score_group))

# ------------------------------------------------------------
# ------------------------------------------------------------
cat("\n========== 6. Save ==========\n")

save_dir <- file.path(root, "GSE188711_SchemeA_marker_annotation",
                      paste0("rebuild_", stamp))
dir.create(save_dir, recursive = TRUE, showWarnings = FALSE)
saveRDS(seu, file.path(save_dir, "10_GSE188711_clustered_with_score_groups.rds"),
        compress = FALSE)
write.csv(seu[[]], file.path(save_dir, "cell_metadata_clustered.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  "GSE188711 clustered object",
  paste0("Run time: ", Sys.time()),
  paste0("Cells: ", ncol(seu)),
  paste0("Genes: ", nrow(seu)),
  paste0("Clusters: ", length(unique(seu$seurat_clusters))),
  paste0("HVG: ", length(VariableFeatures(seu))),
  paste0("PCs: ", n_pcs),
  paste0("resolution: 0.5"),
  paste0("qCSC UP matched: ", length(up_use), "/", length(up_genes)),
  paste0("qCSC DOWN matched: ", length(down_use), "/", length(down_genes)),
  paste0("Output: ", file.path(save_dir, "10_GSE188711_clustered_with_score_groups.rds"))
), file.path(save_dir, "RUN_SUMMARY.txt"))

cat("\nDONE\n")
cat("QC root:", out_root, "\n")
cat("Clustered object:", file.path(save_dir, "10_GSE188711_clustered_with_score_groups.rds"), "\n")
