## ===========================================================================
## singlecell_clinical/05b_MMR_hardening.R
## MMR readout hardening: Youden threshold, subgroup AUCs, leave-one-gene-out
## and internal discovery/validation split.
## ===========================================================================
# ============================================================
# 08b_P4_MMR_readout_hardening.R
#
#
#
#   tables/qCSC_MMR_threshold.csv
#   tables/qCSC_MMR_subgroup_auc.csv
#   tables/qCSC_MMR_leave_one_out.csv
#   figures/Fig13b_qCSC_MMR_threshold.png / .pdf
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
panel_dir <- file.path(QCSC_PROJECT_DIR, "intermediate", "two_cohort_panel")
for (d in c(tab_dir, fig_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

dat <- read.csv(file.path(tab_dir, "external_GSE39582_scores.csv"),
                check.names = FALSE, stringsAsFactors = FALSE)
panel <- read.csv(file.path(tab_dir, "final_panel_stable.csv"),
                  check.names = FALSE, stringsAsFactors = FALSE)

dd <- dat[dat$cohort != "Non Tumoral" & !is.na(dat$mmr), ]
dd$y <- as.integer(dd$mmr == "dMMR")
cat(sprintf("Analysis set: %d (dMMR = %d, pMMR = %d)\n",
            nrow(dd), sum(dd$y), sum(!dd$y)))

# ------------------------------------------------------------
# ------------------------------------------------------------
auc_mw <- function(score, y) {
  pos <- score[y == 1]; neg <- score[y == 0]
  r <- rank(c(pos, neg))
  (sum(r[seq_along(pos)]) - length(pos) * (length(pos) + 1) / 2) /
    (length(pos) * length(neg))
}
youden_thr <- function(score, y) {
  thr <- unique(sort(score)); best <- -Inf; best_t <- NA_real_
  for (t in thr) {
    pred <- score >= t
    j <- mean(pred[y == 1]) + mean(!pred[y == 0]) - 1
    if (j > best) { best <- j; best_t <- t }
  }
  best_t
}
conf_stats <- function(pred, y) {
  tp <- sum(pred & y == 1); fp <- sum(pred & y == 0)
  fn <- sum(!pred & y == 1); tn <- sum(!pred & y == 0)
  sens <- tp / (tp + fn); spec <- tn / (tn + fp)
  ppv  <- if ((tp + fp) > 0) tp / (tp + fp) else NA_real_
  npv  <- if ((tn + fn) > 0) tn / (tn + fn) else NA_real_
  acc  <- (tp + tn) / length(y)
  # Wilson CI for sensitivity / specificity
  wilson <- function(k, n) {
    if (n == 0) return(c(NA, NA))
    p <- k / n; z <- 1.96
    d <- 1 + z^2 / n
    c((p + z^2 / (2 * n) - z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / d,
      (p + z^2 / (2 * n) + z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / d)
  }
  se_ci <- wilson(tp, tp + fn); sp_ci <- wilson(tn, tn + fp)
  data.frame(
    threshold = NA_real_,
    tp = tp, fp = fp, fn = fn, tn = tn,
    sens = sens, sens_lo = se_ci[1], sens_hi = se_ci[2],
    spec = spec, spec_lo = sp_ci[1], spec_hi = sp_ci[2],
    ppv = ppv, npv = npv, accuracy = acc,
    stringsAsFactors = FALSE
  )
}

thr <- youden_thr(dd$panel, dd$y)
pred <- dd$panel >= thr
st <- conf_stats(pred, dd$y)
st$threshold <- round(thr, 4)
st <- st[, c("threshold", setdiff(names(st), "threshold"))]
cat("\n--- Youden threshold ---\n")
print(st, row.names = FALSE)
write.csv(st, file.path(tab_dir, "qCSC_MMR_threshold.csv"), row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
boot_ci <- function(score, y, B = 2000L) {
  out <- numeric(B)
  for (b in seq_len(B)) {
    i <- sample.int(length(y), replace = TRUE)
    if (length(unique(y[i])) < 2L) { out[b] <- NA_real_; next }
    out[b] <- auc_mw(score[i], y[i])
  }
  stats::quantile(out, c(0.025, 0.975), na.rm = TRUE)
}
sub_auc <- function(sub, label) {
  ok <- !is.na(sub$panel) & !is.na(sub$y)
  s <- sub$panel[ok]; y <- sub$y[ok]
  if (length(unique(y)) < 2L || sum(y) < 5 || sum(!y) < 5) return(NULL)
  a <- auc_mw(s, y); ci <- boot_ci(s, y)
  data.frame(subgroup = label, n = length(y), n_dmmr = sum(y), n_pmmr = sum(!y),
             auc = a, ci_low = as.numeric(ci[1]), ci_high = as.numeric(ci[2]),
             stringsAsFactors = FALSE)
}
rows <- list(
  sub_auc(dd, "all"),
  sub_auc(dd[dd$cohort == "discovery", ], "discovery only"),
  sub_auc(dd[dd$cohort == "validation", ], "validation only"),
  sub_auc(dd[dd$stage %in% 0:2, ], "stage 0-2"),
  sub_auc(dd[dd$stage %in% 3:4, ], "stage 3-4"),
  sub_auc(dd[dd$location == "Right", ], "right-sided"),
  sub_auc(dd[dd$location %in% c("Left", "Rectum"), ], "left-sided/rectum"),
  sub_auc(dd[dd$chemo == "N", ], "no adjuvant chemo"),
  sub_auc(dd[dd$chemo == "Y", ], "adjuvant chemo"),
  sub_auc(dd[dd$sex == "Female", ], "female"),
  sub_auc(dd[dd$sex == "Male", ], "male")
)
rows <- Filter(Negate(is.null), rows)
sub <- do.call(rbind, rows)
sub[, 5:7] <- lapply(sub[, 5:7], round, 4)
write.csv(sub, file.path(tab_dir, "qCSC_MMR_subgroup_auc.csv"), row.names = FALSE)
cat("\n--- subgroup AUC ---\n")
print(sub, row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
loo_file <- file.path(QCSC_PROJECT_DIR, "objects", "external_GSE39582.rds")
loo <- NULL
if (file.exists(loo_file)) {
  obj <- readRDS(loo_file)
  if (!is.null(obj$z_all)) {
    z <- obj$z_all
    up <- intersect(obj$panel_up, rownames(z))
    dn <- intersect(obj$panel_down, rownames(z))
    gsm_t <- colnames(z)[obj$is_tumour]
    sc <- function(u, d) {
      s <- rep(0, ncol(z))
      if (length(u)) s <- s + colMeans(z[u, , drop = FALSE], na.rm = TRUE)
      if (length(d)) s <- s - colMeans(z[d, , drop = FALSE], na.rm = TRUE)
      s
    }
    base_score <- sc(up, dn)
    names(base_score) <- colnames(z)
    s0 <- base_score[dd$gsm]
    ok0 <- !is.na(s0)
    cat(sprintf("\nLOO baseline check: AUC = %.4f (07 = %.4f)\n",
                auc_mw(s0[ok0], dd$y[ok0]),
                read.csv(file.path(tab_dir, "qCSC_MMR_status_auc.csv"))$auc[1]))

    loo_rows <- list()
    for (g in c(up, dn)) {
      u2 <- setdiff(up, g); d2 <- setdiff(dn, g)
      s <- sc(u2, d2)[dd$gsm]
      ok <- !is.na(s)
      loo_rows[[length(loo_rows) + 1L]] <- data.frame(
        dropped = g,
        direction = if (g %in% up) "UP" else "DOWN",
        auc = auc_mw(s[ok], dd$y[ok]),
        delta = auc_mw(s[ok], dd$y[ok]) - auc_mw(s0[ok0], dd$y[ok0]),
        stringsAsFactors = FALSE
      )
    }
    for (lbl in c("UP only", "DOWN only")) {
      u2 <- if (lbl == "UP only") up else character(0)
      d2 <- if (lbl == "DOWN only") dn else character(0)
      s <- sc(u2, d2)[dd$gsm]
      ok <- !is.na(s)
      loo_rows[[length(loo_rows) + 1L]] <- data.frame(
        dropped = lbl, direction = lbl,
        auc = auc_mw(s[ok], dd$y[ok]),
        delta = auc_mw(s[ok], dd$y[ok]) - auc_mw(s0[ok0], dd$y[ok0]),
        stringsAsFactors = FALSE
      )
    }
    loo <- do.call(rbind, loo_rows)
    loo[, c("auc", "delta")] <- lapply(loo[, c("auc", "delta")], round, 4)
    loo <- loo[order(loo$auc), ]
    write.csv(loo, file.path(tab_dir, "qCSC_MMR_leave_one_out.csv"), row.names = FALSE)
    cat("\n--- leave-one-gene-out (sorted by AUC, worst first) ---\n")
    print(loo, row.names = FALSE)
  } else {
    cat("
Leave-one-gene-out: SKIPPED (z_all not saved by 04b; re-run 04b first)
")
  }
} else {
  cat("
Leave-one-gene-out: SKIPPED (objects/external_GSE39582.rds not found)
")
}

# ------------------------------------------------------------
# ------------------------------------------------------------
draw <- function() {
  par(mar = c(4.4, 4.6, 3.2, 1.2), mgp = c(2.6, 0.7, 0))
  brk <- seq(min(dd$panel, na.rm = TRUE), max(dd$panel, na.rm = TRUE), length.out = 31)
  h1 <- hist(dd$panel[dd$y == 1], breaks = brk, plot = FALSE)
  h0 <- hist(dd$panel[dd$y == 0], breaks = brk, plot = FALSE)
  ymax <- max(c(h1$density, h0$density)) * 1.18
  plot(NA, xlim = range(brk), ylim = c(0, ymax), bty = "l", las = 1,
       xlab = "qCSC-like panel score", ylab = "Density",
       main = "MMR status by panel score (GSE39582)", cex.main = 1.0)
  with(h0, rect(breaks[-length(breaks)], 0, breaks[-1], density,
                col = rgb(0.17, 0.50, 0.72, 0.55), border = NA))
  with(h1, rect(breaks[-length(breaks)], 0, breaks[-1], density,
                col = rgb(0.85, 0.37, 0.05, 0.60), border = NA))
  abline(v = thr, lty = 2, lwd = 1.8)
  legend("topright", bty = "n",
         fill = c(rgb(0.17, 0.50, 0.72, 0.55), rgb(0.85, 0.37, 0.05, 0.60)),
         border = NA, legend = c(sprintf("pMMR (n = %d)", sum(!dd$y)),
                                 sprintf("dMMR (n = %d)", sum(dd$y))))
  mtext(sprintf("threshold %.2f : sens %.1f%%, spec %.1f%%", thr,
                100 * st$sens, 100 * st$spec),
        side = 3, line = 0.1, cex = 0.78, col = "grey25")
}
png(file.path(fig_dir, "Fig13b_qCSC_MMR_threshold.png"), width = 2400, height = 2000, res = 300)
draw(); dev.off()
pdf(file.path(fig_dir, "Fig13b_qCSC_MMR_threshold.pdf"), width = 5.0, height = 4.2)
draw(); dev.off()

# ------------------------------------------------------------
# ------------------------------------------------------------
summ_file <- file.path(tab_dir, "FINAL_RESULTS_SUMMARY.csv")
new_rows <- data.frame(
  section = rep("qCSC_MMR_readout", 6),
  metric = c("youden_threshold", "youden_sens", "youden_spec",
             "AUC_discovery_only", "AUC_validation_only", "AUC_ppv"),
  value = c(st$threshold, st$sens, st$spec,
            sub$auc[sub$subgroup == "discovery only"],
            sub$auc[sub$subgroup == "validation only"], st$ppv),
  note = c("panel score cut (frozen panel, no gene re-selection)",
           "sensitivity at Youden point", "specificity at Youden point",
           "internal split", "internal split", "PPV at Youden point; prevalence-dependent"),
  stringsAsFactors = FALSE
)
if (file.exists(summ_file)) {
  old <- read.csv(summ_file, check.names = FALSE, stringsAsFactors = FALSE)
  old <- old[!(old$section == "qCSC_MMR_readout" &
                 old$metric %in% new_rows$metric), ]
  old$value <- as.character(old$value); new_rows$value <- as.character(new_rows$value)
  all_s <- rbind(old[, c("section", "metric", "value", "note")], new_rows)
} else all_s <- new_rows
write.csv(all_s, summ_file, row.names = FALSE)

cat("\n================ P4 hardening ================\n")
cat(sprintf("Overall AUC = %.3f ; discovery %.3f ; validation %.3f\n",
            sub$auc[sub$subgroup == "all"],
            sub$auc[sub$subgroup == "discovery only"],
            sub$auc[sub$subgroup == "validation only"]))
cat(sprintf("Youden threshold %.2f -> sens %.1f%%, spec %.1f%%, PPV %.1f%%, NPV %.1f%%\n",
            thr, 100 * st$sens, 100 * st$spec, 100 * st$ppv, 100 * st$npv))
cat("Note: PPV/NPV depend on prevalence (dMMR 14.5% in this cohort) and must be recomputed elsewhere.
")
