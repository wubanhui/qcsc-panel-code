## ===========================================================================
## singlecell_clinical/04b_GSE39582.R
## Bulk validation in GSE39582: prognosis (OS, RFS), MMR discrimination and
## probe-level comparisons.
## ===========================================================================
# ============================================================
# 07_external_validation_GSE39582.R
#
#
#
#
#   tables/external_GSE39582_scores.csv
#   tables/external_GSE39582_cox.csv
#   tables/external_GSE39582_survival.csv
#   tables/external_GSE39582_probe_coverage.csv
#   figures/Fig12_external_GSE39582_survival.png / .pdf
#   objects/external_GSE39582.rds
#
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

suppressPackageStartupMessages({
  library(survival)
  library(hgu133plus2.db)
  library(AnnotationDbi)
})

# ------------------------------------------------------------
# ------------------------------------------------------------
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
obj_dir   <- file.path(QCSC_PROJECT_DIR, "objects")
panel_dir <- file.path(QCSC_PROJECT_DIR, "intermediate", "two_cohort_panel")
for (d in c(tab_dir, fig_dir, obj_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

root <- ROOT_SC
ext_dir  <- file.path(root, "external", "GSE39582")
mat_file <- file.path(ext_dir, "GSE39582_series_matrix.txt.gz")
if (!file.exists(mat_file)) {
  stop("GSE39582 series matrix missing: ", mat_file,
       "
Download: https://ftp.ncbi.nlm.nih.gov/geo/series/GSE39nnn/GSE39582/matrix/
")
}

# ------------------------------------------------------------
# ------------------------------------------------------------
panel_file <- file.path(tab_dir, "final_panel_stable.csv")
if (!file.exists(panel_file)) stop("Cannot find final_panel_stable.csv; please run 03b first")
panel       <- read.csv(panel_file, check.names = FALSE, stringsAsFactors = FALSE)
panel_up    <- toupper(panel$gene[panel$direction == "UP"])
panel_down  <- toupper(panel$gene[panel$direction == "DOWN"])
panel_genes <- c(panel_up, panel_down)
cat(sprintf("Frozen panel: %d UP + %d DOWN = %d genes\n",
            length(panel_up), length(panel_down), length(panel_genes)))

full_up <- full_down <- NULL
data_file <- file.path(panel_dir, "panel_data.rds")
if (file.exists(data_file)) {
  d <- readRDS(data_file)
  full_up   <- toupper(d$up_use)
  full_down <- toupper(d$down_use)
  rm(d); gc()
  cat(sprintf("Full signature available: %d UP + %d DOWN\n",
              length(full_up), length(full_down)))
} else {
  warning("panel_data.rds not found: skipping the panel-versus-full comparison")
}
full_genes <- unique(c(full_up, full_down))
target_genes <- unique(c(panel_genes, full_genes))
cat("Genes to pull from the array:", length(target_genes), "\n")

# ------------------------------------------------------------
# ------------------------------------------------------------
message("Mapping probes via hgu133plus2.db ...")
annot <- suppressMessages(AnnotationDbi::select(
  hgu133plus2.db,
  keys    = keys(hgu133plus2.db),
  columns = "SYMBOL",
  keytype = "PROBEID"
))
annot <- annot[!is.na(annot$SYMBOL), ]
annot$SYMBOL <- toupper(annot$SYMBOL)
probe2gene <- setNames(annot$SYMBOL, annot$PROBEID)
target_probes <- names(probe2gene)[probe2gene %in% target_genes]
cat(sprintf("  probes in annotation: %d ; probes for target genes: %d\n",
            nrow(annot), length(target_probes)))
rm(annot); gc()

# ------------------------------------------------------------
# ------------------------------------------------------------
message("Reading series matrix (chunked, keep only target probes) ...")

con <- gzfile(mat_file, open = "rt")
hdr <- character()
repeat {
  ln <- readLines(con, n = 1L, warn = FALSE)
  if (!length(ln)) break
  hdr <- c(hdr, ln)
  if (startsWith(ln, "!series_matrix_table_begin")) break
  if (length(hdr) > 20000L) { close(con); stop("Unexpected series matrix header: table_begin not found") }
}
if (!startsWith(hdr[length(hdr)], "!series_matrix_table_begin")) {
  close(con); stop("!series_matrix_table_begin not found")
}

split_row <- function(x) gsub('^"|"$', "", strsplit(x, "\t", fixed = TRUE)[[1]])
srows <- hdr[grepl("^!Sample_", hdr)]
stags <- sub("\t.*$", "", srows)
smat  <- lapply(srows, split_row)
ncol_v <- vapply(smat, length, integer(1))
keep_row <- ncol_v == max(ncol_v)
srows <- srows[keep_row]; stags <- stags[keep_row]; smat <- smat[keep_row]
ch <- do.call(rbind, smat)[, -1, drop = FALSE]

clin <- data.frame(
  gsm   = ch[match("!Sample_geo_accession", stags), ],
  title = ch[match("!Sample_title", stags), ],
  stringsAsFactors = FALSE
)
ch_rows <- which(stags == "!Sample_characteristics_ch1")
if (!length(ch_rows)) { close(con); stop("!Sample_characteristics_ch1 not found in the series matrix") }
vals <- ch[ch_rows, , drop = FALSE]
pref <- sub(":.*$", "", vals[, 1])
for (k in seq_len(nrow(vals))) {
  clin[[pref[k]]] <- sub("^[^:]*:\\s*", "", vals[k, ])
}
cat(sprintf("  samples: %d ; clinical fields: %d\n", nrow(clin), ncol(clin) - 2))

mx_hdr <- readLines(con, n = 1L, warn = FALSE)
mx_ids <- gsub('"', "", strsplit(mx_hdr, "\t", fixed = TRUE)[[1]][-1])
cat(sprintf("  matrix columns: %d\n", length(mx_ids)))
if (!identical(mx_ids, clin$gsm)) {
  if (!setequal(mx_ids, clin$gsm)) { close(con); stop("Matrix column names do not match the clinical GSMs") }
  clin <- clin[match(mx_ids, clin$gsm), ]
  cat("  (sample order realigned to matrix columns)\n")
}

chunk_size <- 4000L
kept <- list()
n_read <- 0L
repeat {
  lines <- readLines(con, n = chunk_size, warn = FALSE)
  lines <- lines[nzchar(lines) & lines != "!series_matrix_table_end"]
  if (!length(lines)) break
  ids <- gsub('"', "", sub("\t.*$", "", lines))
  idx <- which(ids %in% target_probes)
  if (length(idx)) {
    sp <- strsplit(lines[idx], "\t", fixed = TRUE)
    for (k in seq_along(sp)) {
      v <- suppressWarnings(as.numeric(gsub('"', "", sp[[k]][-1])))
      if (length(v) == length(mx_ids)) kept[[ids[idx][k]]] <- v
    }
  }
  n_read <- n_read + length(lines)
  if (n_read %% 20000L < chunk_size) cat("   probes read:", n_read, "\n")
}
close(con)
cat(sprintf("  total probe rows read: %d ; target probes captured: %d\n",
            n_read, length(kept)))
if (!length(kept)) stop("No target probes captured; check the annotation or the matrix format")

expr <- do.call(rbind, kept)
rownames(expr) <- names(kept)
colnames(expr) <- mx_ids
rm(kept); gc()

rng <- range(expr, na.rm = TRUE)
cat(sprintf("  expression range: %.2f - %.2f\n", rng[1], rng[2]))
if (rng[2] > 50) {
  message("  values look linear -> applying log2(x + 1)")
  expr <- log2(expr + 1)
}

# ------------------------------------------------------------
# ------------------------------------------------------------
gene_of <- probe2gene[rownames(expr)]
ok <- !is.na(gene_of) & gene_of %in% target_genes
expr <- expr[ok, , drop = FALSE]
gene_of <- gene_of[ok]
expr_mean <- rowMeans(expr, na.rm = TRUE)
ord <- order(gene_of, -expr_mean)
expr <- expr[ord, , drop = FALSE]; gene_of <- gene_of[ord]
keep1 <- !duplicated(gene_of)
expr <- expr[keep1, , drop = FALSE]; gene_of <- gene_of[keep1]
rownames(expr) <- gene_of
cat(sprintf("  genes retained after probe collapsing: %d\n", nrow(expr)))

na_genes <- setdiff(target_genes, rownames(expr))
if (length(na_genes)) {
  cat(sprintf("  genes absent from this platform: %d\n", length(na_genes)))
}
miss_panel <- setdiff(panel_genes, rownames(expr))
if (length(miss_panel)) stop("Panel genes absent from the platform: ", paste(miss_panel, collapse = ", "))
cov_df <- data.frame(
  gene = c(panel_genes, setdiff(full_genes, panel_genes)),
  in_panel = c(rep(TRUE, length(panel_genes)),
               rep(FALSE, length(setdiff(full_genes, panel_genes)))),
  on_platform = c(panel_genes, setdiff(full_genes, panel_genes)) %in% rownames(expr),
  stringsAsFactors = FALSE
)
write.csv(cov_df, file.path(tab_dir, "external_GSE39582_probe_coverage.csv"), row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
is_tumour <- !is.na(clin[["dataset"]]) & clin[["dataset"]] != "Non Tumoral"
cat(sprintf("  tumour samples: %d ; non-tumour: %d\n",
            sum(is_tumour), sum(!is_tumour)))

zmat <- t(scale(t(expr[, is_tumour, drop = FALSE])))
mu   <- rowMeans(expr[, is_tumour, drop = FALSE], na.rm = TRUE)
sdv  <- apply(expr[, is_tumour, drop = FALSE], 1, sd, na.rm = TRUE)
sdv[!is.finite(sdv) | sdv == 0] <- 1
z_all <- (expr - mu) / sdv
rm(zmat); gc()

score_from <- function(genes) {
  g  <- intersect(genes, rownames(z_all))
  if (!length(g)) return(rep(NA_real_, ncol(z_all)))
  colMeans(z_all[g, , drop = FALSE], na.rm = TRUE)
}
panel_score <- score_from(panel_up) - score_from(panel_down)
full_score  <- if (!is.null(full_up)) score_from(full_up) - score_from(full_down) else NULL

# ------------------------------------------------------------
# ------------------------------------------------------------
num <- function(x) suppressWarnings(as.numeric(x))
chr <- function(x) { x <- as.character(x); x[is.na(x) | x %in% c("", "N/A", "NA")] <- NA; x }

dat <- data.frame(
  gsm        = clin$gsm,
  title      = clin$title,
  cohort     = clin[["dataset"]],
  panel      = as.numeric(panel_score),
  full       = if (is.null(full_score)) NA_real_ else as.numeric(full_score),
  os_time    = num(clin[["os.delay (months)"]]),
  os_event   = num(clin[["os.event"]]),
  rfs_time   = num(clin[["rfs.delay"]]),
  rfs_event  = num(clin[["rfs.event"]]),
  age        = num(clin[["age.at.diagnosis (year)"]]),
  sex        = chr(clin[["Sex"]]),
  stage      = num(clin[["tnm.stage"]]),
  chemo      = chr(clin[["chemotherapy.adjuvant"]]),
  mmr        = chr(clin[["mmr.status"]]),
  location   = chr(clin[["tumor.location"]]),
  stringsAsFactors = FALSE
)
dat$sex   <- factor(dat$sex, levels = c("Female", "Male"))
dat$chemo <- factor(dat$chemo, levels = c("N", "Y"))
dat$mmr   <- factor(dat$mmr, levels = c("pMMR", "dMMR"))
dat$stage_f <- factor(ifelse(is.na(dat$stage), NA,
                             ifelse(dat$stage <= 1, "0-1", as.character(dat$stage))),
                      levels = c("0-1", "2", "3", "4"))
tz <- function(x) {
  mx <- mean(x[is_tumour], na.rm = TRUE); sx <- sd(x[is_tumour], na.rm = TRUE)
  if (!is.finite(sx) || sx == 0) return(rep(NA_real_, length(x)))
  (x - mx) / sx
}
dat$panel_z <- tz(dat$panel)
dat$full_z  <- if (all(is.na(dat$full))) rep(NA_real_, nrow(dat)) else tz(dat$full)

write.csv(dat, file.path(tab_dir, "external_GSE39582_scores.csv"), row.names = FALSE)

nt <- dat[dat$cohort == "Non Tumoral", ]
tt <- dat[dat$cohort != "Non Tumoral", ]
cat(sprintf("\nPanel score  tumour mean = %.3f ; normal mucosa mean = %.3f (n=%d)\n",
            mean(tt$panel, na.rm = TRUE), mean(nt$panel, na.rm = TRUE), nrow(nt)))
if (!all(is.na(dat$full))) {
  cat(sprintf("Full  score  tumour mean = %.3f ; normal mucosa mean = %.3f\n",
              mean(tt$full, na.rm = TRUE), mean(nt$full, na.rm = TRUE)))
}

# ------------------------------------------------------------
# ------------------------------------------------------------
fmt_p <- function(p) {
  if (is.na(p)) return("NA")
  if (p < 0.001) return("< 0.001")
  formatC(p, format = "f", digits = 3)
}

ipcw_auc <- function(time, event, marker, t0) {
  ok <- !is.na(time) & !is.na(event) & !is.na(marker)
  time <- time[ok]; event <- event[ok]; marker <- marker[ok]
  if (!length(time)) return(NA_real_)
  km <- survfit(Surv(time, 1 - event) ~ 1)
  gfun <- function(t) {
    s <- summary(km, times = t, extend = TRUE)$surv
    s[!is.finite(s) | s <= 0] <- NA_real_
    s
  }
  case <- time <= t0 & event == 1
  ctrl <- time > t0
  if (sum(case) < 5L || sum(ctrl) < 5L) return(NA_real_)
  wc <- 1 / gfun(time[case])
  wk <- 1 / gfun(rep(t0, sum(ctrl)))
  if (anyNA(wc) || anyNA(wk)) return(NA_real_)
  cmp <- outer(marker[case], marker[ctrl], function(a, b) (a > b) + 0.5 * (a == b))
  as.numeric(wc %*% (cmp %*% wk)) / (sum(wc) * sum(wk))
}

cox_row <- function(fit, endpoint, model, note = "") {
  s <- summary(fit)
  data.frame(
    endpoint = endpoint, model = model,
    n = s$n, events = s$nevent,
    HR = s$conf.int[1, "exp(coef)"],
    CI_low = s$conf.int[1, "lower .95"],
    CI_high = s$conf.int[1, "upper .95"],
    P = s$coefficients[1, "Pr(>|z|)"],
    note = note,
    stringsAsFactors = FALSE
  )
}

## High/low split point: median of the panel score over all tumours of the cohort.
panel_median_all <- median(tt$panel, na.rm = TRUE)
cat(sprintf("Panel median across all tumours: %.4f (n = %d)\n", panel_median_all, nrow(tt)))

run_endpoint <- function(dd, tcol, ecol, endpoint, ylab, fig_label) {
  dd <- dd[!is.na(dd[[tcol]]) & !is.na(dd[[ecol]]) & dd[[tcol]] >= 0, ]
  dd$T <- dd[[tcol]]; dd$E <- dd[[ecol]]
  cat(sprintf("\n===== %s =====\n", endpoint))
  cat(sprintf("  n = %d ; events = %d ; median follow-up (censored) = %.0f months\n",
              nrow(dd), sum(dd$E == 1),
              median(dd$T[dd$E == 0], na.rm = TRUE)))

  ## Split at the median of the panel score across ALL tumours of the cohort, not
  ## within the endpoint-specific subset. This is the grouping used for the
  ## Kaplan-Meier curves of Fig. 4, so the log-rank P reported in the text and the
  ## one drawn on the figure are computed on the same split.
  dd$group <- factor(ifelse(dd$panel >= panel_median_all, "high", "low"),
                     levels = c("low", "high"))

  # --- Cox ---
  rows <- list()
  rows[[1]] <- cox_row(coxph(Surv(T, E) ~ panel_z, data = dd), endpoint,
                       "panel continuous (per SD), univariable")
  adj <- Surv(T, E) ~ panel_z + age + sex + stage_f + chemo + mmr
  f_adj <- coxph(adj, data = dd)
  rows[[2]] <- cox_row(f_adj, endpoint, "panel continuous (per SD), adjusted",
                       "adjusted for age + sex + stage + chemo + MMR")
  rows[[3]] <- cox_row(coxph(Surv(T, E) ~ group, data = dd), endpoint,
                       "panel high vs low (median split)")
  if (!all(is.na(dd$full_z))) {
    rows[[4]] <- cox_row(coxph(Surv(T, E) ~ full_z, data = dd), endpoint,
                         "full 822-gene signature (per SD), univariable",
                         "comparator: panel vs whole signature")
  }
  cox_df <- do.call(rbind, rows)

  # --- KM / log-rank ---
  sd <- survdiff(Surv(T, E) ~ group, data = dd)
  lr_p <- pchisq(sd$chisq, df = length(sd$n) - 1, lower.tail = FALSE)
  sf <- survfit(Surv(T, E) ~ group, data = dd)
  med <- summary(sf)$table[, "median"]
  names(med) <- sub("^.*=", "", names(med))   # "group=low" -> "low"
  cidx <- concordance(Surv(T, E) ~ panel_z, data = dd, reverse = TRUE)$concordance
  auc36 <- ipcw_auc(dd$T, dd$E, dd$panel, 36)
  auc60 <- ipcw_auc(dd$T, dd$E, dd$panel, 60)
  hr_hi <- exp(coef(coxph(Surv(T, E) ~ group, data = dd)))[["grouphigh"]]

  cat(sprintf("  log-rank P = %s ; HR(high vs low) = %.2f\n", fmt_p(lr_p), hr_hi))
  cat(sprintf("  C-index = %.3f ; IPCW AUC 3y = %.3f ; 5y = %.3f\n",
              cidx, auc36, auc60))
  cat(sprintf("  adjusted HR per SD = %.2f (%.2f-%.2f), P = %s ; N = %d, events = %d\n",
              cox_df$HR[2], cox_df$CI_low[2], cox_df$CI_high[2],
              fmt_p(cox_df$P[2]), cox_df$n[2], cox_df$events[2]))

  surv_df <- data.frame(
    endpoint = endpoint,
    metric = c("n", "events", "logrank_P", "HR_high_vs_low",
               "median_months_low", "median_months_high",
               "c_index", "ipcw_auc_3y", "ipcw_auc_5y"),
    value = c(nrow(dd), sum(dd$E == 1), lr_p, hr_hi,
              med[["low"]], med[["high"]], cidx, auc36, auc60),
    stringsAsFactors = FALSE
  )

  op <- par(no.readonly = TRUE)
  par(mar = c(4.6, 4.6, 3.4, 1.2), mgp = c(2.6, 0.7, 0))
  cols <- c("#2C7FB8", "#D95F0E")
  plot(sf, col = cols, lwd = 2.2, mark.time = TRUE, xaxs = "i", yaxs = "i",
       bty = "l", xlab = "Time (months)", ylab = ylab,
       main = sprintf("%s (n = %d)\nlog-rank P = %s", fig_label, nrow(dd), fmt_p(lr_p)),
       cex.main = 1.05, las = 1)
  abline(h = 0.5, lty = 3, col = "grey55")
  abline(v = 60, lty = 3, col = "grey55")
  legend("topright", bty = "n", lwd = 2.4, col = cols,
         legend = c(sprintf("qCSC panel low (n = %d)", sum(dd$group == "low")),
                    sprintf("qCSC panel high (n = %d)", sum(dd$group == "high"))))
  legend("bottomleft", bty = "n", cex = 0.85,
         legend = sprintf("adjusted HR/SD = %.2f (%.2f-%.2f), P = %s",
                          cox_df$HR[2], cox_df$CI_low[2], cox_df$CI_high[2],
                          fmt_p(cox_df$P[2])))
  par(op)

  list(cox = cox_df, surv = surv_df, data = dd, lr_p = lr_p)
}

# ------------------------------------------------------------
# ------------------------------------------------------------
res_os  <- run_endpoint(tt, "os_time",  "os_event",  "OS",  "Overall survival",  "Overall survival")
res_rfs <- run_endpoint(tt, "rfs_time", "rfs_event", "RFS", "Relapse-free survival", "Relapse-free survival")

cox_all  <- rbind(res_os$cox, res_rfs$cox)
surv_all <- rbind(res_os$surv, res_rfs$surv)

# ------------------------------------------------------------
# ------------------------------------------------------------
strat_rows <- list()
for (cv in c("discovery", "validation")) {
  dd <- tt[tt$cohort == cv, ]
  for (ep in c("os", "rfs")) {
    tc <- paste0(ep, "_time"); ec <- paste0(ep, "_event")
    dd2 <- dd[!is.na(dd[[tc]]) & !is.na(dd[[ec]]), ]
    if (nrow(dd2) < 40 || sum(dd2[[ec]] == 1) < 15) next
    fit <- coxph(Surv(dd2[[tc]], dd2[[ec]]) ~ panel_z, data = dd2)
    r <- cox_row(fit, toupper(ep), sprintf("univariable, %s only", cv))
    strat_rows[[length(strat_rows) + 1L]] <- r
  }
}
if (length(strat_rows)) cox_all <- rbind(cox_all, do.call(rbind, strat_rows))

int_p <- NA_real_
dd_i <- tt[!is.na(tt$os_time) & !is.na(tt$os_event) & tt$cohort %in% c("discovery", "validation"), ]
if (nrow(dd_i) > 100) {
  fi <- coxph(Surv(os_time, os_event) ~ panel_z * cohort, data = dd_i)
  int_p <- summary(fi)$coefficients["panel_z:cohortvalidation", "Pr(>|z|)"]
  cat(sprintf("\npanel x cohort interaction (OS) P = %s\n", fmt_p(int_p)))
}

dd_c <- tt[!is.na(tt$os_time) & !is.na(tt$chemo), ]
chemo_rows <- list()
for (lv in c("N", "Y")) {
  dd2 <- dd_c[dd_c$chemo == lv, ]
  if (nrow(dd2) < 40 || sum(dd2$os_event == 1, na.rm = TRUE) < 15) next
  fit <- coxph(Surv(os_time, os_event) ~ panel_z, data = dd2)
  chemo_rows[[length(chemo_rows) + 1L]] <- cox_row(
    fit, "OS", sprintf("univariable, chemo = %s only", lv),
    "adjuvant chemotherapy subgroup")
}
if (length(chemo_rows)) cox_all <- rbind(cox_all, do.call(rbind, chemo_rows))

# ------------------------------------------------------------
# ------------------------------------------------------------
ddos <- tt[!is.na(tt$os_time) & !is.na(tt$os_event), ]
ddos$stage_num <- ddos$stage
pc_rows <- list()
pc_spec <- list(
  list(v = "stage_num", lab = "stage (per unit, 0-4)",     ref = ""),
  list(v = "age",       lab = "age (per year)",            ref = ""),
  list(v = "sex",       lab = "sex (male vs female)",      ref = "Female"),
  list(v = "chemo",     lab = "adjuvant chemo (Y vs N)",   ref = "N"),
  list(v = "mmr",       lab = "MMR (dMMR vs pMMR)",        ref = "pMMR")
)
for (sp in pc_spec) {
  if (all(is.na(ddos[[sp$v]]))) next
  fit <- try(coxph(as.formula(sprintf("Surv(os_time, os_event) ~ %s", sp$v)),
                   data = ddos), silent = TRUE)
  if (inherits(fit, "try-error")) next
  pc_rows[[length(pc_rows) + 1L]] <- cox_row(
    fit, "OS", paste0("positive control: ", sp$lab),
    paste0("known prognostic factor; n = ", fit$n, ", events = ", fit$nevent)
  )
}
if (length(pc_rows)) cox_all <- rbind(cox_all, do.call(rbind, pc_rows))

r_pf <- if (!all(is.na(ddos$full))) cor(ddos$panel, ddos$full, use = "complete.obs") else NA_real_
cat(sprintf("\npanel vs full signature, sample-level r = %.3f\n", r_pf))

rho_stage <- cor(ddos$panel, ddos$stage, method = "spearman", use = "complete.obs")
cat(sprintf("panel vs stage (Spearman) rho = %.3f\n", rho_stage))
if (sum(!is.na(ddos$mmr)) > 20) {
  cat(sprintf("panel mean: dMMR %.3f vs pMMR %.3f\n",
              mean(ddos$panel[ddos$mmr == "dMMR"], na.rm = TRUE),
              mean(ddos$panel[ddos$mmr == "pMMR"], na.rm = TRUE)))
}
surv_all <- rbind(surv_all, data.frame(
  endpoint = c("OS", "OS"),
  metric   = c("panel_full_r", "panel_stage_spearman_rho"),
  value    = c(r_pf, rho_stage),
  stringsAsFactors = FALSE
))

# ------------------------------------------------------------
# ------------------------------------------------------------
cox_all$HR     <- round(cox_all$HR, 3)
cox_all$CI_low <- round(cox_all$CI_low, 3)
cox_all$CI_high<- round(cox_all$CI_high, 3)
cox_all$P      <- signif(cox_all$P, 3)
write.csv(cox_all, file.path(tab_dir, "external_GSE39582_cox.csv"), row.names = FALSE)

surv_all$value <- signif(surv_all$value, 4)
write.csv(surv_all, file.path(tab_dir, "external_GSE39582_survival.csv"), row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
draw <- function() {
  par(mfrow = c(1, 2), mar = c(4.6, 4.6, 3.4, 1.2), mgp = c(2.6, 0.7, 0))
  cols <- c("#2C7FB8", "#D95F0E")
  for (obj in list(res_os, res_rfs)) {
    dd <- obj$data
    sf <- survfit(Surv(T, E) ~ group, data = dd)
    plot(sf, col = cols, lwd = 2.2, mark.time = TRUE, xaxs = "i", yaxs = "i",
         bty = "l", xlab = "Time (months)",
         ylab = if (identical(obj, res_os)) "Overall survival" else "Relapse-free survival",
         main = sprintf("%s\nlog-rank P = %s", obj$surv$endpoint[1], fmt_p(obj$lr_p)),
         cex.main = 1.05, las = 1)
    abline(h = 0.5, lty = 3, col = "grey55"); abline(v = 60, lty = 3, col = "grey55")
    legend("topright", bty = "n", lwd = 2.4, col = cols, cex = 0.9,
           legend = c(sprintf("panel low (n = %d)", sum(dd$group == "low")),
                      sprintf("panel high (n = %d)", sum(dd$group == "high"))))
    legend("bottomleft", bty = "n", cex = 0.8,
           legend = sprintf("adj. HR/SD = %.2f (%.2f-%.2f), P = %s",
                            obj$cox$HR[2], obj$cox$CI_low[2], obj$cox$CI_high[2],
                            fmt_p(obj$cox$P[2])))
  }
}
png(file.path(fig_dir, "Fig12_external_GSE39582_survival.png"),
    width = 3000, height = 1400, res = 300)
draw(); dev.off()
pdf(file.path(fig_dir, "Fig12_external_GSE39582_survival.pdf"), width = 10, height = 4.7)
draw(); dev.off()

# ------------------------------------------------------------
# ------------------------------------------------------------
add_rows <- function(section, metric, value, note = "") {
  data.frame(section = section, metric = metric, value = value, note = note,
             stringsAsFactors = FALSE)
}
hs <- function(ep) surv_all[surv_all$endpoint == ep, ]
os_row  <- function(m) hs("OS")$value[hs("OS")$metric == m]
rfs_row <- function(m) hs("RFS")$value[hs("RFS")$metric == m]
cox_get <- function(ep, model, col) {
  v <- cox_all[[col]][cox_all$endpoint == ep & cox_all$model == model]
  if (!length(v)) NA_real_ else v[1]
}

new_rows <- rbind(
  add_rows("external_GSE39582", "n_tumour", nrow(tt), "GPL570 bulk; 19 normal mucosa excluded"),
  add_rows("external_GSE39582", "OS_n", os_row("n"), "usable OS follow-up"),
  add_rows("external_GSE39582", "OS_events", os_row("events"), ""),
  add_rows("external_GSE39582", "OS_HR_per_SD_univariable",
           cox_get("OS", "panel continuous (per SD), univariable", "HR"),
           sprintf("95%% CI %.2f-%.2f, P = %s",
                   cox_get("OS", "panel continuous (per SD), univariable", "CI_low"),
                   cox_get("OS", "panel continuous (per SD), univariable", "CI_high"),
                   fmt_p(cox_get("OS", "panel continuous (per SD), univariable", "P")))),
  add_rows("external_GSE39582", "OS_HR_per_SD_adjusted",
           cox_get("OS", "panel continuous (per SD), adjusted", "HR"),
           sprintf("95%% CI %.2f-%.2f, P = %s; adj age+sex+stage+chemo+MMR",
                   cox_get("OS", "panel continuous (per SD), adjusted", "CI_low"),
                   cox_get("OS", "panel continuous (per SD), adjusted", "CI_high"),
                   fmt_p(cox_get("OS", "panel continuous (per SD), adjusted", "P")))),
  add_rows("external_GSE39582", "OS_logrank_P_median_split", os_row("logrank_P"), ""),
  add_rows("external_GSE39582", "OS_c_index", os_row("c_index"), "Harrell"),
  add_rows("external_GSE39582", "OS_ipcw_auc_5y", os_row("ipcw_auc_5y"), "Uno IPCW"),
  add_rows("external_GSE39582", "RFS_n", rfs_row("n"), "usable RFS follow-up"),
  add_rows("external_GSE39582", "RFS_events", rfs_row("events"), ""),
  add_rows("external_GSE39582", "RFS_HR_per_SD_univariable",
           cox_get("RFS", "panel continuous (per SD), univariable", "HR"),
           sprintf("95%% CI %.2f-%.2f, P = %s",
                   cox_get("RFS", "panel continuous (per SD), univariable", "CI_low"),
                   cox_get("RFS", "panel continuous (per SD), univariable", "CI_high"),
                   fmt_p(cox_get("RFS", "panel continuous (per SD), univariable", "P")))),
  add_rows("external_GSE39582", "RFS_HR_per_SD_adjusted",
           cox_get("RFS", "panel continuous (per SD), adjusted", "HR"),
           sprintf("95%% CI %.2f-%.2f, P = %s",
                   cox_get("RFS", "panel continuous (per SD), adjusted", "CI_low"),
                   cox_get("RFS", "panel continuous (per SD), adjusted", "CI_high"),
                   fmt_p(cox_get("RFS", "panel continuous (per SD), adjusted", "P")))),
  add_rows("external_GSE39582", "RFS_logrank_P_median_split", rfs_row("logrank_P"), ""),
  add_rows("external_GSE39582", "normal_vs_tumour_panel_mean",
           sprintf("%.3f vs %.3f", mean(nt$panel, na.rm = TRUE), mean(tt$panel, na.rm = TRUE)),
           "normal mucosa scores higher, same direction as scRNA cohorts"),
  add_rows("external_GSE39582", "interaction_panel_x_cohort_OS", int_p,
           "discovery vs validation")
)
summ_file <- file.path(tab_dir, "FINAL_RESULTS_SUMMARY.csv")
if (file.exists(summ_file)) {
  old <- read.csv(summ_file, check.names = FALSE, stringsAsFactors = FALSE)
  old <- old[old$section != "external_GSE39582", ]
  old$value <- as.character(old$value)
  new_rows$value <- as.character(new_rows$value)
  all_s <- rbind(old[, c("section", "metric", "value", "note")],
                 new_rows[, c("section", "metric", "value", "note")])
} else {
  all_s <- new_rows
}
write.csv(all_s, summ_file, row.names = FALSE)

saveRDS(list(dat = dat, cox = cox_all, surv = surv_all,
             panel_up = panel_up, panel_down = panel_down,
             coverage = cov_df,
             z_all = z_all,
             is_tumour = is_tumour),
        file.path(obj_dir, "external_GSE39582.rds"))

# ------------------------------------------------------------
# ------------------------------------------------------------
cat("\n================ GSE39582 external validation ================\n")
cat(sprintf("Tumours: %d (OS n = %d / events = %d ; RFS n = %d / events = %d)\n",
            nrow(tt), os_row("n"), os_row("events"), rfs_row("n"), rfs_row("events")))
cat(sprintf("OS  HR per SD: %.2f (%.2f-%.2f), P = %s | adjusted %.2f, P = %s\n",
            cox_get("OS", "panel continuous (per SD), univariable", "HR"),
            cox_get("OS", "panel continuous (per SD), univariable", "CI_low"),
            cox_get("OS", "panel continuous (per SD), univariable", "CI_high"),
            fmt_p(cox_get("OS", "panel continuous (per SD), univariable", "P")),
            cox_get("OS", "panel continuous (per SD), adjusted", "HR"),
            fmt_p(cox_get("OS", "panel continuous (per SD), adjusted", "P"))))
cat(sprintf("RFS HR per SD: %.2f (%.2f-%.2f), P = %s | adjusted %.2f, P = %s\n",
            cox_get("RFS", "panel continuous (per SD), univariable", "HR"),
            cox_get("RFS", "panel continuous (per SD), univariable", "CI_low"),
            cox_get("RFS", "panel continuous (per SD), univariable", "CI_high"),
            fmt_p(cox_get("RFS", "panel continuous (per SD), univariable", "P")),
            cox_get("RFS", "panel continuous (per SD), adjusted", "HR"),
            fmt_p(cox_get("RFS", "panel continuous (per SD), adjusted", "P"))))
cat("
Pre-specified interpretation criteria (fixed in advance to avoid post-hoc model selection):
")
cat("  adjusted HR > 1, P < 0.05 and CI excluding 1  => 'independently prognostic' may be stated
")
cat("  otherwise state 'no independent prognostic association' and report the C-index / AUC as they are
")
cat("
Table: ", file.path(tab_dir, "external_GSE39582_cox.csv"), "\n")
cat("Figure: ", file.path(fig_dir, "Fig12_external_GSE39582_survival.png"), "\n")
