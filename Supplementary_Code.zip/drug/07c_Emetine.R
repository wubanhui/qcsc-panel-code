## ===========================================================================
## drug/07c_Emetine.R
## Emetine (GSE5486): read the raw CEL files, run a joint RMA normalisation and
## score the panel in the two available cell lines.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
OUT_DIR <- file.path(QCSC_PROJECT_DIR, "output", "drug_Emetine")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)
############################################################
# GSE5486 — Emetine 20-gene validation using raw CEL + RMA
# Windows / RStudio copy-paste script
#
# Main workflow:
# 1) Download GSE5486 raw CEL archive from GEO if CEL files are absent
# 2) Select one CEL file per GSM (prefer uncompressed .CEL over .CEL.gz)
# 3) Read all available GPL570 CEL files
# 4) Perform joint RMA normalization using affy::rma()
# 5) Use the same 20-gene panel and score logic as cx5461.R
#
# Score = mean(UP) - mean(DOWN)
# Delta = Emetine - Control
# Delta > 0 supports movement toward the panel-defined
# differentiation-associated transcriptional state.
#
# UP direction: gene expression change > 0
# DOWN direction: gene expression change < 0
# Full module concordance: UP_change > 0 AND DOWN_change < 0
#
# Important:
# - GSE5486 has one Control and one Emetine sample per cell line.
# - No biological-replicate statistical test or P value is appropriate.
# - This evaluates transcriptional-state direction, not direct qCSC
#   depletion or functional differentiation.
############################################################

############################
# 1. Paths and output folder
############################
data_dir <- DATA_ROOT
signature_file <- file.path(data_dir, "input2.tsv")

if (!file.exists(signature_file)) {
  stop("20-gene signature file not found: ", signature_file,
       "
Please put the same input2.tsv used by 07a_CX5461.R in the data directory.")
}

raw_dir <- file.path(data_dir, "GSE5486_RAW_CEL")
dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
out_root <- file.path(QCSC_PROJECT_DIR, "output", paste0("GSE5486_Emetine_RMA_20gene_", timestamp))
output_dir <- file.path(out_root, "results")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cat("Data directory :", data_dir, "\n")
cat("Signature file :", signature_file, "\n")
cat("Raw CEL folder :", raw_dir, "\n")
cat("Output folder  :", output_dir, "\n\n")

############################
# 2. Packages
############################
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager", repos = "https://cloud.r-project.org")
}

cran_packages <- c("dplyr")
for (pkg in cran_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cloud.r-project.org")
  }
}

bioc_packages <- c("affy", "AnnotationDbi", "hgu133plus2.db", "Biobase")
for (pkg in bioc_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    BiocManager::install(pkg, ask = FALSE, update = FALSE)
  }
}

suppressPackageStartupMessages({
  library(affy)
  library(AnnotationDbi)
  library(hgu133plus2.db)
  library(dplyr)
})

############################
# 3. Target sample metadata
############################
sample_info <- data.frame(
  GSM = c("GSM126419", "GSM126420", "GSM126423", "GSM126424"),
  CellLine = c("LS180", "LS180", "SW480", "SW480"),
  Treatment = c("Control", "Emetine", "Control", "Emetine"),
  stringsAsFactors = FALSE
)

all_gsm <- c(
  "GSM126417", "GSM126418", "GSM126419", "GSM126420",
  "GSM126421", "GSM126422", "GSM126423", "GSM126424"
)

cat("Target comparisons:\n")
print(sample_info)
cat("
One sample per group per cell line; no replicate-based P value is computed.
")

############################
# 4. Find or download raw CEL archive
############################
cel_candidates <- list.files(
  raw_dir,
  pattern = "\\.(cel|CEL)(\\.gz)?$",
  recursive = TRUE,
  full.names = TRUE,
  ignore.case = TRUE
)

if (length(cel_candidates) == 0) {
  raw_tar <- file.path(raw_dir, "GSE5486_RAW.tar")
  raw_url <- "https://www.ncbi.nlm.nih.gov/geo/download/?acc=GSE5486&format=file"
  
  cat("
No CEL file found; attempting to download the raw GEO archive:
", raw_url, "\n")
  download_ok <- FALSE
  try({
    utils::download.file(
      url = raw_url,
      destfile = raw_tar,
      mode = "wb",
      method = "libcurl",
      quiet = FALSE
    )
    download_ok <- file.exists(raw_tar) && file.info(raw_tar)$size > 100000
  }, silent = TRUE)
  
  if (!download_ok) {
    stop(
      "Automatic download of the raw GEO archive failed.
",
      "Open this address in a browser: ", raw_url, "\n",
      "Then put GSE5486_RAW.tar in: ", raw_dir,
      "
and re-run the script."
    )
  }
  
  cat("
Download complete; extracting the CEL archive...
")
  untar(raw_tar, exdir = raw_dir)
  
  gz_cel <- list.files(
    raw_dir,
    pattern = "\\.cel\\.gz$",
    recursive = TRUE,
    full.names = TRUE,
    ignore.case = TRUE
  )
  
  if (length(gz_cel) > 0) {
    if (!requireNamespace("R.utils", quietly = TRUE)) {
      install.packages("R.utils", repos = "https://cloud.r-project.org")
    }
    for (f in gz_cel) {
      out_f <- sub("\\.gz$", "", f, ignore.case = TRUE)
      if (!file.exists(out_f)) {
        R.utils::gunzip(
          f,
          destname = out_f,
          overwrite = FALSE,
          remove = FALSE
        )
      }
    }
  }
}

############################
# 5. Identify GSM and select one file per GSM
############################
all_cel_files <- list.files(
  raw_dir,
  pattern = "\\.(cel|CEL)(\\.gz)?$",
  recursive = TRUE,
  full.names = TRUE,
  ignore.case = TRUE
)

if (length(all_cel_files) == 0) {
  stop(
    "In ", raw_dir, " no CEL or CEL.gz file was found.
",
    "Please check that the raw GEO archive was downloaded and extracted."
  )
}

get_gsm_id <- function(path) {
  filename <- basename(path)
  hits <- all_gsm[
    vapply(all_gsm, function(g) grepl(g, filename, fixed = TRUE), logical(1))
  ]
  if (length(hits) == 0) NA_character_ else hits[1]
}

file_info <- data.frame(
  path = all_cel_files,
  GSM = vapply(all_cel_files, get_gsm_id, character(1)),
  stringsAsFactors = FALSE
)

file_info <- file_info[!is.na(file_info$GSM), , drop = FALSE]

if (nrow(file_info) == 0) {
  stop(
    "CEL files found, but none is named GSM126417-GSM126424.
",
    "Please check the directory: ", raw_dir
  )
}

file_info$is_plain_cel <- grepl(
  "\\.CEL$",
  basename(file_info$path),
  ignore.case = TRUE
)

file_info <- file_info[
  order(file_info$GSM, !file_info$is_plain_cel, file_info$path),
  ,
  drop = FALSE
]

selected_files <- file_info[
  !duplicated(file_info$GSM),
  ,
  drop = FALSE
]

if (anyDuplicated(selected_files$GSM)) {
  stop("Internal check failed: duplicated GSMs remain after de-duplication.")
}

cel_map <- data.frame(
  GSM = selected_files$GSM,
  CEL_file = normalizePath(
    selected_files$path,
    winslash = "/",
    mustWork = TRUE
  ),
  stringsAsFactors = FALSE
)

cat("\nDetected CEL files (one file per GSM; .CEL preferred):\n")
print(cel_map, row.names = FALSE)
cat("Unique GSM samples: ", nrow(cel_map), "\n")

missing_target <- setdiff(sample_info$GSM, cel_map$GSM)
if (length(missing_target) > 0) {
  stop("CEL file missing for target sample(s): ", paste(missing_target, collapse = ", "))
}

############################
# 6. Read CEL files and perform RMA
############################
cat("\nReading CEL files with affy::ReadAffy()...\n")
abatch <- affy::ReadAffy(filenames = cel_map$CEL_file)
sampleNames(abatch) <- cel_map$GSM

cat("\nPerforming joint RMA normalization with affy::rma()...\n")
eset <- affy::rma(abatch)
expr_rma <- Biobase::exprs(eset)

if (is.null(rownames(expr_rma)) || is.null(colnames(expr_rma))) {
  stop("The RMA expression matrix has no probe or sample names.")
}
if (!all(sample_info$GSM %in% colnames(expr_rma))) {
  stop("Not all target GSM samples were found in the RMA result. Current sample names: ",
       paste(colnames(expr_rma), collapse = ", "))
}

cat("RMA matrix dimensions:", nrow(expr_rma), "probes x", ncol(expr_rma), "samples\n")
cat("RMA expression quantiles:\n")
print(quantile(as.numeric(expr_rma), c(0, .01, .25, .5, .75, .99, 1), na.rm = TRUE))

write.csv(
  data.frame(ProbeID = rownames(expr_rma), expr_rma, check.names = FALSE),
  file = file.path(output_dir, "GSE5486_RMA_probe_expression_all_CEL.csv"),
  row.names = FALSE
)
saveRDS(eset, file = file.path(output_dir, "GSE5486_RMA_expression_set.rds"))

############################
# 7. Probe annotation and gene-level expression
############################
cat("\nAnnotating GPL570 probes using hgu133plus2.db...\n")
probe_annotation <- AnnotationDbi::select(
  hgu133plus2.db,
  keys = rownames(expr_rma),
  columns = c("SYMBOL"),
  keytype = "PROBEID"
)

probe_annotation <- probe_annotation %>%
  filter(!is.na(SYMBOL), SYMBOL != "") %>%
  distinct(PROBEID, SYMBOL) %>%
  group_by(PROBEID) %>%
  slice(1) %>%
  ungroup()

probe_annotation$SYMBOL <- toupper(trimws(as.character(probe_annotation$SYMBOL)))

common_probes <- intersect(rownames(expr_rma), probe_annotation$PROBEID)
if (length(common_probes) == 0) {
  stop("No probe matched the hgu133plus2.db annotation.")
}

expr_matrix2 <- expr_rma[common_probes, , drop = FALSE]
symbol_by_probe <- probe_annotation$SYMBOL[
  match(common_probes, probe_annotation$PROBEID)
]
valid <- !is.na(symbol_by_probe) & symbol_by_probe != ""
expr_matrix2 <- expr_matrix2[valid, , drop = FALSE]
symbol_by_probe <- symbol_by_probe[valid]

expr_gene_matrix <- rowsum(expr_matrix2, group = symbol_by_probe, reorder = FALSE)
probe_count <- table(symbol_by_probe)
expr_gene_matrix <- sweep(
  expr_gene_matrix, 1,
  as.numeric(probe_count[rownames(expr_gene_matrix)]), "/"
)
expr_gene_matrix <- expr_gene_matrix[
  !is.na(rownames(expr_gene_matrix)) & rownames(expr_gene_matrix) != "",
  ,
  drop = FALSE
]

cat("Gene-level matrix:", nrow(expr_gene_matrix), "genes x",
    ncol(expr_gene_matrix), "samples\n")

############################
# 8. Read 20-gene signature from input2.tsv
############################
sig <- read.delim(signature_file, stringsAsFactors = FALSE, check.names = FALSE)

if (all(c("Name", "Input Type", "Type") %in% colnames(sig))) {
  sig$Name <- toupper(trimws(as.character(sig$Name)))
  UP_genes <- sig$Name[
    sig[["Input Type"]] == "up_entities" & sig[["Type"]] == "valid"
  ]
  DOWN_genes <- sig$Name[
    sig[["Input Type"]] == "down_entities" & sig[["Type"]] == "valid"
  ]
} else if (all(c("Gene", "Direction") %in% colnames(sig))) {
  sig$Gene <- toupper(trimws(as.character(sig$Gene)))
  UP_genes <- sig$Gene[
    toupper(trimws(as.character(sig$Direction))) == "UP"
  ]
  DOWN_genes <- sig$Gene[
    toupper(trimws(as.character(sig$Direction))) == "DOWN"
  ]
} else {
  stop("Unrecognised input2.tsv format; Name/Input Type/Type or Gene/Direction columns are required.")
}

UP_genes <- unique(UP_genes[!is.na(UP_genes) & UP_genes != ""])
DOWN_genes <- unique(DOWN_genes[!is.na(DOWN_genes) & DOWN_genes != ""])

overlap_signature <- intersect(UP_genes, DOWN_genes)
if (length(overlap_signature) > 0) {
  stop("The following genes appear in both UP and DOWN; fix input2.tsv first: ",
       paste(overlap_signature, collapse = ", "))
}
if (length(UP_genes) == 0 || length(DOWN_genes) == 0) {
  stop("The UP or the DOWN gene set is empty; check input2.tsv.")
}

cat("\nSignature loaded:\n")
cat("UP genes (differentiation-associated):", length(UP_genes), "\n")
cat("DOWN genes (stemness-associated):", length(DOWN_genes), "\n")
cat("Total unique signature genes:", length(union(UP_genes, DOWN_genes)), "\n")

matched_up <- intersect(UP_genes, rownames(expr_gene_matrix))
matched_down <- intersect(DOWN_genes, rownames(expr_gene_matrix))
unmatched_up <- setdiff(UP_genes, rownames(expr_gene_matrix))
unmatched_down <- setdiff(DOWN_genes, rownames(expr_gene_matrix))

if (length(matched_up) == 0 || length(matched_down) == 0) {
  stop("No gene was matched for the UP or the DOWN module; check input2.tsv and the platform annotation.")
}

cat("Matched UP:", length(matched_up), "/", length(UP_genes), "\n")
cat("Matched DOWN:", length(matched_down), "/", length(DOWN_genes), "\n")

############################
# 9. Sample-level score
############################
UP_score <- colMeans(expr_gene_matrix[matched_up, , drop = FALSE], na.rm = TRUE)
DOWN_score <- colMeans(expr_gene_matrix[matched_down, , drop = FALSE], na.rm = TRUE)
panel_score <- UP_score - DOWN_score

sample_score_result <- data.frame(
  GSM = names(panel_score),
  CellLine = NA_character_,
  Treatment = NA_character_,
  UP_score = as.numeric(UP_score),
  DOWN_score = as.numeric(DOWN_score),
  Panel_score = as.numeric(panel_score),
  stringsAsFactors = FALSE
)

sample_score_result$CellLine <- sample_info$CellLine[
  match(sample_score_result$GSM, sample_info$GSM)
]
sample_score_result$Treatment <- sample_info$Treatment[
  match(sample_score_result$GSM, sample_info$GSM)
]
sample_score_result <- sample_score_result[
  sample_score_result$GSM %in% sample_info$GSM, ,
  drop = FALSE
]
sample_score_result <- sample_score_result[
  match(sample_info$GSM, sample_score_result$GSM), ,
  drop = FALSE
]

############################
# 10. Delta score by cell line
############################
delta_list <- list()
for (cell in unique(sample_info$CellLine)) {
  control_gsm <- sample_info$GSM[
    sample_info$CellLine == cell & sample_info$Treatment == "Control"
  ]
  drug_gsm <- sample_info$GSM[
    sample_info$CellLine == cell & sample_info$Treatment == "Emetine"
  ]
  
  if (length(control_gsm) != 1 || length(drug_gsm) != 1) {
    stop("Unexpected sample design: ", cell,
         " exactly one Control and one Emetine sample are required.")
  }
  
  delta_value <- panel_score[drug_gsm] - panel_score[control_gsm]
  delta_list[[cell]] <- data.frame(
    CellLine = cell,
    Control_GSM = control_gsm,
    Drug_GSM = drug_gsm,
    Control_score = as.numeric(panel_score[control_gsm]),
    Emetine_score = as.numeric(panel_score[drug_gsm]),
    Delta_score = as.numeric(delta_value),
    Supports_Differentiation_state_shift = ifelse(delta_value > 0, "YES", "NO"),
    stringsAsFactors = FALSE
  )
}
delta_result <- bind_rows(delta_list)

############################
# 11. Gene-level changes and directional concordance
############################
gene_list <- list()
for (i in seq_len(nrow(delta_result))) {
  cell <- delta_result$CellLine[i]
  control_gsm <- delta_result$Control_GSM[i]
  drug_gsm <- delta_result$Drug_GSM[i]
  gene_delta <- expr_gene_matrix[, drug_gsm] - expr_gene_matrix[, control_gsm]
  
  gene_list[[paste0(cell, "_UP")]] <- data.frame(
    CellLine = cell, Control_GSM = control_gsm, Drug_GSM = drug_gsm,
    Gene = matched_up, Direction = "UP",
    Control_expression = as.numeric(expr_gene_matrix[matched_up, control_gsm]),
    Drug_expression = as.numeric(expr_gene_matrix[matched_up, drug_gsm]),
    log2_expression_difference = as.numeric(gene_delta[matched_up]),
    Directionally_concordant = as.numeric(gene_delta[matched_up]) > 0,
    Signed_change = as.numeric(gene_delta[matched_up]),
    stringsAsFactors = FALSE
  )
  
  gene_list[[paste0(cell, "_DOWN")]] <- data.frame(
    CellLine = cell, Control_GSM = control_gsm, Drug_GSM = drug_gsm,
    Gene = matched_down, Direction = "DOWN",
    Control_expression = as.numeric(expr_gene_matrix[matched_down, control_gsm]),
    Drug_expression = as.numeric(expr_gene_matrix[matched_down, drug_gsm]),
    log2_expression_difference = as.numeric(gene_delta[matched_down]),
    Directionally_concordant = as.numeric(gene_delta[matched_down]) < 0,
    Signed_change = -as.numeric(gene_delta[matched_down]),
    stringsAsFactors = FALSE
  )
}
gene_level_result <- bind_rows(gene_list)

############################
# 12. Module changes and full concordance
############################
module_list <- list()
for (i in seq_len(nrow(delta_result))) {
  cell <- delta_result$CellLine[i]
  control_gsm <- delta_result$Control_GSM[i]
  drug_gsm <- delta_result$Drug_GSM[i]
  
  up_change <- mean(expr_gene_matrix[matched_up, drug_gsm], na.rm = TRUE) -
    mean(expr_gene_matrix[matched_up, control_gsm], na.rm = TRUE)
  down_change <- mean(expr_gene_matrix[matched_down, drug_gsm], na.rm = TRUE) -
    mean(expr_gene_matrix[matched_down, control_gsm], na.rm = TRUE)
  
  module_list[[cell]] <- data.frame(
    CellLine = cell,
    Control_GSM = control_gsm,
    Drug_GSM = drug_gsm,
    UP_change = up_change,
    DOWN_change = down_change,
    Delta_score_from_modules = up_change - down_change,
    Full_concordant_reversal = up_change > 0 && down_change < 0,
    stringsAsFactors = FALSE
  )
}
module_result <- bind_rows(module_list)

############################
# 13. Summary and final table
############################
reversal_summary <- gene_level_result %>%
  group_by(CellLine, Control_GSM, Drug_GSM) %>%
  summarise(
    matched_genes = sum(!is.na(log2_expression_difference)),
    directionally_concordant_genes = sum(Directionally_concordant, na.rm = TRUE),
    concordance_percentage = directionally_concordant_genes / matched_genes * 100,
    mean_signed_change = mean(Signed_change, na.rm = TRUE),
    median_signed_change = median(Signed_change, na.rm = TRUE),
    UP_concordant = sum(Direction == "UP" & Directionally_concordant, na.rm = TRUE),
    DOWN_concordant = sum(Direction == "DOWN" & Directionally_concordant, na.rm = TRUE),
    .groups = "drop"
  )
reversal_summary$Treatment <- "Emetine"

final_result <- delta_result %>%
  left_join(reversal_summary, by = c("CellLine", "Control_GSM", "Drug_GSM")) %>%
  left_join(
    module_result,
    by = c("CellLine", "Control_GSM", "Drug_GSM"),
    suffix = c("", "_module")
  ) %>%
  mutate(
    Biological_replicates_per_group = 1L,
    Replicate_statistical_test = "Not performed: no biological replicates",
    Expression_processing = "Raw CEL jointly normalized by affy::rma"
  )

############################
# 14. Save all outputs
############################
write.csv(sample_info, file.path(output_dir, "GSE5486_target_sample_info.csv"), row.names = FALSE)
write.csv(sample_score_result, file.path(output_dir, "GSE5486_RMA_sample_scores_20gene.csv"), row.names = FALSE)
write.csv(delta_result, file.path(output_dir, "GSE5486_RMA_delta_scores_20gene.csv"), row.names = FALSE)
write.csv(gene_level_result, file.path(output_dir, "GSE5486_RMA_gene_level_20gene.csv"), row.names = FALSE)
write.csv(reversal_summary, file.path(output_dir, "GSE5486_RMA_directional_concordance_20gene.csv"), row.names = FALSE)
write.csv(module_result, file.path(output_dir, "GSE5486_RMA_module_changes_20gene.csv"), row.names = FALSE)
write.csv(final_result, file.path(output_dir, "GSE5486_RMA_FINAL_result_20gene.csv"), row.names = FALSE)

unmatched_df <- data.frame(
  Unmatched_UP = c(
    unmatched_up,
    rep(NA_character_, max(0, length(unmatched_down) - length(unmatched_up)))
  ),
  Unmatched_DOWN = c(
    unmatched_down,
    rep(NA_character_, max(0, length(unmatched_up) - length(unmatched_down)))
  )
)
write.csv(
  unmatched_df,
  file.path(output_dir, "GSE5486_RMA_unmatched_signature_genes.csv"),
  row.names = FALSE
)

write.csv(
  data.frame(Gene = rownames(expr_gene_matrix), expr_gene_matrix, check.names = FALSE),
  file.path(output_dir, "GSE5486_RMA_gene_level_expression_all_samples.csv"),
  row.names = FALSE
)
write.csv(cel_map, file.path(output_dir, "GSE5486_CEL_file_map.csv"), row.names = FALSE)
capture.output(sessionInfo(), file = file.path(output_dir, "sessionInfo.txt"))

save(
  sample_info, cel_map, abatch, eset, expr_rma, expr_gene_matrix,
  sample_score_result, delta_result, gene_level_result, reversal_summary,
  module_result, final_result, UP_genes, DOWN_genes, matched_up, matched_down,
  unmatched_up, unmatched_down,
  file = file.path(output_dir, "GSE5486_Emetine_RMA_20gene_validation.RData")
)

############################
# 15. Print final results
############################
cat("\n================ GSE5486 EMETINE RMA FINAL RESULT ================\n")
print(final_result)
cat("\nRMA expression quantiles:\n")
print(quantile(as.numeric(expr_rma), c(0, .01, .25, .5, .75, .99, 1), na.rm = TRUE))
cat("\nInterpretation:\n")
cat("1) Delta_score > 0 supports movement toward the 20-gene panel-defined differentiation-associated transcriptional state.\n")
cat("2) Full_concordant_reversal = TRUE means UP module change > 0 and DOWN module change < 0.\n")
cat("3) Only one sample per condition per cell line; no biological-replicate test or P value was calculated.\n")
cat("4) These are transcriptional-state results, not direct proof of qCSC depletion or functional differentiation.\n")
cat("5) RMA was performed jointly on the available GSM-labeled CEL files from GSE5486.\n")
cat("Results saved to:", output_dir, "\n")
