## ===========================================================================
## gene_signature/01e_hallmark_gsea.R
##
## Hallmark GSEA on the moderated t statistics of 01d, used for Fig. 1D and
## for the original-versus-adjusted comparison made in 01f.
## ===========================================================================
## ===========================================================================
## gene_signature/01j_hallmark_gsea.R
##
## Hallmark gene-set enrichment (GSEA) on the moderated t statistics of the
## TCGA differential expression analysis, run twice:
##
##   unadjusted model   DEG_ALL.csv
##   ESTIMATE-adjusted  DEG_ESTIMATE_adjusted_all.csv
##
## The two are then compared pathway by pathway, which is the analysis behind
## Fig. 1D and the statement that 49 of the 50 Hallmark pathways change in the
## same direction after adjustment, oxidative phosphorylation being the exception.
##
## Unlike the ORA in 05c/06a, this uses the full ranked list (all valid t
## statistics), not a threshold-defined gene list.
## ===========================================================================

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

suppressPackageStartupMessages({
  library(clusterProfiler)
  library(msigdbr)
  library(dplyr)
  library(ggplot2)
})

if (requireNamespace("BiocParallel", quietly = TRUE)) {
  BiocParallel::register(BiocParallel::SerialParam())
}
options(mc.cores = 1)

## ---------------------------------------------------------------------------
## 1. Input files
## ---------------------------------------------------------------------------
deg_original <- find_deg_file("DEG_ALL.csv")
adj_candidates <- sort(Sys.glob(file.path(DATA_ROOT, "TCGA_CRC_ESTIMATE_GSVA_*",
                                          "DEG_ESTIMATE_adjusted_all.csv")),
                       decreasing = TRUE)
deg_adjusted <- if (length(adj_candidates)) adj_candidates[1] else NA_character_

if (is.na(deg_original) || !file.exists(deg_original))
  stop("DEG_ALL.csv not found; run 01d first.")
if (is.na(deg_adjusted) || !file.exists(deg_adjusted))
  stop("DEG_ESTIMATE_adjusted_all.csv not found; run 01f first.")

output_dir <- file.path(QCSC_PROJECT_DIR, "output", "Hallmark_GSEA")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cat("Input (unadjusted):", deg_original, "\n")
cat("Input (adjusted)  :", deg_adjusted, "\n")
cat("Output directory  :", output_dir, "\n")

## ---------------------------------------------------------------------------
## 2. Hallmark gene sets
## ---------------------------------------------------------------------------
hallmark_df <- tryCatch(
  msigdbr::msigdbr(species = "Homo sapiens", collection = "H"),
  error = function(e1) {
    tryCatch(msigdbr::msigdbr(species = "Homo sapiens", category = "H"),
             error = function(e2) {
               stop("Cannot retrieve the Hallmark collection from msigdbr.\n",
                    "first error : ", conditionMessage(e1), "\n",
                    "fallback    : ", conditionMessage(e2))
             })
  }
)

gene_col <- if ("gene_symbol" %in% colnames(hallmark_df)) "gene_symbol" else {
  stop("msigdbr output has no gene_symbol column: ",
       paste(colnames(hallmark_df), collapse = ", "))
}
set_col <- if ("gs_name" %in% colnames(hallmark_df)) "gs_name" else {
  stop("msigdbr output has no gs_name column.")
}

## ---------------------------------------------------------------------------
## 3. GSEA on one ranked list
## ---------------------------------------------------------------------------
run_gsea <- function(deg_file, label) {
  deg_all <- read.csv(deg_file, stringsAsFactors = FALSE, check.names = FALSE)

  miss <- setdiff(c("Gene", "t"), colnames(deg_all))
  if (length(miss)) {
    stop("Missing column(s) in ", basename(deg_file), ": ",
         paste(miss, collapse = ", "),
         "\n  columns present: ", paste(colnames(deg_all), collapse = ", "))
  }

  deg_all$Gene <- toupper(trimws(as.character(deg_all$Gene)))
  deg_all$t <- suppressWarnings(as.numeric(as.character(deg_all$t)))

  deg_gsea <- deg_all %>%
    filter(!is.na(Gene), Gene != "", !is.na(t), is.finite(t)) %>%
    arrange(desc(abs(t))) %>%
    distinct(Gene, .keep_all = TRUE)

  if (nrow(deg_gsea) < 100) {
    stop("Fewer than 100 valid genes after de-duplication (n = ", nrow(deg_gsea),
         "). Check the Gene and t columns.")
  }

  gene_rank <- deg_gsea$t
  names(gene_rank) <- deg_gsea$Gene
  gene_rank <- sort(gene_rank, decreasing = TRUE)

  if (anyDuplicated(names(gene_rank)) > 0) {
    stop("Duplicated gene symbols remain in the ranked list.")
  }

  cat(sprintf("\n[%s] ranked genes: %d  (max t = %.2f, min t = %.2f)\n",
              label, length(gene_rank), max(gene_rank), min(gene_rank)))

  write.csv(data.frame(Gene = names(gene_rank), t = as.numeric(gene_rank)),
            file.path(output_dir, paste0(label, "_GSEA_ranked_gene_list.csv")),
            row.names = FALSE)

  TERM2GENE <- hallmark_df %>%
    transmute(term = as.character(.data[[set_col]]),
              gene = toupper(as.character(.data[[gene_col]]))) %>%
    filter(!is.na(term), !is.na(gene), gene != "") %>%
    distinct() %>%
    filter(gene %in% names(gene_rank))

  if (nrow(TERM2GENE) == 0) {
    stop("No Hallmark gene overlaps the ranked list; check that Gene holds HGNC symbols.")
  }

  set.seed(1234)
  gsea_res <- clusterProfiler::GSEA(
    geneList = gene_rank,
    TERM2GENE = TERM2GENE,
    minGSSize = 10,
    maxGSSize = 500,
    pvalueCutoff = 1,
    pAdjustMethod = "BH",
    verbose = FALSE,
    seed = TRUE,
    eps = 0,
    nPermSimple = 10000
  )

  tab <- as.data.frame(gsea_res)
  if (nrow(tab) == 0) {
    stop("GSEA returned no pathway; check the gene identifiers and clusterProfiler version.")
  }
  tab <- tab %>% arrange(p.adjust)

  write.csv(tab, file.path(output_dir, paste0(label, "_Hallmark_GSEA_ALL_RESULTS.csv")),
            row.names = FALSE)
  cat(sprintf("[%s] pathways: %d  (FDR < 0.25: %d)\n",
              label, nrow(tab), sum(tab$p.adjust < 0.25, na.rm = TRUE)))
  tab
}

gsea_original <- run_gsea(deg_original, "unadjusted")
gsea_adjusted <- run_gsea(deg_adjusted, "ESTIMATE_adjusted")

## ---------------------------------------------------------------------------
## 4. Compare the two models pathway by pathway (Fig. 1D)
## ---------------------------------------------------------------------------
cmp <- merge(
  data.frame(ID = gsea_original$ID,
             NES_unadjusted = gsea_original$NES,
             FDR_unadjusted = gsea_original$p.adjust,
             size_unadjusted = gsea_original$setSize),
  data.frame(ID = gsea_adjusted$ID,
             NES_adjusted = gsea_adjusted$NES,
             FDR_adjusted = gsea_adjusted$p.adjust,
             size_adjusted = gsea_adjusted$setSize),
  by = "ID"
)
cmp$direction_unadjusted <- ifelse(cmp$NES_unadjusted > 0, "positive", "negative")
cmp$direction_adjusted   <- ifelse(cmp$NES_adjusted   > 0, "positive", "negative")
cmp$same_direction <- cmp$direction_unadjusted == cmp$direction_adjusted
cmp$NES_change <- cmp$NES_adjusted - cmp$NES_unadjusted
cmp <- cmp[order(cmp$ID), ]

write.csv(cmp, file.path(output_dir, "Hallmark_GSEA_model_comparison.csv"),
          row.names = FALSE)

n_total <- nrow(cmp)
n_same <- sum(cmp$same_direction, na.rm = TRUE)
cat(sprintf("\nHallmark pathways in both models : %d\n", n_total))
cat(sprintf("  same direction after adjustment: %d (%.0f%%)\n",
            n_same, 100 * n_same / n_total))
if (n_same < n_total) {
  cat("  direction changed:\n")
  print(cmp[!cmp$same_direction,
            c("ID", "NES_unadjusted", "NES_adjusted", "NES_change")],
        row.names = FALSE)
}

## ---------------------------------------------------------------------------
## 5. Bubble plot data for the preselected pathways
## ---------------------------------------------------------------------------
pathway_labels <- c(
  HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION = "Epithelial-mesenchymal transition",
  HALLMARK_OXIDATIVE_PHOSPHORYLATION         = "Oxidative phosphorylation",
  HALLMARK_FATTY_ACID_METABOLISM             = "Fatty acid metabolism",
  HALLMARK_GLYCOLYSIS                        = "Glycolysis",
  HALLMARK_HYPOXIA                           = "Hypoxia",
  HALLMARK_WNT_BETA_CATENIN_SIGNALING        = "WNT/beta-catenin signaling",
  HALLMARK_NOTCH_SIGNALING                   = "Notch signaling",
  HALLMARK_HEDGEHOG_SIGNALING                = "Hedgehog signaling",
  HALLMARK_TGF_BETA_SIGNALING                = "TGF-beta signaling",
  HALLMARK_PI3K_AKT_MTOR_SIGNALING           = "PI3K-AKT-mTOR signaling",
  HALLMARK_E2F_TARGETS                       = "E2F targets",
  HALLMARK_G2M_CHECKPOINT                    = "G2M checkpoint"
)

plot_df <- cmp[cmp$ID %in% names(pathway_labels), ]
plot_df$label <- pathway_labels[plot_df$ID]
write.csv(plot_df, file.path(output_dir, "Hallmark_GSEA_Fig1D_data.csv"),
          row.names = FALSE)

cat("\nFig. 1D pathways:\n")
print(plot_df[, c("label", "NES_unadjusted", "NES_adjusted",
                  "FDR_unadjusted", "FDR_adjusted")], row.names = FALSE)

cat("\nWritten to:", output_dir, "\n")
