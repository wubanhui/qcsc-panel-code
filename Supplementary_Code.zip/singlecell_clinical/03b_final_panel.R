## ===========================================================================
## singlecell_clinical/03b_final_panel.R
## Final 20-gene panel: concordance with the 822-gene axis, decile
## fidelity, normal-versus-tumour, cluster separation and TCGA scores.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

## Final stable panel: evaluate, validate in normal epithelium and TCGA bulk.
suppressPackageStartupMessages({library(Matrix); library(survival)})
tab_dir <- TAB_DIR; dir.create(tab_dir, recursive=TRUE, showWarnings=FALSE)
d <- readRDS(file.path(panel_dir,"panel_data.rds"))
freq <- read.csv(file.path(tab_dir,"panel_stability_frequency.csv"), check.names=FALSE)
stable <- freq$gene[freq$frequency >= 0.5]
cat("stable genes:", length(stable), "\n"); print(stable)
E1 <- d$E1; E2 <- d$E2; f1 <- d$score1; f2 <- d$score2
up <- d$up_use; down <- d$down_use

## ------------------------------------------------------------------
## ------------------------------------------------------------------
stable_up <- intersect(stable, up)
stable_dn <- intersect(stable, down)
cat(sprintf("panel score genes: %d UP + %d DOWN (of %d stable)\n",
            length(stable_up), length(stable_dn), length(stable)))
s1 <- colMeans(E1[stable_up, , drop = FALSE]) - colMeans(E1[stable_dn, , drop = FALSE])
s2 <- colMeans(E2[stable_up, , drop = FALSE]) - colMeans(E2[stable_dn, , drop = FALSE])

## fidelity
stratified_split <- function(strata, prop=0.7) {
  train <- rep(FALSE,length(strata))
  for (s in unique(strata)) { idx <- which(strata==s); train[sample(idx,max(1,floor(prop*length(idx))))] <- TRUE }
  train
}
set.seed(20261026)
tr1 <- stratified_split(d$meta1$Patient); tr2 <- stratified_split(d$meta2$sample_code)
pat1 <- tapply(s1,d$meta1$Patient,mean); patf <- tapply(f1,d$meta1$Patient,mean)
smp2 <- tapply(s2,d$meta2$sample_code,mean); smpf <- tapply(f2,d$meta2$sample_code,mean)
fid <- data.frame(cohort=c("GSE132465","GSE188711"),n_cells=c(ncol(E1),ncol(E2)),
  n_genes=length(stable),cell_r=c(cor(s1,f1),cor(s2,f2)),
  cell_spearman=c(cor(s1,f1,method="spearman"),cor(s2,f2,method="spearman")),
  test_r=c(cor(s1[!tr1],f1[!tr1]),cor(s2[!tr2],f2[!tr2])),
  patient_or_sample_r=c(cor(pat1,patf),cor(smp2,smpf)))
print(fid,row.names=FALSE); write.csv(fid,file.path(tab_dir,"stable_panel_fidelity.csv"),row.names=FALSE)

decile_concordance <- function(panel, full) {
  qp <- quantile(panel, c(.1, .9)); qf <- quantile(full, c(.1, .9))
  c(decile_top = mean(full[panel >= qp[2]] >= qf[2]))
}
state <- list()
for (co in c("GSE132465","GSE188711")) {
  full <- if(co=="GSE132465") f1 else f2
  panel <- if(co=="GSE132465") s1 else s2
  hi <- full>=quantile(full,.9); lo <- full<=quantile(full,.1)
  dc <- decile_concordance(panel, full)
  state[[co]] <- data.frame(cohort=co,n_panel_high=sum(panel>=quantile(panel,.9)),
    n_panel_low=sum(panel<=quantile(panel,.1)),
    panel_high_mean=mean(panel[hi]),panel_low_mean=mean(panel[lo]),
    decile_top=unname(dc["decile_top"]))
}
state <- do.call(rbind,state); print(state,row.names=FALSE)
write.csv(state,file.path(tab_dir,"stable_panel_qcsc_state.csv"),row.names=FALSE)

nv <- readRDS(file.path(out_dir,"normal_expr_sig.rds"))
nv_up <- intersect(stable_up, rownames(nv$expr))
nv_dn <- intersect(stable_dn, rownames(nv$expr))
npanel <- colMeans(nv$expr[nv_up, , drop = FALSE]) - colMeans(nv$expr[nv_dn, , drop = FALSE])
nfull <- colMeans(nv$expr[d$up_use,,drop=FALSE])-colMeans(nv$expr[d$down_use,,drop=FALSE])
cat("normal panel mean:",mean(npanel)," tumour:",mean(s1),"\n")
cat("normal full mean:",mean(nfull)," tumour:",mean(f1),"\n")
normal_tab <- data.frame(group=c("Normal_epithelium","Tumour_CMS1-4"),
  n=c(length(npanel),length(s1)),panel_mean=c(mean(npanel),mean(s1)),
  full_mean=c(mean(nfull),mean(f1)))
write.csv(normal_tab,file.path(tab_dir,"stable_panel_normal_vs_tumour.csv"),row.names=FALSE)
print(normal_tab,row.names=FALSE)

## panel table
panel_tab <- d$gene_stats[d$gene_stats$gene %in% stable,]
panel_tab <- panel_tab[match(stable,panel_tab$gene),]
panel_tab$weight <- ifelse(panel_tab$gene %in% up,1/sum(stable %in% up),-1/sum(stable %in% down))
write.csv(panel_tab,file.path(tab_dir,"final_panel_stable.csv"),row.names=FALSE)

if ("seurat_clusters" %in% colnames(d$meta2)) {
  cl <- as.character(d$meta2$seurat_clusters)
  if (length(unique(cl)) == 2) {
    cl_mean <- tapply(s2, cl, mean)
    hi_cl <- names(cl_mean)[which.max(cl_mean)]
    y <- as.integer(cl == hi_cl)
    w <- wilcox.test(s2[y == 1], s2[y == 0], exact = FALSE)
    a <- as.numeric(w$statistic) / (sum(y == 1) * sum(y == 0))
    if (a < 0.5) a <- 1 - a
    cluster_auc <- data.frame(
      high_cluster = hi_cl,
      low_cluster = names(cl_mean)[which.min(cl_mean)],
      n_high = sum(y == 1), n_low = sum(y == 0),
      panel_mean_high = max(cl_mean),
      panel_mean_low = min(cl_mean),
      panel_auc = a
    )
    write.csv(cluster_auc, file.path(tab_dir, "stable_panel_cluster_auc.csv"), row.names = FALSE)
    print(cluster_auc, row.names = FALSE)
  }
}

## ============================================================
## ============================================================
tcga_panel_file <- F_TCGA_RDATA
tcga_ssgsea_file <- F_TCGA_GSVA
RUN_TCGA_SURV <- identical(Sys.getenv("QCSC_TCGA_SURVIVAL", unset = "0"), "1")

meta <- NULL; sv <- NULL; cx <- NULL; lr <- NULL

if (file.exists(tcga_panel_file)) {
  load(tcga_panel_file)
  E <- as.matrix(expr_crc); sym <- toupper(rownames(E))
  ord <- order(sym, -rowMeans(E)); E <- E[ord, , drop = FALSE]; sym <- sym[ord]
  keep <- !duplicated(sym); E <- E[keep, , drop = FALSE]; rownames(E) <- sym[keep]
  up_use  <- intersect(up, rownames(E)); dn_use  <- intersect(down, rownames(E))
  panel_up <- intersect(stable[stable %in% up],   rownames(E))
  panel_dn <- intersect(stable[stable %in% down], rownames(E))
  full    <- colMeans(E[up_use, , drop = FALSE])  - colMeans(E[dn_use, , drop = FALSE])
  pscore  <- colMeans(E[panel_up, , drop = FALSE]) - colMeans(E[panel_dn, , drop = FALSE])
  meta <- data.frame(sample = colnames(E), full = full, panel = pscore)
  if (file.exists(tcga_ssgsea_file)) {
    q <- read.csv(tcga_ssgsea_file, check.names = FALSE)
    meta <- merge(meta, q[, c("sampleID", "qCSC_score", "qCSC_group")],
                  by.x = "sample", by.y = "sampleID", all.x = TRUE)
  }
  cat(sprintf("TCGA derivation: panel vs full r = %.3f",
              suppressWarnings(cor(meta$panel, meta$full))), "\n")
  if ("qCSC_score" %in% names(meta)) {
    cat(sprintf("TCGA derivation: panel vs qCSC r = %.3f\n",
                suppressWarnings(cor(meta$panel, meta$qCSC_score, use = "complete.obs"))))
  }
  write.csv(meta, file.path(tab_dir, "tcga_stable_panel_scores.csv"), row.names = FALSE)

  if (RUN_TCGA_SURV) {
    cl_files <- c(F_TCGA_CLIN_COAD,
                  F_TCGA_CLIN_READ)
    if (all(file.exists(cl_files))) {
      c1 <- read.delim(cl_files[1], check.names = FALSE, stringsAsFactors = FALSE)
      c2 <- read.delim(cl_files[2], check.names = FALSE, stringsAsFactors = FALSE)
      cc <- intersect(colnames(c1), colnames(c2))
      clin <- rbind(c1[, cc, drop = FALSE], c2[, cc, drop = FALSE])
      clin <- clin[!duplicated(clin$sampleID), ]
      meta <- merge(meta, clin, by.x = "sample", by.y = "sampleID", all.x = TRUE)
      num <- function(x) suppressWarnings(as.numeric(gsub("[^0-9.].*$", "", as.character(x))))
      meta$vital <- trimws(meta$vital_status)
      meta$os_event <- ifelse(meta$vital == "DECEASED", 1,
                              ifelse(meta$vital == "LIVING", 0, NA))
      meta$os_time <- ifelse(meta$os_event == 1, num(meta$days_to_death), num(meta$days_to_last_followup))
      meta$os_time[meta$os_time <= 0] <- NA
      sv <- meta[!is.na(meta$os_time) & !is.na(meta$os_event) & meta$os_time > 0, ]
      sv$group <- ifelse(sv$panel >= median(sv$panel), "High", "Low")
      sd <- Surv(sv$os_time, sv$os_event)
      lr <- survdiff(sd ~ group, data = sv); cx <- coxph(sd ~ group, data = sv)
      cat("TCGA survival n:", nrow(sv), " events:", sum(sv$os_event),
          " logrank p:", 1 - pchisq(lr$chisq, 1), "\n")
      write.csv(data.frame(n = nrow(sv), events = sum(sv$os_event),
                           logrank_p = 1 - pchisq(lr$chisq, 1),
                           hr = summary(cx)$conf.int[1], low = summary(cx)$conf.int[3],
                           high = summary(cx)$conf.int[4]),
                file.path(tab_dir, "tcga_stable_panel_survival.csv"), row.names = FALSE)
    } else {
      message("QCSC_TCGA_SURVIVAL=1 but the clinical file is missing; skipping TCGA survival")
    }
  } else {
    message("Skipping TCGA survival (not used in the paper; set QCSC_TCGA_SURVIVAL=1 to run)")
  }
} else {
  message("TCGA data missing; skipping the TCGA derivation: ", tcga_panel_file)
  message("  (panel selection and fidelity do not depend on TCGA; the pipeline continues)")
}

saveRDS(list(stable = stable, fidelity = fid, state = state, normal = normal_tab,
             tcga = meta, survival = if (is.null(sv)) NULL else list(data = sv, cox = cx, logrank = lr)),
        file.path(out_dir, "final_stable_panel.rds"))
cat("saved final_stable_panel.rds\n")
