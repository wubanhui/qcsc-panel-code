## ===========================================================================
## run_all.R
##
## Run the whole analysis in order. Each step is executed in its own R process
## so that a failure in one step does not affect the others, and every step
## writes a line to logs/run_all_status.csv.
##
## Usage
##   Rscript run_all.R                 run every step that can run with the available data
##   Rscript run_all.R --from 04       start at step 04
##   Rscript run_all.R --only 03b      run a single step
##   Rscript run_all.R --dry-run       list the steps without running them
##
## Steps whose inputs are not present are reported as SKIP, not as failures, so
## the script can be used on a machine that holds only part of the data.
## ===========================================================================

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(key) {
  i <- match(key, args)
  if (is.na(i) || i == length(args)) return(NULL)
  args[i + 1]
}
DRY   <- "--dry-run" %in% args
FROM  <- get_arg("--from")
ONLY  <- get_arg("--only")

## ---------------------------------------------------------------------------
## Locate the package root
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

## ---------------------------------------------------------------------------
## Step definition
##   id      step identifier
##   script  path relative to the package root
##   needs   files that must exist for the step to run; compared with any_env
##           when the entry starts with "env:"
## ---------------------------------------------------------------------------
STEPS <- list(
  ## 00 - single-cell objects -------------------------------------------------
  ## Rebuilds the QC objects from the raw GEO files. When a prepared QC_stage4_*
  ## directory already exists, point QCSC_ROOT_SC at its parent and step 02a will
  ## pick it up; these two steps then simply overwrite it with a fresh copy.
  list(id = "00a", script = "singlecell_clinical/01a_singlecell_qc_objects.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "00b", script = "singlecell_clinical/01b_build_qc_objects.R",
       needs = "env:QCSC_ROOT_SC"),

  ## Part 1 - gene signature ------------------------------------------------
  list(id = "01a", script = "gene_signature/01a_signature_protein_coding.R",
       needs = "env:QCSC_GENCODE_GTF"),
  list(id = "01b", script = "gene_signature/01b_tcga_sample_matching.R",
       needs = "env:QCSC_TCGA_RSEM,QCSC_TCGA_CLIN_COAD,QCSC_TCGA_CLIN_READ"),
  list(id = "01c", script = "gene_signature/01c_tcga_scoring.R",
       needs = "env:QCSC_TCGA_RDATA"),
  list(id = "01d", script = "gene_signature/01d_tcga_differential.R",
       needs = "env:QCSC_TCGA_RDATA"),
  list(id = "01e", script = "gene_signature/01e_hallmark_gsea.R",
       needs = character()),
  list(id = "01f", script = "gene_signature/01f_estimate_adjust.R",
       needs = "env:QCSC_TCGA_RDATA"),
  list(id = "01g", script = "gene_signature/01g_symbol_and_biotype_filter.R",
       needs = character()),
  list(id = "01h", script = "gene_signature/01h_gene_funnel_summary.R",
       needs = character()),

  ## Part 2 - single cell, panel construction, clinical association ----------
  list(id = "02a", script = "singlecell_clinical/02a_gse132465_epithelial.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "02b", script = "singlecell_clinical/02b_gse188711_epithelial.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "02c", script = "singlecell_clinical/02c_cnv_classifier.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "02d", script = "singlecell_clinical/02d_expression_classifier.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "02e", script = "singlecell_clinical/02e_malignant_integration.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "02f", script = "singlecell_clinical/02f_normal_epithelium.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "02g", script = "singlecell_clinical/02g_doublet_rate.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "03a", script = "singlecell_clinical/03a_stability_selection.R",
       needs = character()),
  list(id = "03b", script = "singlecell_clinical/03b_final_panel.R",
       needs = character()),
  list(id = "03c", script = "singlecell_clinical/03c_sensitivity.R",
       needs = character()),
  list(id = "03d", script = "singlecell_clinical/03d_export_direction_vector.R",
       needs = character()),
  list(id = "03e", script = "singlecell_clinical/03e_auc_sweep.R",
       needs = character()),
  list(id = "03f", script = "singlecell_clinical/03f_final_figures.R",
       needs = character()),
  list(id = "03g", script = "singlecell_clinical/03g_make_summary.R",
       needs = character()),
  list(id = "04a", script = "singlecell_clinical/04a_GSE144735.R",
       needs = c("F_GSE144735_MAT", "F_GSE144735_ANN")),
  list(id = "04b", script = "singlecell_clinical/04b_GSE39582.R",
       needs = c("F_GSE39582")),
  list(id = "04c", script = "singlecell_clinical/04c_GSE14333_DFS.R",
       needs = c("F_GSE14333")),
  list(id = "05a", script = "singlecell_clinical/05a_MMR_status.R",
       needs = character()),
  list(id = "05b", script = "singlecell_clinical/05b_MMR_hardening.R",
       needs = character()),
  list(id = "05c", script = "singlecell_clinical/05c_panel_annotation.R",
       needs = character()),
  list(id = "06a", script = "singlecell_clinical/06a_genomewide_correlation.R",
       needs = "env:QCSC_ROOT_SC"),
  list(id = "06b", script = "singlecell_clinical/06b_ORA_background.R",
       needs = character()),

  ## Part 3 - drug perturbation ---------------------------------------------
  list(id = "07a", script = "drug/07a_CX5461.R", needs = character()),
  list(id = "07b", script = "drug/07b_Wortmannin.R", needs = character()),
  list(id = "07c", script = "drug/07c_Emetine.R", needs = character()),
  list(id = "07d", script = "drug/07d_Calcitriol.R", needs = character()),
  list(id = "07e", script = "drug/07e_pathway_sets.R", needs = character()),

  ## Figures -----------------------------------------------------------------
  list(id = "08a", script = "figures/08a_Fig1_volcano.R", needs = character()),
  list(id = "08b", script = "figures/08b_Fig2B_umap_lineage.R", needs = "env:QCSC_ROOT_SC"),
  list(id = "08b2", script = "figures/08b_Fig2E_umap_zoom.R", needs = "env:QCSC_ROOT_SC"),
  list(id = "08c", script = "figures/08c_Fig3_normal_tumour.R", needs = character()),
  list(id = "08d", script = "figures/08d_Fig4_prognosis_MMR.R", needs = character()),
  list(id = "08e", script = "figures/08e_Fig5_annotation.R", needs = character()),
  list(id = "08f", script = "figures/08f_Fig6_drug_ROC.R", needs = character())
)

## ---------------------------------------------------------------------------
## Apply --from / --only
## ---------------------------------------------------------------------------
if (!is.null(ONLY) && ONLY %in% vapply(STEPS, `[[`, "", "id")) {
  STEPS <- Filter(function(s) identical(s$id, ONLY), STEPS)
} else if (!is.null(FROM)) {
  ids <- vapply(STEPS, `[[`, "", "id")
  i <- match(FROM, ids)
  if (is.na(i)) stop("Unknown step id: ", FROM, call. = FALSE)
  STEPS <- STEPS[i:length(STEPS)]
}

## ---------------------------------------------------------------------------
## Availability check
## ---------------------------------------------------------------------------
step_available <- function(step) {
  if (!length(step$needs)) return(TRUE)
  for (n in step$needs) {
    if (startsWith(n, "env:")) {
      vars <- strsplit(sub("^env:", "", n), ",")[[1]]
      for (v in vars) {
        val <- switch(v,
          "QCSC_TCGA_RSEM"     = F_TCGA_RSEM,
          "QCSC_TCGA_RDATA"    = F_TCGA_RDATA,
          "QCSC_TCGA_GSVA"     = F_TCGA_GSVA,
          "QCSC_TCGA_CLIN_COAD" = F_TCGA_CLIN_COAD,
          "QCSC_TCGA_CLIN_READ" = F_TCGA_CLIN_READ,
          "QCSC_ROOT_SC"        = file.path(ROOT_SC, "data"),
          "QCSC_GENCODE_GTF"    = GENCODE_GTF,
          "QCSC_TCGA_RNADATA"   = F_TCGA_RDATA,
          NULL)
        if (is.null(val) || !file.exists(val)) return(FALSE)
      }
    } else {
      val <- get(n, inherits = TRUE)
      if (!file.exists(val)) return(FALSE)
    }
  }
  TRUE
}

## ---------------------------------------------------------------------------
## Run
## ---------------------------------------------------------------------------
status_file <- file.path(LOG_DIR, "run_all_status.csv")
rows <- list()

cat("=====================================================================\n")
cat("Package root : ", QCSC_PROJECT_DIR, "\n")
cat("R version    : ", R.version.string, "\n")
cat("Steps        : ", length(STEPS), "\n")
cat("=====================================================================\n\n")

for (s in STEPS) {
  script_path <- file.path(QCSC_PROJECT_DIR, s$script)
  avail <- step_available(s) && file.exists(script_path)

  if (DRY) {
    cat(sprintf("  %-4s %-52s %s\n", s$id, s$script,
                ifelse(avail, "READY", "SKIP (inputs missing)")))
    next
  }

  if (!avail) {
    cat(sprintf("\n[SKIP] %s  inputs not available\n", s$script))
    rows[[length(rows) + 1]] <- data.frame(
      step = s$id, script = s$script, status = "SKIP",
      seconds = NA_real_, message = "inputs not available",
      stringsAsFactors = FALSE
    )
    next
  }

  cat("\n=====================================================================\n")
  cat(s$script, "\n")
  cat("=====================================================================\n")
  t0 <- Sys.time()
  logf <- file.path(LOG_DIR, paste0("step_", s$id, ".log"))
  res <- system2(file.path(R.home("bin"), "Rscript"),
                 args = c(shQuote(script_path)),
                 stdout = logf, stderr = logf, wait = TRUE)
  dt <- as.numeric(difftime(Sys.time(), t0, units = "secs"))

  st <- if (identical(as.integer(res), 0L)) "OK" else "FAIL"
  cat(sprintf("[%s] %s  %.1f s   (log: %s)\n", st, s$script, dt, logf))
  if (st == "OK") {
    tail_lines <- tryCatch(readLines(logf, warn = FALSE), error = function(e) character())
    tail_lines <- utils::tail(tail_lines, 4)
    if (length(tail_lines)) cat(paste0("   | ", tail_lines, collapse = "\n"), "\n")
  } else {
    tail_lines <- tryCatch(readLines(logf, warn = FALSE), error = function(e) character())
    tail_lines <- utils::tail(tail_lines, 15)
    if (length(tail_lines)) cat(paste0("   ! ", tail_lines, collapse = "\n"), "\n")
  }

  rows[[length(rows) + 1]] <- data.frame(
    step = s$id, script = s$script, status = st,
    seconds = round(dt, 1), message = ifelse(st == "OK", "", "see log"),
    stringsAsFactors = FALSE
  )
}

if (!DRY && length(rows)) {
  df <- do.call(rbind, rows)
  utils::write.csv(df, status_file, row.names = FALSE)
  cat("\n=====================================================================\n")
  print(df, row.names = FALSE)
  cat("\nStatus written to:", status_file, "\n")
  cat(sprintf("Summary: %d OK, %d SKIP, %d FAIL\n",
              sum(df$status == "OK"), sum(df$status == "SKIP"),
              sum(df$status == "FAIL")))
}
