# Validation of the reproducibility package

Test run performed on **2026-11-05** from a clean copy of the package to check
that the packaged scripts regenerate the numbers reported in the manuscript.

## 1. Environment

| Item | Value |
|---|---|
| R | 4.6.1 (2026-06-24 ucrt), x86_64-w64-mingw32 |
| Bioconductor | 3.23 |
| Platform | Windows 11 x64 |
| Inputs | raw GEO series matrices and TCGA matrices; the single-cell objects were rebuilt from the raw GEO files by step 00a |

The package was copied to a scratch directory and run from there, with inputs
left in their original location. No original file was modified.

## 2. End-to-end run

All 44 analysis steps were executed in order. Result: **44 succeeded.**

| Step | Script | Outcome |
|---|---|---|
| 00a | 01a_singlecell_qc_objects.R | ok; GSE188711 merged 25,189 cells, 18 clusters |
| 01a | 01a_signature_protein_coding.R | ok; 301 candidate genes |
| 01b | 01b_tcga_sample_matching.R | ok; 380 primary tumours |
| 01c | 01c_tcga_scoring.R | ok; 190 / 190 median split |
| 01d | 01d_tcga_differential.R | ok; 2,292 up / 503 down |
| 01e | 01e_hallmark_gsea.R | ok |
| 01f | 01f_estimate_adjust.R | ok; 1,595 ESTIMATE-adjusted DEG |
| 01g | 01g_symbol_and_biotype_filter.R | ok; 885 genes (768 / 117) |
| 01h | 01h_gene_funnel_summary.R | ok |
| 02a | 02a_gse132465_epithelial.R | ok; 17,469 cells, 822/885 genes |
| 02b | 02b_gse188711_epithelial.R | ok; panel_data.rds written |
| 02c | 02c_cnv_classifier.R | ok |
| 02d | 02d_expression_classifier.R | ok |
| 02e | 02e_malignant_integration.R | ok |
| 02f | 02f_normal_epithelium.R | ok; 822 x 1,070 |
| 02g | 02g_doublet_rate.R | ok; 4.6696 % overall |
| 03a | 03a_stability_selection.R | ok; 20 genes |
| 03b | 03b_final_panel.R | ok |
| 03c | 03c_sensitivity.R | ok |
| 03d | 03d_export_direction_vector.R | ok |
| 03e | 03e_auc_sweep.R | ok |
| 03f | 03f_final_figures.R | ok |
| 03g | 03g_make_summary.R | ok |
| 04a | 04a_GSE144735.R | ok |
| 04b | 04b_GSE39582.R | ok; 566 tumours |
| 04c | 04c_GSE14333_DFS.R | ok; 226 patients |
| 05a | 05a_MMR_status.R | ok; 519 samples (75 / 444) |
| 05b | 05b_MMR_hardening.R | ok |
| 05c | 05c_panel_annotation.R | ok |
| 06a | 06a_genomewide_correlation.R | ok; 25,775 genes |
| 06b | 06b_ORA_background.R | ok |
| 07a | 07a_CX5461.R | ok |
| 07b | 07b_Wortmannin.R | ok |
| 07c | 07c_Emetine.R | ok |
| 07d | 07d_Calcitriol.R | ok |
| 07e | 07e_pathway_sets.R | ok; manuscript checks all pass |
| 08a | 08a_Fig1_volcano.R | ok |
| 08b | 08b_Fig2B_umap_lineage.R | ok |
| 08b2 | 08b_Fig2E_umap_zoom.R | ok |
| 08c | 08c_Fig3_normal_tumour.R | ok |
| 08d | 08d_Fig4_prognosis_MMR.R | ok |
| 08e | 08e_Fig5_annotation.R | ok |
| 08f | 08f_Fig6_drug_ROC.R | ok |

The longest steps are 07e (about 44 minutes, dominated by the permutation
testing over roughly 8,000 gene sets per comparison), 02g (about 24 minutes) and
01b (about 5 minutes). A full run takes about 1.5 hours.

## 3. Manuscript values that were checked

### Gene signature

| Quantity | Manuscript | Reproduced |
|---|---|---|
| candidate genes | 301 | 301 |
| protein-coding signature | 290 | 290 |
| TCGA tumours | 380 | 380 |
| differential expression | 2,795 (2,292 / 503) | 2,292 / 503 |
| ESTIMATE-adjusted DEG | 1,595 | 1,595 |
| concordant genes | 1,295 (967 / 328) | 967 / 328 |
| consensus set | 885 (768 / 117) | 768 / 117 |
| panel input | 822 (738 / 84) | 822 |

### Panel construction

| Quantity | Manuscript | Reproduced |
|---|---|---|
| panel | 17 up + 3 down | 17 + 3 |
| selection frequency | 0.500-0.967 | 0.500-0.967 |
| r = 0.899 / 0.901 (cells) | | 0.8990301 / 0.9014128 |
| test-split r 0.897 / 0.892 | | 0.8971993 / 0.8924648 |
| patient/sample r 0.975 / 0.988 | | 0.9747852 / 0.9878589 |
| decile AUC 0.9999 / 1.000 | | 0.9999276 / 1.0000000 |
| TCGA r 0.883 / 0.637 | | 0.883 / 0.637 |

### Classifiers and external cohorts

| Quantity | Manuscript | Reproduced |
|---|---|---|
| CNV classifier CV AUC | 0.929 | 0.9293753 |
| classifier AUC | 0.616 / 0.604 / 0.634 | 0.6156334 / 0.6043234 / 0.6340159 |
| cluster 14 vs 5 panel AUC | 0.919 | 0.9187349 |
| normal vs tumour panel | 0.647 / 0.463 | 0.6467414 / 0.4634955 |
| normal vs tumour full | 0.130 / 0.065 | 0.1302627 / 0.0649108 |
| GSE144735 cell r / patient r | 0.808 / 0.801 | 0.8082004 / 0.8009109 |
| GSE144735 tumour-vs-normal AUC | 0.481 | 0.4810344 |
| GSE39582 normal mucosa | +2.26 SD | +2.258 |

### MMR status

| Quantity | Manuscript | Reproduced |
|---|---|---|
| samples (dMMR / pMMR) | 519 (75 / 444) | 519 (75 / 444) |
| AUC (95 % CI) | 0.757 (0.700-0.815) | identical |
| Youden threshold | 0.573 | identical |
| sensitivity / specificity | 65.3 % / 75.9 % | identical |
| PPV / NPV | 31.4 % / 92.8 % | identical |
| OR per SD (95 % CI) | 2.75 (1.99-3.78), P = 5.7e-10, n = 501 | identical |
| subgroup AUC | 0.731 / 0.797 / 0.652 / 0.768 | identical |
| leave-one-gene-out | BCL11A 0.723, up-only 0.664, down-only 0.768 | identical |
| GSE13294 / GSE13067 | 0.703 / 0.742 | identical |
| pooled | 0.738, I2 = 0 % | identical |

### Prognosis

| Quantity | Manuscript | Reproduced |
|---|---|---|
| GSE39582 OS HR unadjusted | 1.04 (0.90-1.20), P = 0.63 | identical |
| GSE39582 OS HR adjusted | 1.09 (0.92-1.28), P = 0.33 | identical |
| GSE39582 RFS HR unadjusted | 1.00 (0.87-1.16), P = 0.97 | identical |
| GSE39582 RFS HR adjusted | 1.12 (0.95-1.32), P = 0.18 | identical |
| log-rank OS / RFS | 0.44 / 0.91 | 0.4376 / 0.9071 |
| C-index OS / RFS | 0.524 / 0.494 | identical |
| GSE14333 DFS HR unadjusted | 1.24 (0.95-1.61) | identical |
| GSE14333 DFS HR adjusted | 1.31 (1.00-1.72), P = 0.047 | identical |
| GSE14333 C-index | 0.559 | identical |
| positive control, stage | 1.92 (1.57-2.34) | 1.915 (1.568-2.339) |
| positive control, Dukes stage | 2.95 (1.81-4.81) | 2.949 (1.808-4.811) |
| positive control, age | 1.02 per year | 1.024 |

### Genome-wide correlation and enrichment

| Quantity | Manuscript | Reproduced |
|---|---|---|
| genes tested | 25,775 | 25,775 |
| abs(rho) > 0.3 / > 0.2 | 144 / 617 | 144 / 617 |
| top positive | SH3BGRL3 0.555 | 0.555 |
| top negative | RPS27A -0.432 | -0.4316 |
| cytoplasmic translation | 1.35e-57, 54 genes | 1.4e-57, 54 genes |
| response to wounding | 3.2e-06, 23 genes | 3.2e-06, 23 genes |
| panel ORA, CC terms | 8 | 8 |
| panel ORA, smallest adjusted P | 1.6e-03 | 0.0016 |
| GO background | 16,420 | 16,420 |
| 822-gene background | 796 | 796 |
| CMS patient-level | 0.636 / 0.344 / 0.256, P = 1.3e-5 | identical |

### Drug perturbation and pathway response

| Quantity | Manuscript | Reproduced |
|---|---|---|
| CX-5461 delta (DLD-1 1/10 uM) | +0.316 / +0.368 | identical |
| CX-5461 delta (HT-29) | +0.038 / +0.452 | identical |
| CX-5461 delta (SW480) | -0.052 / +0.066 | identical |
| Emetine delta (SW480 / LS180) | +0.139 / -0.101 | identical |
| Calcitriol delta > 0 | 4/6 tumour vs 0/6 normal, P = 0.031 | 4/6 vs 0/6, P = 0.0306 |
| CX-5461 MYC_TARGETS_V1 | 6/6 negative, median -0.086 | 6/6 negative, -0.0858 |
| CX-5461 MYC_TARGETS_V2 | median -0.202 | -0.2023 |
| Emetine MYC_TARGETS_V1 | -0.221 / -0.211 | -0.2209 / -0.2107 |
| Emetine KEGG_RIBOSOME | -0.156 / -0.273 | -0.1558 / -0.2728 |
| Wortmannin SW480 KEGG_RIBOSOME | +0.221 | +0.2206 |
| Wortmannin SW480 rRNA processing | +0.134 | +0.1336 |
| Wortmannin SW480 cytoplasmic translation | +0.134 | +0.1338 |
| Calcitriol VDR vs panel delta rho | -0.15 / -0.21 | -0.147 / -0.210 |

## 4. Notes on individual steps

1. Deterministic panel. 03a sets seed 1234 and iterates seeds 1001-1030. The 20
   genes and all selection frequencies are reproduced exactly
   (BCL11A / MUC1 / TSPAN1 = 0.967, KLK10 = 0.500).

2. Doublet rate. 02g writes 4.6696 % overall (33 samples, 63,689 cells, 2,974
   doublets), identical to the value used in the manuscript.

3. Genome-wide correlation. 06a applies the detection filter used originally
   (genes detected in at least one tumour epithelial cell), so that 25,775
   non-panel genes are tested rather than the full 33,674-gene matrix.

4. Survival split. 04b uses the median of the panel score over all tumours of
   the cohort as the high / low split point, which is the definition that
   underlies the log-rank P values reported in the manuscript (0.44 / 0.91).

5. 03e_tcga_survival.R is a legacy exploration and is deliberately not
   registered in run_all.R, so it does not appear among the 44 steps. The TCGA
   score table produced by 03b contains scores only (no clinical fields), so the
   script detects this and exits with a message. TCGA survival is not reported
   in the manuscript.

6. Gene sets for 07e. The three MSigDB 2024.1.Hs collections are read from
   `<QCSC_DATA_ROOT>/mechanism_standard_R/gmt/` when present and downloaded from
   Broad otherwise.

7. p53 pathway. In the 6 CX-5461 contrasts the HALLMARK_P53_PATHWAY score is
   negative in 3; three contrasts reach adjusted P < 0.05 (two positive, one
   negative), which is consistent with the manuscript statement that the
   direction of change is not consistent.

8. GSEA enrichment scores. The only quantity in the manuscript that is not
   bit-reproducible is the adjusted normalised enrichment score (NES) from
   `clusterProfiler::GSEA` (steps 01e, 01f). About 5% of the ranked genes carry
   tied statistics and their order shifts the permuted score, so two independent
   pipeline runs differ by up to 0.03. The unadjusted NES of oxidative
   phosphorylation is -2.35 in every run; the adjusted NES is +1.14 in the
   original analysis, +1.17 in the delivered code and +1.17 in the full re-run
   above. All direction and significance statements hold in every run: 49 of 50
   Hallmark pathways keep their direction, and oxidative phosphorylation is the
   only pathway that flips.

## 5. Conclusion

The pipeline runs end to end on the recorded environment. Every value quoted in
the Results section of the manuscript is reproduced, including the enrichment
table: the leading terms, their gene counts, the adjusted P values, the number
of significant CC terms and both ORA backgrounds all match.
