## ===========================================================================
## gene_signature/01d_tcga_differential.R
##
## Differential expression between high and low qCSC-score tumours (limma;
## FDR < 0.05 and |log2FC| > 0.5); yields 2,795 DEG.
## ===========================================================================

############################################################
# CRC-qCSC High vs Low Differential Expression Analysis

############################################################

rm(list = ls())

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
options(stringsAsFactors = FALSE)

if (!requireNamespace("limma", quietly = TRUE)) {
  stop("Package 'limma' is not installed. Install it through Bioconductor.")
}
library(limma)

# ----------------------------------------------------------
# ----------------------------------------------------------
data_root <- DATA_ROOT
score_dir   <- file.path(data_root, "TCGA_qCSC_score_GSVA")
output_root <- DEG_DIR

score_file <- file.path(
  score_dir,
  "TCGA_CRC_qCSC_GSVA_ssGSEA_scores.csv"
)

if (!file.exists(score_file)) {
  candidates <- list.files(
    score_dir,
    pattern = "^TCGA_CRC_qCSC_GSVA_ssGSEA_scores\\.csv$",
    recursive = TRUE,
    full.names = TRUE
  )
  
  if (length(candidates) > 0L) {
    score_file <- candidates[
      which.max(file.info(candidates)$mtime)
    ]
  }
}

rdata_file <- file.path(
  data_root,
  "TCGA_CRC_380_samples.RData"
)

if (!file.exists(score_file)) {
  stop(
    "not found in ", score_dir,
    " or its subdirectories; please check the file location."
  )
}

if (!file.exists(rdata_file)) {
  stop("Expression RData not found: ", rdata_file)
}

dir.create(
  output_root,
  recursive = TRUE,
  showWarnings = FALSE
)

cat("Score file used: ", score_file, "\n", sep = "")

# ----------------------------------------------------------
# 2. Load the TCGA expression matrix
# ----------------------------------------------------------
load_env <- new.env()
load(rdata_file, envir = load_env)

if (exists("expr_crc", envir = load_env, inherits = FALSE)) {
  expr <- as.matrix(get("expr_crc", envir = load_env))
} else if (exists("expr", envir = load_env, inherits = FALSE)) {
  expr <- as.matrix(get("expr", envir = load_env))
} else {
  stop("Expression matrix 'expr' or 'expr_crc' was not found.")
}

storage.mode(expr) <- "double"

if (is.null(rownames(expr)) || is.null(colnames(expr))) {
  stop(
    "The expression matrix must have gene row names ",
    "and sample column names."
  )
}

if (any(!is.finite(expr))) {
  stop("Expression matrix contains NA/NaN/Inf values.")
}

if (anyDuplicated(colnames(expr))) {
  stop("Duplicated sample IDs found in the expression matrix.")
}

# ----------------------------------------------------------
# 3. Read the GSVA score table
# ----------------------------------------------------------
qCSC_score_final_df <- read.csv(
  score_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

required_score_columns <- c(
  "sampleID",
  "qCSC_score",
  "qCSC_group"
)

missing_score_columns <- setdiff(
  required_score_columns,
  colnames(qCSC_score_final_df)
)

if (length(missing_score_columns) > 0L) {
  stop(
    "The score CSV is missing required columns: ",
    paste(missing_score_columns, collapse = ", ")
  )
}

qCSC_score_final_df$sampleID <- trimws(
  as.character(qCSC_score_final_df$sampleID)
)

qCSC_score_final_df$qCSC_score <- as.numeric(
  qCSC_score_final_df$qCSC_score
)

qCSC_score_final_df$qCSC_group <- trimws(
  as.character(qCSC_score_final_df$qCSC_group)
)

if (
  anyNA(qCSC_score_final_df$sampleID) ||
  any(qCSC_score_final_df$sampleID == "")
) {
  stop("Missing or blank sampleID values found in the score CSV.")
}

if (anyDuplicated(qCSC_score_final_df$sampleID)) {
  stop("Duplicated sampleID values found in the score CSV.")
}

if (!all(is.finite(qCSC_score_final_df$qCSC_score))) {
  stop("Non-finite qCSC scores found in the score CSV.")
}

group_lower <- tolower(qCSC_score_final_df$qCSC_group)

qCSC_score_final_df$qCSC_group[
  group_lower %in% c("high", "qcsc-high")
] <- "High"

qCSC_score_final_df$qCSC_group[
  group_lower %in% c("low", "qcsc-low")
] <- "Low"

if (!all(qCSC_score_final_df$qCSC_group %in% c("Low", "High"))) {
  stop("qCSC_group must contain only 'Low' and 'High' labels.")
}

# ----------------------------------------------------------
# 4. Match samples between expression and score data
# ----------------------------------------------------------
common_samples <- colnames(expr)[
  colnames(expr) %in% qCSC_score_final_df$sampleID
]

if (length(common_samples) == 0L) {
  stop(
    "No common samples found between expression matrix ",
    "and score CSV."
  )
}

score_index <- match(
  common_samples,
  qCSC_score_final_df$sampleID
)

expr_deg <- expr[, common_samples, drop = FALSE]

qCSC_group <- factor(
  qCSC_score_final_df$qCSC_group[score_index],
  levels = c("Low", "High")
)

names(qCSC_group) <- common_samples

if (anyNA(qCSC_group)) {
  stop("Missing qCSC group assignments after sample matching.")
}

group_table <- table(qCSC_group)

if (any(group_table == 0L)) {
  stop("One of the qCSC groups contains no matched samples.")
}

sample_groups <- data.frame(
  sampleID = common_samples,
  qCSC_score = qCSC_score_final_df$qCSC_score[score_index],
  qCSC_group = as.character(qCSC_group),
  stringsAsFactors = FALSE
)

# ----------------------------------------------------------
# 5. Remove zero-variance genes
# ----------------------------------------------------------
gene_variance <- apply(
  expr_deg,
  1,
  var,
  na.rm = TRUE
)

keep_gene <- !is.na(gene_variance) &
  is.finite(gene_variance) &
  gene_variance > 0

zero_variance_genes <- rownames(expr_deg)[!keep_gene]

expr_deg_final <- expr_deg[
  keep_gene,
  ,
  drop = FALSE
]

if (nrow(expr_deg_final) == 0L) {
  stop("No genes remain after zero-variance filtering.")
}

# ----------------------------------------------------------
# 6. limma: qCSC-High versus qCSC-Low
# ----------------------------------------------------------
design <- model.matrix(~ qCSC_group)
colnames(design) <- c(
  "Intercept",
  "qCSC_High_vs_Low"
)

fit <- lmFit(expr_deg_final, design)
fit <- eBayes(fit)

deg_all <- topTable(
  fit,
  coef = "qCSC_High_vs_Low",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

deg_all$Gene <- rownames(deg_all)

deg_all <- deg_all[
  ,
  c("Gene", setdiff(colnames(deg_all), "Gene")),
  drop = FALSE
]

deg_fdr05 <- deg_all[
  !is.na(deg_all$adj.P.Val) &
    deg_all$adj.P.Val < 0.05,
  ,
  drop = FALSE
]

DEG_FDR_CUTOFF <- 0.05
DEG_LOGFC_CUTOFF <- 0.5

deg_final <- deg_all[
  !is.na(deg_all$adj.P.Val) &
    !is.na(deg_all$logFC) &
    deg_all$adj.P.Val < DEG_FDR_CUTOFF &
    abs(deg_all$logFC) >= DEG_LOGFC_CUTOFF,
  ,
  drop = FALSE
]

deg_up <- deg_final[
  deg_final$logFC >= DEG_LOGFC_CUTOFF,
  ,
  drop = FALSE
]

deg_down <- deg_final[
  deg_final$logFC <= -DEG_LOGFC_CUTOFF,
  ,
  drop = FALSE
]

deg_final <- deg_final[
  order(deg_final$adj.P.Val),
  ,
  drop = FALSE
]

deg_up <- deg_up[
  order(deg_up$adj.P.Val),
  ,
  drop = FALSE
]

deg_down <- deg_down[
  order(deg_down$adj.P.Val),
  ,
  drop = FALSE
]

# ----------------------------------------------------------
# 7. Summary
# ----------------------------------------------------------
analysis_summary <- data.frame(
  Expression_genes = nrow(expr),
  Expression_samples = ncol(expr),
  Matched_samples = length(common_samples),
  qCSC_Low_samples = sum(qCSC_group == "Low"),
  qCSC_High_samples = sum(qCSC_group == "High"),
  Genes_before_variance_filter = nrow(expr_deg),
  Zero_variance_genes_removed = length(zero_variance_genes),
  Genes_after_variance_filter = nrow(expr_deg_final),
  Genes_FDR_lt_0.05 = nrow(deg_fdr05),
  Final_DEGs = nrow(deg_final),
  Upregulated_in_qCSC_High = nrow(deg_up),
  Downregulated_in_qCSC_High = nrow(deg_down),
  DEG_FDR_cutoff = DEG_FDR_CUTOFF,
  DEG_abs_logFC_cutoff = DEG_LOGFC_CUTOFF,
  stringsAsFactors = FALSE
)

# ----------------------------------------------------------
# ----------------------------------------------------------
output_dir <- output_root

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ----------------------------------------------------------
# ----------------------------------------------------------
write.csv(
  sample_groups,
  file.path(output_dir, "qCSC_sample_groups.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  deg_all,
  file.path(output_dir, "DEG_ALL.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  deg_fdr05,
  file.path(output_dir, "DEG_FDR05.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  deg_final,
  file.path(output_dir, "DEG_FINAL.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  deg_up,
  file.path(output_dir, "DEG_UP.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  deg_down,
  file.path(output_dir, "DEG_DOWN.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  analysis_summary,
  file.path(output_dir, "DEG_analysis_summary.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

save(
  expr,
  qCSC_score_final_df,
  qCSC_group,
  expr_deg,
  expr_deg_final,
  zero_variance_genes,
  design,
  fit,
  deg_all,
  deg_fdr05,
  deg_final,
  deg_up,
  deg_down,
  sample_groups,
  analysis_summary,
  file = file.path(
    output_dir,
    "CRC_qCSC_DEG_analysis.RData"
  )
)

# ----------------------------------------------------------
# 10. Provenance
# ----------------------------------------------------------
metadata <- data.frame(
  Metric = c(
    "Score_CSV",
    "Expression_RData",
    "Matched_samples",
    "qCSC_Low_samples",
    "qCSC_High_samples",
    "FDR_cutoff",
    "Absolute_logFC_cutoff",
    "Final_DEGs",
    "Up_in_qCSC_High",
    "Down_in_qCSC_High",
    "Analysis_time"
  ),
  Value = c(
    score_file,
    rdata_file,
    length(common_samples),
    sum(qCSC_group == "Low"),
    sum(qCSC_group == "High"),
    DEG_FDR_CUTOFF,
    DEG_LOGFC_CUTOFF,
    nrow(deg_final),
    nrow(deg_up),
    nrow(deg_down),
    as.character(Sys.time())
  ),
  stringsAsFactors = FALSE
)

write.csv(
  metadata,
  file.path(output_dir, "DEG_analysis_provenance.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

# ----------------------------------------------------------
# 11. Console summary
# ----------------------------------------------------------
cat("\n============================================================\n")
cat("Analysis completed successfully.\n")
cat("Input score CSV  : ", score_file, "\n", sep = "")
cat("Expression RData : ", rdata_file, "\n", sep = "")
cat("Matched samples  : ", length(common_samples), "\n", sep = "")
cat("qCSC-Low samples : ", sum(qCSC_group == "Low"), "\n", sep = "")
cat("qCSC-High samples: ", sum(qCSC_group == "High"), "\n", sep = "")
cat("FDR cutoff       : ", DEG_FDR_CUTOFF, "\n", sep = "")
cat("|logFC| cutoff   : ", DEG_LOGFC_CUTOFF, "\n", sep = "")
cat("Final DEGs       : ", nrow(deg_final), " (no limit)
", sep = "")
cat("Up in qCSC-High  : ", nrow(deg_up), "\n", sep = "")
cat("Down in qCSC-High: ", nrow(deg_down), "\n", sep = "")
cat("Results folder   : ", output_dir, "\n", sep = "")
cat("============================================================\n")