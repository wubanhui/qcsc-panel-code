## ===========================================================================
## singlecell_clinical/05a_MMR_status.R
## Panel score as a readout of MMR status in GSE39582 (ROC/AUC, logistic
## regression).
## ===========================================================================
# ============================================================
# 08a_qCSC_reads_MMR_status.R
#
#
#
#
#   tables/qCSC_MMR_status_auc.csv
#   tables/qCSC_MMR_status_detail.csv
#   figures/Fig13_qCSC_MMR_status.png / .pdf
#
#   AUC 0.70-0.80                   => “moderate readout”
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)
suppressPackageStartupMessages({
  library(survival)
})

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
for (d in c(tab_dir, fig_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

score_file <- file.path(tab_dir, "external_GSE39582_scores.csv")
if (!file.exists(score_file)) stop("Cannot find external_GSE39582_scores.csv; please run 04b first")
dat <- read.csv(score_file, check.names = FALSE, stringsAsFactors = FALSE)

dd <- dat[dat$cohort != "Non Tumoral" & !is.na(dat$mmr), ]
dd$mmr_lab <- dd$mmr
cat(sprintf("Samples with MMR annotation: %d (dMMR = %d, pMMR = %d)\n",
            nrow(dd), sum(dd$mmr == "dMMR"), sum(dd$mmr == "pMMR")))
if (nrow(dd) < 50) stop("Too few samples with MMR annotation for analysis")

# ------------------------------------------------------------
# ------------------------------------------------------------
auc_mw <- function(score, y) {   # y: 1 = dMMR
  pos <- score[y == 1]; neg <- score[y == 0]
  r <- rank(c(pos, neg))
  (sum(r[seq_along(pos)]) - length(pos) * (length(pos) + 1) / 2) /
    (length(pos) * length(neg))
}

auc_delong <- function(score, y) {
  pos <- score[y == 1]; neg <- score[y == 0]
  m <- length(pos); n <- length(neg)
  psi <- function(x, z) (x > z) + 0.5 * (x == z)
  V10 <- rowMeans(outer(pos, neg, psi))   # for each positive
  V01 <- colMeans(outer(pos, neg, psi))   # for each negative
  S10 <- stats::var(V10) / m
  S01 <- stats::var(V01) / n
  auc <- mean(c(V10, V01))  # same as auc_mw
  list(auc = auc, se = sqrt(S10 + S01))
}

boot_auc <- function(score, y, B = 2000L) {
  out <- numeric(B)
  for (b in seq_len(B)) {
    idx <- sample.int(length(y), replace = TRUE)
    if (length(unique(y[idx])) < 2L) { out[b] <- NA_real_; next }
    out[b] <- auc_mw(score[idx], y[idx])
  }
  stats::quantile(out, c(0.025, 0.975), na.rm = TRUE)
}

run_auc <- function(score, y, label) {
  ok <- !is.na(score) & !is.na(y)
  s <- score[ok]; yy <- y[ok]
  if (length(unique(yy)) < 2L || sum(yy) < 5 || sum(!yy) < 5) {
    return(NULL)
  }
  a <- auc_mw(s, yy)
  ci <- boot_auc(s, yy)
  dl <- auc_delong(s, yy)
  z <- (a - 0.5) / dl$se
  p <- 2 * stats::pnorm(-abs(z))
  if (grepl("sign flipped", label, ignore.case = TRUE)) p <- NA_real_
  cut <- suppressWarnings(pROC_free_threshold(s, yy))
  data.frame(
    comparison = label,
    n = length(yy), n_dmmr = sum(yy == 1), n_pmmr = sum(yy == 0),
    auc = a, ci_low = as.numeric(ci[1]), ci_high = as.numeric(ci[2]),
    delong_se = dl$se, p = p,
    youden_cut = cut,
    stringsAsFactors = FALSE
  )
}

pROC_free_threshold <- function(score, y) {
  thr <- unique(sort(score))
  best <- -Inf; best_t <- NA_real_
  for (t in thr) {
    pred <- score >= t
    sens <- mean(pred[y == 1]); spec <- mean(!pred[y == 0])
    j <- sens + spec - 1
    if (j > best) { best <- j; best_t <- t }
  }
  best_t
}

y <- as.integer(dd$mmr == "dMMR")

rows <- list()
rows[[1]] <- run_auc(dd$panel, y, "panel score (20 genes)")

if (!all(is.na(dd$full))) {
  rows[[length(rows) + 1L]] <- run_auc(dd$full, y, "full signature (822 genes)")
}

rows[[length(rows) + 1L]] <- run_auc(-dd$panel, y, "panel score, sign flipped (control)")

res <- do.call(rbind, rows)
res$auc <- round(res$auc, 4); res$ci_low <- round(res$ci_low, 4)
res$ci_high <- round(res$ci_high, 4); res$p <- signif(res$p, 3)
res$youden_cut <- round(res$youden_cut, 4)
write.csv(res, file.path(tab_dir, "qCSC_MMR_status_auc.csv"), row.names = FALSE)
print(res, row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
dd$is_dmmr <- y
ctx_rows <- list()
add_ctx <- function(label, formula, fam = binomial()) {
  fit <- try(glm(formula, data = dd, family = fam), silent = TRUE)
  if (inherits(fit, "try-error")) return(invisible(NULL))
  co <- summary(fit)$coefficients
  if (!"panel_z" %in% rownames(co)) return(invisible(NULL))
  ctx_rows[[length(ctx_rows) + 1L]] <<- data.frame(
    model = label,
    OR_per_SD = exp(co["panel_z", "Estimate"]),
    CI_low = exp(co["panel_z", "Estimate"] - 1.96 * co["panel_z", "Std. Error"]),
    CI_high = exp(co["panel_z", "Estimate"] + 1.96 * co["panel_z", "Std. Error"]),
    P = co["panel_z", "Pr(>|z|)"],
    n = nrow(fit$model),
    stringsAsFactors = FALSE
  )
}
if (!"panel_z" %in% names(dd)) dd$panel_z <- as.numeric(scale(dd$panel))
add_ctx("panel only", is_dmmr ~ panel_z)
add_ctx("panel + stage", is_dmmr ~ panel_z + stage_f)
add_ctx("panel + age + sex", is_dmmr ~ panel_z + age + sex)
add_ctx("panel + age + sex + stage + chemo",
        is_dmmr ~ panel_z + age + sex + stage_f + chemo)
if (length(ctx_rows)) {
  ctx <- do.call(rbind, ctx_rows)
  ctx[, c("OR_per_SD", "CI_low", "CI_high")] <-
    round(ctx[, c("OR_per_SD", "CI_low", "CI_high")], 3)
  ctx$P <- signif(ctx$P, 3)
  write.csv(ctx, file.path(tab_dir, "qCSC_MMR_status_detail.csv"), row.names = FALSE)
  cat("\n--- logistic regression, dMMR ~ panel (odds ratio per SD) ---\n")
  print(ctx, row.names = FALSE)
  or_adj <- ctx$OR_per_SD[nrow(ctx)]
  or_adj_p <- ctx$P[nrow(ctx)]
} else {
  or_adj <- NA_real_; or_adj_p <- NA_real_
}

# ------------------------------------------------------------
# ------------------------------------------------------------
roc_pts <- function(score, y) {
  thr <- unique(sort(score, decreasing = TRUE))
  sens <- vapply(thr, function(t) mean(score[y == 1] >= t), numeric(1))
  spec <- vapply(thr, function(t) mean(score[y == 0] < t), numeric(1))
  data.frame(fpr = 1 - spec, tpr = sens)
}
draw <- function() {
  par(mar = c(4.6, 4.6, 4.6, 1.2), mgp = c(2.6, 0.7, 0))
  r <- roc_pts(dd$panel, y)
  plot(NA, xlim = c(0, 1), ylim = c(0, 1), xaxs = "i", yaxs = "i", bty = "l",
       xlab = "1 - Specificity", ylab = "Sensitivity (dMMR)",
       main = sprintf("qCSC-like panel reads MMR status in GSE39582\n(dMMR = %d, pMMR = %d)",
                      sum(y), sum(!y)), las = 1, cex.main = 1.0, font.main = 2)
  abline(0, 1, lty = 3, col = "grey55")
  lines(r$fpr, r$tpr, col = "#D95F0E", lwd = 2.6)
  a <- res$auc[res$comparison == "panel score (20 genes)"]
  lo <- res$ci_low[res$comparison == "panel score (20 genes)"]
  hi <- res$ci_high[res$comparison == "panel score (20 genes)"]
  legend("bottomright", bty = "n", lwd = 2.6, col = "#D95F0E",
         legend = sprintf("panel, AUC = %.3f (%.3f-%.3f)", a, lo, hi))
  if (!is.na(or_adj)) {
    mtext(sprintf("adjusted OR per SD = %.2f, P = %s",
                  or_adj, if (or_adj_p < 0.001) "< 0.001" else formatC(or_adj_p, format = "f", digits = 3)),
          side = 3, line = 0.1, cex = 0.78, col = "grey25")
  }
}
png(file.path(fig_dir, "Fig13_qCSC_MMR_status.png"), width = 2400, height = 2200, res = 300)
draw(); dev.off()
pdf(file.path(fig_dir, "Fig13_qCSC_MMR_status.pdf"), width = 4.6, height = 4.3)
draw(); dev.off()

# ------------------------------------------------------------
# ------------------------------------------------------------
getv <- function(lbl, col) {
  v <- res[[col]][res$comparison == lbl]
  if (!length(v)) NA_real_ else v[1]
}
new_rows <- data.frame(
  section = rep("qCSC_MMR_readout", 6),
  metric = c("GSE39582_n_dMMR", "GSE39582_n_pMMR",
             "panel_AUC_dMMR", "panel_AUC_CI_low", "panel_AUC_CI_high",
             "panel_OR_per_SD_fully_adjusted"),
  value = c(sum(y), sum(!y),
            getv("panel score (20 genes)", "auc"),
            getv("panel score (20 genes)", "ci_low"),
            getv("panel score (20 genes)", "ci_high"),
            or_adj),
  note = c("IHC/molecular MMR annotation", "",
           "endpoint re-fitted: MMR status instead of prognosis",
           "bootstrap percentile CI", "",
           "logistic model, adjusted for age+sex+stage+chemo"),
  stringsAsFactors = FALSE
)
summ_file <- file.path(tab_dir, "FINAL_RESULTS_SUMMARY.csv")
if (file.exists(summ_file)) {
  old <- read.csv(summ_file, check.names = FALSE, stringsAsFactors = FALSE)
  old <- old[old$section != "qCSC_MMR_readout", ]
  old$value <- as.character(old$value); new_rows$value <- as.character(new_rows$value)
  all_s <- rbind(old[, c("section", "metric", "value", "note")], new_rows)
} else {
  all_s <- new_rows
}
write.csv(all_s, summ_file, row.names = FALSE)

cat("\n================ qCSC panel as MMR readout ================\n")
cat(sprintf("AUC = %.3f (95%% CI %.3f-%.3f), n = %d (%d dMMR / %d pMMR)\n",
            getv("panel score (20 genes)", "auc"),
            getv("panel score (20 genes)", "ci_low"),
            getv("panel score (20 genes)", "ci_high"),
            nrow(dd), sum(y), sum(!y)))
cat(sprintf("Adjusted OR per SD = %.2f, P = %s\n", or_adj,
            if (is.na(or_adj_p)) "NA" else signif(or_adj_p, 3)))
cat("
Interpretation: AUC >= 0.80 with a CI excluding 0.5 => 'transcriptional readout of MMR status' may be stated
")
cat("Table: ", file.path(tab_dir, "qCSC_MMR_status_auc.csv"), "\n")
cat("Figure: ", file.path(fig_dir, "Fig13_qCSC_MMR_status.png"), "\n")
