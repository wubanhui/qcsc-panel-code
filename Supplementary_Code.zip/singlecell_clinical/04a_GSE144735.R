## ===========================================================================
## singlecell_clinical/04a_GSE144735.R
## Independent single-cell validation in GSE144735 (6,168 epithelial cells).
## ===========================================================================
# ============================================================
# 06_external_validation.R
#
#
#   GSE144735_processed_KUL3_CRC_10X_raw_UMI_count_matrix.txt.gz
#   GSE144735_processed_KUL3_CRC_10X_annotation.txt.gz
#
#   tables/external_GSE144735_validation.csv
#   tables/external_GSE144735_summary.csv
#   tables/external_GSE144735_patient_level.csv
#   figures/Fig11_external_validation.png
#   objects/external_GSE144735_scores.rds
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

suppressPackageStartupMessages({
  library(Matrix)
  library(data.table)
  library(ggplot2)
  library(patchwork)
})

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
obj_dir <- file.path(QCSC_PROJECT_DIR, "objects")
panel_dir <- file.path(QCSC_PROJECT_DIR, "intermediate", "two_cohort_panel")
for (d in c(tab_dir, fig_dir, obj_dir)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

root <- ROOT_SC
ext_dir <- file.path(root, "external", "GSE144735")
mat_file <- file.path(ext_dir, "GSE144735_processed_KUL3_CRC_10X_raw_UMI_count_matrix.txt.gz")
ann_file <- file.path(ext_dir, "GSE144735_processed_KUL3_CRC_10X_annotation.txt.gz")

if (!file.exists(mat_file) || !file.exists(ann_file)) {
  stop(
    "GSE144735 files missing. Please download them and place them in:
  ", ext_dir,
    "
Required files:
  ", basename(mat_file), "\n  ", basename(ann_file),
    "
Download: https://ftp.ncbi.nlm.nih.gov/geo/series/GSE144nnn/GSE144735/suppl/
"
  )
}

# ------------------------------------------------------------
# ------------------------------------------------------------
panel_file <- file.path(tab_dir, "final_panel_stable.csv")
if (!file.exists(panel_file)) stop("Cannot find final_panel_stable.csv; please run 03b first")
panel <- read.csv(panel_file, check.names = FALSE, stringsAsFactors = FALSE)
panel_genes <- toupper(panel$gene)
panel_up <- toupper(panel$gene[panel$direction == "UP"])
panel_down <- toupper(panel$gene[panel$direction == "DOWN"])
message("Panel: ", length(panel_up), " UP + ", length(panel_down), " DOWN = ",
        length(panel_genes), " genes")

data_file <- file.path(panel_dir, "panel_data.rds")
if (!file.exists(data_file)) stop("Cannot find panel_data.rds; please run 02b first")
d <- readRDS(data_file)
full_up <- d$up_use
full_down <- d$down_use
full_genes <- c(full_up, full_down)
message("Full signature: ", length(full_up), " UP + ", length(full_down), " DOWN")

# ------------------------------------------------------------
# ------------------------------------------------------------
message("Reading the raw count matrix (54 MB gzip, read in chunks, this takes a few minutes)...")

con <- gzfile(mat_file, open = "rt")
header <- readLines(con, n = 1L, warn = FALSE)
if (length(header) != 1L) {
  close(con)
  stop("Failed to read the matrix header: ", mat_file)
}
cells <- strsplit(header, "\t", fixed = TRUE)[[1]][-1]
if (anyNA(cells) || any(cells == "")) {
  close(con)
  stop("The matrix contains empty cell IDs")
}
message("Matrix cells: ", length(cells))

chunk_size <- 200L
gene_names <- character()
chunks <- list()
n_read <- 0L
repeat {
  lines <- readLines(con, n = chunk_size, warn = FALSE)
  if (!length(lines)) break
  parsed <- strsplit(lines, "\t", fixed = TRUE)
  if (any(lengths(parsed) != length(cells) + 1L)) {
    close(con)
    stop("Inconsistent number of matrix fields; abnormal rows: ", n_read + 1L)
  }
  genes <- vapply(parsed, `[`, character(1), 1)
  vals <- lapply(parsed, function(x) suppressWarnings(as.numeric(x[-1])))
  nz <- lapply(vals, function(x) which(x != 0))
  ii <- rep.int(seq_along(vals), lengths(nz))
  jj <- unlist(nz, use.names = FALSE)
  xx <- unlist(Map(function(x, i) x[i], vals, nz), use.names = FALSE)
  chunks[[length(chunks) + 1L]] <- Matrix::sparseMatrix(
    i = as.integer(ii), j = as.integer(jj), x = xx,
    dims = c(length(vals), length(cells)), giveCsparse = TRUE
  )
  gene_names <- c(gene_names, genes)
  n_read <- n_read + length(lines)
  if (n_read %% 5000L < chunk_size) cat("  gene rows read: ", n_read, "\n")
}
close(con)

mat <- do.call(rbind, chunks)
rm(chunks); gc()
genes <- toupper(trimws(gene_names))
rownames(mat) <- genes
colnames(mat) <- trimws(cells)
message("Matrix dimensions: ", nrow(mat), " x ", ncol(mat))

keep_row <- !is.na(genes) & nzchar(genes)
mat <- mat[keep_row, , drop = FALSE]
genes <- genes[keep_row]
seg_tot <- Matrix::rowSums(mat)
ord <- order(genes, -seg_tot)
mat <- mat[ord, , drop = FALSE]
genes <- genes[ord]
keep_dup <- !duplicated(genes)
mat <- mat[keep_dup, , drop = FALSE]
genes <- genes[keep_dup]
rownames(mat) <- genes
message("After de-duplication by symbol: ", nrow(mat), " genes x ", ncol(mat), " cells")

# ------------------------------------------------------------
# ------------------------------------------------------------
message("Reading the annotation...")
ann <- fread(
  file = ann_file,
  sep = "\t", header = TRUE, data.table = FALSE,
  showProgress = FALSE
)
message("Annotation dimensions: ", nrow(ann), " x ", ncol(ann))
message("Annotation columns: ", paste(colnames(ann), collapse = ", "))

pick_col <- function(cands, cols) {
  hit <- cands[cands %in% cols]
  if (length(hit)) return(hit[1])
  NA_character_
}
id_col <- pick_col(c("Index", "Cell", "Barcode", "cell_id", "CellID"), colnames(ann))
if (is.na(id_col)) id_col <- colnames(ann)[1]
sample_col <- pick_col(
  c("Sample", "sample", "SampleID", "orig.ident", "Library"),
  colnames(ann)
)
type_col <- pick_col(
  c("Cell_type", "CellType", "cell_type", "celltype", "type", "Annotation"),
  colnames(ann)
)
class_col <- pick_col(
  c("Class", "Tissue", "tissue", "Type", "Status", "source"),
  colnames(ann)
)
cat("Columns used: id = ", id_col,
    "| sample =", sample_col,
    "| cell_type =", type_col,
    "| class =", class_col, "\n")

ann[[id_col]] <- trimws(as.character(ann[[id_col]]))
ann <- ann[match(colnames(mat), ann[[id_col]]), , drop = FALSE]
if (all(is.na(ann[[id_col]]))) {
  stop("The cell IDs in the annotation cannot be matched to the matrix column names. Check the id_col setting.")
}

meta <- data.frame(
  cell = colnames(mat),
  sample = if (!is.na(sample_col)) as.character(ann[[sample_col]]) else "unknown",
  cell_type = if (!is.na(type_col)) as.character(ann[[type_col]]) else "unknown",
  stringsAsFactors = FALSE
)
if (!is.na(class_col)) {
  meta$class <- as.character(ann[[class_col]])
}

# ------------------------------------------------------------
# ------------------------------------------------------------
epi_flag <- grepl("epithelial", meta$cell_type, ignore.case = TRUE)
if (sum(epi_flag) < 100) {
  warning("Too few epithelial cells found by cell_type (", sum(epi_flag),
          "), falling back to the EPCAM/KRT18 markers")
  markers <- intersect(c("EPCAM", "KRT18", "KRT8", "KRT19"), rownames(mat))
  if (length(markers) >= 2) {
    lib <- Matrix::colSums(mat)
    m <- mat[markers, , drop = FALSE]
    m <- m %*% Matrix::Diagonal(x = 1e4 / pmax(lib, 1))
    m <- log1p(m)
    epi_flag <- Matrix::colMeans(m) > 0.5
  }
}
message("Epithelial cells: ", sum(epi_flag), " / ", ncol(mat))

sub_cells <- colnames(mat)[epi_flag]
meta <- meta[epi_flag, , drop = FALSE]
mat <- mat[, sub_cells, drop = FALSE]

# ------------------------------------------------------------
# ------------------------------------------------------------
lib <- Matrix::colSums(mat)
bad <- lib <= 0
if (any(bad)) {
  mat <- mat[, !bad, drop = FALSE]
  meta <- meta[!bad, , drop = FALSE]
  lib <- lib[!bad]
}
norm <- mat %*% Matrix::Diagonal(x = 1e4 / lib)
norm <- log1p(norm)
rm(mat); gc()

# ------------------------------------------------------------
# ------------------------------------------------------------
f_up <- intersect(full_up, rownames(norm))
f_down <- intersect(full_down, rownames(norm))
p_up <- intersect(panel_up, rownames(norm))
p_down <- intersect(panel_down, rownames(norm))

cat("Genes in the full score: ", length(f_up), "/", length(full_up),
    " UP, ", length(f_down), "/", length(f_down), " DOWN\n")
cat("Panel genes: ", length(p_up), "/", length(panel_up),
    " UP, ", length(p_down), "/", length(panel_down), " DOWN\n")

mean_genes <- function(x, genes) {
  if (!length(genes)) return(rep(0, ncol(x)))
  as.numeric(Matrix::colMeans(x[genes, , drop = FALSE]))
}
score_full <- mean_genes(norm, f_up) - mean_genes(norm, f_down)
score_panel <- mean_genes(norm, p_up) - mean_genes(norm, p_down)

meta$full_score <- as.numeric(score_full)
meta$panel_score <- as.numeric(score_panel)

# ------------------------------------------------------------
# ------------------------------------------------------------
auc_high_low <- function(p, f) {
  hi <- f >= quantile(f, 0.90)
  lo <- f <= quantile(f, 0.10)
  w <- wilcox.test(p[hi], p[lo], exact = FALSE)
  as.numeric(w$statistic) / (sum(hi) * sum(lo))
}

res <- data.frame(
  cohort = "GSE144735",
  n_cells = nrow(meta),
  n_patients = length(unique(meta$sample)),
  n_genes_full = length(f_up) + length(f_down),
  n_genes_panel = length(p_up) + length(p_down),
  cell_r = cor(score_panel, score_full),
  cell_spearman = cor(score_panel, score_full, method = "spearman"),
  qcsc_high_low_auc = auc_high_low(score_panel, score_full),
  stringsAsFactors = FALSE
)

if ("class" %in% colnames(meta)) {
  lab <- unique(meta$class[!is.na(meta$class)])
  cat("Class values: ", paste(lab, collapse = ", "), "\n")
  tum <- grepl("tumou?r|cancer|malignant|tumour", meta$class, ignore.case = TRUE)
  nor <- grepl("normal|adjacent|normal tissue", meta$class, ignore.case = TRUE)
  if (sum(tum) > 10 && sum(nor) > 10) {
    w <- wilcox.test(meta$panel_score[tum], meta$panel_score[nor], exact = FALSE)
    a <- as.numeric(w$statistic) / (sum(tum) * sum(nor))
    res$tumour_vs_normal_auc <- a
    res$tumour_vs_normal_auc_oriented <- max(a, 1 - a)
    res$n_tumour <- sum(tum)
    res$n_normal <- sum(nor)
    res$panel_tumour_mean <- mean(meta$panel_score[tum])
    res$panel_normal_mean <- mean(meta$panel_score[nor])
    res$full_tumour_mean <- mean(meta$full_score[tum])
    res$full_normal_mean <- mean(meta$full_score[nor])
  } else {
    warning("Insufficient tumour or normal cells in the Class column (tumour=", sum(tum),
            ", normal=", sum(nor), "), skipping the tumour-versus-normal comparison")
  }
}

pat <- aggregate(
  cbind(panel_score, full_score) ~ sample,
  data = meta, FUN = mean
)
pat <- pat[!is.na(pat$sample) & pat$sample != "unknown", ]
if (nrow(pat) >= 3) {
  res$patient_r <- cor(pat$panel_score, pat$full_score)
  res$n_patients_used <- nrow(pat)
}
write.csv(pat, file.path(tab_dir, "external_GSE144735_patient_level.csv"), row.names = FALSE)
write.csv(res, file.path(tab_dir, "external_GSE144735_validation.csv"), row.names = FALSE)
print(res, row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
p1 <- ggplot(meta, aes(full_score, panel_score)) +
  geom_point(alpha = 0.3, size = 0.4, color = "#2C3E50") +
  geom_smooth(method = "lm", se = FALSE, color = "#E67E22") +
  annotate("text", x = -Inf, y = Inf, hjust = -0.05, vjust = 1.2, size = 3.5,
           label = sprintf("r = %.3f\nn = %d", res$cell_r, res$n_cells)) +
  labs(x = "Full 822-gene score", y = "Panel score",
       title = "A  GSE144735 external validation") +
  theme_classic(base_size = 11) +
  theme(plot.title = element_text(face = "bold"))

plots <- list(p1)

if ("class" %in% colnames(meta) && sum(!is.na(meta$class)) > 0) {
  meta$class_grp <- ifelse(
    grepl("tumou?r|cancer|malignant", meta$class, ignore.case = TRUE), "Tumour",
    ifelse(grepl("normal|adjacent", meta$class, ignore.case = TRUE), "Normal", NA)
  )
  sub <- meta[!is.na(meta$class_grp), ]
  if (nrow(sub) > 20) {
    p2 <- ggplot(sub, aes(class_grp, panel_score, fill = class_grp)) +
      geom_boxplot(outlier.shape = NA, width = 0.55) +
      geom_jitter(width = 0.12, size = 0.2, alpha = 0.15) +
      scale_fill_manual(values = c(Normal = "#27AE60", Tumour = "#C0392B")) +
      labs(x = NULL, y = "Panel score", title = "B  Tumour vs normal epithelium") +
      theme_classic(base_size = 11) +
      theme(legend.position = "none",
            plot.title = element_text(face = "bold"))
    plots <- c(plots, list(p2))
  }
}

if (nrow(pat) >= 3) {
  p3 <- ggplot(pat, aes(full_score, panel_score)) +
    geom_point(size = 2, color = "#2C3E50") +
    geom_smooth(method = "lm", se = FALSE, color = "#E67E22") +
    annotate("text", x = -Inf, y = Inf, hjust = -0.05, vjust = 1.2, size = 3.5,
             label = sprintf("r = %.3f\nn = %d patients", res$patient_r, nrow(pat))) +
    labs(x = "Full score (patient mean)", y = "Panel score (patient mean)",
         title = "C  Patient-level agreement") +
    theme_classic(base_size = 11) +
    theme(plot.title = element_text(face = "bold"))
  plots <- c(plots, list(p3))
}

fig <- if (length(plots) == 1) plots[[1]] else wrap_plots(plots, nrow = 1)
ggsave(file.path(fig_dir, "Fig11_external_validation.png"),
       fig, width = 5 * length(plots), height = 4.5, dpi = 300, bg = "white")
ggsave(file.path(fig_dir, "Fig11_external_validation.pdf"),
       fig, width = 5 * length(plots), height = 4.5, bg = "white")

# ------------------------------------------------------------
# ------------------------------------------------------------
saveRDS(
  list(res = res, meta = meta, patient = pat,
       panel_genes = c(panel_up, panel_down),
       full_genes = full_genes),
  file.path(obj_dir, "external_GSE144735_scores.rds")
)

cat("
================ External validation summary ================
")
cat("Cell-level r: ", round(res$cell_r, 3), "\n")
cat("qCSC high/low AUC:", round(res$qcsc_high_low_auc, 3), "\n")
if ("tumour_vs_normal_auc" %in% colnames(res)) {
  cat("Tumour vs normal AUC (tumour as positive): ", round(res$tumour_vs_normal_auc, 3), "\n")
}
if ("patient_r" %in% colnames(res)) {
  cat("Patient-level r: ", round(res$patient_r, 3), "\n")
}
cat("
Interpretation:
")
cat("  r >= 0.80 and AUC >= 0.70 => 'externally validated' may be stated
")
cat("  otherwise state 'partially validated'
")
cat("
Results: 
", file.path(tab_dir, "external_GSE144735_validation.csv"), "\n")
cat("Figure: ", file.path(fig_dir, "Fig11_external_validation.png"), "\n")
