## ===========================================================================
## singlecell_clinical/04c_GSE14333_DFS.R
## Bulk validation in GSE14333: disease-free survival.
## ===========================================================================
# ============================================================
# 08c_external_validation_GSE14333_DFS.R
#
#
#
#
#   tables/final_panel_stable.csv
#   scripts/external_bulk_helpers.R
#
#   tables/external_GSE14333_scores.csv
#   tables/external_GSE14333_cox.csv
#   tables/external_GSE14333_survival.csv
#   figures/Fig14_external_GSE14333_DFS.png / .pdf
#   objects/external_GSE14333.rds
# ============================================================

options(stringsAsFactors = FALSE)
set.seed(1234)

## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "external_bulk_helpers.R"))

tab_dir <- TAB_DIR
fig_dir <- FIG_DIR
obj_dir   <- file.path(QCSC_PROJECT_DIR, "objects")
panel_dir <- file.path(QCSC_PROJECT_DIR, "intermediate", "two_cohort_panel")
for (d in c(tab_dir, fig_dir, obj_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

root <- ROOT_SC
ext_dir  <- file.path(root, "external", "GSE14333")
mat_file <- file.path(ext_dir, "GSE14333_series_matrix.txt.gz")
if (!file.exists(mat_file)) stop("GSE14333 series matrix missing: ", mat_file)

# ------------------------------------------------------------
# ------------------------------------------------------------
panel <- read.csv(file.path(tab_dir, "final_panel_stable.csv"),
                  check.names = FALSE, stringsAsFactors = FALSE)
panel_up   <- toupper(panel$gene[panel$direction == "UP"])
panel_down <- toupper(panel$gene[panel$direction == "DOWN"])
cat(sprintf("Frozen panel: %d UP + %d DOWN = %d genes\n",
            length(panel_up), length(panel_down), length(panel_up) + length(panel_down)))

full_up <- full_down <- NULL
data_file <- file.path(panel_dir, "panel_data.rds")
if (file.exists(data_file)) {
  d <- readRDS(data_file)
  full_up <- toupper(d$up_use); full_down <- toupper(d$down_use)
  rm(d); gc()
  cat(sprintf("Full signature: %d UP + %d DOWN\n", length(full_up), length(full_down)))
}
target_genes <- unique(c(panel_up, panel_down, full_up, full_down))
cat("Genes to pull:", length(target_genes), "\n")

# ------------------------------------------------------------
# ------------------------------------------------------------
pm <- get_probe_map(target_genes)
cat(sprintf("Probes for target genes: %d\n", length(pm$target_probes)))
rd <- read_series_matrix(mat_file, target_genes, pm$probe2gene)
expr <- rd$expr; clin <- rd$clin
missing_panel <- setdiff(c(panel_up, panel_down), rownames(expr))
if (length(missing_panel)) stop("Panel genes missing: ", paste(missing_panel, collapse = ", "))

# ------------------------------------------------------------
#    "Location: Right; DukesStage: A; Age_Diag: 78; ..."
# ------------------------------------------------------------
parse_packed <- function(s) {
  parts <- trimws(strsplit(s, ";", fixed = TRUE)[[1]])
  out <- list()
  for (p in parts) {
    if (grepl(":", p, fixed = TRUE)) {
      out[[trimws(sub(":.*$", "", p))]] <- trimws(sub("^[^:]*:", "", p))
    } else if (nzchar(p)) {
      out[["Location"]] <- p
    }
  }
  out
}
ch_field <- grep("^Location|^DukesStage", names(clin), value = TRUE)
if (!length(ch_field)) ch_field <- setdiff(names(clin), c("gsm", "title"))[1]
packed <- clin[[ch_field[1]]]
parsed <- lapply(packed, parse_packed)
keys <- unique(unlist(lapply(parsed, names)))
mx <- do.call(rbind, lapply(parsed, function(x) {
  setNames(vapply(keys, function(k) if (is.null(x[[k]])) NA_character_ else x[[k]],
                  character(1)), keys)
}))
cd <- as.data.frame(mx, stringsAsFactors = FALSE)

num <- function(x) suppressWarnings(as.numeric(x))
dat <- data.frame(
  gsm      = clin$gsm,
  title    = clin$title,
  location = cd$Location,
  dukes    = cd$DukesStage,
  age      = num(cd$Age_Diag),
  sex      = cd$Gender,
  dfs_time = num(cd$DFS_Time),
  dfs_cens = num(cd$DFS_Cens),
  adj_ctx  = cd$AdjCTX,
  adj_xrt  = cd$AdjXRT,
  stringsAsFactors = FALSE
)
dat$dfs_event <- ifelse(is.na(dat$dfs_cens), NA, ifelse(dat$dfs_cens == 1, 0, 1))
cat(sprintf("\nSamples: %d ; DFS available: %d ; DFS events: %d (%.1f%%)\n",
            nrow(dat), sum(!is.na(dat$dfs_time) & !is.na(dat$dfs_event)),
            sum(dat$dfs_event == 1, na.rm = TRUE),
            100 * mean(dat$dfs_event == 1, na.rm = TRUE)))
print(table(dat$dukes, useNA = "ifany"))

# ------------------------------------------------------------
# ------------------------------------------------------------
is_tumour <- rep(TRUE, nrow(dat))
sc <- score_panels(expr, panel_up, panel_down, is_tumour, full_up, full_down)
dat$panel    <- sc$panel
dat$full     <- if (is.null(sc$full)) NA_real_ else sc$full
dat$panel_z  <- sc$panel_z
dat$full_z   <- if (is.null(sc$full_z)) NA_real_ else sc$full_z

dat$dukes_f <- factor(dat$dukes, levels = c("A", "B", "C", "D"))
dat$sex     <- factor(dat$sex, levels = c("F", "M"))
dat$adj_ctx <- factor(dat$adj_ctx, levels = c("N", "Y"))
dat$adj_xrt <- factor(dat$adj_xrt, levels = c("N", "Y"))

write.csv(dat, file.path(tab_dir, "external_GSE14333_scores.csv"), row.names = FALSE)

# ------------------------------------------------------------
# ------------------------------------------------------------
dd <- dat[!is.na(dat$dfs_time) & !is.na(dat$dfs_event) & dat$dfs_time > 0, ]
dd$T <- dd$dfs_time; dd$E <- dd$dfs_event
cat(sprintf("\nAnalysis set: n = %d ; events = %d\n", nrow(dd), sum(dd$E)))
dd$group <- factor(ifelse(dd$panel >= median(dd$panel), "high", "low"),
                   levels = c("low", "high"))

cox_rows <- list()
cox_rows[[1]] <- cox_row(coxph(Surv(T, E) ~ panel_z, data = dd), "DFS",
                         "panel continuous (per SD), univariable")
f_adj <- coxph(Surv(T, E) ~ panel_z + age + sex + dukes_f + adj_ctx, data = dd)
cox_rows[[2]] <- cox_row(f_adj, "DFS", "panel continuous (per SD), adjusted",
                         "adjusted for age + sex + Dukes stage + adjuvant chemo")
cox_rows[[3]] <- cox_row(coxph(Surv(T, E) ~ group, data = dd), "DFS",
                         "panel high vs low (median split)")
if (!all(is.na(dd$full_z))) {
  cox_rows[[4]] <- cox_row(coxph(Surv(T, E) ~ full_z, data = dd), "DFS",
                           "full signature (per SD), univariable",
                           "comparator: panel vs whole signature")
}
dd$dukes_num <- as.numeric(dd$dukes_f)
for (sp in list(
  list(v = "dukes_num", lab = "Dukes stage (per stage)"),
  list(v = "age",       lab = "age (per year)"),
  list(v = "sex",       lab = "sex (M vs F)"),
  list(v = "adj_ctx",   lab = "adjuvant chemo (Y vs N)")
)) {
  if (all(is.na(dd[[sp$v]]))) next
  fit <- try(coxph(as.formula(sprintf("Surv(T, E) ~ %s", sp$v)), data = dd), silent = TRUE)
  if (inherits(fit, "try-error")) next
  cox_rows[[length(cox_rows) + 1L]] <- cox_row(
    fit, "DFS", paste0("positive control: ", sp$lab),
    sprintf("known prognostic factor; n = %d, events = %d", fit$n, fit$nevent))
}
cox_df <- do.call(rbind, cox_rows)

sd  <- survdiff(Surv(T, E) ~ group, data = dd)
lr  <- pchisq(sd$chisq, df = length(sd$n) - 1, lower.tail = FALSE)
cidx <- concordance(Surv(T, E) ~ panel_z, data = dd, reverse = TRUE)$concordance
auc36 <- ipcw_auc(dd$T, dd$E, dd$panel, 36)
auc60 <- ipcw_auc(dd$T, dd$E, dd$panel, 60)
hr_hi <- exp(coef(coxph(Surv(T, E) ~ group, data = dd)))[["grouphigh"]]

cat(sprintf("\nlog-rank P = %s ; HR(high vs low) = %.2f\n", fmt_p(lr), hr_hi))
cat(sprintf("C-index = %.3f ; IPCW AUC 3y = %.3f ; 5y = %.3f\n", cidx, auc36, auc60))
cat(sprintf("adjusted HR per SD = %.2f (%.2f-%.2f), P = %s ; N = %d, events = %d\n",
            cox_df$HR[2], cox_df$CI_low[2], cox_df$CI_high[2], fmt_p(cox_df$P[2]),
            cox_df$n[2], cox_df$events[2]))

n_ev <- sum(dd$E)
cat(sprintf("\nPower note: %d events -> minimal detectable HR (80%% power, alpha=0.05) ~ %.2f per SD\n",
            n_ev, exp(2.802 / sqrt(n_ev))))

surv_df <- data.frame(
  endpoint = "DFS",
  metric = c("n", "events", "logrank_P", "HR_high_vs_low",
             "c_index", "ipcw_auc_3y", "ipcw_auc_5y", "min_detectable_HR"),
  value = c(nrow(dd), n_ev, lr, hr_hi, cidx, auc36, auc60,
            exp(2.802 / sqrt(n_ev))),
  stringsAsFactors = FALSE
)

# ------------------------------------------------------------
# ------------------------------------------------------------
hr_txt <- sprintf("adj. HR/SD = %.2f (%.2f-%.2f), P = %s",
                  cox_df$HR[2], cox_df$CI_low[2], cox_df$CI_high[2],
                  fmt_p(cox_df$P[2]))
draw <- function() {
  par(mar = c(4.6, 4.6, 3.4, 1.2), mgp = c(2.6, 0.7, 0))
  plot_km_one(dd$T, dd$E, dd$group, "Disease-free survival",
              sprintf("GSE14333 (n = %d, events = %d)", nrow(dd), n_ev), hr_txt)
}
png(file.path(fig_dir, "Fig14_external_GSE14333_DFS.png"),
    width = 2400, height = 2000, res = 300)
draw(); dev.off()
pdf(file.path(fig_dir, "Fig14_external_GSE14333_DFS.pdf"), width = 4.8, height = 4.2)
draw(); dev.off()

# ------------------------------------------------------------
# ------------------------------------------------------------
cox_df$HR <- round(cox_df$HR, 3); cox_df$CI_low <- round(cox_df$CI_low, 3)
cox_df$CI_high <- round(cox_df$CI_high, 3); cox_df$P <- signif(cox_df$P, 3)
write.csv(cox_df, file.path(tab_dir, "external_GSE14333_cox.csv"), row.names = FALSE)
surv_df$value <- signif(surv_df$value, 4)
write.csv(surv_df, file.path(tab_dir, "external_GSE14333_survival.csv"), row.names = FALSE)

saveRDS(list(dat = dat, cox = cox_df, surv = surv_df,
             panel_up = panel_up, panel_down = panel_down,
             z_all = sc$z_all),
        file.path(obj_dir, "external_GSE14333.rds"))

getv <- function(m) surv_df$value[surv_df$metric == m]
cg <- function(model, col) {
  v <- cox_df[[col]][cox_df$model == model]
  if (!length(v)) NA_real_ else v[1]
}
new_rows <- data.frame(
  section = rep("external_GSE14333", 7),
  metric = c("n", "events", "DFS_HR_per_SD_univariable", "DFS_HR_per_SD_adjusted",
             "DFS_logrank_P", "DFS_c_index", "min_detectable_HR"),
  value = c(getv("n"), getv("events"),
            cg("panel continuous (per SD), univariable", "HR"),
            cg("panel continuous (per SD), adjusted", "HR"),
            getv("logrank_P"), getv("c_index"), getv("min_detectable_HR")),
  note = c("Dukes A-D, GPL570", "DFS events (0=event, 1=censored)",
           sprintf("95%% CI %.2f-%.2f, P = %s",
                   cg("panel continuous (per SD), univariable", "CI_low"),
                   cg("panel continuous (per SD), univariable", "CI_high"),
                   fmt_p(cg("panel continuous (per SD), univariable", "P"))),
           sprintf("95%% CI %.2f-%.2f, P = %s; adj age+sex+Dukes+chemo",
                   cg("panel continuous (per SD), adjusted", "CI_low"),
                   cg("panel continuous (per SD), adjusted", "CI_high"),
                   fmt_p(cg("panel continuous (per SD), adjusted", "P"))),
           "median split", "Harrell", "80% power at alpha=0.05"),
  stringsAsFactors = FALSE
)
summ_file <- file.path(tab_dir, "FINAL_RESULTS_SUMMARY.csv")
if (file.exists(summ_file)) {
  old <- read.csv(summ_file, check.names = FALSE, stringsAsFactors = FALSE)
  old <- old[old$section != "external_GSE14333", ]
  old$value <- as.character(old$value); new_rows$value <- as.character(new_rows$value)
  all_s <- rbind(old[, c("section", "metric", "value", "note")], new_rows)
} else all_s <- new_rows
write.csv(all_s, summ_file, row.names = FALSE)

cat("\n================ GSE14333 DFS validation ================\n")
cat(sprintf("n = %d, DFS events = %d\n", nrow(dd), n_ev))
cat(sprintf("univariable HR/SD = %.2f (%.2f-%.2f), P = %s\n",
            cg("panel continuous (per SD), univariable", "HR"),
            cg("panel continuous (per SD), univariable", "CI_low"),
            cg("panel continuous (per SD), univariable", "CI_high"),
            fmt_p(cg("panel continuous (per SD), univariable", "P"))))
cat(sprintf("adjusted   HR/SD = %.2f (%.2f-%.2f), P = %s\n",
            cg("panel continuous (per SD), adjusted", "HR"),
            cg("panel continuous (per SD), adjusted", "CI_low"),
            cg("panel continuous (per SD), adjusted", "CI_high"),
            fmt_p(cg("panel continuous (per SD), adjusted", "P"))))
cat("Table: ", file.path(tab_dir, "external_GSE14333_cox.csv"), "\n")
cat("Figure: ", file.path(fig_dir, "Fig14_external_GSE14333_DFS.png"), "\n")
