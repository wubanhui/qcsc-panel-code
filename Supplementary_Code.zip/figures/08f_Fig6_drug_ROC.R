## ===========================================================================
## figures/08f_Fig6_drug_ROC.R
## Figure 4E-G: three-cohort MMR ROC and the subgroup AUC forest plot with the
## pooled estimate.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
############################################################
#
#   FigE_MMR_three_cohort_ROC.{pdf,png}
#   FigG_MMR_subgroup_AUC_with_pooled.{pdf,png}
#
############################################################

suppressPackageStartupMessages({
  library(pROC); library(ggplot2); library(data.table)
})

fig_dir <- FIG_DIR
val_dir <- MMR_DIR
tab_dir <- TAB_DIR
dir.create(fig_dir, showWarnings = FALSE, recursive = TRUE)

save_one <- function(p, stem, w, h) {
  ggsave(file.path(fig_dir, paste0(stem, ".pdf")), p, width = w, height = h, bg = "white")
  ggsave(file.path(fig_dir, paste0(stem, ".png")), p, width = w, height = h,
         dpi = 600, bg = "white")
  cat("saved:", stem, "\n")
}

BASE <- 16

## ==========================================================
## ==========================================================
roc_from_df <- function(d, score_col, label_col, label, pos_vals, neg_vals) {
  y <- ifelse(d[[label_col]] %in% pos_vals, 1L,
              ifelse(d[[label_col]] %in% neg_vals, 0L, NA_integer_))
  s  <- d[[score_col]]
  ok <- !is.na(y) & is.finite(s)
  if (sum(y[ok] == 1) < 5) { cat("skipped (fewer than 5 positives): ", label, "\n"); return(NULL) }
  r  <- roc(y[ok], s[ok], levels = c(0, 1), direction = "<", quiet = TRUE)
  ci <- ci.auc(r, method = "delong")
  cat(sprintf("%-10s n=%d (pos=%d)  AUC=%.4f (%.4f-%.4f)\n",
              label, sum(ok), sum(y[ok] == 1), ci[2], ci[1], ci[3]))
  list(roc = r, n = sum(ok), n_pos = sum(y[ok] == 1),
       auc = ci[2], lo = ci[1], hi = ci[3], label = label)
}

## ==========================================================
## ==========================================================
f1 <- file.path(tab_dir, "external_GSE39582_scores.csv")
x1 <- if (file.exists(f1)) {
  d <- fread(f1)
  n0 <- nrow(d)
  d  <- d[cohort != "Non Tumoral"]
  d  <- d[!is.na(mmr)]
  cat(sprintf("GSE39582: %d raw samples -> %d tumours with MMR annotation
", n0, nrow(d)))
  roc_from_df(d, "panel", "mmr", "GSE39582", c("dMMR"), c("pMMR"))
} else { cat("GSE39582 scores missing
"); NULL }

f2 <- file.path(val_dir, "GSE13294_panel_scores.csv")
x2 <- if (file.exists(f2)) {
  d <- fread(f2)
  roc_from_df(d, "panel_score", "msi", "GSE13294", c("MSI"), c("MSS"))
} else NULL

f3 <- file.path(val_dir, "GSE13067_MMS_scores.csv")
x3 <- if (file.exists(f3)) {
  d <- fread(f3)
  roc_from_df(d, "panel_score", "msi", "GSE13067", c("MSI"), c("MSS"))
} else NULL

roc_list <- Filter(Negate(is.null), list(x1, x2, x3))
cat("
Cohorts included: ", length(roc_list), "\n")
if (length(roc_list) < 3) warning("Fewer than three cohorts; please check the input files")

meta_f <- file.path(val_dir, "MMR_three_cohort_meta.csv")
pooled_auc <- pooled_lo <- pooled_hi <- NA_real_
if (file.exists(meta_f)) {
  m  <- fread(meta_f)
  pr <- m[grepl("Pooled", cohort)]
  if (nrow(pr)) { pooled_auc <- pr$AUC[1]; pooled_lo <- pr$CI_low[1]; pooled_hi <- pr$CI_high[1] }
}

## ==========================================================
## ==========================================================
rocf <- do.call(rbind, lapply(roc_list, function(x) {
  data.frame(fpr = 1 - x$roc$specificities, tpr = x$roc$sensitivities,
             cohort = x$label, stringsAsFactors = FALSE)
}))

lab_df <- data.frame(
  cohort = sapply(roc_list, `[[`, "label"),
  txt = sprintf("%s (n = %d): AUC %.3f (%.3f-%.3f)",
                sapply(roc_list, `[[`, "label"),
                sapply(roc_list, `[[`, "n"),
                sapply(roc_list, `[[`, "auc"),
                sapply(roc_list, `[[`, "lo"),
                sapply(roc_list, `[[`, "hi")),
  stringsAsFactors = FALSE
)

col_map <- c(GSE39582 = "#2166AC", GSE13294 = "#D95F0E", GSE13067 = "#00A087")
rocf$cohort <- factor(rocf$cohort, levels = intersect(names(col_map), rocf$cohort))

pE <- ggplot(rocf, aes(fpr, tpr, color = cohort)) +
  geom_abline(intercept = 0, slope = 1, linetype = 2, color = "grey60") +
  geom_path(linewidth = 1.1) +
  coord_equal() +
  scale_color_manual(values = col_map, name = NULL,
                     labels = setNames(lab_df$txt, lab_df$cohort)) +
  annotate("text", x = 0.38, y = 0.08, hjust = 0, size = 5.0, color = "grey20",
           label = if (is.finite(pooled_auc))
             sprintf("Pooled AUC = %.3f (%.3f-%.3f)\nI\u00B2 = 0%%",
                     pooled_auc, pooled_lo, pooled_hi)
           else "Pooled AUC = NA") +
  labs(x = "1 - Specificity", y = "Sensitivity (dMMR / MSI)",
       title = NULL, subtitle = NULL) +
  theme_classic(base_size = BASE) +
  theme(axis.text = element_text(size = 19, color = "black"),axis.title = element_text(size = 22),
        legend.position = c(0.62, 0.30),
        legend.text = element_text(size = 14),
        legend.key.size = unit(0.9, "lines"),
        legend.background = element_blank())

save_one(pE, "FigE_MMR_three_cohort_ROC", 6.8, 6.0)

## ==========================================================
## ==========================================================
sg_f <- file.path(tab_dir, "qCSC_MMR_subgroup_auc.csv")
if (file.exists(sg_f)) {
  sg <- fread(sg_f)
  sg <- sg[subgroup != "all"]
  
  sg <- sg[, .(subgroup, n, auc, ci_low, ci_high)]
  sg$group <- "GSE39582"
  
  if (is.finite(pooled_auc)) {
    add <- data.frame(subgroup = "Pooled (3 cohorts)",
                      n = sum(sapply(roc_list, `[[`, "n")),
                      auc = pooled_auc, ci_low = pooled_lo, ci_high = pooled_hi,
                      group = "Pooled", stringsAsFactors = FALSE)
    sg <- rbind(sg, add)
  }
  sg$subgroup <- factor(sg$subgroup, levels = rev(sg$subgroup))
  sg$group    <- factor(sg$group, levels = c("GSE39582", "Pooled"))
  
  pG <- ggplot(sg, aes(auc, subgroup, color = group)) +
    geom_vline(xintercept = 0.5, linetype = 2, color = "grey55") +
    geom_errorbarh(aes(xmin = ci_low, xmax = ci_high), height = 0.28, linewidth = 0.7) +
    geom_point(aes(size = n), shape = 16) +
    geom_text(aes(label = sprintf("%.3f (%.3f-%.3f)", auc, ci_low, ci_high)),
              vjust = -0.9, size = BASE / 5.2, show.legend = FALSE) +
    scale_color_manual(values = c(GSE39582 = "#2C3E50", Pooled = "#C0392B"), name = NULL) +
    scale_size_continuous(range = c(2.2, 5.2), name = "n") +
    scale_y_discrete(expand = expansion(add = 0.5)) +
    labs(x = "AUC for dMMR vs pMMR", y = NULL, title = NULL, subtitle = NULL) +
    theme_classic(base_size = BASE) +
    theme(
      axis.text = element_text(size = 19, color = "black"),
      axis.title = element_text(size = 20),   
      legend.position = "right"
    )
  save_one(pG, "FigG_MMR_subgroup_AUC_with_pooled", 7.8, 5.8)
} else {
  cat("qCSC_MMR_subgroup_auc.csv missing; panel G skipped
")
}