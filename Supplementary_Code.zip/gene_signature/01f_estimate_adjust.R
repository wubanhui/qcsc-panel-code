## ===========================================================================
## gene_signature/01f_estimate_adjust.R
##
## Re-run limma with ESTIMATE stromal and immune scores as covariates
## (1,595 DEG), intersect with the unadjusted model (1,295 genes) and compare
## the two Hallmark GSEA results.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))


############################################################
#
#       TCGA_CRC_qCSC_GSVA_ssGSEA_scores.csv
#
#      ESTIMATEScore
#
############################################################

options(stringsAsFactors = FALSE)

cat("
========== TCGA CRC ESTIMATE robustness analysis ==========
")


work_dir <- DATA_ROOT

find_latest_estimate_dir <- function(root = work_dir) {
  pointer <- file.path(root, "TCGA_CRC_ESTIMATE_GSVA_LATEST.txt")

  if (file.exists(pointer)) {
    p <- sub(
      "^\ufeff",
      "",
      trimws(readLines(pointer, warn = FALSE)[1])
    )
    if (!is.na(p) && dir.exists(p) &&
        file.exists(file.path(p, "DEG_ESTIMATE_adjusted_FINAL.csv"))) {
      return(p)
    }
  }

  cand <- list.dirs(root, recursive = FALSE, full.names = TRUE)
  cand <- cand[grepl("^TCGA_CRC_ESTIMATE_GSVA_", basename(cand))]
  cand <- cand[
    file.exists(file.path(cand, "DEG_ESTIMATE_adjusted_FINAL.csv"))
  ]

  if (length(cand) == 0) {
    stop(
      "No directory containing DEG_ESTIMATE_adjusted_FINAL.csv was found: ",
      "TCGA_CRC_ESTIMATE_GSVA_* directory.
",
      "Please run part 1 of this script first."
    )
  }

  cand[which.max(
    file.info(file.path(
      cand,
      "DEG_ESTIMATE_adjusted_FINAL.csv"
    ))$mtime
  )]
}

expr_file <- file.path(
  work_dir,
  "TCGA_CRC_380_samples.RData"
)

score_file <- file.path(
  work_dir,
  "TCGA_qCSC_score_GSVA",
  "TCGA_CRC_qCSC_GSVA_ssGSEA_scores.csv"
)

if (!file.exists(expr_file)) {
  stop("Expression matrix file not found: ", expr_file)
}

if (!file.exists(score_file)) {
  stop("GSVA score file not found: ", score_file)
}

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")

out_dir <- file.path(
  ESTIMATE_DIR,
  paste0("TCGA_CRC_ESTIMATE_GSVA_", timestamp)
)

dir.create(
  out_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

cat("Output directory: ", out_dir, "\n")


if (!requireNamespace("estimate", quietly = TRUE)) {
  stop(
    "
The estimate package is not installed.
",
    "Install the estimate package and confirm it loads before running this script."
  )
}

if (!requireNamespace("limma", quietly = TRUE)) {
  stop("The limma package is not installed; please install it.")
}

library(estimate)
library(limma)


env <- new.env(parent = emptyenv())
load(expr_file, envir = env)

available_objects <- ls(env)

cat("
Objects in the RData file:
")
print(available_objects)

expr_candidates <- c("expr_crc", "expr", "expr_mat")

expr_name <- expr_candidates[
  expr_candidates %in% available_objects
]

if (length(expr_name) == 0) {
  stop(
    "None of expr_crc, expr or expr_mat was found in the RData file.
",
    "Check the object names printed above to identify the expression matrix."
  )
}

expr <- as.matrix(
  env[[expr_name[1]]]
)

storage.mode(expr) <- "numeric"

cat("
Expression matrix object used: ", expr_name[1], "\n")
cat("Expression matrix dimensions: ", nrow(expr), "genes ×",
    ncol(expr), "samples\n")

if (is.null(rownames(expr)) || is.null(colnames(expr))) {
  stop("The expression matrix must have both gene and sample names.")
}

if (anyDuplicated(colnames(expr))) {
  stop("Duplicated sample names in the expression matrix; please verify.")
}

if (any(!is.finite(expr))) {
  stop("NA, NaN or Inf values in the expression matrix; please check the input data.")
}

if (any(expr < 0)) {
  stop(
    "Negative values in the expression matrix; check the expression scale and ",
    "do not feed negative values to ESTIMATE."
  )
}

normalize_sample_id <- function(x) {
  gsub(".", "-", x, fixed = TRUE)
}

colnames(expr) <- normalize_sample_id(colnames(expr))

if (anyDuplicated(colnames(expr))) {
  stop("Duplicated sample names after standardising the format; please verify.")
}


gene_ids <- trimws(rownames(expr))

is_ensembl_raw <- grepl(
  "^ENSG[0-9]+(\\.[0-9]+)?(_PAR_Y)?$",
  gene_ids
)

if (mean(is_ensembl_raw) > 0.5) {
  stop(
    "The expression matrix appears to use Ensembl IDs rather than gene symbols.
",
    "Map Ensembl IDs to HGNC gene symbols first, ",
    "then run ESTIMATE."
  )
}

gene_ids[is_ensembl_raw] <- sub(
  "\\.[0-9]+$",
  "",
  gene_ids[is_ensembl_raw]
)
rownames(expr) <- gene_ids

if (any(is.na(rownames(expr)) | rownames(expr) == "")) {
  stop("Empty gene names in the expression matrix; please fix before running.")
}

if (anyDuplicated(rownames(expr))) {
  
  cat("
Duplicated gene symbols found; keeping the row with the highest mean expression.
")
  
  gene_mean <- rowMeans(expr)
  
  keep_order <- order(
    gene_mean,
    decreasing = TRUE
  )
  
  expr <- expr[keep_order, , drop = FALSE]
  
  expr <- expr[
    !duplicated(rownames(expr)),
    ,
    drop = FALSE
  ]
}

cat("Genes after de-duplication: ", nrow(expr), "\n")


score_df <- read.csv(
  score_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

cat("
Columns of the GSVA score file:
")
print(colnames(score_df))

if (nrow(score_df) == 0) {
  stop("The GSVA score file contains no data.")
}

sample_candidates <- c(
  "sample", "Sample", "sample_id", "SampleID",
  "sampleID", "barcode", "Barcode", "TCGA_ID",
  "Tumor_Sample_Barcode"
)

sample_col <- sample_candidates[
  sample_candidates %in% colnames(score_df)
]

if (length(sample_col) > 0) {
  sample_col <- sample_col[1]
} else {
  sample_col <- colnames(score_df)[1]
  cat(
    "
No common sample column found; using the first column: ",
    sample_col, "\n"
  )
}

score_candidates <- c(
  "qCSC_score", "qCSC_Score",
  "GSVA_ssGSEA_score", "ssGSEA_score",
  "score", "Score", "ES"
)

score_col <- score_candidates[
  score_candidates %in% colnames(score_df)
]

if (length(score_col) == 0) {
  other_cols <- setdiff(
    colnames(score_df),
    sample_col
  )
  
  numeric_cols <- other_cols[
    vapply(
      score_df[other_cols],
      function(x) {
        is.numeric(x) ||
          all(is.na(x) | grepl(
            "^-?[0-9]+(\\.[0-9]+)?([eE][+-]?[0-9]+)?$",
            as.character(x)
          ))
      },
      logical(1)
    )
  ]
  
  if (length(numeric_cols) == 1) {
    score_col <- numeric_cols
  } else {
    stop(
      "
The qCSC score column cannot be identified unambiguously.
",
      "Check the column names printed above and set score_col explicitly."
    )
  }
} else {
  score_col <- score_col[1]
}

score_df[[sample_col]] <- normalize_sample_id(
  as.character(score_df[[sample_col]])
)

score_df[[score_col]] <- suppressWarnings(
  as.numeric(as.character(score_df[[score_col]]))
)

if (anyDuplicated(score_df[[sample_col]])) {
  stop("Duplicated sample IDs in the GSVA score file.")
}

if (any(!is.finite(score_df[[score_col]]))) {
  stop("Non-numeric or missing values in the GSVA score column; please check.")
}

group_candidates <- c(
  "qCSC_group", "qCSC_Group",
  "group", "Group", "qCSC_group_final"
)

group_col <- group_candidates[
  group_candidates %in% colnames(score_df)
]

if (length(group_col) > 0) {
  
  group_col <- group_col[1]
  group_raw <- tolower(
    trimws(as.character(score_df[[group_col]]))
  )
  
  group <- ifelse(
    grepl("high", group_raw),
    "High",
    ifelse(
      grepl("low", group_raw),
      "Low",
      NA_character_
    )
  )
  
  if (anyNA(group)) {
    stop(
      "
The grouping column contains unrecognised labels.
",
      "
Please check the values in the grouping column.
"
    )
  }
  
} else {
  
  cat(
    "
No grouping column found in the score file, ",
    "
Re-splitting into High/Low at the median of the current GSVA score.
"
  )
  
  cutoff <- median(score_df[[score_col]])
  
  group <- ifelse(
    score_df[[score_col]] >= cutoff,
    "High",
    "Low"
  )
}

qCSC_df <- data.frame(
  Sample = score_df[[sample_col]],
  qCSC_score = score_df[[score_col]],
  qCSC_group = group,
  stringsAsFactors = FALSE
)

cat("
qCSC group counts:
")
print(table(qCSC_df$qCSC_group))


expr_samples <- colnames(expr)
score_samples <- qCSC_df$Sample

missing_in_score <- setdiff(
  expr_samples,
  score_samples
)

missing_in_expr <- setdiff(
  score_samples,
  expr_samples
)

cat("
Samples in the expression matrix: ", length(expr_samples), "\n")
cat("Samples in the score file: ", length(score_samples), "\n")
cat("Samples in the expression matrix without a score: ",
    length(missing_in_score), "\n")
cat("Samples in the score file without an expression profile: ",
    length(missing_in_expr), "\n")

if (
  length(missing_in_score) > 0 ||
  length(missing_in_expr) > 0
) {
  write.csv(
    data.frame(
      Missing_in_score = c(
        missing_in_score,
        rep(NA_character_,
            max(0, length(missing_in_expr) -
                  length(missing_in_score)))
      )[seq_len(max(length(missing_in_score),
                    length(missing_in_expr), 1))],
      Missing_in_expression = c(
        missing_in_expr,
        rep(NA_character_,
            max(0, length(missing_in_score) -
                  length(missing_in_expr)))
      )[seq_len(max(length(missing_in_score),
                    length(missing_in_expr), 1))]
    ),
    file.path(out_dir, "Sample_ID_mismatch.csv"),
    row.names = FALSE
  )
  
  stop(
    "The sample sets of the expression matrix and the score file do not match; ",
    "a matching report has been written; verify it before running the model."
  )
}

qCSC_df <- qCSC_df[
  match(expr_samples, qCSC_df$Sample),
  ,
  drop = FALSE
]

stopifnot(identical(qCSC_df$Sample, expr_samples))

write.csv(
  qCSC_df,
  file.path(out_dir, "qCSC_score_group_matched.csv"),
  row.names = FALSE
)


estimate_input <- data.frame(
  NAME = rownames(expr),
  expr,
  check.names = FALSE
)

input_file <- file.path(
  out_dir,
  "TCGA_CRC_ESTIMATE_input.txt"
)

write.table(
  estimate_input,
  file = input_file,
  sep = "\t",
  quote = FALSE,
  row.names = FALSE,
  col.names = TRUE
)

cat("
ESTIMATE input files generated.
")


filtered_file <- file.path(
  out_dir,
  "TCGA_CRC_ESTIMATE_common_genes.gct"
)

estimate_output <- file.path(
  out_dir,
  "TCGA_CRC_ESTIMATE_scores.gct"
)

filterCommonGenes(
  input.f = input_file,
  output.f = filtered_file,
  id = "GeneSymbol"
)

if (!file.exists(filtered_file)) {
  stop("filterCommonGenes did not produce the expected GCT file.")
}

estimateScore(
  input.ds = filtered_file,
  output.ds = estimate_output,
  platform = "illumina"
)

if (!file.exists(estimate_output)) {
  stop("estimateScore did not produce the expected score file.")
}

# ------------------------------------------------------------
#
# ------------------------------------------------------------
estimate_check <- read.delim(
  estimate_output,
  skip = 2,
  header = TRUE,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

estimate_check_matrix <- as.matrix(estimate_check[, -(1:2), drop = FALSE])

rownames(estimate_check_matrix) <- as.character(estimate_check[[1]])

storage.mode(estimate_check_matrix) <- "numeric"

cat("
Raw ESTIMATE output range (mean +/- SD):
")

for (score_i in rownames(estimate_check_matrix)) {

  score_values <- estimate_check_matrix[score_i, ]

  cat(
    sprintf(
      "  %-14s min = %10.2f  max = %10.2f  n_negative = %3d / %d\n",
      score_i,
      min(score_values),
      max(score_values),
      sum(score_values < 0),
      length(score_values)
    )
  )
}

estimate_invalid <- !all(is.finite(estimate_check_matrix))

if (estimate_invalid) {
  stop("NA, NaN or Inf in the raw ESTIMATE output; please check.")
}

estimate_constant <- apply(estimate_check_matrix, 1, function(x) {
  !is.finite(var(x)) || var(x) == 0
})

if (any(estimate_constant)) {
  stop(
    "An ESTIMATE score component has zero variance and cannot be used as a covariate: ",
    paste(names(estimate_constant)[estimate_constant], collapse = ", ")
  )
}

estimate_collinear <- abs(
  cor(
    estimate_check_matrix["StromalScore", ],
    estimate_check_matrix["ImmuneScore", ]
  )
)

cat(
  sprintf(
    "
StromalScore-ImmuneScore correlation: %.4f
",
    estimate_collinear
  )
)

if (estimate_collinear > 0.95) {
  warning(
    "StromalScore and ImmuneScore are highly collinear (|r| > 0.95); ",
    "including both may destabilise the model."
  )
}


estimate_raw <- read.delim(
  estimate_output,
  skip = 2,
  header = TRUE,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

if (ncol(estimate_raw) < 4) {
  stop(
    "Unexpected number of columns in the ESTIMATE output; check the GCT file format."
  )
}

score_names <- as.character(estimate_raw[[1]])

estimate_matrix <- as.matrix(
  estimate_raw[, -(1:2), drop = FALSE]
)

rownames(estimate_matrix) <- score_names

storage.mode(estimate_matrix) <- "numeric"

required_scores <- c(
  "StromalScore",
  "ImmuneScore",
  "ESTIMATEScore"
)

if (!all(required_scores %in% rownames(estimate_matrix))) {
  stop(
    "Not all expected scores were found in the ESTIMATE output: ",
    paste(required_scores, collapse = ", ")
  )
}

estimate_sample_names <- normalize_sample_id(
  colnames(estimate_matrix)
)

if (anyDuplicated(estimate_sample_names)) {
  stop("Duplicated sample names in the ESTIMATE output after standardisation.")
}

colnames(estimate_matrix) <- estimate_sample_names

if (!setequal(colnames(estimate_matrix), expr_samples)) {
  stop(
    "The ESTIMATE output samples and the expression matrix samples do not match, ",
    "Please check the GCT file and the sample IDs."
  )
}

estimate_matrix <- estimate_matrix[
  ,
  expr_samples,
  drop = FALSE
]

estimate_df <- data.frame(
  Sample = expr_samples,
  StromalScore = as.numeric(
    estimate_matrix["StromalScore", ]
  ),
  ImmuneScore = as.numeric(
    estimate_matrix["ImmuneScore", ]
  ),
  ESTIMATEScore = as.numeric(
    estimate_matrix["ESTIMATEScore", ]
  ),
  stringsAsFactors = FALSE
)

if (any(!is.finite(
  as.matrix(estimate_df[, required_scores])
))) {
  stop("NA, NaN or Inf in the ESTIMATE scores; please check.")
}

write.csv(
  estimate_df,
  file.path(out_dir, "TCGA_CRC_ESTIMATE_scores.csv"),
  row.names = FALSE
)

cat("
ESTIMATE scoring complete.
")
cat("Number of valid samples: ", nrow(estimate_df), "\n")


analysis_df <- merge(
  qCSC_df,
  estimate_df,
  by = "Sample",
  all = FALSE,
  sort = FALSE
)

analysis_df <- analysis_df[
  match(expr_samples, analysis_df$Sample),
  ,
  drop = FALSE
]

if (
  nrow(analysis_df) != ncol(expr) ||
  anyNA(analysis_df[, c(
    "qCSC_group",
    "StromalScore",
    "ImmuneScore"
  )])
) {
  stop("Unexpected number of merged samples or covariates.")
}

analysis_df$StromalScore_z <- as.numeric(
  scale(analysis_df$StromalScore)
)

analysis_df$ImmuneScore_z <- as.numeric(
  scale(analysis_df$ImmuneScore)
)

if (
  any(!is.finite(analysis_df$StromalScore_z)) ||
  any(!is.finite(analysis_df$ImmuneScore_z))
) {
  stop(
    "Covariate standardisation failed; a zero-variance variable may be present."
  )
}

stopifnot(
  abs(mean(analysis_df$StromalScore_z)) < 1e-8,
  abs(mean(analysis_df$ImmuneScore_z)) < 1e-8,
  abs(sd(analysis_df$StromalScore_z) - 1) < 1e-8,
  abs(sd(analysis_df$ImmuneScore_z) - 1) < 1e-8,
  identical(
    rank(analysis_df$StromalScore),
    rank(analysis_df$StromalScore_z)
  ),
  identical(
    rank(analysis_df$ImmuneScore),
    rank(analysis_df$ImmuneScore_z)
  )
)

cat(
  sprintf(
    "
Covariates standardised: StromalScore_z range %.4f ~ %.4f, ImmuneScore_z range %.4f ~ %.4f
",
    min(analysis_df$StromalScore_z),
    max(analysis_df$StromalScore_z),
    min(analysis_df$ImmuneScore_z),
    max(analysis_df$ImmuneScore_z)
  )
)

analysis_df$qCSC_group <- factor(
  analysis_df$qCSC_group,
  levels = c("Low", "High")
)

if (anyNA(analysis_df$qCSC_group)) {
  stop("qCSC grouping must use both the Low and the High label.")
}

write.csv(
  analysis_df,
  file.path(out_dir, "TCGA_CRC_ESTIMATE_qCSC_merged.csv"),
  row.names = FALSE
)


expr_model <- expr[
  ,
  analysis_df$Sample,
  drop = FALSE
]

stopifnot(
  identical(colnames(expr_model), analysis_df$Sample)
)

gene_var <- apply(expr_model, 1, var)

valid_gene <- is.finite(gene_var) & gene_var > 0

expr_model <- expr_model[
  valid_gene,
  ,
  drop = FALSE
]

cat("
Genes with non-zero variance entering limma: ",
    nrow(expr_model), "\n")

design <- model.matrix(
  ~ qCSC_group + StromalScore_z + ImmuneScore_z,
  data = analysis_df
)

if (!"qCSC_groupHigh" %in% colnames(design)) {
  stop("The qCSC_groupHigh coefficient was not found in the design matrix.")
}

if (qr(design)$rank < ncol(design)) {
  stop(
    "The design matrix is not full rank; the covariates may be collinear, ",
    "Please check StromalScore and ImmuneScore."
  )
}

fit <- lmFit(
  expr_model,
  design
)

fit <- eBayes(fit)

deg_adjusted <- topTable(
  fit,
  coef = "qCSC_groupHigh",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

deg_adjusted$Gene <- rownames(deg_adjusted)

deg_adjusted <- deg_adjusted[
  ,
  c("Gene", setdiff(colnames(deg_adjusted), "Gene")),
  drop = FALSE
]

write.csv(
  deg_adjusted,
  file.path(out_dir, "DEG_ESTIMATE_adjusted_all.csv"),
  row.names = FALSE
)

# FDR < 0.05
deg_adjusted_fdr <- subset(
  deg_adjusted,
  !is.na(adj.P.Val) & adj.P.Val < 0.05
)

write.csv(
  deg_adjusted_fdr,
  file.path(out_dir, "DEG_ESTIMATE_adjusted_FDR05.csv"),
  row.names = FALSE
)

deg_adjusted_final <- subset(
  deg_adjusted,
  !is.na(adj.P.Val) &
    adj.P.Val < 0.05 &
    abs(logFC) >= 0.5
)

write.csv(
  deg_adjusted_final,
  file.path(out_dir, "DEG_ESTIMATE_adjusted_FINAL.csv"),
  row.names = FALSE
)

write.csv(
  subset(deg_adjusted_final, logFC > 0),
  file.path(out_dir, "DEG_ESTIMATE_adjusted_UP.csv"),
  row.names = FALSE
)

write.csv(
  subset(deg_adjusted_final, logFC < 0),
  file.path(out_dir, "DEG_ESTIMATE_adjusted_DOWN.csv"),
  row.names = FALSE
)


summary_lines <- c(
  "TCGA CRC ESTIMATE robustness analysis",
  paste0("Run time: ", Sys.time()),
  paste0("Expression file: ", expr_file),
  paste0("qCSC score file: ", score_file),
  paste0("Expression object: ", expr_name[1]),
  paste0("Samples: ", ncol(expr)),
  paste0("Genes after duplicate removal: ", nrow(expr)),
  paste0("Genes entering limma: ", nrow(expr_model)),
  paste0("DEGs FDR < 0.05: ", nrow(deg_adjusted_fdr)),
  paste0(
    "DEGs FDR < 0.05 and |logFC| >= 0.5: ",
    nrow(deg_adjusted_final)
  ),
  paste0(
    "Adjusted UP genes: ",
    sum(deg_adjusted_final$logFC > 0)
  ),
  paste0(
    "Adjusted DOWN genes: ",
    sum(deg_adjusted_final$logFC < 0)
  ),
  "",
  "Covariates: StromalScore_z + ImmuneScore_z",
  paste0("Output directory: ", out_dir)
)

writeLines(
  summary_lines,
  file.path(out_dir, "RUN_SUMMARY.txt")
)

cat("
========== Analysis complete ==========
")
cat(paste(summary_lines, collapse = "\n"), "\n")
cat("
All results saved in: 
", out_dir, "\n")

writeLines(
  out_dir,
  file.path(ESTIMATE_DIR, "TCGA_CRC_ESTIMATE_GSVA_LATEST.txt")
)

############################################################
# TCGA CRC qCSC
# Original vs ESTIMATE-adjusted DEG / Hallmark GSEA
#
# Connects to the preceding ESTIMATE_GSVA script
# Does NOT rerun ESTIMATE
# Does NOT overwrite existing results
############################################################

options(stringsAsFactors = FALSE)

library(limma)
library(clusterProfiler)
library(msigdbr)
library(dplyr)
library(BiocParallel)

BiocParallel::register(BiocParallel::SerialParam())

base_dir <- DATA_ROOT

############################################################
# 1. Locate the latest output from the preceding script
############################################################

if (
  exists("out_dir", inherits = TRUE) &&
  length(out_dir) == 1L &&
  !is.na(out_dir) &&
  dir.exists(out_dir) &&
  grepl("^TCGA_CRC_ESTIMATE_GSVA_", basename(out_dir)) &&
  file.exists(file.path(out_dir, "DEG_ESTIMATE_adjusted_all.csv"))
) {
  estimate_dir <- out_dir
} else {
  estimate_dir <- find_latest_estimate_dir(base_dir)
}

cat("ESTIMATE output directory: 
", estimate_dir, "\n")


############################################################
# 2. Locate adjusted DEG files from the previous script
############################################################

adjusted_all_file <- file.path(
  estimate_dir,
  "DEG_ESTIMATE_adjusted_all.csv"
)

adjusted_final_file <- file.path(
  estimate_dir,
  "DEG_ESTIMATE_adjusted_FINAL.csv"
)

if (!file.exists(adjusted_all_file)) {
  stop("The adjusted whole-transcriptome result is missing: ", adjusted_all_file)
}

if (!file.exists(adjusted_final_file)) {
  stop("The adjusted final DEG list is missing: ", adjusted_final_file)
}


############################################################
# 3. Original DEG and original GSEA input files
############################################################

original_deg_candidates <- c(
  file.path(
    base_dir,
    "TCGA_CRC_qCSC_DEG_GSVA",
    "DEG_FINAL.csv"
  ),
  file.path(
    base_dir,
    "TCGA_CRC_qCSC_DEG_GSVA",
    "TCGA_CRC_qCSC_DEG_FINAL.csv"
  ),
  file.path(
    base_dir,
    "TCGA_CRC_qCSC_original_DEG_recalculated.csv"
  ),
  file.path(
    base_dir,
    "TCGA_CRC_qCSC_DEG_FINAL.csv"
  )
)

gsea_candidates <- list.dirs(
  c(base_dir, ESTIMATE_DIR),
  recursive = FALSE,
  full.names = TRUE
)

gsea_candidates <- gsea_candidates[
  grepl(
    "^TCGA_CRC_qCSC_Hallmark_GSEA_GSVA_",
    basename(gsea_candidates)
  )
]

gsea_candidates <- gsea_candidates[
  file.exists(file.path(
    gsea_candidates,
    "TCGA_CRC_qCSC_Hallmark_GSEA_ALL_RESULTS_FINAL.csv"
  ))
]

## 01j writes its own comparison table; look for it before giving up.
if (length(gsea_candidates) == 0) {
  j_output <- file.path(QCSC_PROJECT_DIR, "output", "Hallmark_GSEA")
  if (dir.exists(j_output)) {
    gsea_candidates <- j_output
  }
}
## If the legacy gsea.R output is absent, rebuild the comparison from 01j, which
## runs the same analysis inside the package.
gsea_from_01j <- FALSE
if (length(gsea_candidates) == 0) {
  j_file <- file.path(QCSC_PROJECT_DIR, "output", "Hallmark_GSEA",
                      "Hallmark_GSEA_model_comparison.csv")
  if (file.exists(j_file)) {
    j_cmp <- read.csv(j_file, stringsAsFactors = FALSE, check.names = FALSE)
    original_gsea_std <- data.frame(
      ID = j_cmp$ID,
      Description = j_cmp$ID,
      NES = j_cmp$NES_unadjusted,
      p.adjust = j_cmp$FDR_unadjusted,
      stringsAsFactors = FALSE
    )
    adjusted_gsea_std <- data.frame(
      ID = j_cmp$ID,
      Description = j_cmp$ID,
      NES = j_cmp$NES_adjusted,
      p.adjust = j_cmp$FDR_adjusted,
      stringsAsFactors = FALSE
    )
    gsea_from_01j <- TRUE
    message("Using the Hallmark GSEA comparison written by 01j: ", j_file)
  } else {
    warning(
      "No TCGA_CRC_qCSC_Hallmark_GSEA_GSVA_* output directory and no 01j output found.\n",
      "  The original-versus-adjusted GSEA comparison is skipped; run 01j to produce it.",
      call. = FALSE
    )
    original_gsea_available <- FALSE
  }
}

if (length(gsea_candidates)) {
  gsea_candidates <- gsea_candidates[
    order(file.info(gsea_candidates)$mtime, decreasing = TRUE)
  ]
}

original_gsea_candidates <- file.path(
  gsea_candidates,
  "TCGA_CRC_qCSC_Hallmark_GSEA_ALL_RESULTS_FINAL.csv"
)

# If needed, replace NA_character_ with the exact file path.
original_deg_override <- NA_character_
original_gsea_override <- NA_character_

if (!is.na(original_deg_override)) {
  original_deg_file <- original_deg_override
} else {
  hits <- original_deg_candidates[
    file.exists(original_deg_candidates)
  ]
  
  if (length(hits) == 0) {
    stop(
      "The raw DEG file was not found automatically.
",
      "Set the full path of the raw DEG CSV in original_deg_override."
    )
  }
  
  original_deg_file <- hits[1]
}

if (!is.na(original_gsea_override)) {
  original_gsea_file <- original_gsea_override
} else {
  hits <- original_gsea_candidates[
    file.exists(original_gsea_candidates)
  ]
  
  if (length(hits) == 0) {
    stop(
      "The raw Hallmark GSEA file was not found automatically.
",
      "Set the full path of the raw GSEA CSV in original_gsea_override."
    )
  }
  
  original_gsea_file <- hits[1]
}

cat("
Raw DEG: ", original_deg_file, "\n")
cat("
Raw GSEA: ", original_gsea_file, "\n")


############################################################
# 4. Create a new comparison output folder
############################################################

comparison_dir <- file.path(
  estimate_dir,
  paste0(
    "Original_vs_Adjusted_Comparison_",
    format(Sys.time(), "%Y%m%d_%H%M%S")
  )
)

dir.create(
  comparison_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

cat("
Comparison output directory: 
", comparison_dir, "\n")


############################################################
# 5. Read DEG files
############################################################

original_deg <- read.csv(
  original_deg_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

adjusted_all <- read.csv(
  adjusted_all_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

adjusted_final <- read.csv(
  adjusted_final_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)


############################################################
# 6. Identify gene columns
############################################################

find_gene_col <- function(dat) {
  possible <- c(
    "Gene", "gene", "SYMBOL", "symbol",
    "GeneSymbol", "gene_symbol"
  )
  
  found <- possible[
    possible %in% colnames(dat)
  ]
  
  if (length(found) > 0) {
    return(found[1])
  }
  
  stop(
    "Cannot identify the gene column. Current column names: ",
    paste(colnames(dat), collapse = ", ")
  )
}

original_gene_col <- find_gene_col(original_deg)
adjusted_gene_col <- find_gene_col(adjusted_final)
adjusted_all_gene_col <- find_gene_col(adjusted_all)


############################################################
# 7. Standardize and deduplicate DEG tables
############################################################

standardize_deg <- function(dat, gene_col) {
  if (!"logFC" %in% colnames(dat)) {
    stop("The DEG table does not contain a logFC column.")
  }
  
  dat$Gene_standard <- toupper(
    trimws(as.character(dat[[gene_col]]))
  )
  
  dat <- dat[
    !is.na(dat$Gene_standard) &
      dat$Gene_standard != "" &
      is.finite(suppressWarnings(as.numeric(dat$logFC))),
    ,
    drop = FALSE
  ]
  
  dat$logFC <- as.numeric(dat$logFC)
  
  # If duplicated symbols exist, retain the row with
  # the smallest adjusted P value when available.
  if ("adj.P.Val" %in% colnames(dat)) {
    dat$adj.P.Val <- as.numeric(dat$adj.P.Val)
    dat <- dat[
      order(dat$adj.P.Val, na.last = TRUE),
      ,
      drop = FALSE
    ]
  }
  
  dat <- dat[
    !duplicated(dat$Gene_standard),
    ,
    drop = FALSE
  ]
  
  dat
}

original_deg_std <- standardize_deg(
  original_deg,
  original_gene_col
)

adjusted_final_std <- standardize_deg(
  adjusted_final,
  adjusted_gene_col
)

original_genes <- original_deg_std$Gene_standard
adjusted_genes <- adjusted_final_std$Gene_standard

shared_genes <- intersect(original_genes, adjusted_genes)
original_only <- setdiff(original_genes, adjusted_genes)
adjusted_only <- setdiff(adjusted_genes, original_genes)
union_genes <- union(original_genes, adjusted_genes)

jaccard <- if (length(union_genes) > 0) {
  length(shared_genes) / length(union_genes)
} else {
  NA_real_
}

original_overlap <- if (length(original_genes) > 0) {
  length(shared_genes) / length(original_genes)
} else {
  NA_real_
}

adjusted_overlap <- if (length(adjusted_genes) > 0) {
  length(shared_genes) / length(adjusted_genes)
} else {
  NA_real_
}


############################################################
# 8. Compare logFC directions for shared DEGs
############################################################

original_direction <- original_deg_std[
  original_deg_std$Gene_standard %in% shared_genes,
  c("Gene_standard", "logFC"),
  drop = FALSE
]

adjusted_direction <- adjusted_final_std[
  adjusted_final_std$Gene_standard %in% shared_genes,
  c("Gene_standard", "logFC"),
  drop = FALSE
]

colnames(original_direction) <- c(
  "Gene",
  "logFC_Original"
)

colnames(adjusted_direction) <- c(
  "Gene",
  "logFC_Adjusted"
)

direction_comparison <- merge(
  original_direction,
  adjusted_direction,
  by = "Gene"
)

direction_comparison$Direction_Original <- ifelse(
  direction_comparison$logFC_Original > 0,
  "Up",
  ifelse(
    direction_comparison$logFC_Original < 0,
    "Down",
    "Zero"
  )
)

direction_comparison$Direction_Adjusted <- ifelse(
  direction_comparison$logFC_Adjusted > 0,
  "Up",
  ifelse(
    direction_comparison$logFC_Adjusted < 0,
    "Down",
    "Zero"
  )
)

# Count consistency only when both directions are non-zero.
direction_comparison$Direction_Consistent <- (
  sign(direction_comparison$logFC_Original) ==
    sign(direction_comparison$logFC_Adjusted)
) &
  direction_comparison$logFC_Original != 0 &
  direction_comparison$logFC_Adjusted != 0

valid_direction_n <- sum(
  direction_comparison$logFC_Original != 0 &
    direction_comparison$logFC_Adjusted != 0
)

direction_consistent_n <- sum(
  direction_comparison$Direction_Consistent,
  na.rm = TRUE
)

direction_consistent_percent <- if (valid_direction_n > 0) {
  100 * direction_consistent_n / valid_direction_n
} else {
  NA_real_
}


############################################################
# 9. Save DEG comparison
############################################################

write.csv(
  data.frame(Gene = shared_genes),
  file.path(comparison_dir, "DEG_SHARED.csv"),
  row.names = FALSE
)

write.csv(
  data.frame(Gene = original_only),
  file.path(comparison_dir, "DEG_ORIGINAL_ONLY.csv"),
  row.names = FALSE
)

write.csv(
  data.frame(Gene = adjusted_only),
  file.path(comparison_dir, "DEG_ADJUSTED_ONLY.csv"),
  row.names = FALSE
)

write.csv(
  direction_comparison,
  file.path(comparison_dir, "DEG_DIRECTION_COMPARISON.csv"),
  row.names = FALSE
)

DEG_summary <- data.frame(
  Original_DEG_n = length(original_genes),
  Adjusted_DEG_n = length(adjusted_genes),
  Shared_DEG_n = length(shared_genes),
  Original_only_n = length(original_only),
  Adjusted_only_n = length(adjusted_only),
  Jaccard = jaccard,
  Original_DEG_retained_percent = 100 * original_overlap,
  Adjusted_DEG_overlapping_original_percent =
    100 * adjusted_overlap,
  Shared_genes_with_nonzero_logFC = valid_direction_n,
  Direction_consistent_n = direction_consistent_n,
  Direction_consistent_percent = direction_consistent_percent
)

write.csv(
  DEG_summary,
  file.path(comparison_dir, "DEG_COMPARISON_SUMMARY.csv"),
  row.names = FALSE
)


############################################################
# 10. Prepare all-gene ranking for adjusted Hallmark GSEA
############################################################

if (!"t" %in% colnames(adjusted_all)) {
  stop(
    "The adjusted whole-transcriptome DEG file has no t-statistic column, ",
    "GSEA cannot be run on the moderated t statistic."
  )
}

adjusted_all$Gene_standard <- toupper(
  trimws(as.character(adjusted_all[[adjusted_all_gene_col]]))
)

adjusted_all$t <- as.numeric(adjusted_all$t)

rank_df <- adjusted_all[
  !is.na(adjusted_all$Gene_standard) &
    adjusted_all$Gene_standard != "" &
    is.finite(adjusted_all$t),
  c("Gene_standard", "t"),
  drop = FALSE
]

rank_df <- rank_df[
  order(abs(rank_df$t), decreasing = TRUE),
  ,
  drop = FALSE
]

rank_df <- rank_df[
  !duplicated(rank_df$Gene_standard),
  ,
  drop = FALSE
]

rank_df <- rank_df[
  order(rank_df$t, decreasing = TRUE),
  ,
  drop = FALSE
]

gene_rank <- rank_df$t
names(gene_rank) <- rank_df$Gene_standard

if (anyDuplicated(names(gene_rank))) {
  stop("Duplicated gene names remain in the GSEA ranking vector.")
}

write.csv(
  rank_df,
  file.path(comparison_dir, "Adjusted_GSEA_Ranked_Genes.csv"),
  row.names = FALSE
)


############################################################
# 11. Run adjusted Hallmark GSEA
############################################################

hallmark_df <- msigdbr::msigdbr(
  species = "Homo sapiens",
  collection = "H"
)

if (!all(c("gs_name", "gene_symbol") %in% colnames(hallmark_df))) {
  stop(
    "The column names returned by msigdbr differ from the expected ones; check the msigdbr version."
  )
}

TERM2GENE <- hallmark_df %>%
  dplyr::select(gs_name, gene_symbol) %>%
  dplyr::distinct()

set.seed(1234)

gsea_adjusted <- clusterProfiler::GSEA(
  geneList = gene_rank,
  exponent = 1,
  minGSSize = 10,
  maxGSSize = 500,
  eps = 0,
  pvalueCutoff = 1,
  pAdjustMethod = "BH",
  TERM2GENE = TERM2GENE,
  verbose = TRUE,
  seed = TRUE,
  nPerm = 10000
)

gsea_adjusted_df <- as.data.frame(gsea_adjusted)

write.csv(
  gsea_adjusted_df,
  file.path(
    comparison_dir,
    "Adjusted_Hallmark_GSEA_ALL_RESULTS.csv"
  ),
  row.names = FALSE
)


############################################################
# 12. Read and standardize original Hallmark GSEA
############################################################

original_gsea <- read.csv(
  original_gsea_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

## Skip the legacy-file reader when the fallback above already built the tables.
if (!exists("gsea_from_01j") || !isTRUE(gsea_from_01j)) {

required_gsea_cols <- c(
  "ID", "Description", "NES", "p.adjust"
)

if (!all(required_gsea_cols %in% colnames(original_gsea))) {
  stop(
    "The raw GSEA file is missing required columns: ",
    paste(
      setdiff(required_gsea_cols, colnames(original_gsea)),
      collapse = ", "
    )
  )
}

if (!all(required_gsea_cols %in% colnames(gsea_adjusted_df))) {
  stop("The adjusted GSEA result is missing required columns.")
}

original_gsea_std <- original_gsea[
  ,
  required_gsea_cols,
  drop = FALSE
]

adjusted_gsea_std <- gsea_adjusted_df[
  ,
  required_gsea_cols,
  drop = FALSE
]

original_gsea_std$ID <- as.character(original_gsea_std$ID)
adjusted_gsea_std$ID <- as.character(adjusted_gsea_std$ID)

original_gsea_std$NES <- as.numeric(original_gsea_std$NES)
adjusted_gsea_std$NES <- as.numeric(adjusted_gsea_std$NES)

}

original_gsea_std$p.adjust <- as.numeric(original_gsea_std$p.adjust)
adjusted_gsea_std$p.adjust <- as.numeric(adjusted_gsea_std$p.adjust)

colnames(original_gsea_std) <- c(
  "ID",
  "Description_Original",
  "NES_Original",
  "FDR_Original"
)

colnames(adjusted_gsea_std) <- c(
  "ID",
  "Description_Adjusted",
  "NES_Adjusted",
  "FDR_Adjusted"
)

original_gsea_std <- original_gsea_std[
  !duplicated(original_gsea_std$ID),
  ,
  drop = FALSE
]

adjusted_gsea_std <- adjusted_gsea_std[
  !duplicated(adjusted_gsea_std$ID),
  ,
  drop = FALSE
]


############################################################
# 13. Compare pathways by ID
############################################################

gsea_comparison <- merge(
  original_gsea_std,
  adjusted_gsea_std,
  by = "ID",
  all = TRUE
)

gsea_comparison$NES_change <- (
  gsea_comparison$NES_Adjusted -
    gsea_comparison$NES_Original
)

gsea_comparison$NES_abs_change <- abs(
  gsea_comparison$NES_change
)

gsea_comparison$NES_direction_consistent <- (
  sign(gsea_comparison$NES_Original) ==
    sign(gsea_comparison$NES_Adjusted)
) &
  is.finite(gsea_comparison$NES_Original) &
  is.finite(gsea_comparison$NES_Adjusted)

gsea_comparison$Original_FDR_lt_0.25 <- (
  !is.na(gsea_comparison$FDR_Original) &
    gsea_comparison$FDR_Original < 0.25
)

gsea_comparison$Adjusted_FDR_lt_0.25 <- (
  !is.na(gsea_comparison$FDR_Adjusted) &
    gsea_comparison$FDR_Adjusted < 0.25
)

gsea_comparison$Significant_in_both <- (
  gsea_comparison$Original_FDR_lt_0.25 &
    gsea_comparison$Adjusted_FDR_lt_0.25
)

gsea_comparison$Original_only_significant <- (
  gsea_comparison$Original_FDR_lt_0.25 &
    !gsea_comparison$Adjusted_FDR_lt_0.25
)

gsea_comparison$Adjusted_only_significant <- (
  !gsea_comparison$Original_FDR_lt_0.25 &
    gsea_comparison$Adjusted_FDR_lt_0.25
)

write.csv(
  gsea_comparison,
  file.path(comparison_dir, "Original_vs_Adjusted_Hallmark_GSEA.csv"),
  row.names = FALSE
)


############################################################
# 14. GSEA summary
############################################################

common_pathways <- intersect(
  original_gsea_std$ID,
  adjusted_gsea_std$ID
)

common_gsea <- gsea_comparison[
  gsea_comparison$ID %in% common_pathways,
  ,
  drop = FALSE
]

valid_nes <- is.finite(common_gsea$NES_Original) &
  is.finite(common_gsea$NES_Adjusted)

direction_valid <- valid_nes &
  common_gsea$NES_Original != 0 &
  common_gsea$NES_Adjusted != 0

gsea_direction_consistent_n <- sum(
  sign(common_gsea$NES_Original[direction_valid]) ==
    sign(common_gsea$NES_Adjusted[direction_valid])
)

gsea_direction_consistent_percent <- if (
  sum(direction_valid) > 0
) {
  100 * gsea_direction_consistent_n / sum(direction_valid)
} else {
  NA_real_
}

both_sig_n <- sum(
  common_gsea$Original_FDR_lt_0.25 &
    common_gsea$Adjusted_FDR_lt_0.25,
  na.rm = TRUE
)

original_only_sig_n <- sum(
  common_gsea$Original_FDR_lt_0.25 &
    !common_gsea$Adjusted_FDR_lt_0.25,
  na.rm = TRUE
)

adjusted_only_sig_n <- sum(
  !common_gsea$Original_FDR_lt_0.25 &
    common_gsea$Adjusted_FDR_lt_0.25,
  na.rm = TRUE
)

if (sum(valid_nes) >= 3) {
  nes_pearson <- cor(
    common_gsea$NES_Original[valid_nes],
    common_gsea$NES_Adjusted[valid_nes],
    method = "pearson"
  )
  
  nes_spearman <- cor(
    common_gsea$NES_Original[valid_nes],
    common_gsea$NES_Adjusted[valid_nes],
    method = "spearman"
  )
  
  mean_abs_nes_change <- mean(
    abs(
      common_gsea$NES_Adjusted[valid_nes] -
        common_gsea$NES_Original[valid_nes]
    )
  )
} else {
  nes_pearson <- NA_real_
  nes_spearman <- NA_real_
  mean_abs_nes_change <- NA_real_
}

GSEA_summary <- data.frame(
  Original_pathways_recorded = nrow(original_gsea_std),
  Adjusted_pathways_recorded = nrow(adjusted_gsea_std),
  Common_pathways_recorded = length(common_pathways),
  Common_pathways_with_valid_NES = sum(valid_nes),
  Original_FDR_lt_0.25_among_common = sum(
    common_gsea$Original_FDR_lt_0.25,
    na.rm = TRUE
  ),
  Adjusted_FDR_lt_0.25_among_common = sum(
    common_gsea$Adjusted_FDR_lt_0.25,
    na.rm = TRUE
  ),
  Significant_in_both = both_sig_n,
  Original_only_significant = original_only_sig_n,
  Adjusted_only_significant = adjusted_only_sig_n,
  NES_direction_consistent_n = gsea_direction_consistent_n,
  NES_direction_consistent_percent =
    gsea_direction_consistent_percent,
  NES_Pearson_correlation = nes_pearson,
  NES_Spearman_correlation = nes_spearman,
  Mean_absolute_NES_change = mean_abs_nes_change
)

write.csv(
  GSEA_summary,
  file.path(comparison_dir, "GSEA_COMPARISON_SUMMARY.csv"),
  row.names = FALSE
)


############################################################
# 15. Overall summary and run information
############################################################

overall_summary <- data.frame(
  Item = c(
    "Adjusted analysis directory",
    "Original DEG file",
    "Original GSEA file",
    "Original DEG count",
    "Adjusted DEG count",
    "Shared DEG count",
    "DEG Jaccard",
    "DEG direction consistency percent",
    "Original GSEA pathways recorded",
    "Adjusted GSEA pathways recorded",
    "Common GSEA pathways",
    "Significant pathways in both",
    "NES direction consistency percent",
    "NES Pearson correlation",
    "NES Spearman correlation",
    "GSEA ranking statistic",
    "Adjusted model used in preceding script"
  ),
  Value = c(
    estimate_dir,
    original_deg_file,
    original_gsea_file,
    length(original_genes),
    length(adjusted_genes),
    length(shared_genes),
    jaccard,
    direction_consistent_percent,
    nrow(original_gsea_std),
    nrow(adjusted_gsea_std),
    length(common_pathways),
    both_sig_n,
    gsea_direction_consistent_percent,
    nes_pearson,
    nes_spearman,
    "limma moderated t",
    "qCSC group + StromalScore + ImmuneScore"
  )
)

write.csv(
  overall_summary,
  file.path(comparison_dir, "OVERALL_COMPARISON_SUMMARY.csv"),
  row.names = FALSE
)

writeLines(
  capture.output(sessionInfo()),
  file.path(comparison_dir, "sessionInfo.txt")
)

cat("\n============================================================\n")
cat("COMPARISON COMPLETED\n")
cat("============================================================\n")

cat("Original DEG: ", length(original_genes), "\n", sep = "")
cat("Adjusted DEG: ", length(adjusted_genes), "\n", sep = "")
cat("Shared DEG: ", length(shared_genes), "\n", sep = "")
cat("DEG Jaccard: ", round(jaccard, 4), "\n", sep = "")
cat(
  "DEG direction consistency: ",
  round(direction_consistent_percent, 2),
  "%\n",
  sep = ""
)

cat("Common GSEA pathways: ", length(common_pathways), "\n", sep = "")
cat("Significant in both: ", both_sig_n, "\n", sep = "")
cat(
  "GSEA direction consistency: ",
  round(gsea_direction_consistent_percent, 2),
  "%\n",
  sep = ""
)

cat("\nAll comparison results saved to:\n")
cat(comparison_dir, "\n")

############################################################
# TCGA CRC qCSC
#
#
############################################################

options(stringsAsFactors = FALSE)

cat("
========== TCGA CRC qCSC: direction consistency of common DEGs ==========
")

############################################################
############################################################

original_deg_file <- file.path(
  DATA_ROOT,
  "TCGA_CRC_qCSC_DEG_GSVA",
  "DEG_FINAL.csv"
)

estimate_dir_ok <- exists("estimate_dir", inherits = TRUE) &&
  length(estimate_dir) == 1L &&
  !is.na(estimate_dir) &&
  dir.exists(estimate_dir) &&
  file.exists(file.path(estimate_dir, "DEG_ESTIMATE_adjusted_FINAL.csv"))

if (!estimate_dir_ok) {
  estimate_dir <- find_latest_estimate_dir(DATA_ROOT)
}

adjusted_deg_file <- file.path(
  estimate_dir,
  "DEG_ESTIMATE_adjusted_FINAL.csv"
)
if (!file.exists(original_deg_file)) {
  stop("Cannot find the raw DEG file; check the path:
", original_deg_file)
}
if (!file.exists(adjusted_deg_file)) {
  stop("Cannot find the ESTIMATE-adjusted DEG file; check the path:
", adjusted_deg_file)
}

############################################################
############################################################

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
output_dir <- file.path(
  ESTIMATE_DIR,
  paste0("Common_DEG_direction_check_", timestamp)
)

if (!dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)) {
  stop("Cannot create the output directory: ", output_dir)
}

cat("Raw DEG file: ", original_deg_file, "\n")
cat("Adjusted DEG file: ", adjusted_deg_file, "\n")
cat("Output directory: ", output_dir, "\n\n")

############################################################
############################################################

read_deg_file <- function(file) {
  x <- read.csv(
    file,
    header = TRUE,
    check.names = FALSE,
    stringsAsFactors = FALSE
  )
  if (nrow(x) == 0) {
    stop("The file has no data rows: ", file)
  }
  names(x) <- trimws(names(x))
  x
}

orig_raw <- read_deg_file(original_deg_file)
adj_raw  <- read_deg_file(adjusted_deg_file)

cat("Rows in the raw DEG file: ", nrow(orig_raw), "\n")
cat("Rows in the adjusted DEG file: ", nrow(adj_raw), "\n")
cat("Column names of the raw file:
")
print(names(orig_raw))
cat("Column names of the adjusted file:
")
print(names(adj_raw))

############################################################
############################################################

find_column <- function(df, candidates, pattern = NULL, label = "column") {
  nms <- names(df)
  hit <- which(tolower(nms) %in% tolower(candidates))
  if (length(hit) >= 1) return(nms[hit[1]])
  
  if (!is.null(pattern)) {
    hit2 <- grep(pattern, nms, ignore.case = TRUE)
    if (length(hit2) >= 1) return(nms[hit2[1]])
  }
  
  stop(
    "Cannot automatically identify ", label, ". The current column names are: ",
    paste(nms, collapse = ", "),
    "
Please confirm the column names and edit the candidate column names in the script."
  )
}

gene_candidates <- c(
  "gene", "genes", "symbol", "gene_symbol", "genesymbol",
  "hgnc_symbol", "external_gene_name", "Gene", "SYMBOL",
  "GeneSymbol", "ID", "gene_id"
)

orig_gene_col <- find_column(
  orig_raw, gene_candidates,
  pattern = "^(gene.?symbol|symbol|gene)$",
  label = "gene-name column of the raw DEG file"
)
adj_gene_col <- find_column(
  adj_raw, gene_candidates,
  pattern = "^(gene.?symbol|symbol|gene)$",
  label = "gene-name column of the adjusted DEG file"
)

orig_logfc_col <- find_column(
  orig_raw, c("logFC", "log2FC", "log2FoldChange", "log_fold_change"),
  pattern = "^log.?fc$|^log2.?fold.?change$",
  label = "logFC column of the raw DEG file"
)
adj_logfc_col <- find_column(
  adj_raw, c("logFC", "log2FC", "log2FoldChange", "log_fold_change"),
  pattern = "^log.?fc$|^log2.?fold.?change$",
  label = "logFC column of the adjusted DEG file"
)

cat("
Columns identified: 
")
cat("Raw gene column: ", orig_gene_col, "\n")
cat("Raw logFC column: ", orig_logfc_col, "\n")
cat("Adjusted gene column: ", adj_gene_col, "\n")
cat("Adjusted logFC column: ", adj_logfc_col, "\n\n")

############################################################
############################################################

prepare_deg <- function(df, gene_col, logfc_col, label) {
  gene <- trimws(as.character(df[[gene_col]]))
  logfc <- suppressWarnings(as.numeric(as.character(df[[logfc_col]])))
  
  out <- data.frame(
    Gene = toupper(gene),
    logFC = logfc,
    stringsAsFactors = FALSE
  )
  
  out <- out[!is.na(out$Gene) & out$Gene != "", , drop = FALSE]
  
  duplicated_genes <- unique(out$Gene[duplicated(out$Gene)])
  if (length(duplicated_genes) > 0) {
    dup_file <- file.path(
      output_dir,
      paste0(gsub("[^A-Za-z0-9]+", "_", label), "_duplicate_gene_rows.csv")
    )
    write.csv(
      out[out$Gene %in% duplicated_genes, , drop = FALSE],
      dup_file,
      row.names = FALSE
    )
    stop(
      label, " duplicated gene names (after upper-casing) were found; duplicated records written to:
",
      dup_file,
      "
Please decide how the duplicated records should be handled before continuing."
    )
  }
  
  out
}

orig <- prepare_deg(orig_raw, orig_gene_col, orig_logfc_col, "original")
adj  <- prepare_deg(adj_raw, adj_gene_col, adj_logfc_col, "adjusted")

if (any(!is.finite(orig$logFC))) {
  warning("The raw DEG file contains missing or non-finite logFC values; the affected genes will be flagged as undecidable.")
}
if (any(!is.finite(adj$logFC))) {
  warning("The adjusted DEG file contains missing or non-finite logFC values; the affected genes will be flagged as undecidable.")
}

############################################################
############################################################

common_genes <- intersect(orig$Gene, adj$Gene)

orig_common <- orig[match(common_genes, orig$Gene), , drop = FALSE]
adj_common  <- adj[match(common_genes, adj$Gene), , drop = FALSE]

common_df <- data.frame(
  Gene = common_genes,
  logFC_original = orig_common$logFC,
  logFC_adjusted = adj_common$logFC,
  stringsAsFactors = FALSE
)

common_df$Direction_original <- ifelse(
  !is.finite(common_df$logFC_original), "Unknown",
  ifelse(common_df$logFC_original > 0, "UP",
         ifelse(common_df$logFC_original < 0, "DOWN", "Zero"))
)
common_df$Direction_adjusted <- ifelse(
  !is.finite(common_df$logFC_adjusted), "Unknown",
  ifelse(common_df$logFC_adjusted > 0, "UP",
         ifelse(common_df$logFC_adjusted < 0, "DOWN", "Zero"))
)

common_df$Direction_consistent <- (
  common_df$Direction_original %in% c("UP", "DOWN") &
    common_df$Direction_original == common_df$Direction_adjusted
)

common_df$Direction_status <- ifelse(
  common_df$Direction_original == "Unknown" |
    common_df$Direction_adjusted == "Unknown",
  "Unknown_logFC",
  ifelse(
    common_df$Direction_original == "Zero" |
      common_df$Direction_adjusted == "Zero",
    "At_least_one_zero_logFC",
    ifelse(
      common_df$Direction_original == common_df$Direction_adjusted,
      "Consistent",
      "Opposite"
    )
  )
)

############################################################
############################################################

common_up <- common_df[
  common_df$Direction_original == "UP" &
    common_df$Direction_adjusted == "UP",
  , drop = FALSE
]

common_down <- common_df[
  common_df$Direction_original == "DOWN" &
    common_df$Direction_adjusted == "DOWN",
  , drop = FALSE
]

direction_opposite <- common_df[
  common_df$Direction_status == "Opposite",
  , drop = FALSE
]

direction_uncertain <- common_df[
  common_df$Direction_status %in%
    c("Unknown_logFC", "At_least_one_zero_logFC"),
  , drop = FALSE
]

############################################################
############################################################

write.csv(
  common_df,
  file.path(output_dir, "Common_DEG_all_with_logFC_directions.csv"),
  row.names = FALSE
)

write.csv(
  common_up,
  file.path(output_dir, "Common_UP_genes_direction_consistent.csv"),
  row.names = FALSE
)

write.csv(
  common_down,
  file.path(output_dir, "Common_DOWN_genes_direction_consistent.csv"),
  row.names = FALSE
)

write.csv(
  direction_opposite,
  file.path(output_dir, "Common_genes_opposite_directions.csv"),
  row.names = FALSE
)

write.csv(
  direction_uncertain,
  file.path(output_dir, "Common_genes_direction_uncertain.csv"),
  row.names = FALSE
)

write.table(
  common_up$Gene,
  file.path(output_dir, "LINCS_candidate_UP_gene_symbols.txt"),
  quote = FALSE, row.names = FALSE, col.names = FALSE
)

write.table(
  common_down$Gene,
  file.path(output_dir, "LINCS_candidate_DOWN_gene_symbols.txt"),
  quote = FALSE, row.names = FALSE, col.names = FALSE
)

############################################################
############################################################

direction_consistent_n <- nrow(common_up) + nrow(common_down)
direction_consistent_pct <- if (nrow(common_df) > 0) {
  100 * direction_consistent_n / nrow(common_df)
} else {
  NA_real_
}

summary_df <- data.frame(
  Metric = c(
    "Original DEG rows after removing blank gene names",
    "Adjusted DEG rows after removing blank gene names",
    "Original unique genes",
    "Adjusted unique genes",
    "Common genes",
    "Common UP genes (logFC > 0 in both)",
    "Common DOWN genes (logFC < 0 in both)",
    "Common genes with opposite directions",
    "Common genes with uncertain direction",
    "Direction-consistent common genes",
    "Direction-consistent common genes (%)"
  ),
  Value = c(
    nrow(orig_raw),
    nrow(adj_raw),
    nrow(orig),
    nrow(adj),
    nrow(common_df),
    nrow(common_up),
    nrow(common_down),
    nrow(direction_opposite),
    nrow(direction_uncertain),
    direction_consistent_n,
    ifelse(is.na(direction_consistent_pct),
           NA, sprintf("%.2f", direction_consistent_pct))
  ),
  stringsAsFactors = FALSE
)

write.csv(
  summary_df,
  file.path(output_dir, "Common_DEG_direction_summary.csv"),
  row.names = FALSE
)

writeLines(
  c(
    "TCGA CRC qCSC common DEG direction consistency analysis",
    paste("Run time:", Sys.time()),
    paste("Original DEG file:", original_deg_file),
    paste("Adjusted DEG file:", adjusted_deg_file),
    paste("Output directory:", output_dir),
    "",
    "Summary:",
    capture.output(print(summary_df, row.names = FALSE)),
    "",
    "Interpretation note:",
    "Common UP/DOWN lists contain only genes with matching non-zero logFC signs in both models.",
    "These files are candidate inputs for a sensitivity/revised LINCS analysis; they do not replace the original analysis automatically."
  ),
  con = file.path(output_dir, "README_summary.txt")
)

writeLines(
  output_dir,
  file.path(estimate_dir, "Common_DEG_direction_check_LATEST.txt")
)

############################################################
############################################################

cat("
================ Analysis complete ================
")
print(summary_df, row.names = FALSE)
cat("
Result folder: 
", output_dir, "\n")
cat("
When building the signature, check in particular:
")
cat("1. Common_UP_genes_direction_consistent.csv\n")
cat("2. Common_DOWN_genes_direction_consistent.csv\n")
cat("3. Common_genes_opposite_directions.csv\n")
cat("4. Common_DEG_direction_summary.csv\n")
cat("
Note: this script only compares the direction of logFC and does not re-test DEG significance.
")
cat("==========================================\n")
