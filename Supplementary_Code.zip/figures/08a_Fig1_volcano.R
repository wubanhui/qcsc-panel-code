## ===========================================================================
## figures/08a_Fig1_volcano.R
## Figure 1A: volcano plot of the TCGA differential expression analysis.
## ===========================================================================
############################################################
############################################################

rm(list = ls())
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

options(stringsAsFactors = FALSE)

# ==========================================================
# ==========================================================
if (!requireNamespace("ggplot2", quietly = TRUE)) {
  stop("ggplot2 is not installed; run install.packages('ggplot2') first")
}

suppressPackageStartupMessages({
  library(ggplot2)
})

# ==========================================================
# ==========================================================
data_root <- DATA_ROOT

deg_file <- file.path(
  data_root,
  "TCGA_CRC_qCSC_DEG_GSVA",
  "DEG_ALL.csv"
)

if (!file.exists(deg_file)) {
  stop(
    "Differential expression result file not found:
", deg_file,
    "
Check that 01e_tcga_differential.R has completed successfully."
  )
}

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")

output_dir <- file.path(QCSC_PROJECT_DIR, "output",
  paste0("TCGA_CRC_qCSC_Volcano_", timestamp)
)

if (!dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)) {
  stop("Cannot create the output directory: ", output_dir)
}

cat("Input file: ", deg_file, "\n")
cat("Output directory: ", output_dir, "\n")

# ==========================================================
# ==========================================================
deg <- read.csv(
  deg_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

required_columns <- c(
  "Gene", "logFC", "P.Value", "adj.P.Val"
)

missing_columns <- setdiff(
  required_columns,
  colnames(deg)
)

if (length(missing_columns) > 0) {
  stop(
    "DEG_ALL.csv is missing the following columns: ",
    paste(missing_columns, collapse = ", ")
  )
}

deg$Gene <- trimws(as.character(deg$Gene))
deg$logFC <- suppressWarnings(as.numeric(deg$logFC))
deg$P.Value <- suppressWarnings(as.numeric(deg$P.Value))
deg$adj.P.Val <- suppressWarnings(as.numeric(deg$adj.P.Val))

deg <- deg[
  !is.na(deg$Gene) &
    deg$Gene != "" &
    is.finite(deg$logFC) &
    is.finite(deg$P.Value) &
    is.finite(deg$adj.P.Val),
  ,
  drop = FALSE
]

if (nrow(deg) == 0) {
  stop("No valid gene record remains for plotting after cleaning.")
}

# ==========================================================
# ==========================================================
FDR_CUTOFF <- 0.05
LOGFC_CUTOFF <- 0.5

deg$Group <- "Not significant"

deg$Group[
  deg$adj.P.Val < FDR_CUTOFF &
    deg$logFC >= LOGFC_CUTOFF
] <- "Upregulated"

deg$Group[
  deg$adj.P.Val < FDR_CUTOFF &
    deg$logFC <= -LOGFC_CUTOFF
] <- "Downregulated"

deg$Group <- factor(
  deg$Group,
  levels = c(
    "Downregulated",
    "Not significant",
    "Upregulated"
  )
)

deg$negLog10FDR <- -log10(
  pmax(deg$adj.P.Val, .Machine$double.xmin)
)

# ==========================================================
# ==========================================================
group_counts <- as.data.frame(
  table(deg$Group),
  stringsAsFactors = FALSE
)

colnames(group_counts) <- c("Group", "Gene_count")

write.csv(
  group_counts,
  file.path(output_dir, "volcano_group_counts.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  deg,
  file.path(output_dir, "volcano_all_genes.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

cat("
Volcano categories:
")
print(group_counts)

# ==========================================================
# ==========================================================
up_label <- deg[
  deg$Group == "Upregulated",
  ,
  drop = FALSE
]

down_label <- deg[
  deg$Group == "Downregulated",
  ,
  drop = FALSE
]

up_label <- up_label[
  order(up_label$adj.P.Val, -up_label$logFC),
  ,
  drop = FALSE
]

down_label <- down_label[
  order(down_label$adj.P.Val, down_label$logFC),
  ,
  drop = FALSE
]

label_data <- rbind(
  head(up_label, 10),
  head(down_label, 10)
)

# ==========================================================
# ==========================================================
p <- ggplot(
  deg,
  aes(x = logFC, y = negLog10FDR, colour = Group)
) +
  geom_point(
    size = 1.25,
    alpha = 0.70
  ) +
  geom_vline(
    xintercept = c(-LOGFC_CUTOFF, LOGFC_CUTOFF),
    linetype = "dashed",
    linewidth = 0.4,
    colour = "grey40"
  ) +
  geom_hline(
    yintercept = -log10(FDR_CUTOFF),
    linetype = "dashed",
    linewidth = 0.4,
    colour = "grey40"
  ) +
  scale_colour_manual(
    values = c(
      "Downregulated" = "#377EB8",
      "Not significant" = "#C9C9C9",
      "Upregulated" = "#D73027"
    ),
    drop = FALSE
  ) +
  labs(
    x = expression(log[2]~"fold change (High vs Low)"),
    y = expression(-log[10]~"FDR"),
    colour = NULL
  ) +
  theme_classic(base_size = 15) +
  theme(
    axis.title = element_text(
      size = 18,
      face = "plain",
      colour = "black"
    ),
    axis.text = element_text(
      size = 17,
      colour = "black"
    ),
    axis.line = element_line(
      linewidth = 0.45,
      colour = "black"
    ),
    axis.ticks = element_line(
      linewidth = 0.4,
      colour = "black"
    ),
    legend.position = "top", legend.justification = "center", 
    legend.text = element_text(size = 14),
    plot.margin = margin(8, 9, 8, 9)
  )

if (requireNamespace("ggrepel", quietly = TRUE) &&
    nrow(label_data) > 0) {
  
  p <- p +
    ggrepel::geom_text_repel(
      data = label_data,
      aes(label = Gene),
      size = 3,
      max.overlaps = Inf,
      box.padding = 0.35,
      point.padding = 0.2,
      min.segment.length = 0,
      show.legend = FALSE
    )
  
} else if (nrow(label_data) > 0) {
  message(
    "Note: ggrepel is not installed; the volcano plot is still produced but genes are not labelled.",
    "
To label genes, run install.packages('ggrepel') and re-run."
  )
}

print(p)

# ==========================================================
# ==========================================================
ggsave(
  filename = file.path(output_dir, "TCGA_CRC_qCSC_volcano.png"),
  plot = p,
  width = 7.2,
  height = 6,
  units = "in",
  dpi = 600,
  bg = "white"
)

ggsave(
  filename = file.path(output_dir, "TCGA_CRC_qCSC_volcano.pdf"),
  plot = p,
  width = 7.2,
  height = 6,
  units = "in",
  device = grDevices::cairo_pdf,
  bg = "white"
)

if (capabilities("cairo")) {
  ggsave(
    filename = file.path(output_dir, "TCGA_CRC_qCSC_volcano.pdf"),
    plot = p,
    width = 7.2,
    height = 6,
    units = "in",
    device = "pdf",
    bg = "white"
  )
}

# ==========================================================
# ==========================================================
parameters <- data.frame(
  Parameter = c(
    "Input DEG file",
    "Comparison",
    "FDR cutoff",
    "Absolute logFC cutoff",
    "Total plotted genes",
    "Upregulated genes",
    "Downregulated genes",
    "Not significant genes",
    "Output directory"
  ),
  Value = c(
    deg_file,
    "qCSC-High vs qCSC-Low",
    FDR_CUTOFF,
    LOGFC_CUTOFF,
    nrow(deg),
    sum(deg$Group == "Upregulated"),
    sum(deg$Group == "Downregulated"),
    sum(deg$Group == "Not significant"),
    output_dir
  ),
  stringsAsFactors = FALSE
)

write.csv(
  parameters,
  file.path(output_dir, "volcano_parameters.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

cat("\n============================================\n")
cat("Volcano plot complete.
")
cat("Total genes: ", nrow(deg), "\n")
cat("Up-regulated genes: ", sum(deg$Group == "Upregulated"), "\n")
cat("Down-regulated genes: ", sum(deg$Group == "Downregulated"), "\n")
cat("Non-significant genes: ", sum(deg$Group == "Not significant"), "\n")
cat("Output directory: ", output_dir, "\n")
cat("============================================\n")
scale_x_continuous(limits = c(-3.5, 3.5))