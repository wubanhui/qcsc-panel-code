## ===========================================================================
## singlecell_clinical/02e_malignant_integration.R
## Combine the CNV and expression classifiers into a single malignancy score.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
root <- ROOT_SC
out_dir <- QCSC_PROJECT_DIR
panel_dir <- PANEL_DIR
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
source(file.path(QCSC_PROJECT_DIR, "singlecell_clinical", "paths.R"))

## Integrated malignant-candidate classification for GSE188711 epithelial cells:
## (1) arm-level CNV classifier trained on GSE132465 tumour vs normal epithelium
## (2) tumour-vs-normal expression classifier trained on GSE132465
suppressPackageStartupMessages({
  library(ggplot2); library(patchwork); library(Seurat); library(SeuratObject)
})
tab_dir <- TAB_DIR; fig_dir <- FIG_DIR
dir.create(tab_dir, recursive=TRUE, showWarnings=FALSE); dir.create(fig_dir, recursive=TRUE, showWarnings=FALSE)

auc <- function(p,y) { w <- wilcox.test(p[y==1],p[y==0]); as.numeric(w$statistic)/(sum(y==1)*sum(y==0)) }

## ---- CNV classifier ----
a <- readRDS(file.path(out_dir,"cnv_gse132465.rds"))
s <- a$scores; arm <- a$arm_scores
ref <- arm[, s$Class=="Normal", drop=FALSE]
mu <- rowMeans(ref); sdv <- apply(ref,1,sd)
z <- t((arm - mu)/sdv)
y <- as.integer(s$Class=="Tumor")
df <- data.frame(y=y, z, check.names=FALSE)
set.seed(1); folds <- sample(rep(1:5,length.out=nrow(df))); pred <- rep(NA_real_,nrow(df))
for(k in 1:5){tr<-folds!=k; fit<-glm(y~.,data=df[tr,],family=binomial()); pred[!tr]<-predict(fit,newdata=df[!tr,],type="response")}
cat("CNV classifier CV AUC GSE132465:",auc(pred,y),"\n")
fit <- glm(y~.,data=df,family=binomial())

b <- readRDS(file.path(out_dir,"cnv_gse188711.rds"))
s2 <- b$scores; arm2 <- b$arm_scores
ref2 <- arm2[, s2$seurat_clusters=="5", drop=FALSE]
mu2 <- rowMeans(ref2); sd2 <- apply(ref2,1,sd)
z2 <- t((arm2 - mu2)/sd2); colnames(z2) <- colnames(z)
cnv_prob <- predict(fit,newdata=as.data.frame(z2),type="response")
cat("CNV prob cluster14 vs 5 AUC:",auc(cnv_prob, as.integer(s2$seurat_clusters=="14")),"\n")

## ---- expression malignancy classifier ----
mg <- readRDS(file.path(out_dir,"malignancy_gse132465.rds"))
m2 <- readRDS(file.path(out_dir,"malignancy_gse188711.rds"))
cat("expression classifier cluster14 vs 5 AUC:",
    auc(m2$score, as.integer(m2$meta$seurat_clusters=="14")),"\n")

## ---- combine ----
common_cells <- intersect(rownames(s2), rownames(m2$meta))
comb <- data.frame(
  cell=common_cells,
  cluster=as.character(s2[common_cells, "seurat_clusters"]),
  cnv_prob=as.numeric(cnv_prob[match(common_cells, rownames(s2))]),
  expr_mal=as.numeric(m2$score[match(common_cells, rownames(m2$meta))]),
  stringsAsFactors=FALSE
)
comb$cnv_z <- as.numeric(scale(comb$cnv_prob))
comb$expr_z <- as.numeric(scale(comb$expr_mal))
comb$combined <- rowMeans(comb[,c("cnv_z","expr_z")])
cat("combined AUC cluster14 vs 5:",
    auc(comb$combined, as.integer(comb$cluster=="14")),"\n")
write.csv(comb, file.path(tab_dir,"GSE188711_malignant_candidate_scores.csv"), row.names=FALSE)

summ <- data.frame(
  subset=c("cluster_14","cluster_5"),
  n_cells=c(sum(comb$cluster=="14"),sum(comb$cluster=="5")),
  cnv_prob_mean=c(mean(comb$cnv_prob[comb$cluster=="14"]),mean(comb$cnv_prob[comb$cluster=="5"])),
  expr_mal_mean=c(mean(comb$expr_mal[comb$cluster=="14"]),mean(comb$expr_mal[comb$cluster=="5"])),
  combined_mean=c(mean(comb$combined[comb$cluster=="14"]),mean(comb$combined[comb$cluster=="5"])),
  cnv_auc=c(auc(comb$cnv_prob,as.integer(comb$cluster=="14")),NA),
  expr_auc=c(auc(comb$expr_mal,as.integer(comb$cluster=="14")),NA),
  combined_auc=c(auc(comb$combined,as.integer(comb$cluster=="14")),NA)
)
write.csv(summ, file.path(tab_dir,"GSE188711_malignant_candidate_summary.csv"), row.names=FALSE)
print(summ, row.names=FALSE)

## ---- figures ----
p1 <- ggplot(comb, aes(cluster,cnv_prob,fill=cluster)) + geom_boxplot(outlier.shape=NA,width=.55) +
  geom_jitter(width=.12,size=.3,alpha=.25) + scale_fill_manual(values=c("#5DADE2","#C0392B")) +
  labs(x=NULL,y="CNV classifier probability",title="A  Arm-level CNV classifier") +
  theme_classic(base_size=11) + theme(legend.position="none",plot.title=element_text(face="bold"))
p2 <- ggplot(comb, aes(cluster,expr_mal,fill=cluster)) + geom_boxplot(outlier.shape=NA,width=.55) +
  geom_jitter(width=.12,size=.3,alpha=.25) + scale_fill_manual(values=c("#5DADE2","#C0392B")) +
  labs(x=NULL,y="Tumour-normal expression score",title="B  Expression malignancy classifier") +
  theme_classic(base_size=11) + theme(legend.position="none",plot.title=element_text(face="bold"))
p3 <- ggplot(comb, aes(cluster,combined,fill=cluster)) + geom_boxplot(outlier.shape=NA,width=.55) +
  geom_jitter(width=.12,size=.3,alpha=.25) + scale_fill_manual(values=c("#5DADE2","#C0392B")) +
  labs(x=NULL,y="Combined malignant-candidate score",title="C  Combined score") +
  theme_classic(base_size=11) + theme(legend.position="none",plot.title=element_text(face="bold"))
p <- p1|p2|p3
ggsave(file.path(fig_dir,"Fig8_GSE188711_malignant_classifiers.png"),p,width=12,height=4.5,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig8_GSE188711_malignant_classifiers.pdf"),p,width=12,height=4.5,bg="white")

## UMAP
obj <- readRDS(find_gse188_clustered(root))
obj <- subset(obj, cells=comb$cell)
obj$cnv_prob <- comb$cnv_prob[match(colnames(obj),comb$cell)]
obj$expr_mal <- comb$expr_mal[match(colnames(obj),comb$cell)]
obj$combined <- comb$combined[match(colnames(obj),comb$cell)]
p4 <- FeaturePlot(obj,features="cnv_prob",reduction="umap",pt.size=.5) +
  scale_color_gradientn(colors=c("#2166AC","grey90","#B2182B")) + ggtitle("D  CNV probability") +
  theme(plot.title=element_text(face="bold",size=11))
p5 <- FeaturePlot(obj,features="combined",reduction="umap",pt.size=.5) +
  scale_color_gradientn(colors=c("#2166AC","grey90","#B2182B")) + ggtitle("E  Combined score") +
  theme(plot.title=element_text(face="bold",size=11))
p6 <- DimPlot(obj,reduction="umap",group.by="seurat_clusters",label=TRUE,pt.size=.5) +
  ggtitle("F  Epithelial clusters") + theme(plot.title=element_text(face="bold",size=11))
p_umap <- p4|p5|p6
ggsave(file.path(fig_dir,"Fig9_GSE188711_malignant_UMAP.png"),p_umap,width=15,height=5,dpi=300,bg="white")
ggsave(file.path(fig_dir,"Fig9_GSE188711_malignant_UMAP.pdf"),p_umap,width=15,height=5,bg="white")
saveRDS(list(comb=comb, summ=summ, fit=fit), file.path(out_dir,"malignant_classification.rds"))
cat("saved\n")
