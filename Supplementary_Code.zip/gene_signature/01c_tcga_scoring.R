## ===========================================================================
## gene_signature/01c_tcga_scoring.R
##
## ssGSEA scoring of the 290 signature genes in TCGA and median split of the
## 380 tumours into high and low groups (190 / 190).
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))

############################################################
# CRC-qCSC: TCGA-COAD/READ scoring with GSVA ssGSEA
# Corrected, reproducible version
#
# Main settings:
#   - GSVA::ssgseaParam() + GSVA::gsva()
#   - alpha = 0.25
#   - normalize = TRUE
#   - Full available expression matrix is passed as ranking background.
#   - FILTER_ZERO_VAR = FALSE by default; GSVA internally filters genes
#     with constant expression before scoring.
#   - Median score cutoff; ties at the median are assigned to High.
#   - Timestamped output folder to avoid overwriting previous results.
#
# Important:
#   This script expects rownames(expr_crc) to be human Gene Symbols.
#   It normalizes SYMBOL letter case to uppercase. If this creates duplicate
#   identifiers, it stops rather than silently combining rows.
############################################################

suppressPackageStartupMessages({
  if (!requireNamespace("GSVA", quietly = TRUE)) {
    stop("Package 'GSVA' is required. Install it using BiocManager::install('GSVA').")
  }
  library(GSVA)
})

options(stringsAsFactors = FALSE)

# ------------------------------------------------------------
# 0. Paths and parameters
# ------------------------------------------------------------
data_dir <- DATA_ROOT
output_root <- GSVA_DIR
dir.create(output_root, recursive = TRUE, showWarnings = FALSE)

# Use a new timestamped run folder to preserve previous outputs.
run_stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
out_dir <- file.path(output_root, paste0("run_", run_stamp))
if (dir.exists(out_dir)) {
  suffix <- 1L
  repeat {
    candidate <- file.path(output_root, paste0("run_", run_stamp, "_", suffix))
    if (!dir.exists(candidate)) {
      out_dir <- candidate
      break
    }
    suffix <- suffix + 1L
  }
}
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

rdata_file <- file.path(data_dir, "TCGA_CRC_380_samples.RData")

sig_dir_override <- NA_character_

if (!is.na(sig_dir_override)) {
  sig_dir <- sig_dir_override
} else {
  sig_pointer <- file.path(
    data_dir,
    "CRC_qCSC_signature_publication_LATEST.txt"
  )

  if (file.exists(sig_pointer)) {
    sig_dir <- sub(
      "^\ufeff",
      "",
      trimws(readLines(sig_pointer, warn = FALSE)[1])
    )
  } else {
    sig_dir <- NA_character_
  }

  if (is.na(sig_dir) || !dir.exists(sig_dir) ||
      !file.exists(file.path(
        sig_dir,
        "CRC_qCSC_final_protein_coding_gene_signature.txt"
      ))) {
    sig_candidates <- list.dirs(
      data_dir,
      recursive = FALSE,
      full.names = TRUE
    )
    sig_candidates <- sig_candidates[
      grepl(
        "^CRC_qCSC_signature_publication_",
        basename(sig_candidates)
      )
    ]
    sig_candidates <- sig_candidates[
      file.exists(file.path(
        sig_candidates,
        "CRC_qCSC_final_protein_coding_gene_signature.txt"
      ))
    ]

    if (length(sig_candidates) == 0) {
      stop(
        "No directory containing CRC_qCSC_final_protein_coding_gene_signature.txt was found: ",
        "CRC_qCSC_signature_publication_* directory.
",
        "Please run 01g_symbol_and_biotype_filter.R first."
      )
    }

    sig_dir <- sig_candidates[
      which.max(
        file.info(file.path(
          sig_candidates,
          "CRC_qCSC_final_protein_coding_gene_signature.txt"
        ))$mtime
      )
    ]
  }
}

sig_file <- file.path(
  sig_dir,
  "CRC_qCSC_final_protein_coding_gene_signature.txt"
)
old_score_file <- file.path(
  data_dir,
  "TCGA_qCSC_score_check",
  "TCGA_CRC_qCSC_ssGSEA_final_scores.csv"
)

ALPHA <- 0.25
NORMALIZE <- TRUE
# FALSE passes the full expression matrix to GSVA. GSVA itself discards
# genes with constant expression during preprocessing. Set TRUE only when
# you explicitly want to remove constant genes before GSVA as well.
FILTER_ZERO_VAR <- FALSE

for (f in c(rdata_file, sig_file)) {
  if (!file.exists(f)) stop("Required input file not found: ", f)
}

log_lines <- character(0)
say <- function(...) {
  msg <- paste0(...)
  cat(msg, "\n", sep = "")
  log_lines <<- c(log_lines, msg)
}

say("============================================================")
say("CRC-qCSC TCGA ssGSEA scoring using GSVA")
say("GSVA version: ", as.character(utils::packageVersion("GSVA")))
say("Output directory: ", out_dir)
say("============================================================")

# ------------------------------------------------------------
# 1. Load and validate expression matrix
# ------------------------------------------------------------
data_env <- new.env(parent = globalenv())
loaded_objects <- load(rdata_file, envir = data_env)

if (!exists("expr_crc", envir = data_env, inherits = FALSE)) {
  stop(
    "Object 'expr_crc' was not found in ", rdata_file,
    ". Objects loaded: ", paste(loaded_objects, collapse = ", ")
  )
}

expr <- as.matrix(get("expr_crc", envir = data_env, inherits = FALSE))
if (is.null(rownames(expr)) || is.null(colnames(expr))) {
  stop("Expression matrix must have gene identifiers as rownames and sample IDs as colnames.")
}
if (nrow(expr) < 2L || ncol(expr) < 2L) {
  stop("Expression matrix has insufficient rows or columns.")
}

storage.mode(expr) <- "double"
if (any(!is.finite(expr))) {
  stop("Expression matrix contains NA/NaN/Inf or non-numeric values after conversion.")
}

# Normalize sample IDs and gene symbols.
colnames(expr) <- trimws(as.character(colnames(expr)))
if (anyNA(colnames(expr)) || any(!nzchar(colnames(expr)))) {
  stop("Expression matrix contains missing or blank sample IDs.")
}
if (anyDuplicated(colnames(expr))) {
  stop("Duplicated sample IDs in the expression matrix after trimming whitespace.")
}

rownames(expr) <- toupper(trimws(as.character(rownames(expr))))
if (anyNA(rownames(expr)) || any(!nzchar(rownames(expr)))) {
  stop("Expression matrix contains missing or blank gene identifiers.")
}
if (anyDuplicated(rownames(expr))) {
  dup <- unique(rownames(expr)[duplicated(rownames(expr))])
  stop(
    "Duplicated gene identifiers after SYMBOL case normalization. Resolve these first; examples: ",
    paste(head(dup, 10L), collapse = ", ")
  )
}

say("Input expression matrix: ", nrow(expr), " genes x ", ncol(expr), " samples")

# Record the full gene universe and identify constant genes. By default, the
# complete matrix is passed to GSVA; the current GSVA implementation filters
# constant-expression genes internally. Optional manual filtering is available
# but should only be enabled intentionally.
n_genes_before_filter <- nrow(expr)
expr_gene_ids_original <- rownames(expr)
row_variance <- apply(expr, 1L, stats::var)
constant_gene <- is.finite(row_variance) & row_variance == 0
constant_gene_ids <- rownames(expr)[constant_gene]
say("Genes with constant expression across all samples: ", sum(constant_gene))

if (FILTER_ZERO_VAR) {
  expr <- expr[!constant_gene, , drop = FALSE]
  say("Manual zero-variance filtering enabled; genes retained: ", nrow(expr))
} else {
  say("Manual zero-variance filtering disabled; full matrix passed to GSVA.")
  say("GSVA internally filters genes with constant expression during scoring.")
}

if (nrow(expr) < 2L) stop("Too few genes remain for ssGSEA scoring.")

# ------------------------------------------------------------
# 2. Read final qCSC signature and check identifier matching
# ------------------------------------------------------------
sig_raw <- readLines(sig_file, warn = FALSE, encoding = "UTF-8")
sig <- toupper(trimws(sig_raw))
sig <- sig[!is.na(sig) & nzchar(sig)]
sig <- unique(sig)

signature_total <- length(sig)


matched_input <- intersect(sig, expr_gene_ids_original)
unmatched <- setdiff(sig, expr_gene_ids_original)
matched_for_gsva <- intersect(sig, rownames(expr))
matching_rate <- 100 * length(matched_input) / length(sig)
matched_constant <- intersect(matched_input, constant_gene_ids)
effective_signature_genes <- setdiff(matched_input, matched_constant)

say("Signature genes (unique): ", signature_total)
say("Signature genes matching original expression rownames: ", length(matched_input),
    " (", sprintf("%.1f", matching_rate), "%)")
say("Signature genes passed to GSVA after optional manual filtering: ", length(matched_for_gsva))
say("Matched signature genes with constant expression: ", length(matched_constant))
say("Potentially scoreable matched signature genes: ", length(effective_signature_genes))
say("Unmatched signature genes: ", length(unmatched))
if (length(unmatched)) say("Unmatched: ", paste(unmatched, collapse = ", "))

if (length(matched_input) == 0L) {
  stop("No signature genes matched the expression matrix. Confirm that rownames are Gene Symbols.")
}
if (length(effective_signature_genes) == 0L) {
  stop("All matched signature genes have constant expression; ssGSEA score cannot be calculated meaningfully.")
}
if (matching_rate < 70) {
  warning("Less than 70% of the signature matched the expression matrix. Confirm gene-ID type and mapping.")
}

matching_table <- data.frame(
  Gene = sig,
  Matched_to_original_expression = sig %in% expr_gene_ids_original,
  Constant_expression = sig %in% constant_gene_ids,
  Effective_for_scoring = sig %in% effective_signature_genes,
  Passed_to_GSVA = sig %in% matched_for_gsva,
  stringsAsFactors = FALSE
)
write.csv(
  matching_table,
  file.path(out_dir, "CRC_qCSC_signature_gene_matching.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
writeLines(matched_input, file.path(out_dir, "CRC_qCSC_signature_matched_genes.txt"), useBytes = TRUE)
writeLines(effective_signature_genes, file.path(out_dir, "CRC_qCSC_signature_effective_for_scoring.txt"), useBytes = TRUE)
writeLines(unmatched, file.path(out_dir, "CRC_qCSC_signature_unmatched_genes.txt"), useBytes = TRUE)

# ------------------------------------------------------------
# 3. Run standard ssGSEA implementation from GSVA
# ------------------------------------------------------------
gene_sets <- list(CRC_qCSC = matched_for_gsva)

param <- GSVA::ssgseaParam(
  exprData = expr,
  geneSets = gene_sets,
  alpha = ALPHA,
  normalize = NORMALIZE
)

say("Scoring settings: alpha = ", ALPHA, "; normalize = ", NORMALIZE)
say("Running GSVA::gsva() ...")
t0 <- Sys.time()
score_mat <- GSVA::gsva(param, verbose = FALSE)
elapsed_seconds <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
say("ssGSEA completed in ", sprintf("%.1f", elapsed_seconds), " seconds")

if (!"CRC_qCSC" %in% rownames(score_mat)) {
  stop("Expected gene-set row 'CRC_qCSC' was not found in the GSVA score matrix.")
}
if (is.null(colnames(score_mat)) || !all(colnames(expr) %in% colnames(score_mat))) {
  stop("GSVA output sample names do not match the input expression matrix.")
}

scores <- as.numeric(score_mat["CRC_qCSC", colnames(expr)])
names(scores) <- colnames(expr)
if (any(!is.finite(scores))) {
  stop("Non-finite ssGSEA scores detected.")
}
if (length(unique(scores)) < 2L) {
  stop("All ssGSEA scores are identical; median splitting is not informative.")
}

score_min <- min(scores)
score_max <- max(scores)
score_mean <- mean(scores)
score_median <- median(scores)
score_sd <- stats::sd(scores)

say(sprintf("Score range: %.6f .. %.6f", score_min, score_max))
say(sprintf("Score median: %.6f", score_median))
say(sprintf("Score mean (SD): %.6f (%.6f)", score_mean, score_sd))

# ------------------------------------------------------------
# 4. Median-based grouping
# ------------------------------------------------------------
score_df <- data.frame(
  sampleID = names(scores),
  qCSC_score = unname(as.numeric(scores)),
  qCSC_group = ifelse(scores >= score_median, "High", "Low"),
  stringsAsFactors = FALSE
)

qCSC_score <- scores
qCSC_group <- stats::setNames(as.character(score_df$qCSC_group), score_df$sampleID)

n_high <- sum(score_df$qCSC_group == "High")
n_low <- sum(score_df$qCSC_group == "Low")
if (n_high == 0L || n_low == 0L) {
  stop("Median split did not produce both High and Low groups. Check score distribution.")
}

say("Median cutoff: ", sprintf("%.6f", score_median))
say("Groups: High ", n_high, " / Low ", n_low)
if (n_high != n_low) {
  say("Note: group sizes are not equal, which can occur when scores tie at the median.")
}

score_csv <- file.path(out_dir, "TCGA_CRC_qCSC_GSVA_ssGSEA_scores.csv")
write.csv(score_df, score_csv, row.names = FALSE, fileEncoding = "UTF-8")

canonical_score_csv <- file.path(
  output_root,
  "TCGA_CRC_qCSC_GSVA_ssGSEA_scores.csv"
)

if (!file.copy(
  score_csv,
  canonical_score_csv,
  overwrite = TRUE
)) {
  stop(
    "Cannot update the fixed score file read downstream:
",
    canonical_score_csv,
    "
Please check whether the file is locked by another program such as Excel."
  )
}

writeLines(out_dir, file.path(output_root, "LATEST_RUN.txt"))
say("Canonical score CSV updated: ", canonical_score_csv)

# ------------------------------------------------------------
# 5. Compare with the earlier custom score (if available)
# ------------------------------------------------------------
comparison_csv <- file.path(out_dir, "TCGA_CRC_qCSC_GSVA_vs_old_comparison.csv")
comparison_written <- FALSE

safe_cor <- function(x, y, method = "pearson") {
  if (length(x) < 2L || length(y) < 2L ||
      !all(is.finite(x)) || !all(is.finite(y)) ||
      stats::sd(x) == 0 || stats::sd(y) == 0) {
    return(NA_real_)
  }
  suppressWarnings(stats::cor(x, y, method = method))
}

if (file.exists(old_score_file)) {
  say("Comparing with previous custom score file: ", old_score_file)
  old <- read.csv(old_score_file, stringsAsFactors = FALSE, check.names = FALSE)
  
  if (!all(c("sampleID", "qCSC_score") %in% colnames(old))) {
    warning("Old score file does not contain sampleID and qCSC_score; comparison skipped.")
  } else {
    old$sampleID <- trimws(as.character(old$sampleID))
    old$qCSC_score <- suppressWarnings(as.numeric(old$qCSC_score))
    
    if (anyDuplicated(old$sampleID[!is.na(old$sampleID) & nzchar(old$sampleID)])) {
      warning("Duplicate sample IDs found in old score file; comparison skipped.")
    } else {
      old <- old[!is.na(old$sampleID) & nzchar(old$sampleID) & is.finite(old$qCSC_score), , drop = FALSE]
      common <- names(scores)[names(scores) %in% old$sampleID]
      
      if (length(common) > 50L) {
        a <- unname(scores[common])
        b <- old$qCSC_score[match(common, old$sampleID)]
        valid <- is.finite(a) & is.finite(b)
        a <- a[valid]
        b <- b[valid]
        
        old_group <- ifelse(b >= stats::median(b), "High", "Low")
        new_group <- ifelse(a >= stats::median(a), "High", "Low")
        pearson_r <- safe_cor(a, b, "pearson")
        spearman_r <- safe_cor(a, b, "spearman")
        agreement <- 100 * mean(old_group == new_group)
        changed <- sum(old_group != new_group)
        
        cmp <- data.frame(
          Metric = c(
            "n_common_samples", "Pearson_correlation", "Spearman_correlation",
            "median_split_agreement_percent", "n_group_changed",
            "old_score_min", "old_score_max", "new_score_min", "new_score_max"
          ),
          Value = c(
            length(a), pearson_r, spearman_r, agreement, changed,
            min(b), max(b), min(a), max(a)
          ),
          stringsAsFactors = FALSE
        )
        write.csv(cmp, comparison_csv, row.names = FALSE, fileEncoding = "UTF-8")
        comparison_written <- TRUE
        print(cmp, row.names = FALSE)
        
        say(sprintf(
          "Old/new score comparison: Pearson = %s; Spearman = %s; group agreement = %.1f%% (%d changed of %d paired samples)",
          ifelse(is.finite(pearson_r), sprintf("%.4f", pearson_r), "NA"),
          ifelse(is.finite(spearman_r), sprintf("%.4f", spearman_r), "NA"),
          agreement, changed, length(a)
        ))
      } else {
        warning("Fewer than 51 common samples; old/new score comparison skipped.")
      }
    }
  }
} else {
  say("No old score file found; old/new comparison skipped.")
}

if (!comparison_written) {
  write.csv(
    data.frame(
      Metric = "status",
      Value = "Comparison not performed; see run_log.txt for reason.",
      stringsAsFactors = FALSE
    ),
    comparison_csv,
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )
}

# ------------------------------------------------------------
# 6. Save reusable data objects
# ------------------------------------------------------------
rdata_out <- file.path(out_dir, "TCGA_CRC_qCSC_GSVA_scores.RData")
score_rds <- file.path(out_dir, "TCGA_CRC_qCSC_GSVA_scores.rds")
save(
  qCSC_score,
  qCSC_group,
  score_df,
  sig,
  matched_input,
  matched_for_gsva,
  unmatched,
  matched_constant,
  effective_signature_genes,
  ALPHA,
  NORMALIZE,
  FILTER_ZERO_VAR,
  rdata_file,
  sig_file,
  out_dir,
  file = rdata_out
)
saveRDS(qCSC_score, score_rds)

# ------------------------------------------------------------
# 7. Write summary and session information
# ------------------------------------------------------------
summary_lines <- c(
  "CRC-qCSC TCGA scoring using GSVA ssGSEA",
  "========================================",
  "",
  paste0("Date/time: ", as.character(Sys.time())),
  paste0("GSVA version: ", as.character(utils::packageVersion("GSVA"))),
  paste0("Input expression RData: ", rdata_file),
  paste0("Input signature: ", sig_file),
  paste0("Output directory: ", out_dir),
  paste0("Canonical score CSV updated: ", canonical_score_csv),
  paste0("Latest run pointer: ", file.path(output_root, "LATEST_RUN.txt")),
  "",
  paste0("Genes in original expression matrix: ", n_genes_before_filter),
  paste0("Genes passed to GSVA: ", nrow(expr)),
  paste0("Input samples: ", ncol(expr)),
  paste0("Unique signature genes: ", signature_total),
  paste0("Signature genes matched to original expression rownames: ", length(matched_input)),
  paste0("Signature genes passed to GSVA after optional manual filtering: ", length(matched_for_gsva)),
  paste0("Matched signature genes with constant expression: ", length(matched_constant)),
  paste0("Potentially scoreable matched signature genes: ", length(effective_signature_genes)),
  paste0("Unmatched signature genes: ", length(unmatched)),
  paste0("Manual zero-variance filtering: ", FILTER_ZERO_VAR),
  "GSVA internally filters genes with constant expression during scoring.",
  "",
  paste0("Method: GSVA::ssgseaParam() + GSVA::gsva()"),
  paste0("alpha: ", ALPHA),
  paste0("normalize: ", NORMALIZE),
  "Ranking background: full expression matrix passed to GSVA (unless manual filtering is enabled).",
  "Gene identifiers: Gene Symbols normalized to uppercase; duplicate symbols cause the script to stop.",
  "High/Low cutoff: median of the ssGSEA scores; scores >= median assigned to High.",
  "",
  paste0("Score min: ", sprintf("%.8f", score_min)),
  paste0("Score max: ", sprintf("%.8f", score_max)),
  paste0("Score mean: ", sprintf("%.8f", score_mean)),
  paste0("Score median: ", sprintf("%.8f", score_median)),
  paste0("Score SD: ", sprintf("%.8f", score_sd)),
  paste0("High samples: ", n_high),
  paste0("Low samples: ", n_low),
  "",
  "Interpretation: scores quantify relative enrichment of the qCSC signature in each sample.",
  "They do not directly measure qCSC abundance, quiescence, or stem-cell function.",
  "",
  "Please cite the GSVA package and the original ssGSEA method in the manuscript."
)
writeLines(summary_lines, file.path(out_dir, "TCGA_CRC_qCSC_GSVA_summary.txt"), useBytes = TRUE)
writeLines(log_lines, file.path(out_dir, "run_log.txt"), useBytes = TRUE)
writeLines(capture.output(utils::sessionInfo()), file.path(out_dir, "sessionInfo.txt"), useBytes = TRUE)

# ------------------------------------------------------------
# 8. Final console report
# ------------------------------------------------------------
cat("\n============================================================\n")
cat("GSVA ssGSEA scoring completed\n")
cat("============================================================\n")
cat("Samples: ", ncol(expr), "\n", sep = "")
cat("Genes passed to GSVA: ", nrow(expr), "\n", sep = "")
cat("Signature genes: ", signature_total, "\n", sep = "")
cat("Matched genes in original matrix: ", length(matched_input), "\n", sep = "")
cat("Matched genes passed to GSVA: ", length(matched_for_gsva), "\n", sep = "")
cat("Potentially scoreable matched genes: ", length(effective_signature_genes), "\n", sep = "")
cat("High / Low: ", n_high, " / ", n_low, "\n", sep = "")
cat("Score range: ", sprintf("%.6f", score_min), " .. ", sprintf("%.6f", score_max), "\n", sep = "")
cat("Output directory: ", out_dir, "\n", sep = "")
cat("Score CSV: ", score_csv, "\n", sep = "")
cat("Canonical score CSV: ", canonical_score_csv, "\n", sep = "")
cat("RData: ", rdata_out, "\n", sep = "")
cat("Summary: ", file.path(out_dir, "TCGA_CRC_qCSC_GSVA_summary.txt"), "\n", sep = "")
cat("============================================================\n")
