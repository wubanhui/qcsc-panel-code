## ===========================================================================
## singlecell_clinical/03e_auc_sweep.R
##
## Explicit-threshold variant of the panel-versus-full discrimination analysis:
## AUC, precision and recall of the panel against the top decile of the full
## axis, plus cross-decile agreement and the correlation after removing the
## top 5% of the full-axis cells.
## ===========================================================================
## ---------------------------------------------------------------------------
## Locate the package root (the folder that contains 00_config.R) and load all
## paths from it, so that the script can be launched from any working directory.
## ---------------------------------------------------------------------------
.find_pkg_root <- function() {
  r <- Sys.getenv("QCSC_PROJECT_DIR", unset = NA_character_)
  if (!is.na(r) && nzchar(r) && file.exists(file.path(r, "00_config.R"))) {
    return(normalizePath(r))
  }
  d <- normalizePath(getwd())
  for (i in seq_len(8)) {
    if (file.exists(file.path(d, "00_config.R"))) return(d)
    nd <- dirname(d)
    if (identical(nd, d)) break
    d <- nd
  }
  stop("Cannot locate the package root (the folder containing 00_config.R).")
}
QCSC_PROJECT_DIR <- .find_pkg_root()
source(file.path(QCSC_PROJECT_DIR, "00_config.R"))
## ============================================================
options(stringsAsFactors = FALSE)
project <- QCSC_PROJECT_DIR
d  <- readRDS(file.path(project, "intermediate", "two_cohort_panel", "panel_data.rds"))
fr <- read.csv(file.path(project, "tables", "panel_stability_frequency.csv"))
UP <- fr$gene[fr$frequency >= 0.5 & fr$direction == "UP"]
DN <- fr$gene[fr$frequency >= 0.5 & fr$direction == "DOWN"]

pair <- function(E) data.frame(
  full  = colMeans(E[d$up_use, , drop = FALSE]) - colMeans(E[d$down_use, , drop = FALSE]),
  panel = colMeans(E[UP, , drop = FALSE])       - colMeans(E[DN, , drop = FALSE]))
p1 <- pair(d$E1); p2 <- pair(d$E2)

strip_auc <- function(labels, score) {          # labels: 1 = full top 10%
  pos <- score[labels == 1]; neg <- score[labels == 0]
  mean(outer(pos, neg, '>')) + 0.5 * mean(outer(pos, neg, '=='))
}

sweep <- function(df, cohort) {
  hit <- df$full >= quantile(df$full, 0.9)
  data.frame(cohort = cohort,
             rule   = "panel threshold at its own top 10%",
             auc    = strip_auc(hit, df$panel),
             precision = mean(hit[df$panel >= quantile(df$panel, 0.9)]),
             recall    = sum(hit[df$panel >= quantile(df$panel, 0.9)]) / sum(hit))
}

out <- rbind(sweep(p1, "GSE132465"), sweep(p2, "GSE188711"))
write.csv(out, file.path(project, "tables", "panel_discrimination_102030.csv"), row.names = FALSE)
print(out, row.names = FALSE)

cat("\n(expected by construction) P(panel_hi > full_hi) =",
    mean(outer(p1$panel[p1$full >= quantile(p1$full, 0.9)],
               p1$full[p1$full >= quantile(p1$full, 0.9)], ">")), "because the panel is a linear shift of the full axis\n")
